# Shared Movement Detection — Per Player
# Reads Pos[0], Pos[1], Pos[2] once, sets ec.moving for all consumers
# Scale 10 for sub-block precision (detects 0.1 block movement)
# Also caches integer X/Y/Z in ec.pos_x/y/z for housing/guild zone checks (OPT: avoids 6+ duplicate Pos[] reads)

execute store result score #mx ec.temp store result score @s ec.pos_x run data get entity @s Pos[0] 10
execute store result score @s ec.pos_y run data get entity @s Pos[1]
execute store result score #mz ec.temp store result score @s ec.pos_z run data get entity @s Pos[2] 10
# Downscale cached pos to block-level for zone checks (÷10)
scoreboard players operation @s ec.pos_x /= #10 ec.const
scoreboard players operation @s ec.pos_z /= #10 ec.const

# On movement detected, set counter to 5 (persists 5 seconds after last movement)
execute unless score #mx ec.temp = @s ec.move_lastx run scoreboard players set @s ec.moving 5
execute unless score #mz ec.temp = @s ec.move_lastz run scoreboard players set @s ec.moving 5
scoreboard players operation @s ec.move_lastx = #mx ec.temp
scoreboard players operation @s ec.move_lastz = #mz ec.temp

# Decay movement counter by 1 per second (0 = fully stopped)
execute if score @s ec.moving matches 1.. run scoreboard players remove @s ec.moving 1
