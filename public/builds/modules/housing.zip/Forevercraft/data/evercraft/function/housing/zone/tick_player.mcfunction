# Housing Zone — Per-player tick (zone check + visitor detection)
# OPT: Consolidates 2 @a[scores={hs.tier=1..}] at @s scans into 1
function evercraft:housing/zone/check
function evercraft:housing/zone/visitor_check
