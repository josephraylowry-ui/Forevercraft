# Page 3 click detection — Prestige info [?] button
# Run as the player with menu open

# Single [?] button — opens chat class selector for prestige ability details
execute as @e[type=interaction,tag=Adv.PrestigeInfoClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run function evercraft:advantage/gui/show_prestige_selector
