# Handle crate title click — run as the interaction entity
# Macro arg: id

# Clear interaction data so click doesn't repeat
data remove entity @s interaction

# Capture session for multiplayer-safe owner lookup
scoreboard players operation #gui_click_sess ec.temp = @s adv.gui_session

# Route to the nearest menu player
$execute as @a[tag=Adv.InMenu,distance=..10] if score @s adv.gui_session = #gui_click_sess ec.temp run function evercraft:advantage/gui/do_crate_title {id:$(id)}
