# Party Trigger Handler — Negative values (decline invite)
# OPT: Consolidates 3 @a scans into 1

function evercraft:party/invite/decline
scoreboard players enable @s ec.party
scoreboard players set @s ec.party 0
