# Party System — 1s Tick Schedule
# Handles: proximity detection, buff application, combo checks, cooldowns, leader timeout

schedule function evercraft:party/tick 1s

# Gate: skip logic if no players online
execute unless entity @a run return 0

# === CORE PARTY MEMBER TICK ===
# OPT: Consolidates 6 @a[scores={ec.party_id=1..}] scans into 1
# Handles: proximity, buffs, combos, cooldowns, sidebar update
execute if entity @a[scores={ec.party_id=1..}] run scoreboard players reset * ec.party_hp
execute as @a[scores={ec.party_id=1..}] at @s run function evercraft:party/member_tick

# === SNEAK INVITE (sneak + empty hand + look at player to invite) ===
# Only runs when a party leader is actively sneaking with empty hand and off cooldown
# OPT: Replaced NBT read (unless data entity @s SelectedItem) with item predicate
execute as @a[scores={ec.party_role=1,ec.party_size=..3},predicate=evercraft:is_sneaking] unless items entity @s weapon.mainhand * unless score @s ec.party_inv_cd matches 1.. at @s anchored eyes positioned ^ ^ ^0.5 run function evercraft:party/invite/sneak_init

# === PING MARKER CLEANUP ===
# Emit beacon particles from active ping markers, kill expired ones
execute store result score #now ec.temp run time query gametime
execute as @e[type=marker,tag=ec.party_ping] at @s if score #now ec.temp >= @s ec.temp run kill @s
execute as @e[type=marker,tag=ec.party_ping] at @s run particle minecraft:end_rod ~ ~1 ~ 0.3 1 0.3 0.02 5 force

# === INVITE TIMEOUT ===
# Cancel expired invites (cooldown decrement moved to tick_cooldowns)
execute as @a[scores={ec.party_inv=1,ec.party_inv_cd=..0}] run function evercraft:party/invite/timeout

# === LEADER DISCONNECT DETECTION ===
execute as @a[scores={ec.party_role=1}] run scoreboard players set @s ec.party_ldr_dc 0
function evercraft:party/check_leader

# === OFFLINE MEMBER DETECTION (10 min timeout) ===
function evercraft:party/check_offline

# === PARTY TRIGGER HANDLER ===
# OPT: 12 @a scans → 2 (positive + negative) with internal routing
execute as @a[scores={ec.party=1..}] at @s run function evercraft:party/trigger_handler
execute as @a[scores={ec.party=..-1}] at @s run function evercraft:party/trigger_handler_neg

# === CLEANUP (no per-tick setdisplay needed — display slots set permanently in load) ===
execute unless entity @a[scores={ec.party_id=1..}] run function evercraft:party/sidebar/hide_sidebar
