# Party Trigger Handler — Positive values (run as @s at @s, score 1+)
# OPT: Consolidates 9 @a scans into 1 with internal routing

# 1 = open menu, 2 = create party, 3 = invite nearby, 4 = disband
# 5 = ping, 6 = leave, 10+ = accept invite from party ID
execute if score @s ec.party matches 1 run function evercraft:party/menu/open
execute if score @s ec.party matches 2 run function evercraft:party/menu/create
execute if score @s ec.party matches 3 run function evercraft:party/invite/scan
execute if score @s ec.party matches 4 run function evercraft:party/menu/disband
execute if score @s ec.party matches 5 run function evercraft:party/ping
execute if score @s ec.party matches 6 run function evercraft:party/menu/leave
execute if score @s ec.party matches 10.. run function evercraft:party/invite/accept

# Reset and re-enable
scoreboard players enable @s ec.party
scoreboard players set @s ec.party 0
