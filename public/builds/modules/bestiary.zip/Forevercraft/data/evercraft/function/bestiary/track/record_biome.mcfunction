# Bestiary — Record Biome (Macro)
# Args: {mob:"blaze"} — reads ec.biome_id from scoreboard
# Run as the player
# Biome tracking is display-only — stored in storage per player UUID
# For simplicity, we record biome names as a string list in storage
# (bitfield approach would require per-mob scoreboards which is too many)

# Get biome ID and store the biome name
execute if score @s ec.biome_id matches 0 run data modify storage evercraft:bestiary biome_name set value "Plains"
execute if score @s ec.biome_id matches 1 run data modify storage evercraft:bestiary biome_name set value "Forest"
execute if score @s ec.biome_id matches 2 run data modify storage evercraft:bestiary biome_name set value "Flower Forest"
execute if score @s ec.biome_id matches 3 run data modify storage evercraft:bestiary biome_name set value "Dark Forest"
execute if score @s ec.biome_id matches 4 run data modify storage evercraft:bestiary biome_name set value "Taiga"
execute if score @s ec.biome_id matches 5 run data modify storage evercraft:bestiary biome_name set value "Mountain"
execute if score @s ec.biome_id matches 6 run data modify storage evercraft:bestiary biome_name set value "Jungle"
execute if score @s ec.biome_id matches 7 run data modify storage evercraft:bestiary biome_name set value "Desert"
execute if score @s ec.biome_id matches 8 run data modify storage evercraft:bestiary biome_name set value "Savanna"
execute if score @s ec.biome_id matches 9 run data modify storage evercraft:bestiary biome_name set value "Ocean"
execute if score @s ec.biome_id matches 10 run data modify storage evercraft:bestiary biome_name set value "River"
execute if score @s ec.biome_id matches 11 run data modify storage evercraft:bestiary biome_name set value "Swamp"
execute if score @s ec.biome_id matches 12 run data modify storage evercraft:bestiary biome_name set value "Mushroom"
execute if score @s ec.biome_id matches 13 run data modify storage evercraft:bestiary biome_name set value "Ice"
execute if score @s ec.biome_id matches 14 run data modify storage evercraft:bestiary biome_name set value "Badlands"
execute if score @s ec.biome_id matches 15 run data modify storage evercraft:bestiary biome_name set value "Lush Caves"
execute if score @s ec.biome_id matches 16 run data modify storage evercraft:bestiary biome_name set value "Dripstone Caves"
execute if score @s ec.biome_id matches 17 run data modify storage evercraft:bestiary biome_name set value "Deep Dark"
execute if score @s ec.biome_id matches 18 run data modify storage evercraft:bestiary biome_name set value "Nether Wastes"
execute if score @s ec.biome_id matches 19 run data modify storage evercraft:bestiary biome_name set value "Crimson Forest"
execute if score @s ec.biome_id matches 20 run data modify storage evercraft:bestiary biome_name set value "Warped Forest"
execute if score @s ec.biome_id matches 21 run data modify storage evercraft:bestiary biome_name set value "Basalt Deltas"
execute if score @s ec.biome_id matches 22 run data modify storage evercraft:bestiary biome_name set value "Soul Sand Valley"
execute if score @s ec.biome_id matches 23 run data modify storage evercraft:bestiary biome_name set value "The End"
execute if score @s ec.biome_id matches 24 run data modify storage evercraft:bestiary biome_name set value "Windy"

# Append to this mob's biome list (duplicates filtered on GUI display)
$data modify storage evercraft:bestiary biomes.$(mob) append from storage evercraft:bestiary biome_name
