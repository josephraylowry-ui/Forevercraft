# ══════════════════════════════════════════════════════════════
# Admin: COMPLETE player progression reset
# Run as TARGET: execute as <player> run function evercraft:admin/strip_player_zero
# WARNING: This is IRREVERSIBLE! Resets ALL player data.
# ══════════════════════════════════════════════════════════════

# === CLEAR INVENTORY + EQUIPMENT ===
clear @s
item replace entity @s armor.head with minecraft:air
item replace entity @s armor.chest with minecraft:air
item replace entity @s armor.legs with minecraft:air
item replace entity @s armor.feet with minecraft:air
item replace entity @s weapon.offhand with minecraft:air

# === REVOKE ALL ADVANCEMENTS ===
advancement revoke @s everything

# === RESET ALL XP ===
experience set @s 0 points
experience set @s 0 levels

# === RESET ALL 122 SCOREBOARD OBJECTIVES ===

# --- adv (1) ---
scoreboard players set @s adv.gui_session 0

# --- cf (1) ---
scoreboard players set @s cf.vault_ominous 0

# --- ec (112) ---
scoreboard players set @s ec.affinity_match 0
scoreboard players set @s ec.anec_beast 0
scoreboard players set @s ec.anec_elder 0
scoreboard players set @s ec.anec_fisher 0
scoreboard players set @s ec.anec_miner 0
scoreboard players set @s ec.anec_scholar 0
scoreboard players set @s ec.anec_wanderer 0
scoreboard players set @s ec.artifact_count 0
scoreboard players set @s ec.biome_id 0
scoreboard players set @s ec.biome_last 0
scoreboard players set @s ec.biome_prev 0
scoreboard players set @s ec.block_glow 0
scoreboard players set @s ec.bm_quicksell 0
scoreboard players set @s ec.bounty_done 0
scoreboard players set @s ec.codex 0
scoreboard players set @s ec.codex_page_count 0
scoreboard players set @s ec.codex_ret_dim 0
scoreboard players set @s ec.codex_ret_x 0
scoreboard players set @s ec.codex_ret_y 0
scoreboard players set @s ec.codex_ret_z 0
scoreboard players set @s ec.codex_spec_cd 0
scoreboard players set @s ec.codex_spec_time 0
scoreboard players set @s ec.codex_tp 0
scoreboard players set @s ec.codex_use 0
scoreboard players set @s ec.compass_cd 0
scoreboard players set @s ec.crate_ach 0
scoreboard players set @s ec.crate_art 0
scoreboard players set @s ec.crate_comp 0
scoreboard players set @s ec.crate_plot 0
scoreboard players set @s ec.crate_tier 0
scoreboard players set @s ec.ddex 0
scoreboard players set @s ec.debug 0
scoreboard players set @s ec.dg_ready 0
scoreboard players set @s ec.dr_history 0
scoreboard players set @s ec.dr_peak_ms 0
scoreboard players set @s ec.dream_petal_count 0
scoreboard players set @s ec.dream_relic_count 0
scoreboard players set @s ec.dreams 0
scoreboard players set @s ec.echo_cd 0
scoreboard players set @s ec.ember_count 0
scoreboard players set @s ec.geode_count 0
scoreboard players set @s ec.has_artifacts 0
scoreboard players set @s ec.health 0
scoreboard players set @s ec.health_pct 0
scoreboard players set @s ec.healthbar 0
scoreboard players set @s ec.last_day 0
scoreboard players set @s ec.last_scorch 0
scoreboard players set @s ec.leave 0
scoreboard players set @s ec.lightning_cd 0
scoreboard players set @s ec.loot_timer 0
scoreboard players set @s ec.lure_count 0
scoreboard players set @s ec.map_count 0
scoreboard players set @s ec.max_health 0
scoreboard players set @s ec.mob_glow 0
scoreboard players set @s ec.monocle_cd 0
scoreboard players set @s ec.moon 0
scoreboard players set @s ec.move_lastx 0
scoreboard players set @s ec.move_lastz 0
scoreboard players set @s ec.moving 0
scoreboard players set @s ec.ncore 0
scoreboard players set @s ec.newcomer_pick 0
scoreboard players set @s ec.notify 0
scoreboard players set @s ec.notify_lvl 0
scoreboard players set @s ec.ore_prev 0
scoreboard players set @s ec.patron_dream_count 0
scoreboard players set @s ec.pet_bonded 0
scoreboard players set @s ec.pos_x 0
scoreboard players set @s ec.pos_y 0
scoreboard players set @s ec.pos_z 0
scoreboard players set @s ec.quest 0
scoreboard players set @s ec.quest_track 0
scoreboard players set @s ec.quill_count 0
scoreboard players set @s ec.ready 0
scoreboard players set @s ec.rh_beet 0
scoreboard players set @s ec.rh_carrot 0
scoreboard players set @s ec.rh_nwart 0
scoreboard players set @s ec.rh_potato 0
scoreboard players set @s ec.rh_wheat 0
scoreboard players set @s ec.sapling_age 0
scoreboard players set @s ec.sapling_try 0
scoreboard players set @s ec.seed_count 0
scoreboard players set @s ec.spark 0
scoreboard players set @s ec.stats 0
scoreboard players set @s ec.struct_1 0
scoreboard players set @s ec.struct_10 0
scoreboard players set @s ec.struct_11 0
scoreboard players set @s ec.struct_12 0
scoreboard players set @s ec.struct_13 0
scoreboard players set @s ec.struct_14 0
scoreboard players set @s ec.struct_15 0
scoreboard players set @s ec.struct_16 0
scoreboard players set @s ec.struct_17 0
scoreboard players set @s ec.struct_18 0
scoreboard players set @s ec.struct_19 0
scoreboard players set @s ec.struct_2 0
scoreboard players set @s ec.struct_20 0
scoreboard players set @s ec.struct_21 0
scoreboard players set @s ec.struct_22 0
scoreboard players set @s ec.struct_3 0
scoreboard players set @s ec.struct_4 0
scoreboard players set @s ec.struct_5 0
scoreboard players set @s ec.struct_6 0
scoreboard players set @s ec.struct_7 0
scoreboard players set @s ec.struct_8 0
scoreboard players set @s ec.struct_9 0
scoreboard players set @s ec.struct_unique 0
scoreboard players set @s ec.temp 0
scoreboard players set @s ec.thread_count 0
scoreboard players set @s ec.tome_count 0
scoreboard players set @s ec.tome_lvl 0
scoreboard players set @s ec.tome_pts 0
scoreboard players set @s ec.var 0

# --- Already covered (included for completeness) ---
scoreboard players set @s ach.prospects_done 0
scoreboard players set @s ach.quests_done 0
scoreboard players set @s ach.total 0
scoreboard players set @s adv.chemistry 0
scoreboard players set @s adv.combat 0
scoreboard players set @s adv.culinary 0
scoreboard players set @s adv.explorer 0
scoreboard players set @s adv.fishing 0
scoreboard players set @s adv.mining 0
scoreboard players set @s adv.stat_attack 0
scoreboard players set @s adv.stat_combat 0
scoreboard players set @s adv.stat_explore 0
scoreboard players set @s adv.stat_fish 0
scoreboard players set @s adv.stat_harvest 0
scoreboard players set @s adv.stat_mine 0
scoreboard players set @s adv.stat_ore 0
scoreboard players set @s adv.stat_quests 0
scoreboard players set @s adv.stat_ranged 0
scoreboard players set @s adv.taskmaster 0
scoreboard players set @s companion.id 0
scoreboard players set @s companion.level 0
scoreboard players set @s ec.chorus_count 0
scoreboard players set @s ec.coins 0
scoreboard players set @s ec.crystal_count 0
scoreboard players set @s ec.daily_quest 0
scoreboard players set @s ec.dg_floors_today 0
scoreboard players set @s ec.dng_attempts 0
scoreboard players set @s ec.dream_ore_count 0
scoreboard players set @s ec.droppings_count 0
scoreboard players set @s ec.gift_cd 0
scoreboard players set @s ec.last_gift_time 0
scoreboard players set @s ec.mushroom_count 0
scoreboard players set @s ec.quest_done_1 0
scoreboard players set @s ec.quest_done_2 0
scoreboard players set @s ec.quest_done_3 0
scoreboard players set @s ec.quest_done_4 0
scoreboard players set @s ec.quest_done_5 0
scoreboard players set @s ec.quest_done_6 0
scoreboard players set @s ec.quest_id_1 0
scoreboard players set @s ec.quest_id_2 0
scoreboard players set @s ec.quest_id_3 0
scoreboard players set @s ec.quest_id_4 0
scoreboard players set @s ec.quest_id_5 0
scoreboard players set @s ec.quest_id_6 0
scoreboard players set @s ec.quest_prog_1 0
scoreboard players set @s ec.quest_prog_2 0
scoreboard players set @s ec.quest_prog_3 0
scoreboard players set @s ec.quest_prog_4 0
scoreboard players set @s ec.quest_prog_5 0
scoreboard players set @s ec.quest_prog_6 0
scoreboard players set @s ec.rep_rank 0
scoreboard players set @s ec.sp_kills 0
scoreboard players set @s ec.sp_mastery 0
scoreboard players set @s ec.sp_tier 0
scoreboard players set @s ec.sp_weapon 0
scoreboard players set @s ec.village_rep 0

# === REMOVE ALL PERMANENT LUCK/ATTRIBUTE MODIFIERS ===
attribute @s luck modifier remove evercraft:crystal_of_dreams_bonus
attribute @s luck modifier remove evercraft:rabbits_dreaming_foot_luck
attribute @s luck modifier remove evercraft:dream_droppings_bonus
attribute @s luck modifier remove evercraft:dream_mushroom_bonus
attribute @s luck modifier remove evercraft:chorus_dreaming_bonus
attribute @s luck modifier remove evercraft:patrons_dream_essence_bonus
attribute @s luck modifier remove evercraft:dreamers_quill_bonus
attribute @s luck modifier remove evercraft:dreamweavers_thread_bonus
attribute @s luck modifier remove evercraft:tome_of_lucid_visions_bonus
attribute @s luck modifier remove evercraft:astral_codex_page_bonus
attribute @s luck modifier remove evercraft:fishermans_dozing_lure_bonus
attribute @s luck modifier remove evercraft:miners_slumbering_geode_bonus
attribute @s luck modifier remove evercraft:harvesters_dreamy_seed_bonus
attribute @s luck modifier remove evercraft:blacksmiths_dreaming_ember_bonus
attribute @s luck modifier remove evercraft:wanderers_dream_map_bonus
attribute @s luck modifier remove evercraft:prospectors_dream_ore_bonus
attribute @s luck modifier remove evercraft:collectors_dream_relic_bonus
attribute @s luck modifier remove evercraft:tillers_dream_petal_bonus
attribute @s luck modifier remove evercraft:dreamdust_crystal
attribute @s luck modifier remove evercraft:journal_ow_surface_luck
attribute @s luck modifier remove evercraft:journal_ow_caves_luck
attribute @s luck modifier remove evercraft:journal_nether_luck
attribute @s luck modifier remove evercraft:journal_end_luck
attribute @s luck modifier remove evercraft:constellation_bonus
attribute @s luck modifier remove evercraft:biome_mastery_dr
attribute @s luck modifier remove evercraft:adv_pres_task2
attribute @s luck modifier remove evercraft:adv_pres_task3
attribute @s luck modifier remove evercraft:inscr_gold_greed
attribute @s luck modifier remove ec_rf_gilded
attribute @s luck modifier remove evercraft:boss_dr_1
attribute @s luck modifier remove evercraft:boss_dr_2
attribute @s luck modifier remove evercraft:boss_dr_3
attribute @s luck modifier remove evercraft:boss_dr_4
attribute @s luck modifier remove evercraft:boss_dr_5
attribute @s luck modifier remove evercraft:boss_dr_6
attribute @s luck modifier remove evercraft:boss_dr_7
attribute @s luck modifier remove evercraft:boss_dr_8
attribute @s luck modifier remove evercraft:boss_dr_9
attribute @s luck modifier remove evercraft:boss_dr_10
attribute @s luck modifier remove evercraft:boss_dr_11
attribute @s luck modifier remove evercraft:boss_dr_12
attribute @s luck modifier remove evercraft:boss_dr_13

# === REMOVE ALL 940 PLAYER TAGS ===

# --- ABYSS tags (2) ---
tag @s remove ABYSS.Ore
tag @s remove ABYSS.announced

# --- Adv tags (2) ---
tag @s remove Adv.InMenu
tag @s remove Adv.RespecMode

# --- BM tags (1) ---
tag @s remove BM.InMenu

# --- CF tags (6) ---
tag @s remove CF.Forging
tag @s remove CF.GlowActive
tag @s remove CF.InCodex
tag @s remove CF.InMenu
tag @s remove CF.MenuElement
tag @s remove CF.SectionContent

# --- CK tags (6) ---
tag @s remove CK.Cooking
tag @s remove CK.FeastSelf
tag @s remove CK.FreeCook
tag @s remove CK.InMenu
tag @s remove CK.PreserveRestore
tag @s remove CK.Restore

# --- DG tags (1) ---
tag @s remove DG.InMenu

# --- FF tags (2) ---
tag @s remove FF.Fusing
tag @s remove FF.InMenu

# --- GuildNPC tags (4) ---
tag @s remove GuildNPC
tag @s remove GuildNPC.day_reset
tag @s remove GuildNPC.new
tag @s remove GuildNPC.wandered

# --- HS tags (10) ---
tag @s remove HS.BarrelFound
tag @s remove HS.InLaborers
tag @s remove HS.InMenu
tag @s remove HS.InSatchel
tag @s remove HS.InSettings
tag @s remove HS.LabelVisible
tag @s remove HS.Labeling
tag @s remove HS.SatchelRestore
tag @s remove HS.StashTarget
tag @s remove HS.ViewingLB

# --- IC tags (1) ---
tag @s remove IC.InMenu

# --- METEOR tags (1) ---
tag @s remove METEOR.Ore

# --- RF tags (1) ---
tag @s remove RF.InMenu

# --- TT tags (1) ---
tag @s remove TT.InMenu

# --- TX tags (2) ---
tag @s remove TX.DepositConfirmed
tag @s remove TX.InMenu

# --- WW tags (1) ---
tag @s remove WW.InMenu

# --- WaterNet tags (3) ---
tag @s remove WaterNet.active
tag @s remove WaterNet.invalid
tag @s remove WaterNet.placing

# --- ach tags (52) ---
tag @s remove ach_biome_badlands
tag @s remove ach_biome_basalt_deltas
tag @s remove ach_biome_crimson_forest
tag @s remove ach_biome_dark_forest
tag @s remove ach_biome_deep_dark
tag @s remove ach_biome_desert
tag @s remove ach_biome_dripstone_caves
tag @s remove ach_biome_flower_forest
tag @s remove ach_biome_forest
tag @s remove ach_biome_ice
tag @s remove ach_biome_jungle
tag @s remove ach_biome_lush_caves
tag @s remove ach_biome_mountain
tag @s remove ach_biome_mushroom
tag @s remove ach_biome_nether_wastes
tag @s remove ach_biome_ocean
tag @s remove ach_biome_plains
tag @s remove ach_biome_river
tag @s remove ach_biome_savanna
tag @s remove ach_biome_soul_sand_valley
tag @s remove ach_biome_swamp
tag @s remove ach_biome_taiga
tag @s remove ach_biome_the_end
tag @s remove ach_biome_warped_forest
tag @s remove ach_biome_wind
tag @s remove ach_set_blood
tag @s remove ach_set_celestial
tag @s remove ach_set_cloaked_skull
tag @s remove ach_set_crystal
tag @s remove ach_set_dragonmaster
tag @s remove ach_set_dragonslayer
tag @s remove ach_set_ember
tag @s remove ach_set_ender
tag @s remove ach_set_ender_dragon
tag @s remove ach_set_fireforged
tag @s remove ach_set_frost
tag @s remove ach_set_golem
tag @s remove ach_set_infernal
tag @s remove ach_set_journey
tag @s remove ach_set_nature
tag @s remove ach_set_netherwalker
tag @s remove ach_set_ninja
tag @s remove ach_set_ocean
tag @s remove ach_set_phantom
tag @s remove ach_set_sculk
tag @s remove ach_set_shadow
tag @s remove ach_set_space
tag @s remove ach_set_splendid
tag @s remove ach_set_storm
tag @s remove ach_set_titan
tag @s remove ach_set_verdant
tag @s remove ach_set_wither

# --- adv tags (1) ---
tag @s remove adv.wolf_set

# --- amethyst tags (5) ---
tag @s remove amethyst_chest
tag @s remove amethyst_feet
tag @s remove amethyst_head
tag @s remove amethyst_legs
tag @s remove amethyst_notified

# --- artifact tags (1) ---
tag @s remove artifact_got_looting

# --- at tags (1) ---
tag @s remove at_village

# --- bestiary tags (6) ---
tag @s remove bestiary.baby_mount.set
tag @s remove bestiary.settings.applied
tag @s remove bestiary.settings.breed.disabled
tag @s remove bestiary.settings.drown.disabled
tag @s remove bestiary.settings.villagename.applied
tag @s remove bestiary.villager.leader

# --- bl tags (8) ---
tag @s remove bl.marked
tag @s remove bl.owned
tag @s remove bl.owner
tag @s remove bl.pierced
tag @s remove bl.restore
tag @s remove bl.sweep_primary
tag @s remove bl.warp_target
tag @s remove bl.warp_wolf

# --- blood tags (2) ---
tag @s remove blood_2pc
tag @s remove blood_4pc

# --- bolt tags (1) ---
tag @s remove bolt_cooldown

# --- ce tags (41) ---
tag @s remove ce.emberheart_revive
tag @s remove ce.evo_arctic_fox
tag @s remove ce.evo_ashborn
tag @s remove ce.evo_butterfly
tag @s remove ce.evo_claude
tag @s remove ce.evo_copper_golem
tag @s remove ce.evo_cow_of_eden
tag @s remove ce.evo_crystalheart
tag @s remove ce.evo_deloris
tag @s remove ce.evo_dreamstag
tag @s remove ce.evo_emberheart
tag @s remove ce.evo_endwalker
tag @s remove ce.evo_golden_dragon
tag @s remove ce.evo_grovekeeper
tag @s remove ce.evo_infernus
tag @s remove ce.evo_iron_golem
tag @s remove ce.evo_leviathan
tag @s remove ce.evo_lunar_moth
tag @s remove ce.evo_monolith
tag @s remove ce.evo_moobloom
tag @s remove ce.evo_nebula_kit
tag @s remove ce.evo_panther
tag @s remove ce.evo_red_panda
tag @s remove ce.evo_regal_tiger
tag @s remove ce.evo_sabertooth
tag @s remove ce.evo_skeleton_horse
tag @s remove ce.evo_snow_fox_spirit
tag @s remove ce.evo_somnia
tag @s remove ce.evo_spirit_wolf
tag @s remove ce.evo_starweaver
tag @s remove ce.evo_stormcaller
tag @s remove ce.evo_time_weaver
tag @s remove ce.evo_twilight_hare
tag @s remove ce.evo_vex
tag @s remove ce.evo_void_walker
tag @s remove ce.evo_voidshade
tag @s remove ce.evo_wither
tag @s remove ce.evo_wraith
tag @s remove ce.evolved_active
tag @s remove ce.evolving
tag @s remove ce.evolving_pet

# --- celestial tags (2) ---
tag @s remove celestial_2pc
tag @s remove celestial_4pc

# --- cf tags (3) ---
tag @s remove cf.checking_player
tag @s remove cf.refresh_consumed
tag @s remove cf.refresh_marker

# --- challenge tags (3) ---
tag @s remove challenge.mode_comp
tag @s remove challenge.mode_duel
tag @s remove challenge.mode_pet

# --- cloaked tags (2) ---
tag @s remove cloaked_skull_2pc
tag @s remove cloaked_skull_4pc

# --- companion tags (115) ---
tag @s remove companion.abyssal
tag @s remove companion.activemenu
tag @s remove companion.activepet
tag @s remove companion.alien
tag @s remove companion.allay
tag @s remove companion.arctic_fox
tag @s remove companion.armadillo
tag @s remove companion.ashborn
tag @s remove companion.baby_potato
tag @s remove companion.bee
tag @s remove companion.blaze
tag @s remove companion.bramble
tag @s remove companion.breeze
tag @s remove companion.bulwark
tag @s remove companion.butterfly
tag @s remove companion.camel
tag @s remove companion.chick
tag @s remove companion.cindershell
tag @s remove companion.claude
tag @s remove companion.copper_golem
tag @s remove companion.cow
tag @s remove companion.cow_of_eden
tag @s remove companion.cragmite
tag @s remove companion.creaking
tag @s remove companion.creeper
tag @s remove companion.crystalheart
tag @s remove companion.deloris
tag @s remove companion.dreamstag
tag @s remove companion.duck
tag @s remove companion.emberheart
tag @s remove companion.ender_dragon
tag @s remove companion.enderman
tag @s remove companion.endwalker
tag @s remove companion.evoker
tag @s remove companion.fox
tag @s remove companion.frog
tag @s remove companion.frostweaver
tag @s remove companion.frozen_zombie
tag @s remove companion.giraffe
tag @s remove companion.glider
tag @s remove companion.goat
tag @s remove companion.golden_dragon
tag @s remove companion.grasshopper
tag @s remove companion.grovekeeper
tag @s remove companion.has_marker
tag @s remove companion.has_whistle
tag @s remove companion.hidden
tag @s remove companion.hoglin
tag @s remove companion.infernus
tag @s remove companion.infoscreen
tag @s remove companion.inmenuv2
tag @s remove companion.iron_golem
tag @s remove companion.juggernaut
tag @s remove companion.knight
tag @s remove companion.koala
tag @s remove companion.leviathan
tag @s remove companion.llama
tag @s remove companion.lunar_moth
tag @s remove companion.marker
tag @s remove companion.moldwarp
tag @s remove companion.monkey
tag @s remove companion.monolith
tag @s remove companion.moobloom
tag @s remove companion.mooshroom
tag @s remove companion.mossy_skeleton
tag @s remove companion.mossy_zombie
tag @s remove companion.mule
tag @s remove companion.mushroom
tag @s remove companion.naiad
tag @s remove companion.nebula_kit
tag @s remove companion.newplayer
tag @s remove companion.ocelot
tag @s remove companion.oracle
tag @s remove companion.owner
tag @s remove companion.panther
tag @s remove companion.pig
tag @s remove companion.piglin
tag @s remove companion.pixie
tag @s remove companion.polar_bear
tag @s remove companion.prowler
tag @s remove companion.rascal
tag @s remove companion.ravager
tag @s remove companion.red_panda
tag @s remove companion.regal_tiger
tag @s remove companion.restore_mainhand
tag @s remove companion.restore_menu
tag @s remove companion.sabertooth
tag @s remove companion.sentinel
tag @s remove companion.shade
tag @s remove companion.silverfish
tag @s remove companion.skeleton_horse
tag @s remove companion.sniffer
tag @s remove companion.snow_fox_spirit
tag @s remove companion.snowman
tag @s remove companion.somnia
tag @s remove companion.spirit_wolf
tag @s remove companion.sporeblossom
tag @s remove companion.squid
tag @s remove companion.starweaver
tag @s remove companion.stormcaller
tag @s remove companion.strider
tag @s remove companion.tidecaller
tag @s remove companion.time_weaver
tag @s remove companion.timerowner
tag @s remove companion.titan
tag @s remove companion.twilight_hare
tag @s remove companion.vex
tag @s remove companion.void_walker
tag @s remove companion.voidshade
tag @s remove companion.wither
tag @s remove companion.wolf
tag @s remove companion.wooly_cow
tag @s remove companion.wraith
tag @s remove companion.zephyr
tag @s remove companion.zoglin

# --- copper tags (5) ---
tag @s remove copper_chest
tag @s remove copper_feet
tag @s remove copper_head
tag @s remove copper_legs
tag @s remove copper_notified

# --- crystal tags (2) ---
tag @s remove crystal_2pc
tag @s remove crystal_4pc

# --- cs tags (1) ---
tag @s remove cs.heist_clearing

# --- dg tags (4) ---
tag @s remove dg.checking_unknown
tag @s remove dg.player
tag @s remove dg.trim_bonus
tag @s remove dg.unknown_detected

# --- diamond tags (5) ---
tag @s remove diamond_chest
tag @s remove diamond_feet
tag @s remove diamond_head
tag @s remove diamond_legs
tag @s remove diamond_notified

# --- dm tags (6) ---
tag @s remove dm_berserk_2pc
tag @s remove dm_berserk_4pc
tag @s remove dm_berserker_6pc
tag @s remove dm_dancer_4pc
tag @s remove dm_dancer_5pc
tag @s remove dm_dancer_6pc

# --- dr tags (11) ---
tag @s remove dr.all_lore
tag @s remove dr.dream_collector
tag @s remove dr.dreamwalker
tag @s remove dr.dreamwalker_announced
tag @s remove dr.in_realm
tag @s remove dr.lucid_dreamer
tag @s remove dr.lucid_dreamer_announced
tag @s remove dr.master_dreamer
tag @s remove dr.maze_input
tag @s remove dr.maze_on_color
tag @s remove dr.trial_active

# --- dragonmaster tags (4) ---
tag @s remove dragonmaster_2pc
tag @s remove dragonmaster_4pc
tag @s remove dragonmaster_5pc
tag @s remove dragonmaster_6pc

# --- dragonslayer tags (2) ---
tag @s remove dragonslayer_2pc
tag @s remove dragonslayer_4pc

# --- duel tags (13) ---
tag @s remove duel.challenger
tag @s remove duel.challenger_confirmed
tag @s remove duel.eliminated
tag @s remove duel.ftx_respawning
tag @s remove duel.ftx_victim
tag @s remove duel.loser
tag @s remove duel.partner_b
tag @s remove duel.pending_target
tag @s remove duel.ray_target
tag @s remove duel.raycaster
tag @s remove duel.self_marker
tag @s remove duel.team_opponent_confirmed
tag @s remove duel.winner

# --- ec tags (331) ---
tag @s remove ec.Confirming
tag @s remove ec.InExchange
tag @s remove ec.InFountain
tag @s remove ec.InGachaInfo
tag @s remove ec._a
tag @s remove ec._bone
tag @s remove ec._clr
tag @s remove ec._ember
tag @s remove ec._lip
tag @s remove ec._nc
tag @s remove ec._petal
tag @s remove ec.absorb_steal
tag @s remove ec.admin
tag @s remove ec.ae_checked
tag @s remove ec.aff_attacker
tag @s remove ec.anglers_pearl_fishing
tag @s remove ec.ar_marked
tag @s remove ec.ar_tethered
tag @s remove ec.arrow_checked
tag @s remove ec.backstabbed
tag @s remove ec.bd_best
tag @s remove ec.bd_buddy
tag @s remove ec.bd_charge_hit
tag @s remove ec.bd_cozy_applied
tag @s remove ec.bd_designating_target
tag @s remove ec.bd_last_active
tag @s remove ec.bd_neardeath_cd
tag @s remove ec.bd_speed_applied
tag @s remove ec.bd_wc_applied
tag @s remove ec.big
tag @s remove ec.bk_active
tag @s remove ec.bk_swinger
tag @s remove ec.bl_active
tag @s remove ec.bleeding
tag @s remove ec.blossom_rod_luck
tag @s remove ec.bm_forage_bonus
tag @s remove ec.bnt_killer
tag @s remove ec.caff_xfeed
tag @s remove ec.cf_bridge_active
tag @s remove ec.cf_gathering
tag @s remove ec.cleave_primary
tag @s remove ec.conv_pickup
tag @s remove ec.crate_checked
tag @s remove ec.crate_done
tag @s remove ec.crop_rolled
tag @s remove ec.cs_restore
tag @s remove ec.deto_mine
tag @s remove ec.df_restore
tag @s remove ec.di_active
tag @s remove ec.di_burst
tag @s remove ec.dlpack_in_menu
tag @s remove ec.dn_active
tag @s remove ec.dn_swinger
tag @s remove ec.dr_1
tag @s remove ec.dr_2
tag @s remove ec.dr_3
tag @s remove ec.dragon_fire
tag @s remove ec.dreamdust_used
tag @s remove ec.ds_active
tag @s remove ec.duel_active_tag
tag @s remove ec.duel_spectator
tag @s remove ec.ember_rod_luck
tag @s remove ec.entity
tag @s remove ec.exquisite
tag @s remove ec.fortitude
tag @s remove ec.fountain_searching
tag @s remove ec.fox_click_cd
tag @s remove ec.fox_owner
tag @s remove ec.fox_tamed
tag @s remove ec.fr_detail_view
tag @s remove ec.fr_inviter
tag @s remove ec.fr_marry_pending
tag @s remove ec.fr_pending
tag @s remove ec.fr_ray_target
tag @s remove ec.furia
tag @s remove ec.furia.greater
tag @s remove ec.furia.minor
tag @s remove ec.furia.processed
tag @s remove ec.furia.standard
tag @s remove ec.gacha_free_pull
tag @s remove ec.gd_pvp
tag @s remove ec.gd_vote_approved
tag @s remove ec.ge_collector
tag @s remove ec.gear_target
tag @s remove ec.gexp_mvp
tag @s remove ec.gexp_voted
tag @s remove ec.gf_crystal_restore
tag @s remove ec.gf_restore
tag @s remove ec.ghast_check
tag @s remove ec.ghast_click_cd
tag @s remove ec.ghast_owner
tag @s remove ec.ghast_tamed
tag @s remove ec.ghast_was_sitting
tag @s remove ec.ghast_was_standing
tag @s remove ec.gm_detail_view
tag @s remove ec.growth_checked
tag @s remove ec.gs_golem
tag @s remove ec.gs_in_menu
tag @s remove ec.gs_new
tag @s remove ec.gs_registered
tag @s remove ec.gs_remote_menu
tag @s remove ec.guild_arrow_warned
tag @s remove ec.guild_in_menu
tag @s remove ec.guild_inv_target
tag @s remove ec.guild_inviter
tag @s remove ec.guild_node
tag @s remove ec.guild_node_new
tag @s remove ec.guild_remote_menu
tag @s remove ec.guild_strike_notified
tag @s remove ec.guild_supply_select
tag @s remove ec.guild_viewer
tag @s remove ec.guild_xp_bonus
tag @s remove ec.had_old_codex
tag @s remove ec.has_accessory
tag @s remove ec.has_aegis
tag @s remove ec.has_any_codex
tag @s remove ec.has_any_trim
tag @s remove ec.has_time_dr
tag @s remove ec.head_checked
tag @s remove ec.healer_self
tag @s remove ec.heist_active_tag
tag @s remove ec.hero_night_dr
tag @s remove ec.hero_src
tag @s remove ec.hl_restore
tag @s remove ec.holding_fortune_tool
tag @s remove ec.hsatch_in_menu
tag @s remove ec.ht_active
tag @s remove ec.hxp_checked
tag @s remove ec.iai_charging
tag @s remove ec.iai_fired
tag @s remove ec.iai_ready
tag @s remove ec.infernal_dmg
tag @s remove ec.inscr_no_res
tag @s remove ec.inscr_pool_guild
tag @s remove ec.inscr_pool_home
tag @s remove ec.inscr_pool_personal
tag @s remove ec.inscr_res
tag @s remove ec.inscr_restore
tag @s remove ec.inscr_was_res
tag @s remove ec.joined
tag @s remove ec.journey_pick_luck
tag @s remove ec.journey_shov_luck
tag @s remove ec.jv_active
tag @s remove ec.kb
tag @s remove ec.kt_active
tag @s remove ec.lb_owner
tag @s remove ec.lb_restore
tag @s remove ec.light
tag @s remove ec.lightning_arrow
tag @s remove ec.lip_ripper_luck
tag @s remove ec.lodestone_registered
tag @s remove ec.lucid_claim_active
tag @s remove ec.miners_lantern_fortune
tag @s remove ec.mt_finished
tag @s remove ec.mt_racer
tag @s remove ec.mt_recalling
tag @s remove ec.mule_in_menu
tag @s remove ec.myth_chest_luck
tag @s remove ec.myth_feet_luck
tag @s remove ec.myth_head_luck
tag @s remove ec.myth_legs_luck
tag @s remove ec.nt_owner
tag @s remove ec.nt_warned
tag @s remove ec.o_blossom_rod_luck
tag @s remove ec.ocelot_click_cd
tag @s remove ec.ocelot_owner
tag @s remove ec.ocelot_tamed
tag @s remove ec.ornate
tag @s remove ec.pantry_in_menu
tag @s remove ec.pantry_mainhand
tag @s remove ec.pantry_restore
tag @s remove ec.party_marked
tag @s remove ec.patron
tag @s remove ec.patron.common
tag @s remove ec.patron.exquisite
tag @s remove ec.patron.mythical
tag @s remove ec.patron.ornate
tag @s remove ec.patron.processed
tag @s remove ec.patron.rare
tag @s remove ec.patron.uncommon
tag @s remove ec.pet_found
tag @s remove ec.player
tag @s remove ec.playerhead
tag @s remove ec.pty_inv_found
tag @s remove ec.pty_named
tag @s remove ec.quest_tracking
tag @s remove ec.r_bone_rod_luck
tag @s remove ec.rare
tag @s remove ec.rd_al_a_h1
tag @s remove ec.rd_al_a_h2
tag @s remove ec.rd_al_a_h3
tag @s remove ec.rd_al_a_h4
tag @s remove ec.rd_al_a_h5
tag @s remove ec.rd_al_anchor_hit
tag @s remove ec.rd_al_lantern_just_lit
tag @s remove ec.rd_al_lantern_off
tag @s remove ec.rd_al_lantern_on
tag @s remove ec.rd_gi_dead
tag @s remove ec.rd_gi_h1
tag @s remove ec.rd_gi_h2
tag @s remove ec.rd_gi_h3
tag @s remove ec.rd_gi_h4
tag @s remove ec.rd_gi_h5
tag @s remove ec.rd_hs_fake_dead
tag @s remove ec.rd_hs_fake_h1
tag @s remove ec.rd_hs_fake_h2
tag @s remove ec.rd_hs_fake_h3
tag @s remove ec.rd_hs_fake_h4
tag @s remove ec.rd_hs_fake_h5
tag @s remove ec.rd_initializing
tag @s remove ec.rd_lv_sponge_used
tag @s remove ec.rd_lv_sponge_valid_placed
tag @s remove ec.rd_lv_target
tag @s remove ec.rd_mw_ch1
tag @s remove ec.rd_mw_ch2
tag @s remove ec.rd_mw_ch3
tag @s remove ec.rd_mw_ch4
tag @s remove ec.rd_mw_core_active
tag @s remove ec.rd_participant
tag @s remove ec.rd_vw_c1
tag @s remove ec.rd_vw_c2
tag @s remove ec.rd_vw_empty
tag @s remove ec.reach
tag @s remove ec.regen_capped
tag @s remove ec.renegade_luck
tag @s remove ec.rf_active
tag @s remove ec.rg_active
tag @s remove ec.rg_proc
tag @s remove ec.rg_shielded
tag @s remove ec.rg_swinger
tag @s remove ec.rune_activated
tag @s remove ec.rw_active
tag @s remove ec.satchel_in_menu
tag @s remove ec.satchel_owner
tag @s remove ec.sc_in_picker
tag @s remove ec.sc_in_showcase
tag @s remove ec.sc_temp_anchor
tag @s remove ec.sc_view_other
tag @s remove ec.searching
tag @s remove ec.sk_active
tag @s remove ec.sk_sentinel
tag @s remove ec.small
tag @s remove ec.soul_rend
tag @s remove ec.sp_active
tag @s remove ec.sp_aegis_active
tag @s remove ec.sp_beast_active
tag @s remove ec.sp_blade_storm
tag @s remove ec.sp_charging
tag @s remove ec.sp_checking_snipe
tag @s remove ec.sp_chrono_active
tag @s remove ec.sp_chrono_boost
tag @s remove ec.sp_crystal_pending
tag @s remove ec.sp_cyclone_active
tag @s remove ec.sp_death_mainhand
tag @s remove ec.sp_death_offhand
tag @s remove ec.sp_dh_charging
tag @s remove ec.sp_flurry_proc
tag @s remove ec.sp_fortress_active
tag @s remove ec.sp_frozen
tag @s remove ec.sp_fused
tag @s remove ec.sp_golden_glow
tag @s remove ec.sp_guarded
tag @s remove ec.sp_guardian
tag @s remove ec.sp_guarding
tag @s remove ec.sp_judging
tag @s remove ec.sp_maelstrom_active
tag @s remove ec.sp_phase_active
tag @s remove ec.sp_poseidon_charging
tag @s remove ec.sp_rampage_active
tag @s remove ec.sp_restore
tag @s remove ec.sp_restore_offhand
tag @s remove ec.sp_rift_active
tag @s remove ec.sp_sanctuary_active
tag @s remove ec.sp_shadow_bonus
tag @s remove ec.sp_surge_charging
tag @s remove ec.sp_taunted
tag @s remove ec.sp_thousand_cuts
tag @s remove ec.sp_tyrant_rage
tag @s remove ec.sp_wall_active
tag @s remove ec.sp_water_boost
tag @s remove ec.sp_zephyr_dance
tag @s remove ec.spec_wp
tag @s remove ec.spelunker_luck
tag @s remove ec.spirit_chosen
tag @s remove ec.sq_update_tome
tag @s remove ec.st_crystal_pending
tag @s remove ec.st_held
tag @s remove ec.st_mining
tag @s remove ec.st_zone_safe
tag @s remove ec.step_height
tag @s remove ec.t_holding
tag @s remove ec.tame_protected
tag @s remove ec.taunted
tag @s remove ec.tb_dying
tag @s remove ec.tb_has_totem
tag @s remove ec.tb_registered
tag @s remove ec.tb_restore
tag @s remove ec.tb_reviving
tag @s remove ec.tb_viewing
tag @s remove ec.te_nth_any
tag @s remove ec.temp_fortress
tag @s remove ec.titans_plate
tag @s remove ec.title_top_contributor
tag @s remove ec.tk_puller
tag @s remove ec.tomb_accept_target
tag @s remove ec.tomb_carrier
tag @s remove ec.tomb_collecting
tag @s remove ec.tomb_delivering
tag @s remove ec.tomb_deny_target
tag @s remove ec.tomb_is_owner
tag @s remove ec.tomb_pending
tag @s remove ec.tomb_reviver
tag @s remove ec.tomb_reviving
tag @s remove ec.tomb_shattering
tag @s remove ec.tomb_uuid_set
tag @s remove ec.tome_cooldown
tag @s remove ec.tome_update
tag @s remove ec.tq_update_tome
tag @s remove ec.trades_set
tag @s remove ec.tt_complete
tag @s remove ec.tt_player
tag @s remove ec.uc_bone_rod_luck
tag @s remove ec.warriors_crown
tag @s remove ec.wishing_star_active
tag @s remove ec.wooden_rod_luck
tag @s remove ec.wt_has_companion
tag @s remove ec.xp
tag @s remove ec.zone_owner
tag @s remove ec_axe_broken
tag @s remove ec_pick_broken
tag @s remove ec_shov_broken

# --- ed tags (5) ---
tag @s remove ed_knight_2pc
tag @s remove ed_knight_5pc
tag @s remove ed_knight_6pc
tag @s remove ed_tank_2pc
tag @s remove ed_tank_4pc

# --- ember tags (2) ---
tag @s remove ember_2pc
tag @s remove ember_4pc

# --- emerald tags (5) ---
tag @s remove emerald_chest
tag @s remove emerald_feet
tag @s remove emerald_head
tag @s remove emerald_legs
tag @s remove emerald_notified

# --- ender tags (6) ---
tag @s remove ender_2pc
tag @s remove ender_4pc
tag @s remove ender_dragon_2pc
tag @s remove ender_dragon_4pc
tag @s remove ender_dragon_5pc
tag @s remove ender_dragon_6pc

# --- fireforged tags (2) ---
tag @s remove fireforged_2pc
tag @s remove fireforged_4pc

# --- frost tags (2) ---
tag @s remove frost_2pc
tag @s remove frost_4pc

# --- full tags (16) ---
tag @s remove full_set_ascendant
tag @s remove full_set_bolt
tag @s remove full_set_coast
tag @s remove full_set_coast_got_looting
tag @s remove full_set_dune
tag @s remove full_set_eye
tag @s remove full_set_flow
tag @s remove full_set_rib
tag @s remove full_set_sentry
tag @s remove full_set_silence
tag @s remove full_set_snout
tag @s remove full_set_spire
tag @s remove full_set_tide
tag @s remove full_set_vex
tag @s remove full_set_ward
tag @s remove full_set_wild

# --- gc tags (2) ---
tag @s remove gc.placing
tag @s remove gc_deflected

# --- ge tags (1) ---
tag @s remove ge.top_contributor

# --- gold tags (5) ---
tag @s remove gold_chest
tag @s remove gold_feet
tag @s remove gold_head
tag @s remove gold_legs
tag @s remove gold_notified

# --- golem tags (2) ---
tag @s remove golem_2pc
tag @s remove golem_4pc

# --- gs tags (3) ---
tag @s remove gs.ig_no_explode
tag @s remove gs.iron_guard
tag @s remove gs.warp_target

# --- h2h tags (6) ---
tag @s remove h2h.challenger
tag @s remove h2h.loser
tag @s remove h2h.participant
tag @s remove h2h.pending_target
tag @s remove h2h.self
tag @s remove h2h.winner

# --- hb tags (5) ---
tag @s remove hb.accent_furia
tag @s remove hb.accent_patron
tag @s remove hb.accent_pet
tag @s remove hb.found
tag @s remove hb.was_enabled

# --- hc tags (2) ---
tag @s remove hc.placing
tag @s remove hc.target

# --- heist tags (1) ---
tag @s remove heist.cd_checking

# --- hero tags (8) ---
tag @s remove hero_2pc
tag @s remove hero_4pc
tag @s remove hero_5pc
tag @s remove hero_6pc
tag @s remove hero_dancer_2pc
tag @s remove hero_dancer_4pc
tag @s remove hero_dancer_5pc
tag @s remove hero_dancer_6pc

# --- hs tags (12) ---
tag @s remove hs.golem
tag @s remove hs.has_satchel
tag @s remove hs.ig_no_explode
tag @s remove hs.iron_guard
# hs.keep_$(category) is a macro tag — skip (dynamic per-category)
tag @s remove hs.owner_check
tag @s remove hs.remote_stash
tag @s remove hs.stashing
tag @s remove hs.vis_self
tag @s remove hs.visiting
tag @s remove hs.warp_owner
tag @s remove hs.warp_target

# --- ic tags (8) ---
tag @s remove ic.bearer_setup
tag @s remove ic.boss_setup
tag @s remove ic.fallen
tag @s remove ic.furia
tag @s remove ic.invited
tag @s remove ic.patron
tag @s remove ic.player
tag @s remove ic.starter

# --- inf tags (6) ---
tag @s remove inf_sentinel_2pc
tag @s remove inf_sentinel_4pc
tag @s remove inf_sentinel_6pc
tag @s remove inf_striker_2pc
tag @s remove inf_striker_4pc
tag @s remove inf_striker_5pc

# --- infernal tags (4) ---
tag @s remove infernal_2pc
tag @s remove infernal_4pc
tag @s remove infernal_5pc
tag @s remove infernal_6pc

# --- iron tags (5) ---
tag @s remove iron_chest
tag @s remove iron_feet
tag @s remove iron_head
tag @s remove iron_legs
tag @s remove iron_notified

# --- jn tags (10) ---
# jn.b$(bid) is a macro tag — skip (dynamic per-biome)
tag @s remove jn.dim_end
tag @s remove jn.dim_neth
tag @s remove jn.dim_ow
tag @s remove jn.s1
tag @s remove jn.s2
tag @s remove jn.s3
tag @s remove jn.s4
tag @s remove jn.s5
# jn.v_$(vid) is a macro tag — skip (dynamic per-village)

# --- join tags (1) ---
tag @s remove join_my_team

# --- journey tags (3) ---
tag @s remove journey_2pc
tag @s remove journey_4pc
tag @s remove journey_5pc

# --- jrn tags (2) ---
tag @s remove jrn_beast_2pc
tag @s remove jrn_heal_2pc

# --- lapis tags (5) ---
tag @s remove lapis_chest
tag @s remove lapis_feet
tag @s remove lapis_head
tag @s remove lapis_legs
tag @s remove lapis_notified

# --- mobs tags (1) ---
tag @s remove mobs.patrons.applied

# --- more tags (13) ---
tag @s remove more_professions_artificer
tag @s remove more_professions_bartender
tag @s remove more_professions_beekeeper
tag @s remove more_professions_circut_board
tag @s remove more_professions_explorer
tag @s remove more_professions_hunter
tag @s remove more_professions_miner
tag @s remove more_professions_nymph
tag @s remove more_professions_retired_adventurer
tag @s remove more_professions_taskmaster
tag @s remove more_professions_verified
tag @s remove more_professions_wise_wanderer
tag @s remove more_professions_zookeeper

# --- mythical tags (3) ---
tag @s remove mythical_spider_t1
tag @s remove mythical_spider_t2
tag @s remove mythical_spider_t3

# --- nature tags (2) ---
tag @s remove nature_2pc
tag @s remove nature_4pc

# --- nc tags (1) ---
tag @s remove nc_absorbing

# --- netherite tags (8) ---
tag @s remove netherite_chest
tag @s remove netherite_falling_fast
tag @s remove netherite_feet
tag @s remove netherite_floating
tag @s remove netherite_head
tag @s remove netherite_legs
tag @s remove netherite_notified
tag @s remove netherite_on_ground

# --- netherwalker tags (2) ---
tag @s remove netherwalker_2pc
tag @s remove netherwalker_4pc

# --- ninja tags (2) ---
tag @s remove ninja_2pc
tag @s remove ninja_4pc

# --- not tags (1) ---
tag @s remove not_at_village

# --- ocean tags (2) ---
tag @s remove ocean_2pc
tag @s remove ocean_4pc

# --- party tags (1) ---
tag @s remove party.boss_death

# --- pc tags (1) ---
tag @s remove pc.target

# --- pd tags (7) ---
tag @s remove pd.attacker
tag @s remove pd.challenger
tag @s remove pd.duelist
tag @s remove pd.loser
tag @s remove pd.pending_target
tag @s remove pd.target
tag @s remove pd.winner

# --- phantom tags (2) ---
tag @s remove phantom_2pc
tag @s remove phantom_4pc

# --- quartz tags (6) ---
tag @s remove quartz_chest
tag @s remove quartz_feet
tag @s remove quartz_head
tag @s remove quartz_legs
tag @s remove quartz_notified
tag @s remove quartz_xp_orb

# --- rd tags (1) ---
tag @s remove rd.voted

# --- redstone tags (5) ---
tag @s remove redstone_chest
tag @s remove redstone_feet
tag @s remove redstone_head
tag @s remove redstone_legs
tag @s remove redstone_notified

# --- resin tags (5) ---
tag @s remove resin_chest
tag @s remove resin_feet
tag @s remove resin_head
tag @s remove resin_legs
tag @s remove resin_notified

# --- rp tags (2) ---
tag @s remove rp.has_omen
tag @s remove rp.raiding

# --- sculk tags (2) ---
tag @s remove sculk_2pc
tag @s remove sculk_4pc

# --- sentry tags (2) ---
tag @s remove sentry_no_explode
tag @s remove sentry_target

# --- shadow tags (2) ---
tag @s remove shadow_2pc
tag @s remove shadow_4pc

# --- silence tags (1) ---
tag @s remove silence_banished

# --- single tags (18) ---
tag @s remove single_bolt
tag @s remove single_coast
tag @s remove single_dune
tag @s remove single_eye
tag @s remove single_flow
tag @s remove single_host
tag @s remove single_raiser
tag @s remove single_rib
tag @s remove single_sentry
tag @s remove single_shaper
tag @s remove single_silence
tag @s remove single_snout
tag @s remove single_spire
tag @s remove single_tide
tag @s remove single_vex
tag @s remove single_ward
tag @s remove single_wayfinder
tag @s remove single_wild

# --- snout tags (1) ---
tag @s remove snout_bonus_given

# --- space tags (2) ---
tag @s remove space_2pc
tag @s remove space_4pc

# --- spl tags (4) ---
tag @s remove spl_rogue_2pc
tag @s remove spl_rogue_4pc
tag @s remove spl_rogue_5pc
tag @s remove spl_rogue_6pc

# --- splendid tags (4) ---
tag @s remove splendid_2pc
tag @s remove splendid_4pc
tag @s remove splendid_5pc
tag @s remove splendid_6pc

# --- sr tags (1) ---
tag @s remove sr.prompted

# --- storm tags (2) ---
tag @s remove storm_2pc
tag @s remove storm_4pc

# --- te tags (2) ---
tag @s remove te.quartz_wearing
tag @s remove te.redstone_wearing

# --- titan tags (4) ---
tag @s remove titan_2pc
tag @s remove titan_4pc
tag @s remove titan_5pc
tag @s remove titan_6pc

# --- trim tags (3) ---
tag @s remove trim_abilities_bolting
tag @s remove trim_boomer
tag @s remove trim_snout

# --- ttn tags (5) ---
tag @s remove ttn_hop_2pc
tag @s remove ttn_hop_4pc
tag @s remove ttn_hoplite_6pc
tag @s remove ttn_jav_2pc
tag @s remove ttn_jav_5pc

# --- verdant tags (3) ---
tag @s remove verdant_2pc
tag @s remove verdant_4pc
tag @s remove verdant_5pc

# --- vex tags (4) ---
tag @s remove vex_ally
tag @s remove vex_attack_cooldown
tag @s remove vex_fangs_cooldown
tag @s remove vex_spawn_cooldown

# --- vrd tags (4) ---
tag @s remove vrd_archer_2pc
tag @s remove vrd_archer_5pc
tag @s remove vrd_hunter_2pc
tag @s remove vrd_hunter_5pc

# --- vs tags (1) ---
tag @s remove vs.just_converted

# --- wb tags (7) ---
tag @s remove wb.enraged
tag @s remove wb.in_water
tag @s remove wb.initializing
tag @s remove wb.last_hit
tag @s remove wb.natural_spawn
tag @s remove wb.participant
tag @s remove wb.summoner

# --- wild tags (1) ---
tag @s remove wild_wolf_cooldown

# --- wither tags (2) ---
tag @s remove wither_2pc
tag @s remove wither_4pc

# === FEEDBACK ===
tellraw @s [{text:"[Admin] ",color:"dark_red"},{text:"Your progression has been FULLY reset to zero. All scoreboards, tags, inventory, advancements, and XP cleared.",color:"red",bold:true}]
tellraw @a [{text:"[Admin] ",color:"dark_red"},{selector:"@s"},{text:" has been completely reset.",color:"gray"}]
playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.3 1.5