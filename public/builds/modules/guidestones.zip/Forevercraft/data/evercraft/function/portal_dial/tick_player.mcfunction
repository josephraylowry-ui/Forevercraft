# Portal Dial — Per-player tick (combines 3 @a scans into 1)

# Called only for players holding a portal dial (gated in portal_dial/tick)
# Cooldown decrement handled in parent tick function

# Check mainhand: has lodestone_tracker AND portal_dial BUT NOT yet portal_dial_bound
execute if items entity @s weapon.mainhand compass[custom_data~{portal_dial:true}] unless data entity @s SelectedItem.components."minecraft:custom_data".portal_dial_bound if data entity @s SelectedItem.components."minecraft:lodestone_tracker".target run function evercraft:portal_dial/bind_mainhand

# Check offhand: has lodestone_tracker AND portal_dial BUT NOT yet portal_dial_bound
execute if items entity @s weapon.offhand compass[custom_data~{portal_dial:true}] unless data entity @s equipment.offhand.components."minecraft:custom_data".portal_dial_bound if data entity @s equipment.offhand.components."minecraft:lodestone_tracker".target run function evercraft:portal_dial/bind_offhand
