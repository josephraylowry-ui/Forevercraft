# Portal Dial — Detection loop (now 1s schedule, OPT-5 Session 9)
# Detects when a Portal Dial first gets bound to a lodestone and charges 30 levels
# After first bind (30 levels), re-binding to different lodestones is free

# Reschedule first (guarantees we keep ticking regardless of gate)
schedule function evercraft:portal_dial/tick 1s

# Gate: skip logic if no players online
execute unless entity @a run return 0

# OPT: Only process players with active cooldown OR holding a portal dial
# Saves function call overhead for players without a dial (most players)
execute as @a[scores={ec.dial_cd=1..}] run scoreboard players remove @s ec.dial_cd 1
execute as @a if items entity @s weapon.mainhand compass[custom_data~{portal_dial:true}] run function evercraft:portal_dial/tick_player
execute as @a if items entity @s weapon.offhand compass[custom_data~{portal_dial:true}] run function evercraft:portal_dial/tick_player

