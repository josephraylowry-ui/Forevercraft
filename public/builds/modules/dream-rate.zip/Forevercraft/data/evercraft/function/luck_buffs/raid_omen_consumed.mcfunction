# Raid Omen Consumed — player HAD omen tag but effect is gone
# Run as: player who lost raid_omen effect
# OPT: Single function replaces 2 duplicate NBT reads per omen holder

# If near a village → real raid started
execute if score @s ec.current_village matches 1.. run tag @s add rp.raiding
# Clear omen tracker
tag @s remove rp.has_omen
