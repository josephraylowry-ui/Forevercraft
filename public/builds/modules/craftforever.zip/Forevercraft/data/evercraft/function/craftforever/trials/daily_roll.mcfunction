# Trade Trial — Roll a new daily challenge (on reload)
# Delegates to daily_roll_global for the actual roll, then announces
# Called from craftforever/load.mcfunction

function evercraft:craftforever/trials/daily_roll_global
function evercraft:craftforever/trials/daily_announce with storage evercraft:trials
