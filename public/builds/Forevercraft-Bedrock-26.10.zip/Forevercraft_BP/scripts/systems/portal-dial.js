/**
 * Portal Dial System — Teleport compass artifact.
 * Bind to lodestone (30 XP first time, free rebinds). Right-click to TP.
 * Shift+click with Guidestone binding opens remote Guidestone menu.
 * Replaces Java portal_dial/ folder (15 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const FIRST_BIND_XP_COST = 30;
const COOLDOWN_TICKS = 100; // 5 second cooldown

export class PortalDialSystem {
  constructor(eventBridge, guidestoneSystem) {
    this.eventBridge = eventBridge;
    this.guidestoneSystem = guidestoneSystem;
    this.cooldowns = new Map(); // playerId → expiry tick

    // Listen for item use events
    world.afterEvents.itemUse.subscribe((event) => {
      this.onItemUse(event);
    });

    // Listen for item use on block (lodestone binding)
    world.afterEvents.itemUseOn.subscribe((event) => {
      this.onItemUseOn(event);
    });
  }

  /**
   * Check if an item is a Portal Dial.
   */
  isPortalDial(item) {
    if (!item) return false;
    return item.typeId === "forevercraft:portal_dial";
  }

  /**
   * Handle right-click use of Portal Dial (teleport or remote menu).
   */
  onItemUse(event) {
    const player = event.source;
    const item = event.itemStack;

    if (!this.isPortalDial(item)) return;

    // Cooldown check
    const now = system.currentTick;
    const cd = this.cooldowns.get(player.id);
    if (cd && now < cd) {
      player.sendMessage("§7Portal Dial is recharging...");
      return;
    }

    // Set cooldown
    this.cooldowns.set(player.id, now + COOLDOWN_TICKS);

    const s = StorageManager.forPlayer(player);
    const boundX = s.get("pd_bound_x");
    const boundY = s.get("pd_bound_y");
    const boundZ = s.get("pd_bound_z");
    const boundDim = s.get("pd_bound_dim");
    const gsId = s.getNumber("pd_gs_id", 0);

    // Not bound yet
    if (boundX === undefined || boundDim === undefined) {
      player.sendMessage("§c§lYour Portal Dial is not bound to a location!");
      player.sendMessage("§7Right-click a lodestone or Guidestone to bind.");
      return;
    }

    // Shift+click with Guidestone binding → open remote menu
    if (player.isSneaking && gsId > 0) {
      this.openRemoteGuidestone(player, gsId);
      return;
    }

    // Shift+click with regular lodestone binding → suggest GS binding
    if (player.isSneaking && gsId === 0) {
      player.sendMessage("§7Bind to a Guidestone for remote network access!");
      return;
    }

    // === NORMAL TELEPORT ===

    // If bound to Guidestone, verify it still exists
    if (gsId > 0 && this.guidestoneSystem) {
      const gs = this.guidestoneSystem.getWaypointById(gsId);
      if (!gs) {
        player.sendMessage("§c§lThe Guidestone your Portal Dial was bound to has been destroyed!");
        return;
      }
    }

    // Teleport
    try {
      const dim = world.getDimension(boundDim);
      player.teleport(
        { x: boundX, y: boundY, z: boundZ },
        { dimension: dim }
      );

      // Effects
      player.playSound("mob.endermen.portal", { volume: 0.5, pitch: 0.5 });
      dim.runCommandAsync(
        `particle minecraft:portal ${boundX} ${boundY + 0.5} ${boundZ} 0.3 0.7 0.3 0 100`
      );

      player.sendMessage("§8▊ §6Warped to lodestone!");
    } catch (e) {
      player.sendMessage("§cTeleport failed! Location may be unloaded.");
    }
  }

  /**
   * Handle right-click on block (lodestone/guidestone binding).
   */
  onItemUseOn(event) {
    const player = event.source;
    const item = event.itemStack;
    const block = event.block;

    if (!this.isPortalDial(item)) return;
    if (!block) return;

    // Check if clicking a lodestone
    if (block.typeId === "minecraft:lodestone") {
      this.bindToLodestone(player, block);
      return;
    }

    // Check if clicking near a Guidestone (barrel with marker)
    if (this.guidestoneSystem && block.typeId === "minecraft:barrel") {
      // Check if there's a guidestone marker nearby
      const gs = this.guidestoneSystem.findNearestWaypoint(player, 8);
      if (gs) {
        this.bindToGuidestone(player, gs);
        return;
      }
    }
  }

  /**
   * Bind Portal Dial to a lodestone.
   */
  bindToLodestone(player, block) {
    const s = StorageManager.forPlayer(player);
    const alreadyBound = s.get("pd_ever_bound");

    // First bind costs 30 XP levels
    if (!alreadyBound) {
      const xpLevel = player.level;
      if (xpLevel < FIRST_BIND_XP_COST) {
        player.sendMessage(`§c§lYou need ${FIRST_BIND_XP_COST} levels to bind the Portal Dial!`);
        player.playSound("note.bass", { volume: 1, pitch: 0.5 });
        return;
      }
      // Deduct XP
      player.runCommandAsync(`xp -${FIRST_BIND_XP_COST}L @s`);
      s.set("pd_ever_bound", true);
    }

    // Store binding location
    s.set("pd_bound_x", block.location.x);
    s.set("pd_bound_y", block.location.y);
    s.set("pd_bound_z", block.location.z);
    s.set("pd_bound_dim", player.dimension.id);
    s.set("pd_gs_id", 0);
    s.set("pd_gs_name", "");

    // Feedback
    player.sendMessage("§6§lPortal Dial §7bound to lodestone!");
    if (!alreadyBound) {
      player.sendMessage("§7(30 levels consumed — future rebinds are free)");
    }
    player.playSound("block.end_portal.spawn", { volume: 0.5, pitch: 1.5 });
    player.playSound("block.beacon.activate", { volume: 0.5, pitch: 1.2 });
  }

  /**
   * Bind Portal Dial to a Guidestone.
   */
  bindToGuidestone(player, guidestone) {
    const s = StorageManager.forPlayer(player);
    const alreadyBound = s.get("pd_ever_bound");

    // First bind costs 30 XP levels
    if (!alreadyBound) {
      const xpLevel = player.level;
      if (xpLevel < FIRST_BIND_XP_COST) {
        player.sendMessage(`§c§lYou need ${FIRST_BIND_XP_COST} levels to bind the Portal Dial!`);
        player.playSound("note.bass", { volume: 1, pitch: 0.5 });
        return;
      }
      player.runCommandAsync(`xp -${FIRST_BIND_XP_COST}L @s`);
      s.set("pd_ever_bound", true);
    }

    // Store binding
    s.set("pd_bound_x", guidestone.x);
    s.set("pd_bound_y", guidestone.y);
    s.set("pd_bound_z", guidestone.z);
    s.set("pd_bound_dim", guidestone.dim || player.dimension.id);
    s.set("pd_gs_id", guidestone.id);
    s.set("pd_gs_name", guidestone.name || "Guidestone");

    // Feedback
    const gsName = guidestone.name || "Guidestone";
    player.sendMessage(`§6§lPortal Dial §7bound to §e${gsName}§7!`);
    if (!alreadyBound) {
      player.sendMessage("§7(30 levels consumed — future rebinds are free)");
    }
    player.sendMessage("§7Shift+click to open the remote Guidestone menu.");
    player.playSound("block.end_portal.spawn", { volume: 0.5, pitch: 1.5 });
    player.playSound("block.beacon.activate", { volume: 0.5, pitch: 1.2 });
  }

  /**
   * Open remote Guidestone menu via Portal Dial (shift+click).
   */
  openRemoteGuidestone(player, gsId) {
    if (!this.guidestoneSystem) {
      player.sendMessage("§cGuidestone system not available.");
      return;
    }

    // Verify guidestone still exists
    const gs = this.guidestoneSystem.getWaypointById(gsId);
    if (!gs) {
      player.sendMessage("§c§lThe Guidestone your Portal Dial was bound to has been destroyed!");
      return;
    }

    // Check if guidestone is primed
    if (gs.primed === false) {
      player.sendMessage("§cThis Guidestone hasn't been primed for interdimensional access!");
      return;
    }

    // Open the guidestone menu in remote mode
    player.addTag("ec.gs_remote_menu");
    player.playSound("block.portal.ambient", { volume: 0.3, pitch: 1.0 });

    // Delegate to guidestone system
    this.guidestoneSystem.openMenu(player, gsId);
  }

  /**
   * Open Portal Dial info menu.
   */
  openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const boundDim = s.get("pd_bound_dim");
    const gsId = s.getNumber("pd_gs_id", 0);
    const gsName = s.get("pd_gs_name") || "";

    let body = "§6§lPortal Dial\n§7Ancient Warping Device\n\n";

    if (!boundDim) {
      body += "§7Status: §cUnbound\n";
      body += "§7Right-click a lodestone to bind.\n";
      body += "§7First bind costs §c30 levels§7.\n";
    } else {
      body += "§7Status: §aBound\n";
      if (gsId > 0) {
        body += `§7Bound to: §e${gsName}\n`;
        body += "§7Shift+click to open remote menu.\n";
      } else {
        const x = Math.floor(s.get("pd_bound_x") || 0);
        const y = Math.floor(s.get("pd_bound_y") || 0);
        const z = Math.floor(s.get("pd_bound_z") || 0);
        body += `§7Location: §f${x}, ${y}, ${z}\n`;
        body += `§7Dimension: §f${boundDim.replace("minecraft:", "")}\n`;
      }
    }

    body += "\n§7Use to teleport to bound location.\n";
    body += "§7Rebinding to a new location is §afree§7.";

    const form = new ActionFormData()
      .title("§6⊛ Portal Dial")
      .body(body)
      .button("§7Close");

    form.show(player).then(() => {});
  }
}
