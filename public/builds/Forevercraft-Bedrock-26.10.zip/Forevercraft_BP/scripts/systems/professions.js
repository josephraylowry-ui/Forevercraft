/**
 * Profession System — Custom villager professions and trading.
 * Replaces Java professions/ folder (433 files).
 * 12 custom job roles with daily specials, berry upgrades, Wise Wanderer, and Artificer.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const PROFESSIONS = [
  { id: "blacksmith", name: "Blacksmith", icon: "⚒", color: "§6", desc: "Weapons and armor" },
  { id: "alchemist", name: "Alchemist", icon: "⚗", color: "§5", desc: "Potions and ingredients" },
  { id: "enchanter", name: "Enchanter", icon: "✦", color: "§b", desc: "Enchanted books and lapis" },
  { id: "farmer", name: "Farmer", icon: "🌾", color: "§2", desc: "Crops and food" },
  { id: "miner", name: "Miner", icon: "⛏", color: "§7", desc: "Ores and minerals" },
  { id: "explorer", name: "Expeditionist", icon: "🧭", color: "§e", desc: "Maps and rare items" },
  { id: "fisher", name: "Fisher", icon: "🎣", color: "§3", desc: "Fish and aquatic items" },
  { id: "builder", name: "Builder", icon: "🏗", color: "§f", desc: "Building materials" },
  { id: "lumberjack", name: "Lumberjack", icon: "🪓", color: "§4", desc: "Wood and tools" },
  { id: "shepherd", name: "Shepherd", icon: "🐑", color: "§d", desc: "Wool and dyes" },
  { id: "cook", name: "Cook", icon: "🍳", color: "§c", desc: "Prepared meals" },
  { id: "jeweler", name: "Jeweler", icon: "💎", color: "§a", desc: "Gems and accessories" },
];

// 13 Glyph definitions for Artificer buy trades
const ARTIFICER_GLYPHS = [
  { id: "ec.ember",   name: "Emberheart Glyph" },
  { id: "ec.verdant", name: "Verdant Glyph" },
  { id: "ec.quick",   name: "Quicksilver Glyph" },
  { id: "ec.obsidian", name: "Obsidian Glyph" },
  { id: "ec.zephyr",  name: "Zephyr Glyph" },
  { id: "ec.briar",   name: "Briar Glyph" },
  { id: "ec.stalwart", name: "Stalwart Glyph" },
  { id: "ec.gilded",  name: "Gilded Glyph" },
  { id: "ec.tide",    name: "Tidecall Glyph" },
  { id: "ec.hearth",  name: "Hearthstone Glyph" },
  { id: "ec.prism",   name: "Prism Glyph" },
  { id: "ec.tempest", name: "Tempest Glyph" },
  { id: "ec.arcanum", name: "Arcanum Glyph" },
];

// Daily special items rotate each day
const DAILY_SPECIALS = [
  { item: "minecraft:enchanted_golden_apple", name: "Enchanted Golden Apple", price: 64 },
  { item: "minecraft:totem_of_undying", name: "Totem of Undying", price: 48 },
  { item: "minecraft:netherite_ingot", name: "Netherite Ingot", price: 32 },
  { item: "minecraft:elytra", name: "Elytra", price: 128 },
  { item: "minecraft:trident", name: "Trident", price: 96 },
  { item: "minecraft:heart_of_the_sea", name: "Heart of the Sea", price: 48 },
  { item: "minecraft:nether_star", name: "Nether Star", price: 64 },
];

export class ProfessionSystem {
  constructor(eventBridge) {
    this.dailySpecialIndex = 0;

    // Track villager interactions
    world.afterEvents.playerInteractWithEntity.subscribe((event) => {
      const entity = event.target;
      if (entity?.typeId === "minecraft:villager" || entity?.typeId === "minecraft:wandering_trader") {
        // Check for Wise Wanderer tag
        if (entity.hasTag?.("ec.wise_wanderer")) {
          this.openWiseWanderer(event.player);
        }
        // Check for Artificer tag
        if (entity.hasTag?.("ec.artificer")) {
          this.openArtificer(event.player);
        }
      }
    });
  }

  /** Open profession menu for player */
  openProfessionMenu(player) {
    const s = StorageManager.forPlayer(player);
    const currentProf = s.get("profession") || "none";

    const form = new ActionFormData()
      .title("Professions")
      .body(currentProf !== "none"
        ? `§7Current profession: §f${PROFESSIONS.find(p => p.id === currentProf)?.name || currentProf}\n\n§7Choose a profession to specialize in:`
        : "§7Choose a profession to begin your career:");

    for (const prof of PROFESSIONS) {
      form.button(`${prof.color}${prof.icon} ${prof.name}\n§7${prof.desc}`);
    }

    form.show(player).then(response => {
      if (response.canceled) return;
      const selected = PROFESSIONS[response.selection];
      if (selected) this.selectProfession(player, selected);
    });
  }

  selectProfession(player, prof) {
    const s = StorageManager.forPlayer(player);
    s.set("profession", prof.id);
    s.set("profession_level", s.getNumber("profession_level") || 1);
    player.sendMessage(`${prof.color}§l${prof.icon} ${prof.name} §r§7profession selected!`);
    player.sendMessage(`§7${prof.desc}`);
    player.playSound("random.levelup");
  }

  /** Wise Wanderer special NPC */
  openWiseWanderer(player) {
    const s = StorageManager.forPlayer(player);
    const talked = s.getNumber("ww_talked") || 0;

    const form = new ActionFormData()
      .title("§6Wise Wanderer")
      .body("§7§oAh, a fellow traveler. I have wisdom to share...\n\n§7I can offer you today's daily special, or share knowledge about the world.")
      .button("§eDaily Special")
      .button("§bWorld Lore")
      .button("§dDream Rate Info");

    form.show(player).then(response => {
      if (response.canceled) return;
      s.set("ww_talked", talked + 1);
      switch (response.selection) {
        case 0: this.showDailySpecial(player); break;
        case 1: this.shareLore(player); break;
        case 2: this.dreamRateInfo(player); break;
      }
    });
  }

  showDailySpecial(player) {
    const special = DAILY_SPECIALS[this.dailySpecialIndex % DAILY_SPECIALS.length];
    player.sendMessage(`§6§l✦ Today's Special: §r§e${special.name}`);
    player.sendMessage(`§7Price: §f${special.price} emeralds`);
  }

  shareLore(player) {
    const loreSnippets = [
      "§7§oThe Dreaming Realm holds secrets beyond mortal understanding...",
      "§7§oArtifacts grow more powerful with time. Let them age.",
      "§7§oPatron mobs carry the essence of ancient power.",
      "§7§oThe moon phases influence the strength of night terrors.",
      "§7§oSet bonuses from matching armor unlock devastating abilities.",
    ];
    const snippet = loreSnippets[Math.floor(Math.random() * loreSnippets.length)];
    player.sendMessage(snippet);
  }

  dreamRateInfo(player) {
    const s = StorageManager.forPlayer(player);
    const dr = s.getNumber("dream_rate") || 0;
    player.sendMessage(`§d§lDream Rate: §r§f${dr}`);
    player.sendMessage("§7Dream Rate increases from exploration, combat, and milestones.");
    player.sendMessage("§7Higher DR means better treasure, but stronger night terrors.");
  }

  /** Artificer special NPC — crate sales, lore shard exchanges, glyph buying */
  openArtificer(player) {
    const form = new ActionFormData()
      .title("§6⚙ Artificer")
      .body("§7§oI deal in artifacts, crates, and glyphs.\n\n§7What can I help you with?")
      .button("§eSell Glyphs\n§7Trade glyphs for netherite scraps")
      .button("§bLore Shard Exchange\n§74 Lore Shards → 1 Tree Token")
      .button("§7Close");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 2) return;
      switch (response.selection) {
        case 0: this.openGlyphSellMenu(player); break;
        case 1: this.doLoreShardExchange(player); break;
      }
    });
  }

  /** Artificer: Sell glyphs for netherite scraps */
  openGlyphSellMenu(player) {
    const form = new ActionFormData()
      .title("§6Sell Glyphs")
      .body("§7Select a glyph to sell for §f1 Netherite Scrap§7.\n§8You must have the glyph in your inventory.");

    for (const glyph of ARTIFICER_GLYPHS) {
      form.button(`§e${glyph.name}\n§7→ 1 Netherite Scrap`);
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection < ARTIFICER_GLYPHS.length) {
        this.sellGlyph(player, ARTIFICER_GLYPHS[response.selection]);
      } else {
        this.openArtificer(player);
      }
    });
  }

  /** Execute glyph → netherite scrap trade */
  sellGlyph(player, glyph) {
    // Try to find and remove the glyph from inventory
    const inv = player.getComponent("minecraft:inventory");
    if (!inv) return;
    const container = inv.container;
    let found = false;

    for (let i = 0; i < container.size; i++) {
      const item = container.getItem(i);
      if (!item) continue;
      // Check if item has the matching rune tag
      const tags = item.getTags?.() || [];
      const hasGlyphTag = tags.some(t => t.includes(glyph.id) || t.includes("ec.rune"));
      const nameMatch = item.nameTag?.includes(glyph.name);
      if (hasGlyphTag || nameMatch) {
        // Remove one glyph
        if (item.amount > 1) {
          item.amount -= 1;
          container.setItem(i, item);
        } else {
          container.setItem(i, undefined);
        }
        found = true;
        break;
      }
    }

    if (found) {
      try {
        player.runCommandAsync("give @s netherite_scrap 1");
        player.sendMessage(`§6§l✦ Trade Complete! §r§7Sold §e${glyph.name} §7for §f1 Netherite Scrap§7.`);
        player.playSound("random.orb", { volume: 0.5, pitch: 1.2 });
      } catch {}
    } else {
      player.sendMessage(`§c§l✗ §r§7You don't have a §e${glyph.name} §7in your inventory.`);
      player.playSound("note.bass", { volume: 0.5, pitch: 0.5 });
    }
    // Return to glyph menu
    this.openGlyphSellMenu(player);
  }

  /** Lore Shard exchange: 4 Lore Shards → 1 Tree Token */
  doLoreShardExchange(player) {
    const inv = player.getComponent("minecraft:inventory");
    if (!inv) return;
    const container = inv.container;
    let shardCount = 0;
    const shardSlots = [];

    for (let i = 0; i < container.size; i++) {
      const item = container.getItem(i);
      if (!item) continue;
      const tags = item.getTags?.() || [];
      if (tags.some(t => t.includes("lore_shard")) || item.typeId?.includes("lore_shard")) {
        shardCount += item.amount;
        shardSlots.push({ slot: i, item });
      }
    }

    if (shardCount >= 4) {
      // Remove 4 shards
      let toRemove = 4;
      for (const { slot, item } of shardSlots) {
        if (toRemove <= 0) break;
        const remove = Math.min(toRemove, item.amount);
        if (remove >= item.amount) {
          container.setItem(slot, undefined);
        } else {
          item.amount -= remove;
          container.setItem(slot, item);
        }
        toRemove -= remove;
      }
      // Give tree token
      try {
        player.runCommandAsync("give @s forevercraft:tree_token 1");
        player.sendMessage("§6§l✦ Exchange Complete! §r§74 Lore Shards → §a1 Tree Token§7.");
        player.playSound("random.orb", { volume: 0.5, pitch: 1.2 });
      } catch {}
    } else {
      player.sendMessage(`§c§l✗ §r§7You need §f4 Lore Shards §7(you have §f${shardCount}§7).`);
      player.playSound("note.bass", { volume: 0.5, pitch: 0.5 });
    }
  }

  /** Per-minute tick: rotate daily special */
  tick(players) {
    const day = world.getDay();
    this.dailySpecialIndex = day % DAILY_SPECIALS.length;
  }
}
