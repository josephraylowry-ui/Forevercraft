/**
 * Treasure System — Mining-based treasure drops with 6 rarity tiers.
 * Replaces Java treasure/ folder (1,847 files).
 * Detects ore/stone mining and rolls for artifact drops.
 *
 * Updates:
 * - Depth multiplier (deeper Y = better chance)
 * - Frequency settings (minimal/low/standard/high/extreme)
 * - Despawn timing settings (standard/fast/hypersonic)
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Depth bonus tiers — deeper mining = better treasure
const DEPTH_BONUS = [
  { maxY: 320, mult: 0.5 },  // Sky — halved chance
  { maxY: 64,  mult: 1.0 },  // Surface — normal
  { maxY: 32,  mult: 1.2 },  // Shallow cave
  { maxY: 0,   mult: 1.5 },  // Deep cave
  { maxY: -32, mult: 2.0 },  // Deep dark range
  { maxY: -64, mult: 2.5 },  // Deepest
];

// Frequency settings (world-level, adjustable)
const FREQUENCY_PRESETS = {
  minimal:  0.25,
  low:      0.5,
  standard: 1.0,
  high:     1.5,
  extreme:  2.0,
};

// Ore types and their relative treasure chance multipliers
const ORE_CHANCES = {
  "minecraft:stone": 1,
  "minecraft:deepslate": 1,
  "minecraft:andesite": 1,
  "minecraft:diorite": 1,
  "minecraft:granite": 1,
  "minecraft:tuff": 1,
  "minecraft:calcite": 1,
  "minecraft:dripstone_block": 2,
  "minecraft:coal_ore": 3,
  "minecraft:deepslate_coal_ore": 3,
  "minecraft:iron_ore": 4,
  "minecraft:deepslate_iron_ore": 4,
  "minecraft:copper_ore": 4,
  "minecraft:deepslate_copper_ore": 4,
  "minecraft:gold_ore": 6,
  "minecraft:deepslate_gold_ore": 6,
  "minecraft:lapis_ore": 6,
  "minecraft:deepslate_lapis_ore": 6,
  "minecraft:redstone_ore": 5,
  "minecraft:deepslate_redstone_ore": 5,
  "minecraft:diamond_ore": 10,
  "minecraft:deepslate_diamond_ore": 10,
  "minecraft:emerald_ore": 12,
  "minecraft:deepslate_emerald_ore": 12,
  "minecraft:nether_gold_ore": 5,
  "minecraft:nether_quartz_ore": 4,
  "minecraft:ancient_debris": 20,
  "minecraft:amethyst_block": 3,
  "minecraft:amethyst_cluster": 8,
};

// Rarity tiers with base drop chance (per 10000)
const RARITY_TIERS = [
  { name: "common", chance: 500, color: "§f", loot: "artifacts/common/main" },
  { name: "uncommon", chance: 200, color: "§e", loot: "artifacts/uncommon/main" },
  { name: "rare", chance: 80, color: "§b", loot: "artifacts/rare/main" },
  { name: "ornate", chance: 30, color: "§5", loot: "artifacts/ornate/main" },
  { name: "exquisite", chance: 10, color: "§6", loot: "artifacts/exquisite/main" },
  { name: "mythical", chance: 3, color: "§c", loot: "artifacts/mythical/main" },
];

// Rune types and effects
const RUNES = {
  pearl: { name: "Pearl Rune", effect: "luck", duration: 600, amplifier: 0, color: "§f" },
  sponge: { name: "Sponge Rune", effect: "water_breathing", duration: 600, amplifier: 0, color: "§e" },
  ice: { name: "Ice Rune", effect: "fire_resistance", duration: 600, amplifier: 0, color: "§b" },
  assassin: { name: "Assassin Rune", effect: "speed", duration: 300, amplifier: 1, color: "§c" },
  jungle: { name: "Jungle Rune", effect: "regeneration", duration: 300, amplifier: 0, color: "§2" },
  black: { name: "Black Rune", effect: "night_vision", duration: 600, amplifier: 0, color: "§8" },
};

export class TreasureSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.storage = StorageManager.world();

    // Block break event
    eventBridge.on("block_break", (player, block) => {
      this.onBlockBreak(player, block);
    });

    // Also listen via afterEvents
    world.afterEvents.playerBreakBlock.subscribe((event) => {
      const blockType = event.brokenBlockPermutation?.type?.id;
      if (blockType && ORE_CHANCES[blockType]) {
        this.onBlockBreak(event.player, { typeId: blockType, location: event.block.location, dimension: event.block.dimension });
      }
    });
  }

  onBlockBreak(player, block) {
    const blockId = block.typeId || block?.type?.id;
    if (!blockId) return;
    const chanceMultiplier = ORE_CHANCES[blockId];
    if (!chanceMultiplier) return;

    const s = StorageManager.forPlayer(player);

    // Track blocks mined
    const mined = s.getNumber("blocks_mined") + 1;
    s.set("blocks_mined", mined);

    // Dream Rate bonus (higher DR = better treasure chance)
    const dreamRate = s.getNumber("dream_rate") || 0;
    const drBonus = Math.floor(dreamRate / 10); // +1% per 10 DR

    // Depth bonus (deeper = better)
    const y = block.location?.y ?? player.location.y;
    let depthMult = 1.0;
    for (const tier of DEPTH_BONUS) {
      if (y <= tier.maxY) depthMult = tier.mult;
    }

    // Frequency setting (world-level)
    const freqSetting = this.storage.getString("treasure_frequency", "standard");
    const freqMult = FREQUENCY_PRESETS[freqSetting] || 1.0;

    // Roll for treasure
    const roll = Math.random() * 10000;
    let threshold = 0;

    for (const tier of RARITY_TIERS) {
      const adjustedChance = tier.chance * chanceMultiplier * depthMult * freqMult * (1 + drBonus * 0.01);
      threshold += adjustedChance;
      if (roll < threshold) {
        this.dropTreasure(player, block, tier);
        return;
      }
    }

    // Rune drop chance (separate, very rare)
    if (Math.random() < 0.001 * chanceMultiplier) {
      this.dropRune(player);
    }
  }

  dropTreasure(player, block, tier) {
    const loc = block.location || player.location;
    try {
      player.dimension.runCommandAsync(
        `loot spawn ${loc.x} ${loc.y + 1} ${loc.z} loot "${tier.loot}"`
      );
    } catch {}

    player.sendMessage(`${tier.color}§l✦ ${tier.name.charAt(0).toUpperCase() + tier.name.slice(1)} Treasure §r§7found!`);
    player.playSound("random.levelup");

    // Track
    const s = StorageManager.forPlayer(player);
    const count = s.getNumber(`${tier.name}_found`) + 1;
    s.set(`${tier.name}_found`, count);
    s.set("crates_mining", s.getNumber("crates_mining") + 1);
    s.set("crates_opened", s.getNumber("crates_opened") + 1);
    this.eventBridge.emit("crate_opened", player, "mining", tier.name);

    console.log(`[Treasure] ${player.name} found ${tier.name} treasure from mining`);
  }

  dropRune(player) {
    const runeKeys = Object.keys(RUNES);
    const runeKey = runeKeys[Math.floor(Math.random() * runeKeys.length)];
    const rune = RUNES[runeKey];

    player.runCommandAsync(`effect @s ${rune.effect} ${rune.duration} ${rune.amplifier}`);
    player.sendMessage(`${rune.color}§l✦ ${rune.name} §r§7activated!`);
    player.playSound("random.orb");
  }

  /** Set treasure frequency (admin/settings command) */
  setFrequency(preset) {
    if (!FREQUENCY_PRESETS[preset]) return false;
    this.storage.set("treasure_frequency", preset);
    return true;
  }

  /** Get current frequency setting */
  getFrequency() {
    return this.storage.getString("treasure_frequency", "standard");
  }

  /** Open treasure settings form */
  async openSettings(player) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    const current = this.getFrequency();

    const form = new ActionFormData()
      .title("§l§6Treasure Settings")
      .body(`§7Current frequency: §f${current}\n\n§7Affects how often treasures drop from mining.`);

    for (const [key, mult] of Object.entries(FREQUENCY_PRESETS)) {
      const label = key === current ? `§a✓ ${key} §7(${mult}x)` : `§f${key} §7(${mult}x)`;
      form.button(label);
    }

    const res = await form.show(player);
    if (res.canceled) return;

    const keys = Object.keys(FREQUENCY_PRESETS);
    if (res.selection < keys.length) {
      this.setFrequency(keys[res.selection]);
      player.sendMessage(`§eTreasure frequency set to §f${keys[res.selection]}`);
    }
  }
}
