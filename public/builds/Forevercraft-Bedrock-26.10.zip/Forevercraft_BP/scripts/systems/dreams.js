/**
 * Dreams System — Dream Rate tracking & milestones (compiled JS)
 * Crash-proof: reapplies all permanent DR effects on join/death.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { showActionForm } from "./gui-manager.js";

const DR_WEIGHTS = {
  artifact_collected: 5, lore_discovered: 3, pet_befriended: 10,
  quest_completed: 8, achievement_earned: 15, biome_mastered: 12,
  structure_explored: 4, boss_defeated: 20, constellation_completed: 25,
  recipe_discovered: 2,
};

// Items that grant permanent DR effects (luck effect at various amplifiers)
// Maps storage key → { effect amplifier, duration (999999 = "permanent") }
const PERMANENT_DR_EFFECTS = [
  { key: "dreamdust_crystal_active", effect: "luck", amplifier: 2 },
  { key: "dream_sight_active", effect: "night_vision", amplifier: 0 },
  { key: "dream_walk_active", effect: "speed", amplifier: 1 },
];

const MILESTONES = [
  { threshold: 50, name: "Awakening", reward: "First dream fragment" },
  { threshold: 100, name: "Lucidity", reward: "Dream sight ability" },
  { threshold: 200, name: "Resonance", reward: "Dream echo weapon" },
  { threshold: 350, name: "Transcendence", reward: "Dream walk ability" },
  { threshold: 500, name: "Ascension", reward: "Dreaming Realm access" },
  { threshold: 750, name: "Enlightenment", reward: "Dream forge unlock" },
  { threshold: 1000, name: "Omniscience", reward: "Master dreamer title" },
];

export class DreamsSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    eventBridge.on("player_killed_entity", (player, entity) => {
      if (entity.hasTag?.("wb.boss")) this.addDreamRate(player, DR_WEIGHTS.boss_defeated);
    });

    // Reapply DR on death (1-tick delay so respawn completes first)
    eventBridge.on("player_death", (player) => {
      system.runTimeout(() => {
        try { this.reapplyPermanentDR(player); } catch {}
      }, 20); // 1 second after respawn
    });

    // Listen for dream_rate_changed from other systems (e.g., gacha Dreamdust Crystal)
    eventBridge.on("dream_rate_changed", (player) => {
      this.recalculateAndStore(player);
    });
  }

  /**
   * Crash-proof reapply: recalculates DR from all persistent sources,
   * reapplies all permanent effects that should be active.
   * Called on player join and after death respawn.
   */
  reapplyPermanentDR(player) {
    const s = StorageManager.forPlayer(player);

    // Recalculate and persist current DR
    const dr = this.calculateDreamRate(player);
    s.set("dream_rate", dr);

    // Reapply all permanent effects that are flagged as active
    for (const entry of PERMANENT_DR_EFFECTS) {
      if (s.get(entry.key)) {
        try {
          player.runCommandAsync(
            `effect @s ${entry.effect} 999999 ${entry.amplifier} true`
          );
        } catch {}
      }
    }

    // Reapply dream milestone effects based on current DR
    if (dr >= 100) {
      // Lucidity milestone: dream sight (night vision)
      s.set("dream_sight_active", true);
      try { player.runCommandAsync("effect @s night_vision 999999 0 true"); } catch {}
    }
    if (dr >= 350) {
      // Transcendence milestone: dream walk (speed boost)
      s.set("dream_walk_active", true);
      try { player.runCommandAsync("effect @s speed 999999 1 true"); } catch {}
    }
  }

  /** Recalculate DR from all sources and store */
  recalculateAndStore(player) {
    const s = StorageManager.forPlayer(player);
    const dr = this.calculateDreamRate(player);
    s.set("dream_rate", dr);
    this.checkMilestones(player, dr);
  }

  calculateDreamRate(player) {
    const s = StorageManager.forPlayer(player);
    let total = 0;
    total += s.getNumber("artifacts_collected") * DR_WEIGHTS.artifact_collected;
    total += s.getNumber("lore_collected") * DR_WEIGHTS.lore_discovered;
    total += s.getNumber("pets_befriended") * DR_WEIGHTS.pet_befriended;
    total += s.getNumber("quests_completed") * DR_WEIGHTS.quest_completed;
    total += s.getNumber("achievements_earned") * DR_WEIGHTS.achievement_earned;
    total += s.getNumber("biomes_mastered") * DR_WEIGHTS.biome_mastered;
    total += s.getNumber("structures_explored") * DR_WEIGHTS.structure_explored;
    total += s.getNumber("bosses_defeated") * DR_WEIGHTS.boss_defeated;
    total += s.getNumber("constellations_completed") * DR_WEIGHTS.constellation_completed;
    total += s.getNumber("recipes_discovered") * DR_WEIGHTS.recipe_discovered;
    total += s.getNumber("dr_consumable_bonus");
    return total;
  }

  addDreamRate(player, amount) {
    const s = StorageManager.forPlayer(player);
    const bonus = s.getNumber("dr_consumable_bonus");
    s.set("dr_consumable_bonus", bonus + amount);
    const newDR = this.calculateDreamRate(player);
    s.set("dream_rate", newDR);
    this.checkMilestones(player, newDR);
  }

  checkMilestones(player, newDR) {
    const s = StorageManager.forPlayer(player);
    const peak = s.getNumber("dr_peak");
    if (newDR > peak) {
      s.set("dr_peak", newDR);
      for (const ms of MILESTONES) {
        if (newDR >= ms.threshold && peak < ms.threshold) {
          player.onScreenDisplay.setTitle(`§d✦ ${ms.name} ✦`, {
            subtitle: "§7Dream Rate milestone reached!",
            fadeInDuration: 20, stayDuration: 100, fadeOutDuration: 20,
          });
          player.sendMessage(`§d§l✦ Dream Milestone: ${ms.name}§r\n§7Reward: §e${ms.reward}`);
        }
      }
    }
  }

  async showDreamRate(player) {
    const dr = this.calculateDreamRate(player);
    const s = StorageManager.forPlayer(player);
    let current = "None", next = MILESTONES[0];
    for (const ms of MILESTONES) {
      if (dr >= ms.threshold) { current = ms.name; next = MILESTONES[MILESTONES.indexOf(ms) + 1] || ms; }
    }
    const pct = next ? Math.min(100, Math.floor((dr / next.threshold) * 100)) : 100;
    const constDone = s.getNumber("constellations_completed", 0);
    let body = `§eDream Rate: §f${dr}\n`;
    body += `§7Milestone: §d${current}\n`;
    body += `§7Next: §d${next?.name || "MAX"} §7(${pct}%)\n\n`;
    body += `§7Artifacts: §f${s.getNumber("artifacts_collected")}\n`;
    body += `§7Lore: §f${s.getNumber("lore_collected")}\n`;
    body += `§7Pets: §f${s.getNumber("pets_befriended")}\n`;
    body += `§7Constellations: §f${constDone}/10\n`;
    body += `§7Biomes Mastered: §f${s.getNumber("biomes_mastered", 0)}\n`;
    body += `§7Bosses Defeated: §f${s.getNumber("bosses_defeated", 0)}\n`;
    body += `§7Peak DR: §f${s.getNumber("dr_peak", 0)}\n`;
    const { ActionFormData } = await import("@minecraft/server-ui");
    const form = new ActionFormData()
      .title("§dDream Rate")
      .body(body)
      .button("§5DR Leaderboard")
      .button("§7Close");
    const res = await form.show(player);
    if (res.selection === 0) this.showLeaderboard(player);
  }

  /** Show DR leaderboard — top 10 players by Dream Rate */
  async showLeaderboard(player) {
    const players = world.getAllPlayers();
    const entries = [];
    for (const p of players) {
      const dr = this.calculateDreamRate(p);
      entries.push({ name: p.name, dr });
    }
    entries.sort((a, b) => b.dr - a.dr);
    let body = "§d§lDream Rate Leaderboard\n\n";
    const top = entries.slice(0, 10);
    for (let i = 0; i < top.length; i++) {
      const medal = i === 0 ? "§6" : i === 1 ? "§f" : i === 2 ? "§c" : "§7";
      body += `${medal}#${i + 1} §f${top[i].name} §7— §d${top[i].dr}\n`;
    }
    if (entries.length === 0) body += "§7No players online.\n";
    await showActionForm(player, "§dDR Leaderboard", body, [{ text: "§7Back" }]);
  }
}
