/**
 * Codex System — Artifact collection browser and hub menu.
 * 292 artifacts across 6 rarity tiers (Common→Mythical).
 * 9 hub sections: Artifacts, Advantages, Challenges, Constellations, Journal,
 *   Lore, Classes, Career Stats, Help Guide.
 * Replaces Java codex/ folder (680 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";
import { ARTIFACTS } from "../data/artifact-registry.js";
import { getArtifactDescription, formatDescription } from "../data/artifact-descriptions.js";

// Click cooldown to prevent double-opens (20 ticks = 1 second)
const CODEX_COOLDOWN = 20;

// Rarity tiers
const RARITIES = [
  { id: "common", name: "Common", color: "§7", count: 13 },
  { id: "uncommon", name: "Uncommon", color: "§a", count: 13 },
  { id: "rare", name: "Rare", color: "§b", count: 20 },
  { id: "ornate", name: "Ornate", color: "§d", count: 109 },
  { id: "exquisite", name: "Exquisite", color: "§5", count: 60 },
  { id: "mythical", name: "Mythical", color: "§6", count: 77 },
];

const TOTAL_ARTIFACTS = 292;

// Artifact categories
const CATEGORIES = ["Weapons", "Armor", "Accessories", "Tools"];

export class CodexSystem {
  constructor(eventBridge, systems) {
    this.eventBridge = eventBridge;
    this.systems = systems; // references to other systems for hub delegation
    this.lastOpenTick = new Map(); // playerId → tick (cooldown tracking)

    // Listen for artifact collection to auto-give codex
    eventBridge.on("artifact_collected", (player, artifactId) => {
      this.onArtifactCollected(player, artifactId);
    });

    // Listen for codex item use
    world.afterEvents.itemUse.subscribe((event) => {
      if (event.itemStack?.typeId === "forevercraft:codex") {
        this.openHub(event.source);
      }
    });
  }

  /**
   * Handle artifact collection — increment count, auto-give codex if first.
   */
  onArtifactCollected(player, artifactId) {
    const storage = StorageManager.forPlayer(player);
    storage.set(`art_${artifactId}`, 1);

    // Recount artifacts
    const count = this.countArtifacts(player);
    storage.set("artifacts_collected", count);

    // First artifact — give codex item
    if (count === 1) {
      try {
        player.dimension.runCommandAsync(
          `give "${player.name}" forevercraft:codex 1`
        );
      } catch {}
      player.sendMessage("§6§l✦ New Codex Entry! §r§7You received the Forevercraft Codex.");
    } else {
      player.sendMessage("§6§l✦ New Codex Entry!");
    }

    try {
      player.playSound("random.toast", { volume: 0.5, pitch: 1.0 });
    } catch {}
  }

  /**
   * Count total collected artifacts.
   */
  countArtifacts(player) {
    const storage = StorageManager.forPlayer(player);
    return storage.getNumber("artifacts_collected", 0);
  }

  /**
   * Open the main Codex hub.
   */
  openHub(player) {
    // Click cooldown
    const now = system.currentTick;
    const lastOpen = this.lastOpenTick.get(player.id) || 0;
    if (now - lastOpen < CODEX_COOLDOWN) return;
    this.lastOpenTick.set(player.id, now);

    const storage = StorageManager.forPlayer(player);
    const collected = storage.getNumber("artifacts_collected", 0);

    const form = new ActionFormData()
      .title("§6✦ The Forevercraft Codex ✦")
      .body(`§7Artifacts Collected: §e${collected}/${TOTAL_ARTIFACTS}\n\n§7Choose a section to explore:`)
      .button("§e⊞ Artifact Browser")
      .button("§d⊕ Advantage Trees")
      .button("§b☆ Challenges")
      .button("§5✦ Constellations")
      .button("§a✎ Travel Journal")
      .button("§6✉ Lore Discovery")
      .button("§c⚔ Classes")
      .button("§3♦ Career Stats")
      .button("§2⚔ Guild")
      .button("§4☠ Bestiary")
      .button("§f? Help Guide")
      .button("§7Close");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 11) return;
      switch (r.selection) {
        case 0: this.openArtifactBrowser(player); break;
        case 1: this.systems.advantages?.openMenu?.(player); break;
        case 2: this.openChallenges(player); break;
        case 3: this.systems.constellations?.openMenu?.(player); break;
        case 4: this.systems.journal?.openMenu?.(player); break;
        case 5: this.systems.lore?.openMenu?.(player); break;
        case 6: this.openClasses(player); break;
        case 7: this.systems.stats?.openMenu?.(player); break;
        case 8: this.systems.guild?.openGuildMenu?.(player); break;
        case 9: this.systems.bestiary?.openBestiary?.(player); break;
        case 10: this.openHelpGuide(player); break;
      }
    });
  }

  /**
   * Open artifact browser — browse by rarity tier.
   */
  openArtifactBrowser(player) {
    const storage = StorageManager.forPlayer(player);

    let body = "§7Browse artifacts by rarity:\n\n";
    for (const r of RARITIES) {
      const collected = storage.getNumber(`art_count_${r.id}`, 0);
      body += `${r.color}${r.name}: §f${collected}/${r.count}\n`;
    }

    const form = new ActionFormData()
      .title("§6Artifact Browser")
      .body(body);

    for (const r of RARITIES) {
      form.button(`${r.color}${r.name}`);
    }
    form.button("§7← Back");

    form.show(player).then((r) => {
      if (r.canceled) return;
      if (r.selection < RARITIES.length) {
        this.openRarityPage(player, RARITIES[r.selection]);
      } else {
        this.openHub(player);
      }
    });
  }

  /**
   * Open a rarity page showing categories.
   */
  openRarityPage(player, rarity) {
    const form = new ActionFormData()
      .title(`${rarity.color}${rarity.name} Artifacts`)
      .body(`§7Browse ${rarity.name} artifacts by category:`);

    for (const cat of CATEGORIES) {
      form.button(`§e${cat}`);
    }
    form.button("§7← Back");

    form.show(player).then((r) => {
      if (r.canceled) return;
      if (r.selection < CATEGORIES.length) {
        this.openCategoryPage(player, rarity, CATEGORIES[r.selection]);
      } else {
        this.openArtifactBrowser(player);
      }
    });
  }

  /**
   * Open a category page listing discovered artifacts with descriptions.
   */
  openCategoryPage(player, rarity, category) {
    const storage = StorageManager.forPlayer(player);
    const tierName = rarity.name.toLowerCase();

    // Map category to base item types
    const categoryFilters = {
      "Weapons": ["sword", "axe", "mace", "bow", "crossbow", "trident", "spear"],
      "Armor": ["helmet", "chestplate", "leggings", "boots", "elytra"],
      "Accessories": ["rabbit_foot", "flint", "feather", "compass", "clock", "glowstone_dust",
                       "iron_nugget", "gold_nugget", "paper", "sugar", "echo_shard", "amethyst_shard",
                       "nether_star", "heart_of_the_sea", "totem_of_undying", "dragon_breath",
                       "phantom_membrane", "breeze_rod", "blaze_powder", "ghast_tear", "ender_pearl",
                       "ender_eye", "nautilus_shell", "prismarine_shard", "shulker_shell"],
      "Tools": ["pickaxe", "shovel", "hoe", "fishing_rod", "shears"],
    };

    const filters = categoryFilters[category] || [];

    // Find matching artifacts from registry
    const matching = ARTIFACTS.filter(a => {
      if (a.tier !== tierName) return false;
      const base = a.baseItem?.replace("minecraft:", "") || "";
      return filters.some(f => base.includes(f));
    });

    if (matching.length === 0) {
      const form = new ActionFormData()
        .title(`${rarity.color}${rarity.name} ${category}`)
        .body(`§7No ${rarity.name} ${category} found.`)
        .button("§7← Back");
      form.show(player).then(() => this.openRarityPage(player, rarity));
      return;
    }

    // Build list — show discovered vs undiscovered
    const form = new ActionFormData()
      .title(`${rarity.color}${rarity.name} ${category}`);

    let body = `§7${matching.length} artifacts in this category:\n\n`;
    const displayList = [];

    for (const art of matching) {
      const discovered = storage.get(`art_${art.id}`);
      const desc = getArtifactDescription(art.id);
      if (discovered) {
        body += `${rarity.color}✦ §f${art.name}${desc ? " §a[i]" : ""}\n`;
        displayList.push(art);
      } else {
        body += `§8✗ ???\n`;
      }
    }

    form.body(body);

    // Add buttons for discovered artifacts that have descriptions
    for (const art of displayList) {
      form.button(`${rarity.color}${art.name}`);
    }
    form.button("§7← Back");

    form.show(player).then((r) => {
      if (r.canceled) return;
      if (r.selection < displayList.length) {
        this.showArtifactDetail(player, displayList[r.selection], rarity, category);
      } else {
        this.openRarityPage(player, rarity);
      }
    });
  }

  /**
   * Show detailed artifact description page.
   */
  showArtifactDetail(player, artifact, rarity, category) {
    const desc = getArtifactDescription(artifact.id);

    let body;
    if (desc) {
      body = formatDescription(artifact, desc);
    } else {
      // Auto-generated minimal description
      const tierColors = {
        common: "§f", uncommon: "§9", rare: "§b",
        ornate: "§5", exquisite: "§d", mythical: "§6"
      };
      const color = tierColors[artifact.tier] || "§f";
      body = `${color}§l${artifact.name}§r\n`;
      body += `§7${artifact.tier.charAt(0).toUpperCase() + artifact.tier.slice(1)} Artifact\n`;
      body += `${color}══════════════════§r\n\n`;
      body += `§7Base: §f${artifact.baseItem?.replace("minecraft:", "") || "unknown"}\n\n`;
      body += `§8§oNo detailed description available yet.§r\n`;
      body += `\n${color}══════════════════§r`;
    }

    const form = new ActionFormData()
      .title(`${artifact.name}`)
      .body(body)
      .button("§7← Back");

    form.show(player).then(() => {
      this.openCategoryPage(player, rarity, category);
    });

    // Play UI click sound
    try { player.playSound("ui.button.click", { volume: 0.5, pitch: 1.2 }); } catch {}
  }

  /**
   * Open challenges page (placeholder for Phase 2 content).
   */
  openChallenges(player) {
    const form = new ActionFormData()
      .title("§b☆ Challenges")
      .body("§7Complete challenges to earn special rewards.\n\n§8Coming in Phase 2!")
      .button("§7← Back");

    form.show(player).then(() => {
      this.openHub(player);
    });
  }

  /**
   * Open classes page — weapon class overview.
   */
  openClasses(player) {
    const classes = [
      { name: "Rogue", color: "§c", desc: "Daggers and dual-wield, +30% speed, multi-target" },
      { name: "Berserker", color: "§4", desc: "Dual axes, Rage Mode, Dancer subclass with gauntlets" },
      { name: "Archer", color: "§a", desc: "Bows, Overcharge, Hunter subclass with crossbows" },
      { name: "Beastlord", color: "§e", desc: "Spears, pet buffs, Warp Strike, Rally Cry" },
    ];

    let body = "§7Weapon classes and their specializations:\n\n";
    for (const c of classes) {
      body += `${c.color}§l${c.name}§r §7— ${c.desc}\n`;
    }

    const form = new ActionFormData()
      .title("§c⚔ Classes")
      .body(body)
      .button("§7← Back");

    form.show(player).then(() => {
      this.openHub(player);
    });
  }

  // ─── HELP GUIDE (Section 9) ─────────────────────────────────

  /**
   * Open Help Guide — 20 topic buttons covering all game systems.
   */
  openHelpGuide(player) {
    const form = new ActionFormData()
      .title("§f✦ Help Guide ✦")
      .body("§7Select a topic to learn more:")
      .button("§6☀ Dream Rate")
      .button("§e⛏ Mining Crates")
      .button("§a🌾 Harvesting")
      .button("§b🎣 Fishing")
      .button("§c⚔ Mobs & Patrons")
      .button("§d✦ Artifacts")
      .button("§3⊕ Mastery")
      .button("§e🐾 Companions")
      .button("§a📜 Quests & Bounties")
      .button("§6⊞ Advantage Trees")
      .button("§4⚔ Classes")
      .button("§e🍳 Cooking")
      .button("§f🏠 Housing")
      .button("§c⚔ Dungeons & Bosses")
      .button("§2🏪 Professions")
      .button("§3🌍 World & Travel")
      .button("§5⚙ Glyphforge & Transmute")
      .button("§8💰 Black Market")
      .button("§9💎 Armor Trim Effects")
      .button("§f📦 Satchels & Items")
      .button("§7← Back");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 20) {
        this.openHub(player);
        return;
      }
      const topics = [
        "dream_rate", "mining_crates", "harvesting", "fishing",
        "mobs_patrons", "artifacts", "mastery", "companions",
        "quests_bounties", "advantage_trees", "classes", "cooking",
        "housing", "dungeons_bosses", "professions", "world_travel",
        "glyphforge_transmute", "black_market", "armor_trims", "satchels_items",
      ];
      if (r.selection < topics.length) {
        this.showHelpTopic(player, topics[r.selection]);
      }
    });
  }

  /**
   * Display a help topic as chat messages.
   */
  showHelpTopic(player, topicId) {
    try { player.playSound("random.page_turn", { volume: 0.5, pitch: 1.0 }); } catch {}
    const lines = HELP_TOPICS[topicId];
    if (!lines) return;
    for (const line of lines) {
      player.sendMessage(line);
    }
    // Re-open help guide after a delay
    player.sendMessage("§8─────────────────────────────────");
  }

  // === ECODEX XP BANK ===
  // Deposit XP levels into storage, withdraw later
  async showXPBank(player) {
    const s = StorageManager.forPlayer(player);
    const stored = s.getNumber("xp_bank", 0);
    const currentLevels = player.level || 0;

    const form = new ActionFormData()
      .title("§d✦ Eternal Codex — XP Vault ✦")
      .body([
        `§7Stored XP: §a${stored} levels`,
        `§7Current XP: §e${currentLevels} levels`,
        "",
        "§7Deposit your XP for safekeeping.",
        "§7Withdraw when you need it.",
      ].join("\n"))
      .button("§a↓ Deposit All XP")
      .button("§e↑ Withdraw All XP")
      .button("§a↓ Deposit 10 Levels")
      .button("§e↑ Withdraw 10 Levels")
      .button("§7Close");

    const res = await form.show(player);
    if (res.canceled) return;

    switch (res.selection) {
      case 0: // Deposit all
        if (currentLevels > 0) {
          s.setNumber("xp_bank", stored + currentLevels);
          try { player.runCommandAsync("xp -" + currentLevels + "L @s"); } catch {}
          player.sendMessage(`§a↓ Deposited ${currentLevels} levels. Bank: ${stored + currentLevels}`);
          player.playSound("random.orb", { pitch: 1.2 });
        }
        break;
      case 1: // Withdraw all
        if (stored > 0) {
          s.setNumber("xp_bank", 0);
          try { player.runCommandAsync("xp " + stored + "L @s"); } catch {}
          player.sendMessage(`§e↑ Withdrew ${stored} levels.`);
          player.playSound("random.orb", { pitch: 0.8 });
        }
        break;
      case 2: // Deposit 10
        const dep = Math.min(10, currentLevels);
        if (dep > 0) {
          s.setNumber("xp_bank", stored + dep);
          try { player.runCommandAsync("xp -" + dep + "L @s"); } catch {}
          player.sendMessage(`§a↓ Deposited ${dep} levels. Bank: ${stored + dep}`);
          player.playSound("random.orb", { pitch: 1.2 });
        }
        break;
      case 3: // Withdraw 10
        const wd = Math.min(10, stored);
        if (wd > 0) {
          s.setNumber("xp_bank", stored - wd);
          try { player.runCommandAsync("xp " + wd + "L @s"); } catch {}
          player.sendMessage(`§e↑ Withdrew ${wd} levels. Bank: ${stored - wd}`);
          player.playSound("random.orb", { pitch: 0.8 });
        }
        break;
    }
  }

  // === ECODEX ITEM COMBINE ===
  // Combine tomes and portal dials (Java ecodex/do_combine_*)
  async showCombineMenu(player) {
    const form = new ActionFormData()
      .title("§d✦ Eternal Codex — Combine Items ✦")
      .body("§7Combine duplicate items for enhanced effects.\n\n§7Place matching items in your inventory, then select a type to combine.")
      .button("§b⚗ Combine Tomes")
      .button("§5🔮 Combine Portal Dials")
      .button("§7Close");

    const res = await form.show(player);
    if (res.canceled || res.selection === 2) return;

    if (res.selection === 0) {
      this.eventBridge?.emit("combine_tomes", { player });
      player.sendMessage("§bSearching for combinable tomes...");
    } else {
      this.eventBridge?.emit("combine_dials", { player });
      player.sendMessage("§5Searching for combinable portal dials...");
    }
  }
}

// ─── HELP TOPIC CONTENT (20 topics) ─────────────────────────

const HELP_TOPICS = {
  dream_rate: [
    "§6§l===========================",
    "§6§l    ☀ Dream Rate ☀",
    "§6§l===========================",
    "",
    "§fDream Rate (DR) is your personal luck stat that",
    "§faffects nearly every reward system in Forevercraft.",
    "§fHigher DR means better crate tiers, rarer artifacts,",
    "§fand access to dream-gated structures.",
    "",
    "§7Permanent sources: §6Mythical armor §7(+0.5 per piece),",
    "§6Crystal of Dreams§7, §6Owl companion §7at Lv100.",
    "§7Temporary boosts: §ePotions§7, §eenchantments§7, §etime-of-day§7,",
    "§emoon phases§7, and §eConstellations§7 (+0.25 each, max +2.5).",
    "§7DR is §ccapped at 50§7. Dream-gated structures need",
    "§7specific DR thresholds to enter.",
  ],
  mining_crates: [
    "§e§l===========================",
    "§e§l    ⛏ Mining Crates ⛏",
    "§e§l===========================",
    "",
    "§fMining any ore has a chance to drop a treasure crate.",
    "§fCrate tier depends on your Dream Rate and the biome",
    "§fyou're mining in. There are 25 unique biome loot pools.",
    "",
    "§76 tiers: §7Common§7, §aUncommon§7, §bRare§7, §dOrnate§7,",
    "§5Exquisite§7, §6Mythical§7. Opening plays an animation.",
    "§7Each crate has a §e20% chance §7to contain an",
    "§6Awakening Stone §7for artifact mastery.",
    "§7Mining at §enoon §7gives §a+1.0 DR§7 bonus.",
  ],
  harvesting: [
    "§a§l===========================",
    "§a§l    🌾 Harvesting 🌾",
    "§a§l===========================",
    "",
    "§fBreaking fully-grown crops drops harvest crates.",
    "§fThe Harvest Festival world event boosts harvest rates.",
    "§fHoes auto-replant crops when you break them.",
    "",
    "§7§eProspect Nodes§7: Biome-specific mining nodes spawn",
    "§7near you. Each has a per-player cooldown. Hold still",
    "§7for 3 seconds to harvest. §eTimber§7: Chopping trees",
    "§7can drop extra wood crates. §eFoliage Foraging§7:",
    "§7Biome bushes spawn with a 3-second gather timer.",
  ],
  fishing: [
    "§b§l===========================",
    "§b§l    🎣 Fishing 🎣",
    "§b§l===========================",
    "",
    "§fFishing can yield treasure crates in 6 tiers.",
    "§fYour Dream Rate and fishing enchantments affect",
    "§fthe quality of catches.",
    "",
    "§7Time bonuses: §eMorning §a+0.5 DR§7, §eRain §a+0.5 DR§7,",
    "§eFull Moon §a+0.5 DR§7 — these §astack§7!",
    "§7Luck of the Sea enchantment boosts quality further.",
    "§7Each fishing crate has a §e20% chance §7to contain",
    "§7an §6Awakening Stone§7.",
  ],
  mobs_patrons: [
    "§c§l===========================",
    "§c§l    ⚔ Mobs & Patrons ⚔",
    "§c§l===========================",
    "",
    "§f5% of hostile mobs spawn as Patrons — elite versions",
    "§fwith 6 tiers from Common to Mythical. Mythical Patrons",
    "§fhave 250 HP, +20 armor, and deal +300% damage.",
    "",
    "§7Patrons drop §emob crates §7scaled to their tier.",
    "§c§lFuria§r§7 mobs (10% chance) have 3 tiers with",
    "§7particle effects and bonus loot.",
    "§7§5New Moon §7doubles spawn rates and gives §a+0.5 DR§7.",
    "§7Greater depth increases Patron spawn chance.",
  ],
  artifacts: [
    "§d§l===========================",
    "§d§l    ✦ Artifacts ✦",
    "§d§l===========================",
    "",
    "§f290+ unique artifacts across 6 rarity tiers. Each has",
    "§fon-hit abilities, and matching armor sets unlock",
    "§fdevastating set bonuses. Mythical pieces give +0.5 DR.",
    "",
    "§7§6Constellations§7: Groups of 10 themed artifacts. Completing",
    "§7one grants §a+0.25 DR§7. All 10 = §a+2.5 DR§7 total.",
    "§7§ePatina§7: After 72hr real playtime, artifacts age to",
    "§7Legendary quality (+2% stat boost).",
    "§719 accessories, 13 rings, 12 healer artifacts, Graviton Core.",
  ],
  mastery: [
    "§3§l===========================",
    "§3§l    ⊕ Weapon & Armor Mastery ⊕",
    "§3§l===========================",
    "",
    "§fAwaken artifacts with tier-matched Awakening Stones.",
    "§fGear gains XP from orbs and auto-enchants per level.",
    "§fTiers cap at different levels (Common=1, Mythical=7).",
    "",
    "§75 armor slots gain XP simultaneously from combat.",
    "§7§ePrestige§7: Reset mastery up to 3x for permanent bonuses.",
    "§7Party members share bonus mastery XP when nearby.",
    "§7Higher mastery levels unlock stronger enchantments",
    "§7and special passive abilities on the item.",
  ],
  companions: [
    "§e§l===========================",
    "§e§l    🐾 Companions 🐾",
    "§e§l===========================",
    "",
    "§f100 unique companions found in biome-specific pools",
    "§f(7% encounter chance). Each has unique passives and",
    "§fone of 21 trigger abilities.",
    "",
    "§7§eBond system§7: 7 moods from Lonely to Overjoyed.",
    "§7§6Eternal Bond §7= 1.5x ability power. Bond decays if neglected.",
    "§7Companions fight, level up, and track kills.",
    "§7§eWhistle§7 to summon. §eCampfire treats §7give 75-300 RP.",
    "§7Shared memories unlock at high bond levels.",
  ],
  quests_bounties: [
    "§a§l===========================",
    "§a§l    📜 Quests & Bounties 📜",
    "§a§l===========================",
    "",
    "§fVillage quest boards offer daily quests in 6 tiers.",
    "§fThe first daily quest always gives a bonus reward.",
    "§fReputation grows from Stranger to Legend (2500+ rep).",
    "",
    "§7Higher reputation unlocks better quests and rewards.",
    "§725% of quest slots are §cPatron Bounties§7 — guaranteed",
    "§7elite mob spawns with an actionbar distance tracker.",
    "§7Complete bounties for premium crates and rare tokens.",
  ],
  advantage_trees: [
    "§6§l===========================",
    "§6§l    ⊞ Advantage Trees ⊞",
    "§6§l===========================",
    "",
    "§f13 skill trees with a level cap of 25 each.",
    "§fEach level grants passive bonuses or unlocks abilities.",
    "§fPrestige up to 3x for permanent stat boosts.",
    "",
    "§7§eChallenges§7 earn §aTree Tokens§7. 15 tokens unlock a",
    "§6Cosmetic Crate §7(36 exclusive particles and titles).",
    "§7§eSynergies§7: Hidden cross-tree bonuses that activate",
    "§7when you reach certain levels in multiple trees.",
  ],
  classes: [
    "§4§l===========================",
    "§4§l    ⚔ Weapon Classes ⚔",
    "§4§l===========================",
    "",
    "§c§lRogue§r§7: Daggers and dual-wield combat. +30% speed,",
    "§7multi-target attacks, high mobility.",
    "",
    "§4§lBerserker§r§7: Dual axes, sacrifices -7 armor and -5 hearts",
    "§7for Rage Mode. §eDancer§7 subclass uses gauntlets.",
    "",
    "§a§lArcher§r§7: Bows with Overcharge and Disengage. §eHunter§7",
    "§7subclass uses crossbows with Steady Aim and Fade.",
    "",
    "§e§lBeastlord§r§7: Spears, pet buffs, Warp Strike, Rally Cry,",
    "§7Alpha Howl. The ultimate companion-focused class.",
  ],
  cooking: [
    "§e§l===========================",
    "§e§l    🍳 Cooking 🍳",
    "§e§l===========================",
    "",
    "§fCampfire Kitchen with 5 meal categories: combat,",
    "§fmining, fortune, wayfarer, and delicacy. Each meal",
    "§fgrants unique temporary buffs.",
    "",
    "§74 seasons (every 16 days) with 4 exclusive recipes each.",
    "§7§eRecipe discovery§7: Find new recipes through exploration",
    "§7and experimentation. §eCooking mastery§7 titles at",
    "§710 recipes (Apprentice) and 100 (Master Chef).",
    "§7Cook §ecompanion treats §7for 75-300 bond RP.",
  ],
  housing: [
    "§f§l===========================",
    "§f§l    🏠 Housing 🏠",
    "§f§l===========================",
    "",
    "§fPlace a Hearthstone (lodestone) to create your home.",
    "§fYour home zone covers a 64-block radius with a 3x3",
    "§fchunk forceloaded area and auto-Guidestone.",
    "",
    "§75 upgrade tiers: §eRegen§7, §eSaturation§7, §eDR+Garden§7,",
    "§eFire Resist§7, §eResistance I§7.",
    "§7§aGarden§7 auto-grows crops in your zone.",
    "§7§eQuick Stash§7: 8 barrel categories for fast sorting.",
    "§7§6Comfort Score§7 milestones at 25/50/100/200. House Key at 100+Tier3.",
  ],
  dungeons_bosses: [
    "§c§l===========================",
    "§c§l    ⚔ Dungeons & Bosses ⚔",
    "§c§l===========================",
    "",
    "§f5-wave combat encounters with 16 dungeon themes.",
    "§fWave 5 is always a boss. Random modifiers (6 types)",
    "§fchange the rules each run. 7-day lockout per dungeon.",
    "",
    "§7DR-based difficulty: §aEasy §7under 7 DR, §cBrutal §7at 30+",
    "§7(+100% HP, +50% damage). Brutal rewards: §6Mythical crate§7,",
    "§74 emerald blocks, 5000 XP.",
    "§7§eVillage Defense§7 variant. §6World Bosses §7use rituals",
    "§7with phases. §d11 exclusive boss artifacts §7for Hero's Satchel.",
  ],
  professions: [
    "§2§l===========================",
    "§2§l    🏪 Professions 🏪",
    "§2§l===========================",
    "",
    "§f11 custom professions in villages. Each offers unique",
    "§ftrades and daily specials that rotate.",
    "",
    "§7Key professions: §5Bartender §7(Potions of Dreams, up to",
    "§a+6 DR§7), §eWise Wanderer §7(XP for crates),",
    "§dNymph §7(Tree Tokens for Cosmetic Crates),",
    "§bZookeeper §7(companion shards and gear),",
    "§6Retired Adventurer §7(recycling, rare items like",
    "§6Rabbit's Dreaming Foot §a+1 DR§7).",
    "§7§eArtificer§7 buys Glyphs for Netherite Scraps.",
  ],
  world_travel: [
    "§3§l===========================",
    "§3§l    🌍 World & Travel 🌍",
    "§3§l===========================",
    "",
    "§fGuidestones create a fast-travel network (4 color",
    "§fvariants). Place them anywhere and teleport between.",
    "§fPortal Dial binds to lodestones for pocket teleports.",
    "",
    "§71 real hour = 1 Forevercraft day. 8 moon phases,",
    "§74 seasons (16-day cycle).",
    "§75 §eWorld Events§7: §6Starfall§7, §5The Dreaming§7, §cAbyssal Tremor§7,",
    "§aAurora Bloom§7, §9Rift Echo§7.",
    "§7§eWormhole§7: 5000-10000 block random teleport for 30 XP.",
    "§7162 discoverable lore sets across the world.",
  ],
  glyphforge_transmute: [
    "§5§l===========================",
    "§5§l    ⚙ Glyphforge & Transmute ⚙",
    "§5§l===========================",
    "",
    "§fGlyphforge: Forge permanent rune glyphs onto weapons.",
    "§f12 unique glyph types plus Arcanum (random glyph).",
    "§fForging takes real time (3 Forevercraft days first, scaling).",
    "",
    "§7No duplicates per item. Tier determines glyph capacity:",
    "§7Base = 1 slot, §6Mythical = 13 slots§7.",
    "§7§eTransmute§7: Sacrifice 5 artifacts of one tier to receive",
    "§71 artifact of the next tier. The §eArtificer §7villager",
    "§7reduces the transmute cost. Both use lodestone stations.",
  ],
  black_market: [
    "§8§l===========================",
    "§8§l    💰 Black Market 💰",
    "§8§l===========================",
    "",
    "§fLocked barrels with skull labels found in villages.",
    "§fTrades use netherite ingots as currency.",
    "§fTabbed GUI: Buy, Sell, and Listings tabs.",
    "",
    "§714 daily rotating items from a pool of 56.",
    "§7§eSell tab§7 appraises held artifacts: §dOrnate §7= 1-2 NI,",
    "§5Exquisite §7= 4-6 NI, §6Mythical §7= 8-12 NI.",
    "§7§eEscrow§7: List up to 5 items for sale. Each has a",
    "§74% daily sell chance. Profits collected on next visit.",
  ],
  armor_trims: [
    "§9§l===========================",
    "§9§l    💎 Armor Trim Effects 💎",
    "§9§l===========================",
    "",
    "§f11 trim materials grant real gameplay effects.",
    "§fBonuses stack per piece and a full matching set of",
    "§f4 pieces unlocks an extra set bonus.",
    "",
    "§7Materials: §5Amethyst§7, §6Copper§7, §bDiamond§7, §aEmerald§7,",
    "§eGold§7, §fIron§7, §9Lapis§7, §8Netherite§7, §fQuartz§7,",
    "§cRedstone§7, §eResin§7.",
    "§7Each material provides a different stat or ability,",
    "§7from damage reduction to speed to luck bonuses.",
  ],
  satchels_items: [
    "§f§l===========================",
    "§f§l    📦 Satchels & Items 📦",
    "§f§l===========================",
    "",
    "§fEssentials Satchel: Portable overflow storage that",
    "§fexpands your carrying capacity.",
    "§fHero's Satchel: 11 boss artifact slots with active",
    "§fAoE effects that radiate while equipped.",
    "",
    "§7§eTome of Experience§7: Bank XP levels for safekeeping.",
    "§7§eArmored Elytra§7: Merge elytra with chestplates on a",
    "§7beacon for combined armor + flight.",
    "§7§eRune Stones§7: 8 types, max 3 active, pair for amplified effects.",
  ],
};
