/**
 * Mob Crate System — Patron mob death drops with tier-based crates.
 * Replaces Java mob_crates/ folder (100 files).
 * Patron mobs (tagged with tiers) drop artifact crates on death.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const PATRON_TIERS = {
  "ec.patron.common": { name: "Common", color: "§f", loot: "artifacts/common/main", totemChance: 0.05 },
  "ec.patron.uncommon": { name: "Uncommon", color: "§e", loot: "artifacts/uncommon/main", totemChance: 0.03 },
  "ec.patron.rare": { name: "Rare", color: "§b", loot: "artifacts/rare/main", totemChance: 0.02 },
  "ec.patron.ornate": { name: "Ornate", color: "§5", loot: "artifacts/ornate/main", totemChance: 0.01 },
  "ec.patron.exquisite": { name: "Exquisite", color: "§6", loot: "artifacts/exquisite/main", totemChance: 0.005 },
  "ec.patron.mythical": { name: "Mythical", color: "§c", loot: "artifacts/mythical/main", totemChance: 0.002 },
};

export class MobCrateSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    // Listen for entity death
    world.afterEvents.entityDie.subscribe((event) => {
      const entity = event.deadEntity;
      if (!entity) return;

      // Check for patron tags
      for (const [tag, tierData] of Object.entries(PATRON_TIERS)) {
        if (entity.hasTag?.(tag)) {
          this.onPatronDeath(entity, event.damageSource, tierData);
          return;
        }
      }
    });
  }

  onPatronDeath(entity, damageSource, tierData) {
    const killer = damageSource?.damagingEntity;
    const loc = entity.location;
    const dim = entity.dimension;

    // Check for Dream Surge event (upgrades tier)
    const worldStorage = StorageManager.world();
    const isDreamSurge = worldStorage.get("active_event") === "dream_surge";

    // Spawn loot
    try {
      dim.runCommandAsync(
        `loot spawn ${loc.x} ${loc.y + 0.5} ${loc.z} loot "${tierData.loot}"`
      );
    } catch {}

    // Notification
    if (killer?.typeId === "minecraft:player") {
      killer.sendMessage(`${tierData.color}§l✦ ${tierData.name} Patron §r§7defeated! Crate dropped.`);
      killer.playSound("random.levelup");

      // Track kills and crate stats
      const s = StorageManager.forPlayer(killer);
      const kills = s.getNumber("patron_kills") + 1;
      s.set("patron_kills", kills);
      s.set("crates_mob", s.getNumber("crates_mob") + 1);
      s.set("crates_opened", s.getNumber("crates_opened") + 1);
      this.eventBridge.emit("crate_opened", killer, "mob", tierData.name);

      // Totem drop chance
      if (Math.random() < tierData.totemChance) {
        try {
          dim.runCommandAsync(
            `give "${killer.name}" totem_of_undying 1`
          );
          killer.sendMessage("§6§l✦ Totem of Undying §r§7dropped by patron!");
        } catch {}
      }
    }

    console.log(`[MobCrates] ${tierData.name} patron defeated at ${Math.floor(loc.x)}, ${Math.floor(loc.y)}, ${Math.floor(loc.z)}`);
  }
}
