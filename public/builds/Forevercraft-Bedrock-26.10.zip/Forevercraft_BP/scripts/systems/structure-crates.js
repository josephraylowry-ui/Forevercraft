/**
 * Structure Crate System — Per-player loot from structure chests.
 * Replaces Java structures/ folder (99 files).
 * Uses position encoding for per-player chest tracking with refresh timers.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Structure loot tiers based on Dream Rate
const STRUCTURE_TIERS = [
  { minDR: 0, name: "Common", loot: "artifacts/common/main" },
  { minDR: 10, name: "Uncommon", loot: "artifacts/uncommon/main" },
  { minDR: 25, name: "Rare", loot: "artifacts/rare/main" },
  { minDR: 50, name: "Ornate", loot: "artifacts/ornate/main" },
  { minDR: 75, name: "Exquisite", loot: "artifacts/exquisite/main" },
  { minDR: 100, name: "Mythical", loot: "artifacts/mythical/main" },
];

// Refresh interval in seconds (3600 = 1 hour)
const REFRESH_INTERVAL = 3600;

export class StructureCrateSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    // Block interaction for chests
    world.afterEvents.playerInteractWithBlock.subscribe((event) => {
      const block = event.block;
      if (block?.typeId === "minecraft:barrel" || block?.typeId === "minecraft:chest") {
        this.onChestInteract(event.player, block);
      }
    });
  }

  /** Encode position into a compact key */
  encodePosition(x, y, z) {
    return `${Math.floor(x)}_${Math.floor(y)}_${Math.floor(z)}`;
  }

  onChestInteract(player, block) {
    // Check if this block is a structure crate (has marker nearby)
    const loc = block.location;
    try {
      const markers = block.dimension.getEntities({
        type: "forevercraft:marker",
        location: loc,
        maxDistance: 2,
        tags: ["ec.struct_crate"],
      });
      if (markers.length === 0) return;
      this.processStructureLoot(player, block, markers[0]);
    } catch {}
  }

  processStructureLoot(player, block, marker) {
    const s = StorageManager.forPlayer(player);
    const posKey = this.encodePosition(block.location.x, block.location.y, block.location.z);
    const storageKey = `struct_${posKey}`;

    // Check if already looted (with timer)
    const lastLooted = s.getNumber(storageKey);
    if (lastLooted > 0) {
      const now = system.currentTick;
      const elapsed = (now - lastLooted) / 20; // Convert ticks to seconds
      if (elapsed < REFRESH_INTERVAL) {
        const remaining = Math.ceil(REFRESH_INTERVAL - elapsed);
        const mins = Math.floor(remaining / 60);
        player.sendMessage(`§7This crate refreshes in §f${mins}m`);
        return;
      }
    }

    // Determine tier based on Dream Rate
    const dreamRate = s.getNumber("dream_rate") || 0;
    let selectedTier = STRUCTURE_TIERS[0];
    for (const tier of STRUCTURE_TIERS) {
      if (dreamRate >= tier.minDR) selectedTier = tier;
    }

    // Bonus roll chance based on luck
    const bonusRoll = Math.random() < (dreamRate * 0.005); // 0.5% per DR point

    // Drop loot
    const loc = block.location;
    try {
      block.dimension.runCommandAsync(
        `loot spawn ${loc.x} ${loc.y + 1} ${loc.z} loot "${selectedTier.loot}"`
      );
      if (bonusRoll) {
        block.dimension.runCommandAsync(
          `loot spawn ${loc.x} ${loc.y + 1} ${loc.z} loot "${selectedTier.loot}"`
        );
        player.sendMessage("§6§l✦ Bonus Roll!");
      }
    } catch {}

    // Mark as looted
    s.set(storageKey, system.currentTick);
    player.sendMessage(`§6§l✦ Structure Crate §r§7— ${selectedTier.name} loot!`);
    player.playSound("random.levelup");

    // Track
    const count = s.getNumber("structures_looted") + 1;
    s.set("structures_looted", count);
    s.set("crates_structure", s.getNumber("crates_structure") + 1);
    s.set("crates_opened", s.getNumber("crates_opened") + 1);
    this.eventBridge.emit("crate_opened", player, "structure", selectedTier.name);

    // First-Find bonus: double loot on first-ever loot from this position
    const firstFindKey = `struct_first_${posKey}`;
    if (!s.get(firstFindKey)) {
      s.set(firstFindKey, true);
      const found = s.getNumber("structures_found", 0) + 1;
      s.set("structures_found", found);
      // Bonus: extra loot drop + XP
      try {
        block.dimension.runCommandAsync(
          `loot spawn ${loc.x} ${loc.y + 1} ${loc.z} loot "${selectedTier.loot}"`
        );
        player.runCommandAsync("xp 50 @s");
      } catch {}
      player.sendMessage("§6§l✦ First Discovery! §r§7Double loot + 50 XP!");
      this.eventBridge.emit("structure_first_find", player, posKey);
    }
  }

  tick() {
    // Structure crates are event-driven, no per-tick work needed
  }
}
