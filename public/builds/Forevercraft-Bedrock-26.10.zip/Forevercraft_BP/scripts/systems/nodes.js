/**
 * Nodes System — Biome-specific resource nodes with resonance mechanics.
 * Spawns harvestable nodes near players based on biome. Includes artisan rank tracking.
 * Replaces Java craftforever/nodes/ (40 files) + craftforever/artisan/ (12 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// Node types by biome category
const NODE_TYPES = [
  { id: 1,  name: "Iron Vein",        biomes: ["plains", "forest"],    rarity: 1, xp: 5,  drops: "iron_ingot",      dropCount: [1, 3] },
  { id: 2,  name: "Gold Deposit",     biomes: ["badlands", "mesa"],    rarity: 2, xp: 10, drops: "gold_ingot",      dropCount: [1, 2] },
  { id: 3,  name: "Diamond Cluster",  biomes: ["mountain", "extreme"], rarity: 4, xp: 25, drops: "diamond",         dropCount: [1, 2] },
  { id: 4,  name: "Emerald Pocket",   biomes: ["mountain"],            rarity: 3, xp: 15, drops: "emerald",         dropCount: [1, 3] },
  { id: 5,  name: "Copper Outcrop",   biomes: ["desert", "savanna"],   rarity: 1, xp: 3,  drops: "copper_ingot",    dropCount: [2, 5] },
  { id: 6,  name: "Lapis Cache",      biomes: ["ocean", "river"],      rarity: 2, xp: 8,  drops: "lapis_lazuli",    dropCount: [3, 8] },
  { id: 7,  name: "Redstone Cluster",  biomes: ["jungle", "swamp"],    rarity: 2, xp: 8,  drops: "redstone",        dropCount: [4, 12] },
  { id: 8,  name: "Quartz Formation", biomes: ["nether"],              rarity: 2, xp: 10, drops: "quartz",          dropCount: [2, 6] },
  { id: 9,  name: "Ancient Debris",   biomes: ["nether"],              rarity: 5, xp: 50, drops: "netherite_scrap", dropCount: [1, 1] },
  { id: 10, name: "Amethyst Geode",   biomes: ["any"],                 rarity: 3, xp: 12, drops: "amethyst_shard",  dropCount: [2, 4] },
  { id: 11, name: "Herb Patch",       biomes: ["forest", "plains"],    rarity: 1, xp: 3,  drops: "wheat_seeds",     dropCount: [3, 8] },
  { id: 12, name: "Mushroom Colony",  biomes: ["swamp", "dark_forest"],rarity: 2, xp: 5,  drops: "brown_mushroom",  dropCount: [2, 5] },
  { id: 13, name: "Crystal Bloom",    biomes: ["flower_forest"],       rarity: 4, xp: 20, drops: "prismarine_shard",dropCount: [1, 3] },
  { id: 14, name: "Coral Fragment",   biomes: ["ocean"],               rarity: 3, xp: 10, drops: "prismarine_crystals", dropCount: [2, 4] },
  { id: 15, name: "Soul Sand Pocket", biomes: ["nether"],              rarity: 2, xp: 8,  drops: "soul_sand",       dropCount: [4, 8] },
];

// Artisan rank thresholds
const ARTISAN_RANKS = [
  { rank: 0,  name: "Novice",       xp: 0,      color: "§7" },
  { rank: 1,  name: "Apprentice",   xp: 500,    color: "§f" },
  { rank: 2,  name: "Journeyman",   xp: 1500,   color: "§a" },
  { rank: 3,  name: "Craftsman",    xp: 3500,   color: "§b" },
  { rank: 4,  name: "Expert",       xp: 7000,   color: "§5" },
  { rank: 5,  name: "Artisan",      xp: 12000,  color: "§6" },
  { rank: 6,  name: "Master",       xp: 20000,  color: "§c" },
  { rank: 7,  name: "Grandmaster",  xp: 35000,  color: "§d" },
  { rank: 8,  name: "Legendary",    xp: 50000,  color: "§e" },
];

// Spawn chance per 1200-tick cycle (1 minute)
const NODE_SPAWN_CHANCE = 0.15; // 15% per cycle per player
const NODE_MAX_NEARBY = 3;      // Max nodes within 32 blocks
const NODE_LIFETIME = 6000;     // 5 minutes before despawn

export class NodeSystem {
  constructor(eventBridge, biomeSystem) {
    this.eventBridge = eventBridge;
    this.biomeSystem = biomeSystem;
    // Active nodes: Map<entityId, { nodeType, spawnTick, ownerId }>
    this.activeNodes = new Map();
  }

  // Called every 1200 ticks (1 minute)
  tick(players) {
    // Spawn new nodes
    for (const player of players) {
      this.trySpawnNode(player);
    }

    // Despawn expired nodes
    const now = system.currentTick;
    for (const [entityId, node] of this.activeNodes) {
      if (now - node.spawnTick > NODE_LIFETIME) {
        this.despawnNode(entityId);
      }
    }
  }

  trySpawnNode(player) {
    if (Math.random() > NODE_SPAWN_CHANCE) return;

    // Check max nearby
    let nearbyCount = 0;
    for (const [_, node] of this.activeNodes) {
      if (node.ownerId === player.id) nearbyCount++;
    }
    if (nearbyCount >= NODE_MAX_NEARBY) return;

    // Get player biome
    const biome = this.biomeSystem?.getCurrentBiome(player) || "plains";

    // Find matching node types
    const candidates = NODE_TYPES.filter(n =>
      n.biomes.includes("any") || n.biomes.some(b => biome.includes(b))
    );
    if (candidates.length === 0) return;

    // Weight by rarity (lower rarity = more common)
    const weighted = [];
    for (const node of candidates) {
      const weight = Math.max(1, 6 - node.rarity);
      for (let i = 0; i < weight; i++) weighted.push(node);
    }
    const selected = weighted[Math.floor(Math.random() * weighted.length)];

    // Spawn node marker near player
    const loc = player.location;
    const spawnX = loc.x + (Math.random() - 0.5) * 20;
    const spawnZ = loc.z + (Math.random() - 0.5) * 20;
    const spawnY = loc.y;

    try {
      const dim = player.dimension;
      // Use armor stand as visible node marker
      const marker = dim.spawnEntity("minecraft:armor_stand", { x: spawnX, y: spawnY, z: spawnZ });
      marker.addTag("ec.node");
      marker.addTag(`ec.node_${selected.id}`);
      marker.nameTag = `§e✦ ${selected.name}`;

      this.activeNodes.set(marker.id, {
        nodeType: selected,
        spawnTick: system.currentTick,
        ownerId: player.id,
      });

      player.sendMessage(`§e✦ §7A ${selected.name} appeared nearby!`);
    } catch (e) {}
  }

  // Called when player interacts with a node
  harvestNode(player, nodeEntityId) {
    const nodeData = this.activeNodes.get(nodeEntityId);
    if (!nodeData) return;

    const node = nodeData.nodeType;
    const s = StorageManager.forPlayer(player);

    // Check resonance bonus from inscription stones
    const resonanceBonus = this.getResonanceBonus(player);
    const dropMin = node.dropCount[0];
    const dropMax = node.dropCount[1];
    const count = Math.floor(dropMin + Math.random() * (dropMax - dropMin + 1)) + resonanceBonus;

    // Grant drops
    try {
      player.runCommandAsync(`give @s ${node.drops} ${count}`);
    } catch (e) {}

    // Add artisan XP
    const xp = s.getNumber("artisan_xp", 0) + node.xp;
    s.setNumber("artisan_xp", xp);
    this.checkArtisanRankUp(player, s, xp);

    // Track prospects
    const prospects = s.getNumber("stat_prospects", 0) + 1;
    s.setNumber("stat_prospects", prospects);

    player.sendMessage(`§a+${count} ${node.drops.replace("minecraft:", "")} §7(+${node.xp} Artisan XP)`);
    player.playSound("random.orb");

    // Despawn node
    this.despawnNode(nodeEntityId);

    this.eventBridge.emit("prospect_complete", { player });
  }

  getResonanceBonus(player) {
    // Check for nearby inscription stones
    try {
      const stones = player.dimension.getEntities({
        location: player.location, maxDistance: 16, tags: ["ec.inscr_marker"],
      });
      return Math.min(stones.length, 3); // Max +3 bonus from resonance
    } catch (e) { return 0; }
  }

  despawnNode(entityId) {
    try {
      const entity = world.getEntity(entityId);
      if (entity) entity.kill();
    } catch (e) {}
    this.activeNodes.delete(entityId);
  }

  checkArtisanRankUp(player, s, xp) {
    const currentRank = s.getNumber("artisan_rank", 0);
    let newRank = currentRank;
    for (let i = ARTISAN_RANKS.length - 1; i >= 0; i--) {
      if (xp >= ARTISAN_RANKS[i].xp) { newRank = i; break; }
    }
    if (newRank > currentRank) {
      s.setNumber("artisan_rank", newRank);
      const rank = ARTISAN_RANKS[newRank];
      player.sendMessage(`\n§6✦ Artisan Rank Up! ${rank.color}${rank.name} §6✦\n`);
      player.playSound("random.levelup");
    }
  }

  showArtisanStatus(player) {
    const s = StorageManager.forPlayer(player);
    const xp = s.getNumber("artisan_xp", 0);
    const rank = s.getNumber("artisan_rank", 0);
    const rankData = ARTISAN_RANKS[Math.min(rank, ARTISAN_RANKS.length - 1)];
    const nextRank = rank < ARTISAN_RANKS.length - 1 ? ARTISAN_RANKS[rank + 1] : null;
    const pct = nextRank ? Math.min(100, Math.floor((xp / nextRank.xp) * 100)) : 100;
    const bar = "§a" + "█".repeat(Math.floor(pct / 5)) + "§8" + "░".repeat(20 - Math.floor(pct / 5));

    const form = new ActionFormData()
      .title("Artisan Status")
      .body([
        `§7Rank: ${rankData.color}§l${rankData.name}`,
        `§7XP: §f${xp.toLocaleString()}${nextRank ? ` / ${nextRank.xp.toLocaleString()}` : " (MAX)"}`,
        bar + ` §f${pct}%`,
      ].join("\n"))
      .button("Close");
    form.show(player);
  }
}
