import { getOrCreateObjective } from "../utils/scoreboard.js";

export function initScoreboards() {
  // Core
  getOrCreateObjective("ec.var", "Variables");
  getOrCreateObjective("ec.const", "Constants");
  getOrCreateObjective("ec.temp", "Temp");
  // Codex
  getOrCreateObjective("ec.codex", "Forevercraft Codex");
  getOrCreateObjective("ec.artifact_count", "Artifacts Collected");
  getOrCreateObjective("ec.has_artifacts", "Has Artifacts");
  getOrCreateObjective("ec.codex_use", "Used Codex");
  getOrCreateObjective("ec.mob_glow", "Mob Glow");
  getOrCreateObjective("ec.block_glow", "Block Glow");
  getOrCreateObjective("ec.codex_spec_cd", "Codex Spectator Cooldown");
  getOrCreateObjective("ec.codex_spec_time", "Codex Spectator Timer");
  getOrCreateObjective("ec.codex_ret_x", "Codex Return X");
  getOrCreateObjective("ec.codex_ret_y", "Codex Return Y");
  getOrCreateObjective("ec.codex_ret_z", "Codex Return Z");
  getOrCreateObjective("ec.codex_ret_dim", "Codex Return Dimension");
  // Health
  getOrCreateObjective("ec.health", "Health");
  getOrCreateObjective("ec.max_health", "Max Health");
  getOrCreateObjective("ec.health_pct", "Health Percent");
  // Cooldowns
  getOrCreateObjective("ec.monocle_cd", "Monocle Cooldown");
  getOrCreateObjective("ec.compass_cd", "Compass Cooldown");
  getOrCreateObjective("ec.echo_cd", "Echo Cooldown");
  getOrCreateObjective("ec.lightning_cd", "Lightning Strike Cooldown");
  // Dream Rate
  getOrCreateObjective("ec.dr_peak_ms", "DR Peak Milestone");
  getOrCreateObjective("ec.dreams", "Check Dreams");
  getOrCreateObjective("ec.last_day", "Last Day Online");
  getOrCreateObjective("ec.crystal_count", "Crystal Count");
  getOrCreateObjective("ec.droppings_count", "Droppings Count");
  getOrCreateObjective("ec.mushroom_count", "Mushroom Count");
  getOrCreateObjective("ec.chorus_count", "Chorus Count");
  // DR Consumables
  for (const name of ["patron_dream","quill","thread","tome","codex_page","lure","geode","seed","ember","map","dream_ore","dream_relic","dream_petal"]) {
    getOrCreateObjective(`ec.${name}_count`, `${name} Count`);
  }
  // Moon, Loot, Stats
  getOrCreateObjective("ec.moon", "Moon Phase Info");
  getOrCreateObjective("ec.loot_timer", "Loot Reset Timer");
  getOrCreateObjective("ec.stats", "Player Stats");
  // Anecdotes
  for (const a of ["elder","fisher","miner","wanderer","scholar","beast"]) {
    getOrCreateObjective(`ec.anec_${a}`, `${a} Anecdote`);
  }
  // Biome
  getOrCreateObjective("ec.affinity_match", "Affinity Match");
  getOrCreateObjective("ec.biome_id", "Biome ID");
  getOrCreateObjective("ec.biome_prev", "Previous Biome ID");
  getOrCreateObjective("ec.biome_last", "Biome Cache Time");
  // Tome of Experience
  getOrCreateObjective("ec.tome_lvl", "Tome Stored Levels");
  getOrCreateObjective("ec.tome_pts", "Tome Stored Points");
  // GUI / Advantage
  getOrCreateObjective("adv.gui_session", "GUI Session");
  getOrCreateObjective("adv.menu", "Advantage Menu");
  getOrCreateObjective("adv.temp", "Advantage Temp");
  // Crate / Debug
  getOrCreateObjective("ec.crate_plot", "Crate Animation");
  getOrCreateObjective("ec.crate_tier", "Crate Tier");
  getOrCreateObjective("ec.debug", "Debug Flags");
  getOrCreateObjective("cf.vault_ominous", "Vault Ominous Flag");
  // World features
  getOrCreateObjective("ec.sapling_age", "Sapling Ground Age");
  getOrCreateObjective("ec.healthbar", "Toggle Health Bar");
  // Weapons
  for (const w of ["kt","rg","bk","dn","bl","jv","sk"]) {
    getOrCreateObjective(`ec.${w}_active`, `${w} Active`);
  }
  // Archer/Hunter
  getOrCreateObjective("ec.ar_draw", "Archer Draw");
  getOrCreateObjective("ec.ar_stale", "Archer Stale");
  getOrCreateObjective("ec.ar_hit_timer", "Archer Hit Timer");
  getOrCreateObjective("ec.ar_charged", "Archer Charged");
  getOrCreateObjective("ec.ht_hit_timer", "Hunter Hit Timer");
  getOrCreateObjective("ec.ht_charged", "Hunter Charged");
  // Tomb / Lore / Forage / Prospect
  getOrCreateObjective("ec.tomb_death", "Tomb Death");
  getOrCreateObjective("ec.lore_cached", "Lore Cached");
  getOrCreateObjective("ec.lore_add", "Lore Add");
  getOrCreateObjective("ec.lore_picking", "Lore Picking");
  getOrCreateObjective("ec.lore_map", "Lore Map");
  getOrCreateObjective("ec.fg_picking", "Forage Picking");
  getOrCreateObjective("ec.pr_picking", "Prospect Picking");
  // Healer / Companion
  getOrCreateObjective("ec.hl_locked", "Healer Locked");
  getOrCreateObjective("companion.wcd", "Whistle Cooldown");
  // Movement
  getOrCreateObjective("ec.moving", "Shared Moving Flag");
  getOrCreateObjective("ec.move_lastx", "Shared Last X");
  getOrCreateObjective("ec.move_lastz", "Shared Last Z");
  // Transmute
  getOrCreateObjective("tx.dep_conf", "Transmute Deposit Confirm");
  // Structures
  for (let i = 1; i <= 22; i++) getOrCreateObjective(`ec.struct_${i}`, `Structure ${i}`);
  getOrCreateObjective("ec.struct_unique", "Unique Structures");
  // Triggers (Script API replacements)
  for (const t of ["ec.ncore","ec.codex_tp","ec.quest","ec.wake","ec.biome_mastery","ec.milestones"]) {
    getOrCreateObjective(t, t);
  }
  // Other
  getOrCreateObjective("ec.leave", "Leave Game");
  getOrCreateObjective("ec.dream_active", "Dream Active");
  for (const c of ["rh_wheat","rh_carrot","rh_potato","rh_beet","rh_nwart"]) {
    getOrCreateObjective(`ec.${c}`, c);
  }
  console.log("[Forevercraft] Scoreboard objectives initialized.");
}
