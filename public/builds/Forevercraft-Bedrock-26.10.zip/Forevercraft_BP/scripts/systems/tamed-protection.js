/**
 * Tamed Protection System — Prevents players from accidentally killing their tamed animals.
 * Also provides Combat AI for tamed mobs (foxes, cats, ocelots, horses, parrots).
 * When a player hits a tamed mob, all tamed companions within 64 blocks get instant health.
 * Replaces Java tamed_protection/ folder + tamed_combat/ system.
 *
 * Combat AI per mob type:
 *   Foxes:   3 block range, 2 damage, fox bite sound
 *   Cats:    3 block range, 2 damage, cat hiss sound
 *   Ocelots: 4 block range, 3 damage + sweep, cat hiss sound
 *   Horses:  1 block range (close-range only)
 *   Parrots: 2 block range
 */
import { world, EffectTypes, system } from "@minecraft/server";

// Entity types considered tameable companions
const TAMEABLE_TYPES = new Set([
  "minecraft:wolf",
  "minecraft:cat",
  "minecraft:parrot",
  "minecraft:horse",
  "minecraft:donkey",
  "minecraft:mule",
  "minecraft:llama",
  "minecraft:trader_llama",
  "minecraft:camel",
  "minecraft:fox",
  "minecraft:ocelot",
]);

// Combat AI configuration per mob type
const COMBAT_AI = {
  "minecraft:fox":    { range: 3, damage: 2, sound: "mob.fox.bite",    cooldown: 30, sweep: false },
  "minecraft:cat":    { range: 3, damage: 2, sound: "mob.cat.hiss",    cooldown: 30, sweep: false },
  "minecraft:ocelot": { range: 4, damage: 3, sound: "mob.cat.hiss",    cooldown: 25, sweep: true },
  "minecraft:horse":  { range: 1, damage: 4, sound: "mob.horse.angry", cooldown: 40, sweep: false },
  "minecraft:parrot": { range: 2, damage: 1, sound: "mob.parrot.idle", cooldown: 35, sweep: false },
};

// Hostile mobs that tamed pets will attack
const HOSTILE_TYPES = new Set([
  "minecraft:zombie", "minecraft:skeleton", "minecraft:creeper", "minecraft:spider",
  "minecraft:cave_spider", "minecraft:enderman", "minecraft:witch", "minecraft:pillager",
  "minecraft:vindicator", "minecraft:evoker", "minecraft:ravager", "minecraft:drowned",
  "minecraft:husk", "minecraft:stray", "minecraft:phantom", "minecraft:blaze",
  "minecraft:wither_skeleton", "minecraft:piglin_brute", "minecraft:hoglin",
  "minecraft:zombified_piglin", "minecraft:magma_cube", "minecraft:slime",
]);

export class TamedProtectionSystem {
  constructor(eventBridge) {
    // Listen for entity hurt events
    world.afterEvents.entityHurt.subscribe((event) => {
      this.onEntityHurt(event);
    });
  }

  onEntityHurt(event) {
    const entity = event.hurtEntity;
    const source = event.damageSource;

    // Only care about player-caused damage
    if (!source || !source.damagingEntity) return;
    const attacker = source.damagingEntity;
    if (attacker.typeId !== "minecraft:player") return;

    // Only care about tameable types
    if (!TAMEABLE_TYPES.has(entity.typeId)) return;

    // Check if entity is tamed (has owner via tameable component)
    try {
      const tameable = entity.getComponent("minecraft:tameable");
      // In Bedrock, tamed mobs have an owner
      // Alternative: check for the is_tamed tag or family
      const isTamed = entity.getComponent("minecraft:is_tamed") ||
                       entity.hasTag("ec.tame_protected");

      if (!tameable && !isTamed) {
        // Try checking if it's a horse-type (rideable = tamed in most cases)
        // Horses don't have tameable component but have is_tamed
        if (!entity.getComponent("minecraft:is_tamed")) return;
      }
    } catch {
      // If we can't determine tamed status, check tag
      if (!entity.hasTag("ec.tame_protected")) return;
    }

    // Heal all tamed companions within 64 blocks of the attacker
    try {
      const nearbyEntities = attacker.dimension.getEntities({
        location: attacker.location,
        maxDistance: 64,
      });

      for (const nearby of nearbyEntities) {
        if (!TAMEABLE_TYPES.has(nearby.typeId)) continue;

        // Check if tamed
        const isTamed = nearby.getComponent("minecraft:is_tamed") ||
                        nearby.hasTag("ec.tame_protected");
        if (!isTamed) continue;

        // Apply instant health V (heals 64 HP — covers any single hit)
        try {
          nearby.addEffect(EffectTypes.get("instant_health"), 1, {
            amplifier: 5,
            showParticles: false,
          });
        } catch {}
      }
    } catch {}
  }

  /**
   * Periodic tick for tagging + combat AI.
   * OPT: Tagging runs every 100 ticks. Combat runs every 20 ticks.
   * OPT: Single entity query per player instead of 5 type-specific queries.
   */
  tickCounter = 0;

  tick(players) {
    this.tickCounter++;

    // Tag scan: every 100 ticks (5 seconds) — just tag new tamed mobs
    if (this.tickCounter % 5 === 0) { // Since tick() called every 100 ticks, this = every 500 ticks
      this.tagNewTamedMobs(players);
    }

    // Combat AI: every tick that this is called (100 ticks from main)
    this.combatTick(players);
  }

  /** Tag tamed entities — OPT: only scan near players, not entire dimensions */
  tagNewTamedMobs(players) {
    for (const player of players) {
      try {
        // Single query: all entities near player, filter in JS
        const nearby = player.dimension.getEntities({
          location: player.location, maxDistance: 64,
        });
        for (const entity of nearby) {
          if (!TAMEABLE_TYPES.has(entity.typeId)) continue;
          if (entity.hasTag("ec.tame_protected")) continue;
          if (entity.getComponent("minecraft:is_tamed") ||
              entity.hasTag("ec.fox_tamed") ||
              entity.hasTag("ec.ocelot_tamed") ||
              entity.hasTag("ec.ghast_tamed")) {
            entity.addTag("ec.tame_protected");
          }
        }
      } catch {}
    }
  }

  /** Combat AI — OPT: single query per player for all tamed pets + hostiles */
  combatTick(players) {
    for (const player of players) {
      try {
        // ONE query: all tagged tamed pets within 32 blocks
        const allNearby = player.dimension.getEntities({
          tags: ["ec.tame_protected"],
          location: player.location,
          maxDistance: 32,
        });

        // Filter to combat-capable pets
        const combatPets = [];
        for (const entity of allNearby) {
          const config = COMBAT_AI[entity.typeId];
          if (!config) continue;
          if (entity.hasTag("ec.combat_cd")) continue;
          if (entity.hasTag("ec.fox_sitting") || entity.hasTag("ec.ocelot_sitting")) continue;
          combatPets.push({ entity, config });
        }

        if (combatPets.length === 0) continue;

        // ONE query: all potential hostile targets near player
        const allHostiles = player.dimension.getEntities({
          location: player.location,
          maxDistance: 36, // slightly beyond max pet range
        });
        const hostileList = [];
        for (const h of allHostiles) {
          if (HOSTILE_TYPES.has(h.typeId)) hostileList.push(h);
        }

        if (hostileList.length === 0) continue;

        // Match each pet to nearest hostile within range
        for (const { entity: pet, config } of combatPets) {
          let target = null;
          let minDist = config.range + 1;
          for (const hostile of hostileList) {
            const d = this.distance(pet.location, hostile.location);
            if (d < minDist) {
              minDist = d;
              target = hostile;
            }
          }
          if (target) this.petAttack(pet, target, config);
        }
      } catch {}
    }
  }

  /** Execute a pet attack on a hostile target */
  petAttack(pet, target, config) {
    try {
      // Apply damage
      target.applyDamage(config.damage, {
        cause: "entityAttack",
        damagingEntity: pet,
      });

      // Sweep attack for ocelots (hits additional nearby hostiles)
      if (config.sweep) {
        const nearby = pet.dimension.getEntities({
          location: target.location,
          maxDistance: 2,
        });
        for (const extra of nearby) {
          if (extra.id === target.id) continue;
          if (!HOSTILE_TYPES.has(extra.typeId)) continue;
          try {
            extra.applyDamage(Math.floor(config.damage / 2), {
              cause: "entityAttack",
              damagingEntity: pet,
            });
          } catch {}
        }
      }

      // Play sound
      try {
        pet.dimension.playSound(config.sound, pet.location, { volume: 0.7 });
      } catch {}

      // Set cooldown tag (removed after config.cooldown ticks)
      pet.addTag("ec.combat_cd");
      system.runTimeout(() => {
        try { pet.removeTag("ec.combat_cd"); } catch {}
      }, config.cooldown);
    } catch {}
  }

  distance(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }
}
