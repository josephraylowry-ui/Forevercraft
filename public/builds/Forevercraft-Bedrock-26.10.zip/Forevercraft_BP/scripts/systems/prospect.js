/**
 * Prospect System — Mining node spawning and harvesting.
 * Nodes spawn near players, right-click starts 3s mining → loot + XP.
 * Replaces Java prospect/ folder (17 files).
 */
import { world, system, ItemStack } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Node visual blocks by dimension/depth
const NODE_BLOCKS = {
  overworld_surface: "minecraft:raw_copper_block",
  overworld_deep: "minecraft:raw_iron_block",
  nether: "minecraft:gilded_blackstone",
  end: "minecraft:purpur_block",
};

// Loot tables (weighted random selection)
const NODE_LOOT = [
  { item: "minecraft:iron_nugget", weight: 20, min: 3, max: 6 },
  { item: "minecraft:copper_ingot", weight: 15, min: 1, max: 3 },
  { item: "minecraft:coal", weight: 15, min: 2, max: 4 },
  { item: "minecraft:lapis_lazuli", weight: 10, min: 1, max: 3 },
  { item: "minecraft:gold_nugget", weight: 8, min: 2, max: 4 },
  { item: "minecraft:redstone", weight: 7, min: 2, max: 5 },
  { item: "minecraft:amethyst_shard", weight: 5, min: 1, max: 2 },
  { item: "minecraft:diamond", weight: 3, min: 1, max: 1, condition: "deep" },
  { item: "minecraft:emerald", weight: 2, min: 1, max: 1 },
];

const PICKAXE_TYPES = new Set([
  "minecraft:iron_pickaxe", "minecraft:diamond_pickaxe", "minecraft:netherite_pickaxe",
  "forevercraft:mythical_pickaxe",
]);

const MINE_DURATION = 60; // 3 seconds at 20 TPS
const MAX_NODES = 7;
const MAX_DISTANCE = 100;
const NODE_LIFETIME = 300; // 5 minutes in seconds
const SPAWN_TIMER_MOVING = 30; // seconds
const SPAWN_TIMER_STILL = 400; // ~6.7 minutes in seconds

export class ProspectSystem {
  constructor(eventBridge, movementSystem) {
    this.eventBridge = eventBridge;
    this.movementSystem = movementSystem;
    this.nodes = []; // {x, y, z, dim, spawnTime, blockType}
    this.miningPlayers = new Map(); // playerId → {nodeIdx, progress, startTick}
  }

  /**
   * Spawn tick — runs every 20 ticks (1 second).
   */
  tickSpawn(players) {
    const now = system.currentTick;

    for (const player of players) {
      const gm = player.getGameMode?.() ?? "survival";
      if (gm === "creative" || gm === "spectator") continue;

      const s = StorageManager.forPlayer(player);
      let timer = s.getNumber("pr_timer", SPAWN_TIMER_MOVING);
      timer--;

      if (timer <= 0) {
        this.trySpawn(player);
        // Reset timer based on movement
        const moving = this.movementSystem?.isMoving(player) ?? false;
        timer = moving ? SPAWN_TIMER_MOVING : SPAWN_TIMER_STILL;
      }

      s.set("pr_timer", timer);
    }

    // Despawn expired nodes
    this.tickDespawn(now);
  }

  /**
   * Attempt to spawn a node near a player.
   */
  trySpawn(player) {
    // Count nearby nodes
    const nearby = this.countNearbyNodes(player.location, player.dimension.id, MAX_DISTANCE);
    if (nearby >= MAX_NODES) return;

    const pos = player.location;
    const dim = player.dimension;

    // Random position 15-80 blocks away
    const angle = Math.random() * Math.PI * 2;
    const dist = 15 + Math.random() * 65;
    const nx = Math.floor(pos.x + Math.cos(angle) * dist);
    const nz = Math.floor(pos.z + Math.sin(angle) * dist);

    // Find ground level
    const ny = this.findGround(dim, nx, Math.floor(pos.y), nz);
    if (ny === null) return;

    // Determine block type
    let blockType;
    if (dim.id === "minecraft:nether") {
      blockType = NODE_BLOCKS.nether;
    } else if (dim.id === "minecraft:the_end") {
      blockType = NODE_BLOCKS.end;
    } else {
      blockType = ny < 0 ? NODE_BLOCKS.overworld_deep : NODE_BLOCKS.overworld_surface;
    }

    // Store node
    const node = {
      x: nx, y: ny, z: nz,
      dim: dim.id,
      spawnTime: system.currentTick,
      blockType,
    };
    this.nodes.push(node);

    // Place the visual block
    try {
      dim.runCommandAsync(`setblock ${nx} ${ny} ${nz} ${blockType}`);
    } catch {}

    // Cluster chance: 50% single, 35% double, 15% triple
    const roll = Math.random();
    if (roll > 0.5 && nearby + 1 < MAX_NODES) {
      this.spawnClusterNode(dim, nx, ny, nz, pos.y);
    }
    if (roll > 0.85 && nearby + 2 < MAX_NODES) {
      this.spawnClusterNode(dim, nx, ny, nz, pos.y);
    }

    // Spawn particles
    try {
      dim.runCommandAsync(`particle minecraft:basic_smoke_particle ${nx} ${ny + 0.5} ${nz}`);
    } catch {}
  }

  spawnClusterNode(dim, baseX, baseY, baseZ, playerY) {
    const ox = baseX + Math.floor(Math.random() * 6) - 3;
    const oz = baseZ + Math.floor(Math.random() * 6) - 3;
    const oy = this.findGround(dim, ox, Math.floor(playerY), oz);
    if (oy === null) return;

    let blockType;
    if (dim.id === "minecraft:nether") blockType = NODE_BLOCKS.nether;
    else if (dim.id === "minecraft:the_end") blockType = NODE_BLOCKS.end;
    else blockType = oy < 0 ? NODE_BLOCKS.overworld_deep : NODE_BLOCKS.overworld_surface;

    this.nodes.push({ x: ox, y: oy, z: oz, dim: dim.id, spawnTime: system.currentTick, blockType });
    try {
      dim.runCommandAsync(`setblock ${ox} ${oy} ${oz} ${blockType}`);
    } catch {}
  }

  findGround(dim, x, refY, z) {
    // Scan down from refY, then up
    for (let y = refY; y >= refY - 50 && y >= -64; y--) {
      try {
        const block = dim.getBlock({ x, y, z });
        const above = dim.getBlock({ x, y: y + 1, z });
        if (block && !block.isAir && above && above.isAir) {
          return y + 1;
        }
      } catch { break; }
    }
    for (let y = refY; y <= refY + 30 && y <= 320; y++) {
      try {
        const block = dim.getBlock({ x, y, z });
        const above = dim.getBlock({ x, y: y + 1, z });
        if (block && !block.isAir && above && above.isAir) {
          return y + 1;
        }
      } catch { break; }
    }
    return null;
  }

  countNearbyNodes(pos, dimId, maxDist) {
    return this.nodes.filter((n) =>
      n.dim === dimId &&
      Math.abs(n.x - pos.x) + Math.abs(n.z - pos.z) <= maxDist
    ).length;
  }

  tickDespawn(now) {
    const expiredTicks = NODE_LIFETIME * 20;
    const expired = [];
    for (let i = this.nodes.length - 1; i >= 0; i--) {
      if (now - this.nodes[i].spawnTime >= expiredTicks) {
        const node = this.nodes[i];
        // Remove the block
        try {
          world.getDimension(node.dim).runCommandAsync(
            `setblock ${node.x} ${node.y} ${node.z} air`
          );
        } catch {}
        this.nodes.splice(i, 1);
      }
    }
  }

  /**
   * Handle block interaction (right-click on node block).
   * Called from event bridge when player interacts with block.
   */
  onBlockInteract(player, block) {
    if (!block) return false;

    // Check if this is a node location
    const nodeIdx = this.nodes.findIndex(
      (n) => n.x === block.location.x && n.y === block.location.y &&
             n.z === block.location.z && n.dim === player.dimension.id
    );
    if (nodeIdx === -1) return false;

    // Check for pickaxe
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (!mainhand || !PICKAXE_TYPES.has(mainhand.typeId)) {
      player.sendMessage("§c§l[Prospecting] §7You need an iron pickaxe or better!");
      return true;
    }

    // Already mining?
    if (this.miningPlayers.has(player.id)) {
      return true;
    }

    // Start mining
    this.miningPlayers.set(player.id, {
      nodeIdx,
      progress: 0,
      startTick: system.currentTick,
      nodeX: this.nodes[nodeIdx].x,
      nodeY: this.nodes[nodeIdx].y,
      nodeZ: this.nodes[nodeIdx].z,
    });

    player.sendMessage("§7§l[Prospecting] §7Mining...");
    try {
      player.playSound("hit.stone", { volume: 0.6, pitch: 0.8 });
    } catch {}

    // Show actionbar progress
    player.onScreenDisplay.setActionBar("§e⛏ Mining... [          ] 0%");

    return true;
  }

  /**
   * Progress tick — runs every tick for active miners.
   */
  tickMining(players) {
    for (const player of players) {
      const mining = this.miningPlayers.get(player.id);
      if (!mining) continue;

      // Range check
      const pos = player.location;
      const dx = Math.abs(pos.x - mining.nodeX);
      const dz = Math.abs(pos.z - mining.nodeZ);
      if (dx > 4 || dz > 4) {
        this.cancelMining(player, "You moved too far away!");
        continue;
      }

      // Node still exists?
      if (mining.nodeIdx >= this.nodes.length || !this.nodes[mining.nodeIdx]) {
        this.cancelMining(player, "The node disappeared!");
        continue;
      }

      mining.progress++;

      // Progress bar
      const pct = Math.floor((mining.progress / MINE_DURATION) * 100);
      const filled = Math.floor(mining.progress / MINE_DURATION * 10);
      const bar = "█".repeat(filled) + "░".repeat(10 - filled);
      player.onScreenDisplay.setActionBar(`§e⛏ Mining... [${bar}] ${pct}%`);

      // Sound at intervals
      if (mining.progress === 15 || mining.progress === 30 || mining.progress === 45) {
        try { player.playSound("break.stone", { volume: 0.4, pitch: 1.0 + mining.progress * 0.01 }); } catch {}
      }

      // Complete
      if (mining.progress >= MINE_DURATION) {
        this.completeMining(player, mining);
      }
    }
  }

  cancelMining(player, reason) {
    this.miningPlayers.delete(player.id);
    player.sendMessage(`§c§l[Prospecting] §7${reason}`);
    player.onScreenDisplay.setActionBar("");
    try { player.playSound("break.stone", { volume: 0.4, pitch: 0.6 }); } catch {}
  }

  completeMining(player, mining) {
    this.miningPlayers.delete(player.id);

    // Remove the node
    const node = this.nodes[mining.nodeIdx];
    if (node) {
      try {
        world.getDimension(node.dim).runCommandAsync(
          `setblock ${node.x} ${node.y} ${node.z} air`
        );
      } catch {}
      this.nodes.splice(mining.nodeIdx, 1);
    }

    // Roll loot
    const loot = this.rollLoot(player, node);
    if (loot) {
      try {
        const stack = new ItemStack(loot.item, loot.count);
        const inv = player.getComponent("minecraft:inventory")?.container;
        if (inv) {
          for (let i = 0; i < inv.size; i++) {
            if (!inv.getItem(i)) { inv.setItem(i, stack); break; }
          }
        }
      } catch {}
    }

    // XP reward
    try { player.runCommandAsync("xp 5 @s"); } catch {}

    // Track stats
    const s = StorageManager.forPlayer(player);
    s.set("stat_mine", (s.getNumber("stat_mine", 0)) + 4);
    s.set("prospects_done", (s.getNumber("prospects_done", 0)) + 1);

    player.onScreenDisplay.setActionBar("§a⛏ Mining complete!");
    player.sendMessage("§a§l[Prospecting] §7Node harvested!");
    try {
      player.playSound("random.orb", { volume: 0.5, pitch: 0.8 });
    } catch {}

    this.eventBridge.emit("prospect_complete", player);
  }

  rollLoot(player, node) {
    const isDeep = node && node.y < 0;
    const filtered = NODE_LOOT.filter((l) => {
      if (l.condition === "deep" && !isDeep) return false;
      return true;
    });

    const totalWeight = filtered.reduce((sum, l) => sum + l.weight, 0);
    let roll = Math.random() * totalWeight;

    for (const entry of filtered) {
      roll -= entry.weight;
      if (roll <= 0) {
        const count = entry.min + Math.floor(Math.random() * (entry.max - entry.min + 1));
        return { item: entry.item, count };
      }
    }
    return { item: "minecraft:cobblestone", count: 1 };
  }
}
