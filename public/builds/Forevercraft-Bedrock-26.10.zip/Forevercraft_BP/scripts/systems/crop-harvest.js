/**
 * Crop Auto-Replant System — When a player breaks a mature crop while holding a hoe,
 * the crop is automatically replanted at age 0.
 * Supports: wheat, carrots, potatoes, beetroots, nether_wart.
 * Replaces Java crop_harvest/ folder (3 files).
 */
import { world } from "@minecraft/server";

// Crops that can be auto-replanted and their soil type
const REPLANTABLE_CROPS = {
  "minecraft:wheat": "minecraft:farmland",
  "minecraft:carrots": "minecraft:farmland",
  "minecraft:potatoes": "minecraft:farmland",
  "minecraft:beetroot": "minecraft:farmland",
  "minecraft:nether_wart": "minecraft:soul_sand",
};

// All hoe item types
const HOE_TYPES = new Set([
  "minecraft:wooden_hoe",
  "minecraft:stone_hoe",
  "minecraft:iron_hoe",
  "minecraft:golden_hoe",
  "minecraft:diamond_hoe",
  "minecraft:netherite_hoe",
  "forevercraft:hoe_of_honor",
]);

export class CropHarvestSystem {
  constructor(eventBridge) {
    // Listen for block break events
    world.afterEvents.playerBreakBlock.subscribe((event) => {
      this.onBlockBreak(event);
    });
  }

  onBlockBreak(event) {
    const player = event.player;
    const brokenBlock = event.brokenBlockPermutation;
    if (!player || !brokenBlock) return;

    const blockId = brokenBlock.type?.id;
    if (!blockId) return;

    // Check if broken block is a replantable crop
    const soilType = REPLANTABLE_CROPS[blockId];
    if (!soilType) return;

    // Check if player is holding a hoe in mainhand
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;

    const mainhand = equip.getEquipment("Mainhand");
    if (!mainhand) return;

    if (!HOE_TYPES.has(mainhand.typeId)) return;

    // Get the block location where the crop was broken
    const block = event.block;
    if (!block) return;

    // Check if the block below is the correct soil type
    try {
      const below = block.below();
      if (!below) return;

      if (below.typeId === soilType) {
        // Replant the crop at age 0
        // Use setPermutation or place block
        try {
          const cropType = block.dimension.getBlock(block.location);
          if (cropType && (cropType.typeId === "minecraft:air" || cropType.isAir)) {
            // Place the crop block back
            block.dimension.runCommandAsync(
              `setblock ${block.location.x} ${block.location.y} ${block.location.z} ${blockId}`
            );
          }
        } catch {}
      }
    } catch {}

    // 3% chance to drop a random cooking ingredient
    if (Math.random() < 0.03) {
      this.dropIngredient(player, "cooking");
    }
  }

  /** Drop a random ingredient near the player */
  dropIngredient(player, type) {
    const COOKING_INGREDIENTS = [
      "minecraft:sugar", "minecraft:egg", "minecraft:cocoa_beans",
      "minecraft:dried_kelp", "minecraft:honeycomb", "minecraft:glow_berries",
    ];
    const FORGING_INGREDIENTS = [
      "minecraft:iron_nugget", "minecraft:gold_nugget", "minecraft:quartz",
      "minecraft:prismarine_shard", "minecraft:prismarine_crystals", "minecraft:amethyst_shard",
    ];

    const pool = type === "cooking" ? COOKING_INGREDIENTS : FORGING_INGREDIENTS;
    const item = pool[Math.floor(Math.random() * pool.length)];

    try {
      const pos = player.location;
      player.dimension.runCommandAsync(
        `give @s ${item} 1`
      );
      player.sendMessage(`§a§l+ §r§7Found a ${type} ingredient!`);
    } catch {}
  }
}
