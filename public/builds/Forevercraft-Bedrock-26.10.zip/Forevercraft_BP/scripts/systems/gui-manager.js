/**
 * GUI Manager — Form-based UI system replacing all Java text_display GUIs.
 * Routes GUI open requests to the appropriate system menus.
 * Compiled from src/systems/gui-manager.ts
 */
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";
import { StorageManager } from "../utils/storage.js";

// === FORM HELPERS ===

export async function showActionForm(player, title, body, buttons) {
  const form = new ActionFormData().title(title).body(body);
  for (const btn of buttons) {
    btn.icon ? form.button(btn.text, btn.icon) : form.button(btn.text);
  }
  const response = await form.show(player);
  if (response.canceled) return -1;
  return response.selection ?? -1;
}

export async function showConfirm(player, title, body, confirmText = "Confirm", cancelText = "Cancel") {
  const form = new MessageFormData().title(title).body(body).button1(confirmText).button2(cancelText);
  const response = await form.show(player);
  return response.selection === 0;
}

export async function showPaginatedMenu(player, title, items, page = 0, pageSize = 8) {
  const totalPages = Math.ceil(items.length / pageSize);
  const start = page * pageSize;
  const end = Math.min(start + pageSize, items.length);
  const pageItems = items.slice(start, end);
  const buttons = [...pageItems];
  if (page > 0) buttons.push({ text: "§c← Previous Page" });
  if (page < totalPages - 1) buttons.push({ text: "§aNext Page →" });
  buttons.push({ text: "§7Close" });
  const body = `Page ${page + 1} of ${totalPages} (${items.length} total)`;
  const selection = await showActionForm(player, title, body, buttons);
  if (selection === -1) return { index: -1, page };
  const navStart = pageItems.length;
  if (page > 0 && selection === navStart) return showPaginatedMenu(player, title, items, page - 1, pageSize);
  if (page < totalPages - 1 && selection === navStart + (page > 0 ? 1 : 0)) return showPaginatedMenu(player, title, items, page + 1, pageSize);
  if (selection >= navStart) return { index: -1, page };
  return { index: start + selection, page };
}


// === GUI MANAGER CLASS ===

export class GUIManager {
  constructor(systems) {
    this.systems = systems;
  }

  /** Route GUI open requests by name */
  openByName(player, name) {
    switch (name) {
      case "codex": openCodexHub(player, this.systems); break;
      case "pets": case "companions": this.systems.companions?.openPetMenu?.(player) || openPetMenu(player); break;
      case "quests": this.systems.quests?.openQuestBoard?.(player) || openQuestBoard(player); break;
      case "guidestone": this.systems.guidestone?.openMenu?.(player) || openGuidestoneMenu(player); break;
      case "cooking": this.systems.cooking?.openCookingMenu?.(player) || openCookingMenu(player); break;
      case "satchel": this.systems.satchel?.openSatchelMenu?.(player) || openSatchelMenu(player); break;
      case "black_market": this.systems.blackMarket?.openMenu?.(player) || openBlackMarket(player); break;
      case "party": this.systems.party?.openPartyMenu?.(player) || openPartyMenu(player); break;
      case "housing": case "hearthstone": this.systems.housing?.openMenu?.(player) || openHearthstoneMenu(player); break;
      case "advantages": case "skills": this.systems.advantages?.openMenu?.(player) || openCodexHub(player, this.systems); break;
      case "stats": openStatsViewer(player); break;
      case "transmute": openTransmuteMenu(player); break;
      case "glyphforge": this.systems.glyphforge?.giveForgeBlock?.(player) || openGlyphforgeMenu(player); break;
      case "inscription": player.sendMessage("§5§l✦ §r§7Use a glyph on polished deepslate to create an Inscription Stone."); break;
      case "dungeon": openDungeonMenu(player); break;
      case "dreams": this.showDreamRate(player); break;
      case "achievements": this.systems.achievements?.showAchievements?.(player); break;
      case "lore": this.systems.lore?.showLoreMenu?.(player); break;
      case "bounty": this.systems.bounty?.openBountyBoard?.(player); break;
      case "professions": this.systems.professions?.openProfessionMenu?.(player); break;
      default:
        player.sendMessage(`§7Unknown menu: ${name}`);
        break;
    }
  }

  showDreamRate(player) {
    const s = StorageManager.forPlayer(player);
    const dr = s.getNumber("dream_rate") || 0;
    player.sendMessage(`§d§lDream Rate: §r§f${dr}`);
    player.sendMessage("§7Dream Rate affects treasure quality, night terrors, and more.");
  }
}


// === CODEX HUB ===
export async function openCodexHub(player, systems) {
  const s = await showActionForm(player, "§6§lCodex of Everything", "Choose a section:", [
    { text: "§eArtifact Browser" }, { text: "§bClass Details" }, { text: "§dLore Exchange" },
    { text: "§aExploration Journal" }, { text: "§cChallenges & Achievements" },
    { text: "§5Advantage Trees" }, { text: "§6Player Stats" }, { text: "§7Settings" },
  ]);
  switch (s) {
    case 0: await openArtifactBrowser(player); break;
    case 1: await openClassDetails(player); break;
    case 4: systems?.achievements?.showAchievements?.(player); break;
    case 5: systems?.advantages?.openMenu?.(player); break;
    case 6: await openStatsViewer(player); break;
  }
}

// === ARTIFACT BROWSER ===
async function openArtifactBrowser(player) {
  const tiers = ["common","uncommon","rare","ornate","exquisite","mythical","special"];
  const colors = ["§f","§e","§b","§5","§6","§c","§d"];
  const buttons = tiers.map((t, i) => ({ text: `${colors[i]}${t.charAt(0).toUpperCase()+t.slice(1)} Artifacts` }));
  buttons.push({ text: "§7← Back" });
  const s = await showActionForm(player, "§eArtifact Browser", "Browse by tier:", buttons);
  if (s === 7) await openCodexHub(player);
  else if (s >= 0) player.sendMessage(`§7Opening ${tiers[s]} artifacts...`);
}

// === CLASS DETAILS ===
async function openClassDetails(player) {
  const classes = [
    { text: "§e⚔ Knight\n§7Fencer Stance: +damage without shield" },
    { text: "§c🗡 Rogue\n§7Auto-swing dagger combo" },
    { text: "§4⚔ Berserker\n§7Dual axes, rage mode" },
    { text: "§d✦ Dancer\n§7Gauntlets, evasion, flurry" },
    { text: "§a🏹 Archer\n§7Overcharge bow system" },
    { text: "§6🎯 Hunter\n§7Precision crossbow + fade" },
    { text: "§b🔱 Javelin\n§7Trident momentum + hoplite" },
    { text: "§8🔨 Striker\n§7Mace impact + ground slam" },
    { text: "§2🐾 Beastlord\n§7Spear + animal warp strikes" },
    { text: "§7← Back" },
  ];
  const s = await showActionForm(player, "§bWeapon Classes", "Each weapon type has a unique combat class:", classes);
  if (s === 9) await openCodexHub(player);
}

// === PET MENU ===
export async function openPetMenu(player) {
  await showActionForm(player, "§6Companion Menu", "Manage your companions:", [
    { text: "§aActive Pet: None" }, { text: "§ePet Collection" },
    { text: "§bPet Abilities" }, { text: "§dPet Rivalry" },
    { text: "§cDismiss Pet" }, { text: "§7Close" },
  ]);
}

// === QUEST BOARD ===
export async function openQuestBoard(player) {
  await showActionForm(player, "§6Quest Board", "Select a quest tier:", [
    { text: "§fTier 1 — Beginner" }, { text: "§eTier 2 — Apprentice" },
    { text: "§bTier 3 — Journeyman" }, { text: "§5Tier 4 — Expert" },
    { text: "§6Tier 5 — Master" }, { text: "§cActive Quests" },
    { text: "§aCompleted Quests" }, { text: "§7Close" },
  ]);
}

// === GUIDESTONE ===
export async function openGuidestoneMenu(player) {
  await showActionForm(player, "§aGuidestone Network", "Select destination:", [
    { text: "§7No guidestones registered yet" }, { text: "§cClose" },
  ]);
}

// === TRANSMUTE ===
export async function openTransmuteMenu(player) {
  await showActionForm(player, "§dTransmutation Altar", "Sacrifice artifact for new one:", [
    { text: "§eDeposit Artifact" }, { text: "§bView History" },
    { text: "§aTransmute Now" }, { text: "§7Close" },
  ]);
}

// === GLYPHFORGE ===
export async function openGlyphforgeMenu(player) {
  await showActionForm(player, "§5Glyphforge", "Inscribe glyphs:", [
    { text: "§eView Glyphs" }, { text: "§bApply Glyph" },
    { text: "§cRemove Glyph" }, { text: "§7Close" },
  ]);
}

// === HEARTHSTONE ===
export async function openHearthstoneMenu(player) {
  await showActionForm(player, "§6Hearthstone", "Your home base:", [
    { text: "§aTeleport Home" }, { text: "§eStash" },
    { text: "§bGarden" }, { text: "§dSet Home" }, { text: "§7Close" },
  ]);
}

// === COOKING ===
export async function openCookingMenu(player) {
  await showActionForm(player, "§6Campfire Kitchen", "Cook recipes:", [
    { text: "§eView Recipes" }, { text: "§aCook a Meal" },
    { text: "§bRecipe Discovery" }, { text: "§7Close" },
  ]);
}

// === SATCHEL ===
export async function openSatchelMenu(player) {
  await showActionForm(player, "§eEssentials Satchel", "Manage satchel:", [
    { text: "§aSlot 1: Empty" }, { text: "§aSlot 2: Empty" },
    { text: "§aSlot 3: Empty" }, { text: "§aSlot 4: Empty" },
    { text: "§aSlot 5: Empty" }, { text: "§7Close" },
  ]);
}

// === BLACK MARKET ===
export async function openBlackMarket(player) {
  await showActionForm(player, "§4Black Market", "Today's deals:", [
    { text: "§eDeal #1" }, { text: "§eDeal #2" }, { text: "§eDeal #3" },
    { text: "§cBuy/Sell" }, { text: "§7Close" },
  ]);
}

// === DUNGEON ===
export async function openDungeonMenu(player) {
  await showActionForm(player, "§cDungeon Instance", "Configure & enter:", [
    { text: "§aEasy" }, { text: "§eNormal" }, { text: "§cHard" },
    { text: "§4Nightmare" }, { text: "§bParty Status" }, { text: "§7Close" },
  ]);
}

// === PARTY ===
export async function openPartyMenu(player) {
  await showActionForm(player, "§bParty", "Manage party:", [
    { text: "§aInvite Player" }, { text: "§eView Members" },
    { text: "§cLeave Party" }, { text: "§7Close" },
  ]);
}

// === STATS ===
export async function openStatsViewer(player) {
  const s = StorageManager.forPlayer(player);
  const stats = {
    "Artifacts Collected": s.getNumber("artifacts_collected"),
    "Lore Collected": s.getNumber("lore_collected"),
    "Dream Rate": s.getNumber("dream_rate"),
    "Blocks Mined": s.getNumber("blocks_mined"),
    "Fish Caught": s.getNumber("fish_caught"),
    "Patron Kills": s.getNumber("patron_kills"),
    "Bounties Completed": s.getNumber("bounties_completed"),
    "Quests Completed": s.getNumber("quests_done"),
  };

  let body = "";
  for (const [name, value] of Object.entries(stats)) {
    body += `§7${name}: §f${value || 0}\n`;
  }

  await showActionForm(player, "§6Player Statistics", body, [
    { text: "§eCombat Stats" }, { text: "§bExploration Stats" },
    { text: "§aCollection Stats" }, { text: "§7Close" },
  ]);
}
