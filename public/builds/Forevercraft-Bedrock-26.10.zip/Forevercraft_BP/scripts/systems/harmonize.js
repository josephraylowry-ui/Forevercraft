/**
 * Harmonize System — Compounds multiple sources of the same effect into stronger effects.
 * 2 sources of Level N = 1 source of Level N+1 (cascading).
 * 6 effects: Strength, Speed, Haste, Resistance, Jump Boost, Regeneration.
 * Replaces Java harmonize/ folder.
 */
import { StorageManager } from "../utils/storage.js";

// Effect definitions with Bedrock effect IDs
const EFFECTS = [
  { id: "str", name: "strength", display: "Strength", maxLevel: 4 },
  { id: "spd", name: "speed", display: "Speed", maxLevel: 4 },
  { id: "hst", name: "haste", display: "Haste", maxLevel: 4 },
  { id: "res", name: "resistance", display: "Resistance", maxLevel: 4 },
  { id: "jmp", name: "jump_boost", display: "Jump Boost", maxLevel: 4 },
  { id: "reg", name: "regeneration", display: "Regeneration", maxLevel: 4 },
];

// Source detection: maps item tags/properties to effect contributions
// Each source: { tag/check, effect, level }
// In full implementation, this would check equipped items, armor sets, etc.
const ARMOR_SET_BONUSES = {
  // 2-piece bonuses
  "golem_2pc": [{ effect: "res", level: 1 }, { effect: "hst", level: 1 }],
  "blood_2pc": [{ effect: "str", level: 1 }],
  "shadow_2pc": [{ effect: "spd", level: 1 }],
  "storm_2pc": [{ effect: "spd", level: 1 }],
  "crystal_2pc": [{ effect: "res", level: 1 }],
  "nature_2pc": [{ effect: "reg", level: 1 }],
  "ninja_2pc": [{ effect: "spd", level: 2 }],
  "journey_2pc": [{ effect: "hst", level: 1 }],
  "space_2pc": [{ effect: "jmp", level: 3 }],
  "splendid_2pc": [{ effect: "spd", level: 1 }],
  "infernal_2pc": [{ effect: "res", level: 1 }],
  "ender_dragon_2pc": [{ effect: "res", level: 1 }],
  "celestial_2pc": [{ effect: "res", level: 1 }],
  "dragonmaster_2pc": [{ effect: "str", level: 1 }],
  "cloaked_skull_2pc": [{ effect: "res", level: 1 }],
  // 4-piece bonuses
  "golem_4pc": [{ effect: "str", level: 1 }],
  "blood_4pc": [{ effect: "str", level: 2 }, { effect: "hst", level: 1 }],
  "shadow_4pc": [{ effect: "spd", level: 2 }],
  "crystal_4pc": [{ effect: "res", level: 2 }],
  "sculk_4pc": [{ effect: "str", level: 1 }],
  "ninja_4pc": [{ effect: "spd", level: 2 }, { effect: "jmp", level: 2 }],
  "celestial_4pc": [{ effect: "res", level: 1 }],
  "cloaked_skull_4pc": [{ effect: "str", level: 1 }, { effect: "res", level: 1 }],
  "space_4pc": [{ effect: "spd", level: 1 }, { effect: "jmp", level: 3 }],
  // 5-piece bonuses
  "ender_dragon_5pc": [{ effect: "res", level: 1 }, { effect: "reg", level: 1 }, { effect: "str", level: 2 }],
  "infernal_5pc": [{ effect: "str", level: 2 }],
  "dragonmaster_5pc": [{ effect: "str", level: 2 }],
  "titan_5pc": [{ effect: "spd", level: 1 }],
};

export class HarmonizeSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  /**
   * Tick — runs every 40 ticks (2 seconds). Detects and compounds effects.
   */
  tick(players) {
    for (const player of players) {
      if (player.getGameMode() === "creative" || player.getGameMode() === "spectator") continue;
      this.processPlayer(player);
    }
  }

  /**
   * Process harmonization for a single player.
   */
  processPlayer(player) {
    const storage = StorageManager.forPlayer(player);

    // Initialize level counters
    const levels = {};
    for (const eff of EFFECTS) {
      levels[eff.id] = [0, 0, 0, 0, 0]; // counts for levels 1-5
    }

    // Count sources from equipped armor set bonuses
    this.countArmorSetSources(player, storage, levels);

    // Count sources from individual artifacts
    this.countArtifactSources(player, storage, levels);

    // Compound and apply each effect
    for (const eff of EFFECTS) {
      const finalLevel = this.compound(levels[eff.id]);

      // Only apply if level 2+ (single sources handled by their items)
      if (finalLevel >= 2) {
        const amplifier = Math.min(finalLevel - 1, 4); // cap at amplifier 4
        // Resistance capped at level 3 (amplifier 2) to prevent invincibility
        const cappedAmp = eff.id === "res" ? Math.min(amplifier, 2) : amplifier;
        try {
          player.addEffect(eff.name, 600, {
            amplifier: cappedAmp,
            showParticles: false,
          });
        } catch {}
      }
    }
  }

  /**
   * Count effect sources from equipped armor set tags.
   */
  countArmorSetSources(player, storage, levels) {
    for (const [setTag, bonuses] of Object.entries(ARMOR_SET_BONUSES)) {
      if (player.hasTag(`ec.set_${setTag}`)) {
        for (const bonus of bonuses) {
          const lvlIdx = bonus.level - 1;
          if (lvlIdx >= 0 && lvlIdx < 5) {
            levels[bonus.effect][lvlIdx]++;
          }
        }
      }
    }
  }

  /**
   * Count effect sources from individual artifact items.
   */
  countArtifactSources(player, storage, levels) {
    // Check for specific artifact tags
    const artifactSources = [
      // Strength sources
      { tag: "ec.has_beacon_ancients", effect: "str", level: 1 },
      { tag: "ec.has_berserkers_fang", effect: "str", level: 1 },
      { tag: "ec.has_wither_rose_crown", effect: "str", level: 1 },
      { tag: "ec.has_dragons_tear", effect: "str", level: 1 },
      { tag: "ec.has_infernal_heart", effect: "str", level: 1 },
      { tag: "ec.has_warden_ring", effect: "str", level: 2 },
      { tag: "ec.has_ender_dragon_scale", effect: "str", level: 3 },
      // Speed sources
      { tag: "ec.has_diamond_ring", effect: "spd", level: 1 },
      { tag: "ec.has_travelers_charm", effect: "spd", level: 1 },
      { tag: "ec.has_seers_compass", effect: "spd", level: 1 },
      { tag: "ec.has_wind_chime", effect: "spd", level: 1 },
      { tag: "ec.has_beacon_ancients", effect: "spd", level: 1 },
      { tag: "ec.has_windwalker_boots", effect: "spd", level: 1 },
      { tag: "ec.has_berserkers_fang", effect: "spd", level: 1 },
      // Haste sources
      { tag: "ec.has_redstone_ring", effect: "hst", level: 1 },
      { tag: "ec.has_stormcatcher_shard", effect: "hst", level: 1 },
      { tag: "ec.has_spelunkers_echo", effect: "hst", level: 1 },
      { tag: "ec.has_beacon_ancients", effect: "hst", level: 1 },
      { tag: "ec.has_golden_gauntlet", effect: "hst", level: 1 },
      { tag: "ec.has_redstone_heart", effect: "hst", level: 3 },
      // Resistance sources
      { tag: "ec.has_iron_talisman", effect: "res", level: 1 },
      { tag: "ec.has_nether_star_shard", effect: "res", level: 1 },
      { tag: "ec.has_heart_of_void", effect: "res", level: 1 },
      { tag: "ec.has_beacon_ancients", effect: "res", level: 1 },
      { tag: "ec.has_nether_ring", effect: "res", level: 2 },
      { tag: "ec.has_void_ring", effect: "res", level: 2 },
      // Jump sources
      { tag: "ec.has_slime_ring", effect: "jmp", level: 1 },
      { tag: "ec.has_beacon_ancients", effect: "jmp", level: 1 },
      // Regen sources
      { tag: "ec.has_healers_salve", effect: "reg", level: 1 },
      { tag: "ec.has_nether_star_shard", effect: "reg", level: 1 },
      { tag: "ec.has_beacon_ancients", effect: "reg", level: 1 },
    ];

    for (const src of artifactSources) {
      if (player.hasTag(src.tag)) {
        const lvlIdx = src.level - 1;
        if (lvlIdx >= 0 && lvlIdx < 5) {
          levels[src.effect][lvlIdx]++;
        }
      }
    }
  }

  /**
   * Compound level counts using integer division cascade.
   * 2 sources of level N become 1 source of level N+1.
   * Returns the highest level with at least 1 source.
   */
  compound(counts) {
    // counts[0] = count at level 1, counts[1] = count at level 2, etc.
    for (let i = 0; i < counts.length - 1; i++) {
      const carry = Math.floor(counts[i] / 2);
      counts[i] = counts[i] % 2;
      counts[i + 1] += carry;
    }

    // Find highest non-zero level
    for (let i = counts.length - 1; i >= 0; i--) {
      if (counts[i] > 0) return i + 1; // +1 because index 0 = level 1
    }
    return 0;
  }
}
