/**
 * Advantage Tree System — 15 skill trees with leveling, prestige, challenges.
 * Replaces Java advantage/ folder (321 files).
 * Core progression system with stat-based XP, token economy, cosmetics.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";
import { applyKnockback } from "../utils/knockback.js";

const MAX_LEVEL = 25;

const SKILL_TREES = [
  { id: "agility", name: "Agility", icon: "🏃", color: "§a", stat: "walk_cm", statName: "Blocks Walked", category: "utility", multiplier: 10000 },
  { id: "dexterity", name: "Dexterity", icon: "🤸", color: "§e", stat: "blocks_placed", statName: "Blocks Placed", category: "utility", multiplier: 500 },
  { id: "evasion", name: "Evasion", icon: "💨", color: "§b", stat: "crouch_cm", statName: "Blocks Crouched", category: "combat", multiplier: 5000 },
  { id: "stealth", name: "Stealth", icon: "🥷", color: "§8", stat: "sneak_time", statName: "Sneak Time", category: "combat", multiplier: 2000 },
  { id: "vitality", name: "Vitality", icon: "❤", color: "§c", stat: "food_eaten", statName: "Food Eaten", category: "support", multiplier: 200 },
  { id: "taskmaster", name: "Taskmaster", icon: "📋", color: "§6", stat: "quests_done", statName: "Quests Completed", category: "utility", multiplier: 20 },
  { id: "beastmaster", name: "Beastmaster", icon: "🐾", color: "§2", stat: "pets_owned", statName: "Pets Collected", category: "support", multiplier: 10 },
  { id: "victorian", name: "Victorian", icon: "⚔", color: "§4", stat: "mob_kills", statName: "Mobs Killed", category: "combat", multiplier: 500 },
  { id: "fishing", name: "Fishing", icon: "🎣", color: "§3", stat: "fish_caught", statName: "Fish Caught", category: "gather", multiplier: 100 },
  { id: "mining", name: "Mining", icon: "⛏", color: "§7", stat: "blocks_mined", statName: "Blocks Mined", category: "gather", multiplier: 1000 },
  { id: "gathering", name: "Gathering", icon: "🌿", color: "§a", stat: "crops_harvested", statName: "Crops Harvested", category: "gather", multiplier: 300 },
  { id: "blacksmith", name: "Blacksmith", icon: "🔨", color: "§6", stat: "items_smelted", statName: "Items Smelted", category: "gather", multiplier: 200 },
  { id: "explorer", name: "Explorer", icon: "🧭", color: "§e", stat: "structures_looted", statName: "Structures Found", category: "utility", multiplier: 30 },
  { id: "culinary", name: "Culinary", icon: "🍳", color: "§c", stat: "meals_cooked", statName: "Meals Cooked", category: "support", multiplier: 50 },
  { id: "dreamer", name: "Dreamer", icon: "🌙", color: "§d", stat: "dream_rate", statName: "Dream Rate", category: "support", multiplier: 5 },
];

// XP required per level (escalating curve)
function xpForLevel(level) {
  return Math.floor(100 * Math.pow(1.3, level));
}

// Synergy bonuses when multiple trees are leveled
const SYNERGIES = [
  { id: "combat", trees: ["victorian", "evasion", "stealth"], name: "Combat Synergy", bonus: "Strength I" },
  { id: "gather", trees: ["mining", "gathering", "fishing"], name: "Gather Synergy", bonus: "Haste I" },
  { id: "utility", trees: ["agility", "explorer", "dexterity"], name: "Utility Synergy", bonus: "Speed I" },
  { id: "support", trees: ["vitality", "beastmaster", "culinary"], name: "Support Synergy", bonus: "Regeneration" },
];

export class AdvantageTreeSystem {
  constructor(eventBridge) {
    this.tickCounter = 0;

    // Evasion dodge event — triggered by combat system on successful dodge
    eventBridge.on("evasion_dodge", (player) => {
      this.onEvasionDodge(player);
    });
  }

  /**
   * Evasion Dodge — Resistance 5 for 1 tick + prestige abilities.
   * P1: Shadow Counter — 4-step knockback on nearest mob
   * P2: Vanishing Dodge — 2s invisibility
   * P3: Perfect Evasion — 1s guaranteed dodge window (20 ticks)
   */
  onEvasionDodge(player) {
    // Base dodge: near-immunity via Resistance V
    player.runCommandAsync("effect @s resistance 1 4 true");
    player.playSound("entity.player.attack.sweep");
    player.onScreenDisplay.setActionBar("§b§lDodged!");

    const s = StorageManager.forPlayer(player);
    s.increment("ach_dodge_count");

    const prestige = s.getNumber("adv_pres_evasion") || 0;

    // P1+: Shadow Counter — knockback nearest mob 4 steps away
    if (prestige >= 1) {
      try {
        const nearby = player.dimension.getEntities({
          location: player.location, maxDistance: 5,
          excludeTypes: ["minecraft:player", "minecraft:item"],
          excludeFamilies: ["inanimate"],
          limit: 1, closest: true,
        });
        for (const entity of nearby) {
          applyKnockback(entity, player, 4);
        }
        player.playSound("entity.enderman.teleport");
      } catch {}
    }

    // P2+: Vanishing Dodge — 2s invisibility
    if (prestige >= 2) {
      player.runCommandAsync("effect @s invisibility 2 0 true");
    }

    // P3: Perfect Evasion — 1s guaranteed dodge window
    if (prestige >= 3) {
      s.set("adv_pa_evas3_tm", 20);
    }

    // Challenge hook: increment dodge counter for Ghost challenge
    const chalId = s.getNumber("adv_chal_id");
    if (chalId === 4) s.increment("adv_chal_prog");
  }

  /** Open main advantage tree menu */
  openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const totalLevel = this.getTotalLevel(s);
    const tokens = s.getNumber("adv_tokens") || 0;

    const form = new ActionFormData()
      .title("§6Advantage Trees")
      .body(`§7Total Level: §f${totalLevel}/375\n§7Tokens: §e${tokens}\n\n§7Select a skill tree to view:`);

    for (const tree of SKILL_TREES) {
      const level = s.getNumber(`adv_${tree.id}`) || 0;
      const prestige = s.getNumber(`adv_pres_${tree.id}`) || 0;
      const prestigeStr = prestige > 0 ? ` §d✦${prestige}` : "";
      form.button(`${tree.color}${tree.icon} ${tree.name} §fLv.${level}${prestigeStr}`);
    }
    form.button("§eSynergies");
    form.button("§dPrestige Info");
    form.button("§bChallenges");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection < SKILL_TREES.length) {
        this.showTreeDetail(player, SKILL_TREES[response.selection]);
      } else if (response.selection === SKILL_TREES.length) {
        this.showSynergies(player);
      } else if (response.selection === SKILL_TREES.length + 1) {
        this.showPrestigeInfo(player);
      } else {
        this.showChallenges(player);
      }
    });
  }

  showTreeDetail(player, tree) {
    const s = StorageManager.forPlayer(player);
    const level = s.getNumber(`adv_${tree.id}`) || 0;
    const xp = s.getNumber(`adv_xp_${tree.id}`) || 0;
    const prestige = s.getNumber(`adv_pres_${tree.id}`) || 0;
    const statValue = s.getNumber(tree.stat) || 0;
    const reqXp = xpForLevel(level);

    let body = `${tree.color}§l${tree.icon} ${tree.name}\n\n`;
    body += `§7Level: §f${level}/${MAX_LEVEL}\n`;
    body += `§7XP: §f${xp}/${reqXp}\n`;
    body += `§7${tree.statName}: §f${statValue}\n`;
    if (prestige > 0) body += `§dPrestige: §f${prestige}\n`;
    body += `\n§7Category: §f${tree.category}`;

    const form = new ActionFormData()
      .title(`${tree.color}${tree.name}`)
      .body(body);

    if (level >= MAX_LEVEL) {
      form.button("§dPrestige (Reset to 0)");
    }
    form.button("§7Back");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (level >= MAX_LEVEL && response.selection === 0) {
        this.prestigeTree(player, tree);
      }
    });
  }

  showSynergies(player) {
    const s = StorageManager.forPlayer(player);
    let body = "§7Synergies activate when all required trees reach level 5+:\n\n";

    for (const syn of SYNERGIES) {
      const levels = syn.trees.map(t => s.getNumber(`adv_${t}`) || 0);
      const active = levels.every(l => l >= 5);
      const status = active ? "§a✓" : "§c✗";
      const treeLevels = syn.trees.map((t, i) => `${t}: ${levels[i]}`).join(", ");
      body += `${status} §f${syn.name}\n§7  ${syn.bonus} | ${treeLevels}\n\n`;
    }

    const form = new ActionFormData()
      .title("§eSynergies")
      .body(body)
      .button("§7Back");

    form.show(player);
  }

  showPrestigeInfo(player) {
    const form = new ActionFormData()
      .title("§dPrestige")
      .body("§7Prestige resets a tree to level 0 but grants:\n\n§f• Prestige star (§d✦§f)\n§f• +1 Prestige token\n§f• Unlocks prestige abilities\n§f• Permanent stat bonus\n\n§7Max prestige per tree: §f3")
      .button("§7Back");
    form.show(player);
  }

  showChallenges(player) {
    const s = StorageManager.forPlayer(player);
    const challengeId = s.getNumber("adv_chal_id");

    if (challengeId > 0) {
      const progress = s.getNumber("adv_chal_prog") || 0;
      const form = new ActionFormData()
        .title("§bActive Challenge")
        .body(`§7Challenge #${challengeId}\n§7Progress: §f${progress}%`)
        .button("§cAbandon Challenge")
        .button("§7Back");
      form.show(player);
    } else {
      const form = new ActionFormData()
        .title("§bChallenges")
        .body("§7No active challenge.\n§7Challenges reward bonus tokens upon completion.")
        .button("§aAccept Random Challenge")
        .button("§7Back");
      form.show(player).then(response => {
        if (response.canceled || response.selection === 1) return;
        this.acceptChallenge(player);
      });
    }
  }

  acceptChallenge(player) {
    const s = StorageManager.forPlayer(player);
    const challengeId = Math.floor(Math.random() * 15) + 1;
    const tree = SKILL_TREES[challengeId - 1] || SKILL_TREES[0];
    s.set("adv_chal_id", challengeId);
    s.set("adv_chal_prog", 0);
    s.set("adv_chal_tree", tree.id);
    player.sendMessage(`§b§l✦ Challenge: §r§7Level up §f${tree.name} §7by 3 levels`);
  }

  prestigeTree(player, tree) {
    const s = StorageManager.forPlayer(player);
    const prestige = s.getNumber(`adv_pres_${tree.id}`) || 0;
    if (prestige >= 3) {
      player.sendMessage("§cMax prestige reached for this tree!");
      return;
    }

    s.set(`adv_${tree.id}`, 0);
    s.set(`adv_xp_${tree.id}`, 0);
    s.set(`adv_pres_${tree.id}`, prestige + 1);
    const tokens = s.getNumber("adv_tokens") + 1;
    s.set("adv_tokens", tokens);

    player.sendMessage(`§d§l✦ ${tree.name} Prestiged! §r§7(${prestige + 1}/3)`);
    player.sendMessage(`§e+1 Token §r§7(Total: ${tokens})`);
    player.playSound("random.levelup");
  }

  getTotalLevel(s) {
    let total = 0;
    for (const tree of SKILL_TREES) {
      total += s.getNumber(`adv_${tree.id}`) || 0;
    }
    return total;
  }

  /** Check stat-based level-ups (called periodically) */
  checkLevelUps(player) {
    const s = StorageManager.forPlayer(player);

    for (const tree of SKILL_TREES) {
      const level = s.getNumber(`adv_${tree.id}`) || 0;
      if (level >= MAX_LEVEL) continue;

      const statValue = s.getNumber(tree.stat) || 0;
      const xpFromStat = Math.floor(statValue / tree.multiplier);
      const currentXp = s.getNumber(`adv_xp_${tree.id}`) || 0;
      const newXp = Math.max(currentXp, xpFromStat);

      if (newXp !== currentXp) {
        s.set(`adv_xp_${tree.id}`, newXp);
      }

      const reqXp = xpForLevel(level);
      if (newXp >= reqXp) {
        s.set(`adv_${tree.id}`, level + 1);
        s.set(`adv_xp_${tree.id}`, newXp - reqXp);
        player.sendMessage(`${tree.color}§l⬆ ${tree.name} §r§7leveled up to §f${level + 1}!`);
        player.playSound("random.levelup");

        // Token reward every 5 levels
        if ((level + 1) % 5 === 0) {
          const tokens = s.getNumber("adv_tokens") + 1;
          s.set("adv_tokens", tokens);
          player.sendMessage("§e§l+1 Advantage Token!");
        }
      }
    }

    // Check synergies
    this.checkSynergies(player, s);
  }

  checkSynergies(player, s) {
    for (const syn of SYNERGIES) {
      const levels = syn.trees.map(t => s.getNumber(`adv_${t}`) || 0);
      const active = levels.every(l => l >= 5);
      const tag = `ec.syn_${syn.id}`;

      if (active && !player.hasTag(tag)) {
        player.addTag(tag);
        player.sendMessage(`§6§l✦ Synergy Activated: §r§e${syn.name} §7— ${syn.bonus}`);
      } else if (!active && player.hasTag(tag)) {
        player.removeTag(tag);
      }

      // Apply synergy effects
      if (active) {
        switch (syn.id) {
          case "combat": player.runCommandAsync("effect @s strength 30 0 true"); break;
          case "gather": player.runCommandAsync("effect @s haste 30 0 true"); break;
          case "utility": player.runCommandAsync("effect @s speed 30 0 true"); break;
          case "support": player.runCommandAsync("effect @s regeneration 30 0 true"); break;
        }
      }
    }
  }
}
