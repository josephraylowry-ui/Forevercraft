/**
 * Pet Duel System — 1v1 companion battles with invite, combat, and stats.
 * Replaces Java pet_duel/ folder (19 mcfunction files).
 *
 * Flow: Challenge → Accept → Countdown → Auto-resolved combat → Winner
 * Stats: Pet HP/ATK from bond level. Wins/losses/draws tracked.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const DUEL_COUNTDOWN = 60;  // 3 seconds
const DUEL_DURATION = 600;  // 30 seconds max
const DUEL_COOLDOWN = 12000; // 10 min

export class PetDuelSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.pendingDuels = new Map(); // challengerID → {targetID, timer}
    this.activeDuels = new Map();  // duelID → {p1, p2, p1hp, p2hp, timer}
    this.duelCounter = 0;
  }

  async challenge(challenger, targetName) {
    const target = world.getAllPlayers().find(p => p.name === targetName);
    if (!target) { challenger.sendMessage("§cPlayer not found."); return; }
    if (target.id === challenger.id) { challenger.sendMessage("§cCan't duel yourself!"); return; }

    const s = StorageManager.forPlayer(challenger);
    const cd = s.getNumber("pd_cooldown", 0);
    if (cd > 0) { challenger.sendMessage(`§cDuel cooldown: ${Math.ceil(cd / 20)}s`); return; }

    const activePet = s.get("active_pet") || s.get("bd_active_type");
    if (!activePet) { challenger.sendMessage("§cYou need an active companion!"); return; }

    this.pendingDuels.set(challenger.id, { targetId: target.id, timer: 400 }); // 20s to accept

    target.sendMessage(`\n§d§l✦ Pet Duel Challenge! ✦§r`);
    target.sendMessage(`§f${challenger.name} §7challenges you to a pet duel!`);
    challenger.sendMessage(`§7Challenge sent to §f${target.name}§7!`);

    const form = new ActionFormData()
      .title("§dPet Duel Challenge")
      .body(`§f${challenger.name} §7wants to duel pets!\nAccept?`)
      .button("§a✦ Accept ✦")
      .button("§cDecline");

    const res = await form.show(target);
    if (res.canceled || res.selection !== 0) {
      this.pendingDuels.delete(challenger.id);
      challenger.sendMessage(`§7${target.name} declined the duel.`);
      return;
    }

    this.startDuel(challenger, target);
  }

  startDuel(p1, p2) {
    this.pendingDuels.delete(p1.id);
    this.duelCounter++;
    const duelId = this.duelCounter;

    const s1 = StorageManager.forPlayer(p1);
    const s2 = StorageManager.forPlayer(p2);

    // Calculate pet stats from bond/tier
    const p1hp = 50 + s1.getNumber("bd_points_" + (s1.get("bd_active_type") || ""), 0) / 50;
    const p2hp = 50 + s2.getNumber("bd_points_" + (s2.get("bd_active_type") || ""), 0) / 50;
    const p1atk = 5 + s1.getNumber("bd_tier_" + (s1.get("bd_active_type") || ""), 0) * 3;
    const p2atk = 5 + s2.getNumber("bd_tier_" + (s2.get("bd_active_type") || ""), 0) * 3;

    this.activeDuels.set(duelId, {
      p1id: p1.id, p2id: p2.id,
      p1name: p1.name, p2name: p2.name,
      p1hp, p2hp, p1atk, p2atk,
      timer: DUEL_DURATION,
    });

    for (const p of [p1, p2]) {
      p.sendMessage("\n§d§l✦ PET DUEL START! ✦§r");
      p.onScreenDisplay.setTitle("§d§lFIGHT!", { fadeInDuration: 5, stayDuration: 40, fadeOutDuration: 10 });
      p.playSound("mob.wolf.bark", { volume: 1.0, pitch: 0.8 });
    }

    // Auto-resolve combat in timed rounds
    this.tickDuel(duelId);
  }

  tickDuel(duelId) {
    const duel = this.activeDuels.get(duelId);
    if (!duel) return;

    // Alternate attacks every second
    const interval = system.runInterval(() => {
      duel.timer -= 20;

      // P1 attacks P2
      const p1dmg = duel.p1atk * (0.8 + Math.random() * 0.4); // ±20%
      duel.p2hp -= p1dmg;

      // P2 attacks P1
      const p2dmg = duel.p2atk * (0.8 + Math.random() * 0.4);
      duel.p1hp -= p2dmg;

      // Display to both players
      for (const p of world.getAllPlayers()) {
        if (p.id === duel.p1id || p.id === duel.p2id) {
          const bar1 = Math.max(0, Math.floor(duel.p1hp / 5));
          const bar2 = Math.max(0, Math.floor(duel.p2hp / 5));
          p.onScreenDisplay.setActionBar(
            `§a${duel.p1name}: ${"§a█".repeat(Math.min(bar1, 20))}§8${"░".repeat(Math.max(0, 20 - bar1))} §7vs §c${duel.p2name}: ${"§c█".repeat(Math.min(bar2, 20))}§8${"░".repeat(Math.max(0, 20 - bar2))}`
          );
        }
      }

      // Check victory
      if (duel.p1hp <= 0 || duel.p2hp <= 0 || duel.timer <= 0) {
        system.clearRun(interval);
        this.resolveDuel(duelId, duel);
      }
    }, 20); // Every 1 second
  }

  resolveDuel(duelId, duel) {
    let winner, loser, isDraw = false;

    if (duel.p1hp <= 0 && duel.p2hp <= 0) isDraw = true;
    else if (duel.timer <= 0) isDraw = true;
    else if (duel.p1hp <= 0) { winner = duel.p2id; loser = duel.p1id; }
    else { winner = duel.p1id; loser = duel.p2id; }

    for (const p of world.getAllPlayers()) {
      if (p.id !== duel.p1id && p.id !== duel.p2id) continue;
      const s = StorageManager.forPlayer(p);

      if (isDraw) {
        p.sendMessage("\n§e§lDRAW! §r§7Both pets are exhausted.");
        s.set("pd_draws", s.getNumber("pd_draws", 0) + 1);
      } else if (p.id === winner) {
        p.sendMessage("\n§a§l✦ VICTORY! ✦§r §7Your pet wins!");
        s.set("pd_wins", s.getNumber("pd_wins", 0) + 1);
        s.set("pd_streak", s.getNumber("pd_streak", 0) + 1);
        this.eventBridge.emit("grant_coins", { player: p, amount: 3, reason: "Pet Duel Win" });
        p.playSound("random.levelup", { volume: 0.7, pitch: 1.2 });
      } else {
        p.sendMessage("\n§c§lDEFEAT §r§7Your pet was bested.");
        s.set("pd_losses", s.getNumber("pd_losses", 0) + 1);
        s.set("pd_streak", 0);
      }

      s.set("pd_cooldown", DUEL_COOLDOWN);
    }

    this.activeDuels.delete(duelId);
  }

  /** Tick cooldowns */
  tickCooldowns(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const cd = s.getNumber("pd_cooldown", 0);
      if (cd > 0) s.set("pd_cooldown", cd - 20);
    }
  }
}
