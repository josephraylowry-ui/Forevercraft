/**
 * Companion (Pet) System — 93 pets with bond, feeding, memories, rivalry, abilities.
 * Replaces Java companions/ folder (93 pet definitions + menu + combat + abilities).
 *
 * Core systems:
 * - Bond: 6 levels (0-5), 0-5000 RP, scaling attack/XP multipliers
 * - Feeding: 11 food tiers (5-300 RP per feed, with cooldowns)
 * - Memories: 10-bit system tracking shared milestones
 * - Rivalry: Atmospheric messages when near other pet owners
 * - Leveling: 1-100 with formula: level * 5 + 5 CXP per level
 * - Abilities: Per-pet-type abilities scaling with bond level
 * - Dreamweaver's Thread: Awarded at Eternal Bond (level 5)
 */
import { world, system, EffectTypes } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// ─── BOND SYSTEM ───────────────────────────────────────────
const BOND_LEVELS = [
  { name: "Neutral",      threshold: 0,    xpMult: 1.0, atkMult: 0,    abilityMult: 1.0 },
  { name: "Friendly",     threshold: 500,  xpMult: 1.1, atkMult: 0.10, abilityMult: 1.1 },
  { name: "Bonded",       threshold: 1250, xpMult: 1.2, atkMult: 0.20, abilityMult: 1.2 },
  { name: "Devoted",      threshold: 2250, xpMult: 1.3, atkMult: 0.30, abilityMult: 1.3 },
  { name: "Soulbound",    threshold: 3500, xpMult: 1.4, atkMult: 0.40, abilityMult: 1.4 },
  { name: "Eternal Bond",  threshold: 4500, xpMult: 1.5, atkMult: 0.50, abilityMult: 1.5 },
];
const MAX_RP = 5000;

// ─── FEEDING SYSTEM ────────────────────────────────────────
const FOOD_TIERS = [
  { items: ["minecraft:rotten_flesh"], rp: 5, cooldown: 30 },
  { items: ["minecraft:beef", "minecraft:porkchop", "minecraft:chicken", "minecraft:mutton", "minecraft:rabbit"], rp: 10, cooldown: 30 },
  { items: ["minecraft:cooked_beef", "minecraft:cooked_porkchop", "minecraft:cooked_chicken", "minecraft:cooked_mutton", "minecraft:cooked_rabbit", "minecraft:cooked_salmon", "minecraft:cooked_cod"], rp: 20, cooldown: 30 },
  { items: ["minecraft:golden_carrot"], rp: 30, cooldown: 60 },
  { items: ["minecraft:golden_apple"], rp: 50, cooldown: 300 },
  { items: ["forevercraft:companion_treat"], rp: 75, cooldown: 120 },
  { items: ["forevercraft:meadow_biscuit"], rp: 100, cooldown: 120 },
  { items: ["forevercraft:honey_cake"], rp: 150, cooldown: 120 },
  { items: ["forevercraft:savory_bone_broth"], rp: 200, cooldown: 120 },
  { items: ["forevercraft:golden_morsel"], rp: 300, cooldown: 120 },
  { items: ["minecraft:enchanted_golden_apple"], rp: 100, cooldown: 600 },
];

// ─── MEMORY SYSTEM ─────────────────────────────────────────
const MEMORIES = [
  { bit: 0, name: "First Steps Together" },     // First summon
  { bit: 1, name: "The Hunt" },                  // Patron kill
  { bit: 2, name: "Against the Colossus" },       // Boss kill
  { bit: 3, name: "Treasure Found" },             // Mythical crate
  { bit: 4, name: "New Horizons" },               // Biome change
  { bit: 5, name: "The Long Road" },              // 10 real hours
  { bit: 6, name: "Into the Depths" },            // Y < -48
  { bit: 7, name: "Through the Portal" },         // Enter Nether/End
  { bit: 8, name: "A Mythical Discovery" },       // Mythical artifact found
  { bit: 9, name: "Eternal Bond" },               // Reach bond level 5
];

// ─── RIVALRY MESSAGES ──────────────────────────────────────
const RIVALRY_MESSAGES = [
  "Your companion glances at the nearby pet and snorts disapprovingly.",
  "Your companion puffs up, trying to look bigger than the other pet.",
  "Your companion lets out a low growl toward the rival pet...",
  "Your companion turns away from the other pet with an air of superiority.",
  "Your companion nudges you, as if to say it's clearly the better pet.",
  "The two companions eye each other warily.",
  "Your companion flexes, showing off for you while eyeing the rival.",
  "Your companion pretends to ignore the other pet entirely.",
];

// ─── PET TIERS ─────────────────────────────────────────────
const PET_TIERS = {
  common:    { color: "§f", baseXpMult: 1.0 },
  uncommon:  { color: "§e", baseXpMult: 1.2 },
  rare:      { color: "§b", baseXpMult: 1.5 },
  epic:      { color: "§d", baseXpMult: 2.0 },
  legendary: { color: "§6", baseXpMult: 3.0 },
};

const MAX_LEVEL = 100;
const PET_TREAT_COOLDOWN = 5; // 5 seconds

// ─── MOOD SYSTEM ──────────────────────────────────────────
// Mood is a -10 to +10 scale. Positive = happy, negative = grumpy.
// Mood decays toward 0 over time, affected by feeding, combat, neglect.
const MOOD_STATES = [
  { min: -10, name: "Miserable", icon: "😢", rpMult: 0.5 },
  { min: -5,  name: "Grumpy",   icon: "😤", rpMult: 0.75 },
  { min: -2,  name: "Sulky",    icon: "😐", rpMult: 0.9 },
  { min: 0,   name: "Content",  icon: "🙂", rpMult: 1.0 },
  { min: 3,   name: "Happy",    icon: "😊", rpMult: 1.1 },
  { min: 6,   name: "Joyful",   icon: "😄", rpMult: 1.25 },
  { min: 9,   name: "Ecstatic", icon: "🤩", rpMult: 1.5 },
];

// ─── GACHA-EXCLUSIVE PET ABILITIES ────────────────────────
// 6 special pets from Exquisite/Mythical gacha tiers with unique active + passive abilities.
// Active: triggered via pet menu (cooldown-gated). Passive: applied while pet is active at home.
const GACHA_PET_ABILITIES = {
  dreamstag: {
    name: "Dreamstag",
    tier: "legendary",
    active: {
      name: "Dreamstep",
      description: "Phase forward 12 blocks, leaving a trail of regeneration mist.",
      cooldown: 60, // seconds
      execute(player, abilityMult) {
        const dist = Math.floor(12 * abilityMult);
        try {
          // Teleport forward along facing direction
          player.runCommandAsync(`tp @s ^0 ^0 ^${dist}`);
          // Regeneration mist at arrival point
          player.runCommandAsync(`effect @s regeneration 8 1 true`);
          player.runCommandAsync(`particle minecraft:dragon_breath_trail ~ ~1 ~ 0.5 0.5 0.5 0.02 20`);
        } catch {}
        player.sendMessage("§d§l✦ Dreamstep! §r§7You phase through the dreamscape...");
        player.playSound("mob.endermen.portal");
      },
    },
    passive: {
      name: "Dream Grazing",
      description: "+2 Dream Rate per day while active at home.",
      interval: 24000, // ticks (~20 min real, 1 game day)
      apply(player, s, abilityMult) {
        const bonus = Math.floor(2 * abilityMult);
        const dr = s.getNumber("dr_consumable_bonus", 0);
        s.set("dr_consumable_bonus", dr + bonus);
        player.sendMessage(`§d§l✦ §r§7Dreamstag grazes peacefully... §d+${bonus} Dream Rate`);
      },
    },
  },
  somnia: {
    name: "Somnia",
    tier: "legendary",
    active: {
      name: "Lullaby",
      description: "Put all hostile mobs within 16 blocks to sleep (Slowness V + Weakness V) for 10s.",
      cooldown: 90,
      execute(player, abilityMult) {
        const radius = Math.floor(16 * abilityMult);
        const duration = Math.floor(10 * abilityMult);
        try {
          player.runCommandAsync(`effect @e[type=!player,r=${radius},family=monster] slowness ${duration} 4 true`);
          player.runCommandAsync(`effect @e[type=!player,r=${radius},family=monster] weakness ${duration} 4 true`);
          player.runCommandAsync(`particle minecraft:falling_dust ~ ~2 ~ 3 2 3 0.01 30`);
        } catch {}
        player.sendMessage("§5§l✦ Lullaby! §r§7A soothing melody fills the air...");
        player.playSound("note.harp");
      },
    },
    passive: {
      name: "Dreamward",
      description: "Hostile mobs spawn 30% less frequently nearby while active at home.",
      interval: 200, // check every 10 seconds
      apply(player, s, abilityMult) {
        // Apply invisibility briefly to reduce aggro range
        try { player.runCommandAsync("effect @s invisibility 12 0 true"); } catch {}
      },
    },
  },
  starweaver: {
    name: "Starweaver",
    tier: "legendary",
    active: {
      name: "Constellation Burst",
      description: "Rain down 5 star bolts dealing 8 damage each in a 10-block radius.",
      cooldown: 120,
      execute(player, abilityMult) {
        const bolts = Math.floor(5 * abilityMult);
        const dmg = Math.floor(8 * abilityMult);
        try {
          for (let i = 0; i < bolts; i++) {
            const ox = (Math.random() * 20 - 10).toFixed(1);
            const oz = (Math.random() * 20 - 10).toFixed(1);
            player.runCommandAsync(`summon lightning_bolt ~${ox} ~ ~${oz}`);
          }
          player.runCommandAsync(`damage @e[type=!player,r=10,family=monster] ${dmg} entity_attack entity @s`);
        } catch {}
        player.sendMessage("§e§l✦ Constellation Burst! §r§7Stars rain down from above!");
        player.playSound("ambient.weather.thunder");
      },
    },
    passive: {
      name: "Starlight Harvest",
      description: "+15% XP from all sources while active at home.",
      interval: 200,
      apply(player, s, abilityMult) {
        // XP boost stored as flag, read by XP granting systems
        s.set("starweaver_xp_boost", Math.floor(15 * abilityMult));
      },
    },
  },
  lunar_moth: {
    name: "Lunar Moth",
    tier: "epic",
    active: {
      name: "Moonbeam Veil",
      description: "Become invisible for 15s while gaining Night Vision and Speed II.",
      cooldown: 45,
      execute(player, abilityMult) {
        const duration = Math.floor(15 * abilityMult);
        try {
          player.runCommandAsync(`effect @s invisibility ${duration} 0 true`);
          player.runCommandAsync(`effect @s night_vision ${duration} 0 true`);
          player.runCommandAsync(`effect @s speed ${duration} 1 true`);
          player.runCommandAsync(`particle minecraft:endrod ~ ~1 ~ 1 1 1 0.05 15`);
        } catch {}
        player.sendMessage("§b§l✦ Moonbeam Veil! §r§7You shimmer and fade into moonlight...");
        player.playSound("mob.phantom.flap");
      },
    },
    passive: {
      name: "Moth Dust",
      description: "Permanent Night Vision while active at home.",
      interval: 200,
      apply(player, s, abilityMult) {
        try { player.runCommandAsync("effect @s night_vision 15 0 true"); } catch {}
      },
    },
  },
  nebula_kit: {
    name: "Nebula Kit",
    tier: "epic",
    active: {
      name: "Cosmic Pounce",
      description: "Launch forward dealing 12 damage to the first mob hit, leaving cosmic particles.",
      cooldown: 30,
      execute(player, abilityMult) {
        const dmg = Math.floor(12 * abilityMult);
        try {
          // Launch forward
          player.runCommandAsync("tp @s ^0 ^1 ^6");
          // Damage nearby
          player.runCommandAsync(`damage @e[type=!player,r=4,family=monster,c=1] ${dmg} entity_attack entity @s`);
          player.runCommandAsync("particle minecraft:end_rod ~ ~1 ~ 2 1 2 0.1 30");
        } catch {}
        player.sendMessage("§d§l✦ Cosmic Pounce! §r§7The nebula kit hurls you forward!");
        player.playSound("mob.cat.attack");
      },
    },
    passive: {
      name: "Nebula Aura",
      description: "Slow Fall + reduced fall damage while active at home.",
      interval: 200,
      apply(player, s, abilityMult) {
        try { player.runCommandAsync("effect @s slow_falling 15 0 true"); } catch {}
      },
    },
  },
  twilight_hare: {
    name: "Twilight Hare",
    tier: "epic",
    active: {
      name: "Dusk Dash",
      description: "Gain Speed III + Jump Boost III for 20s. Each mob killed during dash extends by 3s.",
      cooldown: 40,
      execute(player, abilityMult) {
        const duration = Math.floor(20 * abilityMult);
        try {
          player.runCommandAsync(`effect @s speed ${duration} 2 true`);
          player.runCommandAsync(`effect @s jump_boost ${duration} 2 true`);
          player.runCommandAsync("particle minecraft:totem_particle ~ ~1 ~ 1 1 1 0.1 20");
        } catch {}
        // Set dusk dash active flag for kill extension
        const s = StorageManager.forPlayer(player);
        s.set("dusk_dash_active", system.currentTick + duration * 20);
        player.sendMessage("§6§l✦ Dusk Dash! §r§7The twilight hare blazes a trail!");
        player.playSound("mob.rabbit.hop");
      },
    },
    passive: {
      name: "Hare's Fortune",
      description: "+10% rare loot chance while active at home.",
      interval: 200,
      apply(player, s, abilityMult) {
        s.set("hare_loot_boost", Math.floor(10 * abilityMult));
      },
    },
  },
};

export class CompanionSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Pet gains XP and combat kills when player kills mobs
    eventBridge.on("player_killed_entity", (player, entity) => {
      this.addPetXP(player, 5);
      this.onPetCombatKill(player);
      // Twilight Hare dusk dash kill extension: +3s per kill during dash
      const s = StorageManager.forPlayer(player);
      const dashEnd = s.getNumber("dusk_dash_active", 0);
      if (dashEnd > 0 && system.currentTick < dashEnd) {
        s.set("dusk_dash_active", dashEnd + 60); // +3 seconds (60 ticks)
        try {
          player.runCommandAsync("effect @s speed 3 2 true");
          player.runCommandAsync("effect @s jump_boost 3 2 true");
        } catch {}
      }
    });

    // Feed pet when player consumes item near active pet
    eventBridge.on("item_consumed", (player, item) => {
      this.tryFeedPet(player, item);
    });

    // Memory: boss kill
    eventBridge.on("boss_killed", (player) => {
      this.recordMemory(player, 2);
    });

    // Memory: patron kill
    eventBridge.on("patron_killed", (player) => {
      this.recordMemory(player, 1);
    });

    // Memory: mythical crate
    eventBridge.on("mythical_crate_opened", (player) => {
      this.recordMemory(player, 3);
    });

    // Memory: mythical artifact found
    eventBridge.on("mythical_artifact_found", (player) => {
      this.recordMemory(player, 8);
    });
  }

  // ─── BOND HELPERS ──────────────────────────────────────────

  getBondLevel(rp) {
    for (let i = BOND_LEVELS.length - 1; i >= 0; i--) {
      if (rp >= BOND_LEVELS[i].threshold) return i;
    }
    return 0;
  }

  getBondData(rp) {
    return BOND_LEVELS[this.getBondLevel(rp)];
  }

  /** Get RP memory bonus multiplier based on memory count */
  getMemoryBonus(memoryBits) {
    let count = 0;
    for (let i = 0; i < 10; i++) {
      if (memoryBits & (1 << i)) count++;
    }
    if (count >= 10) return 1.25;
    if (count >= 8) return 1.15;
    if (count >= 5) return 1.10;
    return 1.0;
  }

  /** XP required for a given level */
  xpForLevel(level) {
    return level * 5 + 5;
  }

  // ─── ACTIVE PET DATA ──────────────────────────────────────

  getActivePet(player) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return null;
    return {
      id: petId,
      name: s.getString("pet_name_" + petId, petId),
      level: s.getNumber("pet_level_" + petId, 1),
      xp: s.getNumber("pet_xp_" + petId, 0),
      tier: s.getString("pet_tier_" + petId, "common"),
      rp: s.getNumber("pet_rp_" + petId, 0),
      memories: s.getNumber("pet_mem_" + petId, 0),
      activeTime: s.getNumber("pet_active_time_" + petId, 0),
    };
  }

  // ─── PET XP & LEVELING ────────────────────────────────────

  addPetXP(player, amount) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return;

    const tier = s.getString("pet_tier_" + petId, "common");
    const rp = s.getNumber("pet_rp_" + petId, 0);
    const bond = this.getBondData(rp);
    const tierMult = PET_TIERS[tier]?.baseXpMult || 1;
    const totalMult = tierMult * bond.xpMult;

    const xpKey = "pet_xp_" + petId;
    const lvlKey = "pet_level_" + petId;
    let currentXP = s.getNumber(xpKey) + Math.floor(amount * totalMult);
    let currentLevel = s.getNumber(lvlKey, 1);

    // Check level ups (may level multiple times)
    while (currentLevel < MAX_LEVEL) {
      const needed = this.xpForLevel(currentLevel);
      if (currentXP >= needed) {
        currentXP -= needed;
        currentLevel++;
        const name = s.getString("pet_name_" + petId, petId);
        player.sendMessage(`§6§l⬆ §r§e${name}§6 leveled up to §lLevel ${currentLevel}§r§6!`);
        player.playSound("random.levelup");
      } else break;
    }
    s.set(xpKey, currentXP);
    s.set(lvlKey, currentLevel);
  }

  // ─── BOND (RP) SYSTEM ──────────────────────────────────────

  addRP(player, amount) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return;

    const rpKey = "pet_rp_" + petId;
    const memBits = s.getNumber("pet_mem_" + petId, 0);
    const memBonus = this.getMemoryBonus(memBits);
    const oldRP = s.getNumber(rpKey, 0);
    const oldLevel = this.getBondLevel(oldRP);
    const newRP = Math.min(oldRP + Math.floor(amount * memBonus), MAX_RP);
    s.set(rpKey, newRP);

    const newLevel = this.getBondLevel(newRP);
    if (newLevel > oldLevel) {
      const bond = BOND_LEVELS[newLevel];
      const name = s.getString("pet_name_" + petId, petId);
      player.sendMessage(`§d§l✦ Bond Level Up! §r§e${name} §7→ §d${bond.name}`);
      player.sendMessage(`§7Attack: §c+${Math.floor(bond.atkMult * 100)}% §7| XP: §a${bond.xpMult}x §7| Ability: §b${bond.abilityMult}x`);
      player.playSound("random.levelup");

      // Eternal Bond (level 5) → Dreamweaver's Thread
      if (newLevel === 5) {
        this.awardDreamweaversThread(player, petId);
        this.recordMemory(player, 9); // Eternal Bond memory
      }
    }
  }

  /** Petting interaction (menu treat or direct click) */
  petTreat(player) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return;

    const cdKey = "pet_treat_cd";
    const cd = s.getNumber(cdKey);
    if (cd > 0) return;

    s.set(cdKey, PET_TREAT_COOLDOWN);
    this.addRP(player, 5);
    player.playSound("mob.cat.purr");
    player.onScreenDisplay.setActionBar("§d♥ §7Your companion purrs happily!");
  }

  // ─── FEEDING SYSTEM ────────────────────────────────────────

  tryFeedPet(player, item) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return;

    const typeId = item?.typeId || "";
    for (const tier of FOOD_TIERS) {
      if (tier.items.includes(typeId)) {
        const cdKey = `pet_feed_cd_${typeId.replace(":", "_")}`;
        const cd = s.getNumber(cdKey);
        if (cd > 0) {
          player.sendMessage(`§7Feed cooldown: §f${cd}s`);
          return;
        }
        s.set(cdKey, tier.cooldown);
        this.addRP(player, tier.rp);
        this.adjustMood(player, tier.rp >= 50 ? 2 : 1); // Feeding boosts mood
        const name = s.getString("pet_name_" + petId, petId);
        player.sendMessage(`§a§l✦ §r§7Fed §e${name} §7→ §d+${tier.rp} Bond`);
        player.playSound("random.eat");
        return;
      }
    }
  }

  // ─── MEMORY SYSTEM ─────────────────────────────────────────

  recordMemory(player, bitIndex) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return;

    const memKey = "pet_mem_" + petId;
    const current = s.getNumber(memKey, 0);
    const bit = 1 << bitIndex;
    if (current & bit) return; // Already recorded

    s.set(memKey, current | bit);
    const memory = MEMORIES[bitIndex];
    if (memory) {
      const name = s.getString("pet_name_" + petId, petId);
      player.sendMessage(`§d§l✦ New Memory: §r§5${memory.name}`);
      player.sendMessage(`§7${name} will remember this moment forever.`);
      player.playSound("random.orb");
    }
  }

  checkMemoryTriggers(player, s, petId) {
    const mem = s.getNumber("pet_mem_" + petId, 0);

    // First Steps Together (bit 0) — if no memories yet
    if (mem === 0) {
      this.recordMemory(player, 0);
    }

    // Into the Depths (bit 6) — Y < -48
    if (!(mem & (1 << 6)) && player.location.y < -48) {
      this.recordMemory(player, 6);
    }

    // Through the Portal (bit 7) — Nether or End
    if (!(mem & (1 << 7))) {
      const dim = player.dimension.id;
      if (dim === "minecraft:the_nether" || dim === "minecraft:the_end") {
        this.recordMemory(player, 7);
      }
    }

    // The Long Road (bit 5) — 10 real hours (36000 seconds of active time)
    if (!(mem & (1 << 5))) {
      const activeTime = s.getNumber("pet_active_time_" + petId, 0);
      if (activeTime >= 36000) {
        this.recordMemory(player, 5);
      }
    }
  }

  // ─── DREAMWEAVER'S THREAD ──────────────────────────────────

  awardDreamweaversThread(player, petId) {
    const s = StorageManager.forPlayer(player);
    const threadCount = s.getNumber("thread_count", 0);
    // Only award once per Eternal Bond
    const threadKey = `pet_thread_${petId}`;
    if (s.getNumber(threadKey)) return;

    s.set(threadKey, 1);
    s.set("thread_count", threadCount + 1);

    // +1 Dream Rate
    const dreamRate = s.getNumber("dream_rate", 0);
    s.set("dream_rate", dreamRate + 1);

    player.sendMessage("§d§l✦ Dreamweaver's Thread received! §r§7(+1 Dream Rate)");
    player.playSound("entity.player.levelup");
  }

  // ─── RIVALRY SYSTEM ────────────────────────────────────────

  checkRivalry(player, s) {
    const petId = s.getString("active_pet");
    if (!petId) return;

    const rivalCd = s.getNumber("rivalry_cd", 0);
    if (rivalCd > 0) return;

    try {
      const nearbyPlayers = player.dimension.getEntities({
        type: "minecraft:player",
        location: player.location,
        maxDistance: 16,
        excludeNames: [player.name],
      });
      for (const other of nearbyPlayers) {
        const os = StorageManager.forPlayer(other);
        if (os.getString("active_pet")) {
          // Both have active pets — rivalry!
          const msg = RIVALRY_MESSAGES[Math.floor(Math.random() * RIVALRY_MESSAGES.length)];
          player.sendMessage(`§7${msg}`);
          s.set("rivalry_cd", 24); // ~2 minutes at 5s tick interval
          return;
        }
      }
    } catch {}
  }

  // ─── BEFRIEND & MANAGE ─────────────────────────────────────

  befriendPet(player, petId, petName, tier = "common") {
    const s = StorageManager.forPlayer(player);
    const collection = s.getString("pet_collection", "");
    const petList = collection ? collection.split(",") : [];

    if (petList.includes(petId)) {
      player.sendMessage("§7You already have this companion!");
      return false;
    }

    petList.push(petId);
    s.set("pet_collection", petList.join(","));
    s.set("pet_name_" + petId, petName);
    s.set("pet_level_" + petId, 1);
    s.set("pet_xp_" + petId, 0);
    s.set("pet_tier_" + petId, tier);
    s.set("pet_rp_" + petId, 0);
    s.set("pet_mem_" + petId, 0);
    s.set("pet_active_time_" + petId, 0);

    const befriended = s.getNumber("pets_befriended");
    s.set("pets_befriended", befriended + 1);

    player.sendMessage(`§a§l✦ §r§eNew Companion: ${petName}§a!`);
    return true;
  }

  dismissPet(player) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (petId) {
      player.sendMessage(`§7${s.getString("pet_name_" + petId)} §7has been dismissed.`);
      s.set("active_pet", "");
      // Cleanup: kill any pet entities belonging to this player
      this.cleanupPetEntities(player);
    }
  }

  /** Remove stale pet entities near a player */
  cleanupPetEntities(player) {
    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 64,
        tags: [`ec.pet_owner_${player.name}`],
      });
      for (const entity of nearby) {
        try { entity.kill(); } catch {}
      }
    } catch {}
  }

  /** Get pet data for a specific pet by ID */
  getPetData(player, petId) {
    const s = StorageManager.forPlayer(player);
    const name = s.getString("pet_name_" + petId, petId);
    if (!name) return null;
    return {
      id: petId,
      name: name,
      level: s.getNumber("pet_level_" + petId, 1),
      xp: s.getNumber("pet_xp_" + petId, 0),
      rp: s.getNumber("pet_rp_" + petId, 0),
      tier: s.getString("pet_tier_" + petId, "common"),
      memories: s.getNumber("pet_mem_" + petId, 0),
      activeTime: s.getNumber("pet_active_time_" + petId, 0),
      mood: s.getNumber("pet_mood_" + petId, 0),
      combatKills: s.getNumber("pet_kills_" + petId, 0),
    };
  }

  /** Reset a pet (clear all data, used for re-rolling or removal) */
  resetPet(player, petId) {
    const s = StorageManager.forPlayer(player);
    // Remove from collection
    const collection = s.getString("pet_collection", "");
    const petList = collection.split(",").filter(id => id && id !== petId);
    s.set("pet_collection", petList.join(","));

    // If this was the active pet, dismiss
    if (s.getString("active_pet") === petId) {
      s.set("active_pet", "");
      this.cleanupPetEntities(player);
    }

    // Clear pet data
    s.set("pet_name_" + petId, "");
    s.set("pet_level_" + petId, 0);
    s.set("pet_xp_" + petId, 0);
    s.set("pet_rp_" + petId, 0);
    s.set("pet_tier_" + petId, "");
    s.set("pet_mem_" + petId, 0);
    s.set("pet_active_time_" + petId, 0);

    player.sendMessage(`§c§l✗ §r§7Pet ${petId} has been removed.`);
  }

  // ─── MENUS ─────────────────────────────────────────────────

  async openMenu(player) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    const s = StorageManager.forPlayer(player);
    const pet = this.getActivePet(player);
    const collection = s.getString("pet_collection", "");
    const petList = collection ? collection.split(",").filter(Boolean) : [];

    let info = "§7No active companion";
    if (pet) {
      const bond = this.getBondData(pet.rp);
      info = `§aActive: ${pet.name} §7Lv.${pet.level} | §d${bond.name}`;
    }

    const hasAbility = pet && this.hasGachaAbility(player);
    const abilityInfo = hasAbility ? this.getGachaAbilityInfo(player) : null;

    if (pet && abilityInfo) {
      info += `\n§bAbility: §f${abilityInfo.activeName}${abilityInfo.cooldown > 0 ? ` §7(${abilityInfo.cooldown}s)` : " §a(Ready)"}`;
      info += `\n§5Passive: §f${abilityInfo.passiveName}`;
    }

    const actions = [];
    const form = new ActionFormData()
      .title("Companion Menu")
      .body(`${info}\n§7Companions: §f${petList.length}/93`);

    form.button("Pet Collection"); actions.push("collection");
    form.button("Swap Active Pet"); actions.push("swap");
    if (pet) { form.button("Give Treat"); actions.push("treat"); }
    if (pet) { form.button("Pet Stats"); actions.push("stats"); }
    if (hasAbility) {
      const cdText = abilityInfo.cooldown > 0 ? ` §7(${abilityInfo.cooldown}s)` : "";
      form.button(`§b${abilityInfo.activeName}${cdText}`);
      actions.push("ability");
    }
    if (pet) { form.button("Dismiss Pet"); actions.push("dismiss"); }
    form.button("Close"); actions.push("close");

    const res = await form.show(player);
    if (res.canceled || res.selection === undefined) return;

    switch (actions[res.selection]) {
      case "collection": await this.showCollection(player, petList); break;
      case "swap": await this.swapPet(player, petList); break;
      case "treat": this.petTreat(player); break;
      case "stats": await this.showPetStats(player, pet); break;
      case "ability": this.useGachaAbility(player); break;
      case "dismiss": this.dismissPet(player); break;
    }
  }

  static PETS_PER_PAGE = 48;

  async showCollection(player, petList, page = 0) {
    if (petList.length === 0) {
      player.sendMessage("§7You haven't befriended any companions yet!");
      return;
    }
    const { ActionFormData } = await import("@minecraft/server-ui");
    const s = StorageManager.forPlayer(player);

    const totalPages = Math.ceil(petList.length / CompanionSystem.PETS_PER_PAGE);
    const start = page * CompanionSystem.PETS_PER_PAGE;
    const pageList = petList.slice(start, start + CompanionSystem.PETS_PER_PAGE);

    const form = new ActionFormData()
      .title(`Pet Collection §7(${page + 1}/${totalPages})`);

    // Navigation buttons
    const actions = [];
    if (page > 0) { form.button("§7← Previous Page"); actions.push("prev"); }
    if (page < totalPages - 1) { form.button("§7Next Page →"); actions.push("next"); }

    for (const id of pageList) {
      const name = s.getString("pet_name_" + id, id);
      const level = s.getNumber("pet_level_" + id, 1);
      const tier = s.getString("pet_tier_" + id, "common");
      const color = PET_TIERS[tier]?.color || "§f";
      const rp = s.getNumber("pet_rp_" + id, 0);
      const bondName = this.getBondData(rp).name;
      form.button(`${color}${name} §7Lv.${level} | §d${bondName}`);
      actions.push(`pet_${id}`);
    }

    form.button("§7← Back"); actions.push("back");

    const res = await form.show(player);
    if (res.canceled || res.selection === undefined) return;

    const action = actions[res.selection];
    if (action === "prev") { await this.showCollection(player, petList, page - 1); return; }
    if (action === "next") { await this.showCollection(player, petList, page + 1); return; }
    if (action === "back") { await this.openMenu(player); return; }

    // Clicked a pet — show that pet's stats
    if (action.startsWith("pet_")) {
      const petId = action.slice(4);
      const petData = this.getPetData(player, petId);
      if (petData) await this.showPetStats(player, petData);
    }
  }

  async swapPet(player, petList) {
    if (petList.length === 0) { player.sendMessage("§7No pets available!"); return; }
    const { ActionFormData } = await import("@minecraft/server-ui");
    const s = StorageManager.forPlayer(player);
    const form = new ActionFormData().title("Swap Companion");
    for (const id of petList) {
      form.button(`§e${s.getString("pet_name_" + id, id)}`);
    }
    const res = await form.show(player);
    if (res.canceled || res.selection === undefined) return;
    const petId = petList[res.selection];
    s.set("active_pet", petId);
    player.sendMessage(`§a${s.getString("pet_name_" + petId)} §7is now your active companion!`);
    // Record first summon memory
    this.recordMemory(player, 0);
  }

  async showPetStats(player, pet) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    const bond = this.getBondData(pet.rp);
    const nextXP = this.xpForLevel(pet.level);
    const memCount = this.countMemories(pet.memories);

    const lines = [
      `§eName: §f${pet.name}`,
      `§eLevel: §f${pet.level}/${MAX_LEVEL}`,
      `§eXP: §f${pet.xp}/${pet.level >= MAX_LEVEL ? "MAX" : nextXP}`,
      `§eTier: §f${pet.tier}`,
      `§eBond: §d${bond.name} §7(${pet.rp}/${MAX_RP} RP)`,
      `§eMemories: §f${memCount}/10`,
      `§eAttack Bonus: §c+${Math.floor(bond.atkMult * 100)}%`,
      `§eAbility Power: §b${bond.abilityMult}x`,
      `§eXP Multiplier: §a${bond.xpMult}x`,
      `§eActive Time: §f${Math.floor(pet.activeTime / 3600)}h ${Math.floor((pet.activeTime % 3600) / 60)}m`,
      `§eMood: §f${this.getMoodState(pet.mood).icon} ${this.getMoodState(pet.mood).name}`,
      `§eCombat Kills: §f${pet.combatKills || 0}`,
    ];

    // Gacha ability info
    const gachaAbility = GACHA_PET_ABILITIES[pet.id];
    if (gachaAbility) {
      lines.push("");
      lines.push(`§b§lSpecial Ability: §r§b${gachaAbility.active.name}`);
      lines.push(`§7${gachaAbility.active.description}`);
      lines.push(`§5§lPassive: §r§5${gachaAbility.passive.name}`);
      lines.push(`§7${gachaAbility.passive.description}`);
    }

    const body = lines.join("\n");

    const form = new ActionFormData()
      .title(pet.name)
      .body(body)
      .button("View Memories")
      .button("Close");

    const res = await form.show(player);
    if (res.selection === 0) {
      await this.showMemories(player, pet);
    }
  }

  async showMemories(player, pet) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    let body = "";
    for (const mem of MEMORIES) {
      const has = pet.memories & (1 << mem.bit);
      body += has ? `§a✓ ${mem.name}\n` : `§8✗ ${mem.name}\n`;
    }
    const form = new ActionFormData()
      .title(`${pet.name}'s Memories`)
      .body(body)
      .button("Close");
    await form.show(player);
  }

  // ─── MOOD SYSTEM ───────────────────────────────────────────

  getMoodState(mood) {
    let state = MOOD_STATES[0];
    for (const ms of MOOD_STATES) {
      if (mood >= ms.min) state = ms;
    }
    return state;
  }

  /** Adjust mood by delta, clamp to -10..+10 */
  adjustMood(player, delta) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return;
    const key = "pet_mood_" + petId;
    const current = s.getNumber(key, 0);
    const newMood = Math.max(-10, Math.min(10, current + delta));
    s.set(key, newMood);
    return newMood;
  }

  /** Called when pet's owner kills a mob — track combat kills and boost mood */
  onPetCombatKill(player) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return;
    // Increment kill counter
    const killKey = "pet_kills_" + petId;
    s.set(killKey, s.getNumber(killKey, 0) + 1);
    // Small mood boost
    this.adjustMood(player, 0.1);
  }

  /** Mood decay: nudge toward 0 over time (called from tick) */
  tickMoodDecay(player) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return;
    const key = "pet_mood_" + petId;
    const mood = s.getNumber(key, 0);
    if (mood > 0) s.set(key, Math.max(0, mood - 0.05));
    else if (mood < 0) s.set(key, Math.min(0, mood + 0.03));
  }

  countMemories(bits) {
    let count = 0;
    for (let i = 0; i < 10; i++) {
      if (bits & (1 << i)) count++;
    }
    return count;
  }

  // ─── TICK (called every 2 seconds / 40 ticks) ─────────────

  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const petId = s.getString("active_pet");
      if (!petId) continue;

      // Active time tracking (seconds)
      const timeKey = "pet_active_time_" + petId;
      s.set(timeKey, s.getNumber(timeKey, 0) + 2);

      // Passive RP gain (+1 every 10 seconds)
      const passiveKey = "pet_passive_tick";
      const pt = s.getNumber(passiveKey, 0) + 1;
      if (pt >= 5) { // 5 * 2s = 10s
        s.set(passiveKey, 0);
        this.addRP(player, 1);
      } else {
        s.set(passiveKey, pt);
      }

      // Decrement treat cooldown
      let treatCd = s.getNumber("pet_treat_cd", 0);
      if (treatCd > 0) s.set("pet_treat_cd", Math.max(0, treatCd - 2));

      // Decrement feed cooldowns (every 10 seconds)
      if (pt === 0) {
        for (const tier of FOOD_TIERS) {
          for (const item of tier.items) {
            const cdKey = `pet_feed_cd_${item.replace(":", "_")}`;
            let cd = s.getNumber(cdKey, 0);
            if (cd > 0) s.set(cdKey, Math.max(0, cd - 10));
          }
        }
      }

      // Memory triggers (every ~10 seconds)
      if (pt === 0) {
        this.checkMemoryTriggers(player, s, petId);
      }

      // Rivalry (every ~20 seconds via internal counter)
      let rivalTick = s.getNumber("rivalry_tick", 0) + 1;
      if (rivalTick >= 10) { // 10 * 2s = 20s
        rivalTick = 0;
        this.checkRivalry(player, s);
        let rivalCd = s.getNumber("rivalry_cd", 0);
        if (rivalCd > 0) s.set("rivalry_cd", rivalCd - 1);
      }
      s.set("rivalry_tick", rivalTick);

      // Mood decay (every ~20 seconds)
      if (rivalTick === 0) {
        this.tickMoodDecay(player);
      }

      // Bond attack bonus — OPT: use native addEffect (not runCommandAsync) + only apply when missing
      const rp = s.getNumber("pet_rp_" + petId, 0);
      const bondLevel = this.getBondLevel(rp);
      if (bondLevel >= 3) { // Devoted+: apply Strength I (reapply only when expired)
        // OPT: null-check instead of try/catch (avoids JIT de-optimization)
        const strEffect = EffectTypes.get("strength");
        const hasStr = player.getEffect?.(strEffect);
        if (!hasStr?.duration || hasStr.duration < 20) {
          player.addEffect?.(strEffect, 60, { amplifier: 0, showParticles: false });
        }
      }

      // Gacha-exclusive pet abilities (passives + cooldown tick)
      this.tickGachaAbilities(player, s, petId);

      // Twilight Hare dusk dash kill extension
      if (petId === "twilight_hare") {
        const dashEnd = s.getNumber("dusk_dash_active", 0);
        if (dashEnd > 0 && system.currentTick > dashEnd) {
          s.set("dusk_dash_active", 0);
        }
      }
    }
  }

  // ─── GACHA PET ABILITIES ─────────────────────────────────────

  /** Use active ability for the current gacha pet (triggered from menu) */
  useGachaAbility(player) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) { player.sendMessage("§7No active companion."); return; }

    const ability = GACHA_PET_ABILITIES[petId];
    if (!ability) { player.sendMessage("§7This companion has no special ability."); return; }

    const cdKey = `gacha_ability_cd_${petId}`;
    const cd = s.getNumber(cdKey, 0);
    if (cd > 0) {
      player.sendMessage(`§7Ability on cooldown: §f${cd}s`);
      return;
    }

    const rp = s.getNumber("pet_rp_" + petId, 0);
    const bond = this.getBondData(rp);
    const abilityMult = bond.abilityMult;

    // Execute active ability
    ability.active.execute(player, abilityMult);
    s.set(cdKey, ability.active.cooldown);
    this.addRP(player, 15); // Using ability grants bond RP
  }

  /** Check if active pet has a gacha ability */
  hasGachaAbility(player) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    return petId && GACHA_PET_ABILITIES[petId] != null;
  }

  /** Get gacha ability info for display */
  getGachaAbilityInfo(player) {
    const s = StorageManager.forPlayer(player);
    const petId = s.getString("active_pet");
    if (!petId) return null;
    const ability = GACHA_PET_ABILITIES[petId];
    if (!ability) return null;
    const cd = s.getNumber(`gacha_ability_cd_${petId}`, 0);
    return {
      activeName: ability.active.name,
      activeDesc: ability.active.description,
      passiveName: ability.passive.name,
      passiveDesc: ability.passive.description,
      cooldown: cd,
    };
  }

  /** Tick gacha passives + ability cooldowns (called from main tick, every 2s) */
  tickGachaAbilities(player, s, petId) {
    const ability = GACHA_PET_ABILITIES[petId];
    if (!ability) return;

    // Decrement ability cooldown
    const cdKey = `gacha_ability_cd_${petId}`;
    const cd = s.getNumber(cdKey, 0);
    if (cd > 0) s.set(cdKey, Math.max(0, cd - 2));

    // Passive: check interval
    const passiveTickKey = `gacha_passive_tick_${petId}`;
    const pt = s.getNumber(passiveTickKey, 0) + 40; // 2 seconds = 40 ticks
    if (pt >= ability.passive.interval) {
      s.set(passiveTickKey, 0);
      const rp = s.getNumber("pet_rp_" + petId, 0);
      const bond = this.getBondData(rp);
      ability.passive.apply(player, s, bond.abilityMult);
    } else {
      s.set(passiveTickKey, pt);
    }
  }

  // ─── COMPANION EXPEDITIONS ──────────────────────────────────
  // Send pets on timed solo expeditions (30 min / 36000 gametime ticks).
  // Up to 3 concurrent per player.

  static EXPEDITION_DURATION = 36000; // gametime ticks
  static MAX_EXPEDITIONS = 3;

  static EXPEDITION_REWARDS = [
    { min: 1,  max: 40, name: "Common",    emeralds: 8,  xp: 100, crate: null },
    { min: 41, max: 65, name: "Uncommon",  emeralds: 16, xp: 250, crate: null },
    { min: 66, max: 85, name: "Rare",      emeralds: 24, xp: 500, crate: "forevercraft:common_companion_crate" },
    { min: 86, max: 95, name: "Ornate",    emeralds: 32, xp: 1000, crate: "forevercraft:uncommon_companion_crate" },
    { min: 96, max: 100, name: "Exquisite", emeralds: 18, xp: 2000, crate: "forevercraft:rare_companion_crate" },
  ];

  /** Send a pet on expedition */
  sendOnExpedition(player, petSlot) {
    const s = StorageManager.forPlayer(player);
    const expCount = s.getNumber("exp_count", 0);
    if (expCount >= CompanionSystem.MAX_EXPEDITIONS) {
      player.sendMessage("§c§l✗ §r§7Max 3 expeditions active.");
      return;
    }

    // Check pet isn't active
    const activeSlot = s.getNumber("active_pet_slot", -1);
    if (petSlot === activeSlot) {
      player.sendMessage("§c§l✗ §r§7Can't send your active pet on expedition.");
      return;
    }

    // Check pet exists in that slot
    const petId = s.get(`pet_slot_${petSlot}`);
    if (!petId) {
      player.sendMessage("§c§l✗ §r§7No pet in that slot.");
      return;
    }

    // Find a free expedition slot (1-3)
    let freeSlot = 0;
    for (let i = 1; i <= 3; i++) {
      if (!s.getNumber(`exp${i}_end`, 0)) { freeSlot = i; break; }
    }
    if (!freeSlot) {
      player.sendMessage("§c§l✗ §r§7All expedition slots full.");
      return;
    }

    // Calculate return time using gametime
    let now = 0;
    try {
      const dim = world.getDimension("overworld");
      // Use world age as gametime proxy
      now = system.currentTick;
    } catch {}
    const returnTime = now + CompanionSystem.EXPEDITION_DURATION;

    s.set(`exp${freeSlot}_end`, returnTime);
    s.set(`exp${freeSlot}_slot`, petSlot);
    s.set(`exp${freeSlot}_pet`, petId);
    s.set("exp_count", expCount + 1);

    player.sendMessage(`§6§l✦ §r§e${petId} §7sent on expedition! Returns in ~30 minutes.`);
    player.playSound("mob.horse.armor");
  }

  /** Check for completed expeditions (called every 60 seconds) */
  checkExpeditions(player) {
    const s = StorageManager.forPlayer(player);
    const expCount = s.getNumber("exp_count", 0);
    if (expCount <= 0) return;

    const now = system.currentTick;

    for (let i = 1; i <= 3; i++) {
      const endTime = s.getNumber(`exp${i}_end`, 0);
      if (!endTime || now < endTime) continue;

      // Expedition complete!
      const petId = s.get(`exp${i}_pet`) || "companion";
      this.grantExpeditionReward(player, petId);

      // Clear slot
      s.set(`exp${i}_end`, 0);
      s.set(`exp${i}_slot`, 0);
      s.set(`exp${i}_pet`, "");
      s.set("exp_count", Math.max(0, s.getNumber("exp_count", 0) - 1));
    }
  }

  grantExpeditionReward(player, petId) {
    const roll = Math.floor(Math.random() * 100) + 1;
    let reward = CompanionSystem.EXPEDITION_REWARDS[0];
    for (const r of CompanionSystem.EXPEDITION_REWARDS) {
      if (roll >= r.min && roll <= r.max) { reward = r; break; }
    }

    // Grant rewards
    try {
      if (reward.emeralds > 0) player.runCommandAsync(`give @s emerald ${reward.emeralds}`);
      if (reward.xp > 0) player.runCommandAsync(`xp ${reward.xp} @s`);
      if (reward.crate) player.runCommandAsync(`give @s ${reward.crate} 1`);
    } catch {}

    player.sendMessage(`§6§l✦ Expedition Complete! §r§e${petId} §7returned with §a${reward.name} §7loot!`);
    player.sendMessage(`§7  ${reward.emeralds} Emeralds + ${reward.xp} XP${reward.crate ? " + Crate" : ""}`);
    player.playSound("random.levelup");
  }

  /** Show expedition status in companion menu */
  getExpeditionStatus(player) {
    const s = StorageManager.forPlayer(player);
    const lines = [];
    const now = system.currentTick;

    for (let i = 1; i <= 3; i++) {
      const endTime = s.getNumber(`exp${i}_end`, 0);
      if (!endTime) { lines.push(`§7Slot ${i}: §8Empty`); continue; }
      const petId = s.get(`exp${i}_pet`) || "?";
      const remaining = Math.max(0, endTime - now);
      const minutes = Math.floor(remaining / 1200);
      lines.push(`§7Slot ${i}: §e${petId} §7(${minutes}m remaining)`);
    }
    return lines.join("\n");
  }
}
