/**
 * Newcomer System — First-join starter weapon/tool selection.
 * Replaces Java newcomer/ folder (5 mcfunction files).
 *
 * New players choose a starter spirit weapon (14 options) or tool (6 options).
 * One-time grant with toast effects.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const STARTER_WEAPONS = [
  { id: 1, name: "Hollow Fangs", class: "Rogue", desc: "Dual daggers — Shadow Step + Thousand Cuts" },
  { id: 2, name: "Voidpiercer", class: "Hunter", desc: "Crossbow — Rift Bolt + Phase Shot" },
  { id: 3, name: "Firebrand", class: "Berserker", desc: "Axe — Earthshatter + Rampage" },
  { id: 4, name: "Zephyr Edge", class: "Dancer", desc: "Sword — Cyclone + Zephyr Dance" },
  { id: 5, name: "Nite", class: "Dual Swordsman", desc: "Twin blades — Dimensional Rift + Blade Storm" },
  { id: 6, name: "Whispering Spear", class: "Beastlord", desc: "Spear — Beast Rally + Primal Fusion" },
  { id: 7, name: "Ashcrown Mace", class: "Sentinel", desc: "Mace — Ground Pound + Judgment Strike" },
  { id: 8, name: "Ellegaard's Trident", class: "Javelin", desc: "Trident — Tidal Surge + Poseidon's Wrath" },
  { id: 9, name: "Pharaoh's Fist", class: "Striker", desc: "Gauntlets — Sandstorm + Titan Breaker" },
  { id: 10, name: "Lifewoven Branch", class: "Healer", desc: "Staff — Heal Pulse + Life Surge" },
  { id: 11, name: "Sabrewing", class: "Archer", desc: "Bow — Piercing Shot + Singularity Arrow" },
  { id: 12, name: "Dragonheart Sword", class: "Knight", desc: "Greatsword — Dragon Slash + Dragonheart Strike" },
  { id: 13, name: "Bulwark Shield", class: "Tank", desc: "Shield — Shield Bash + Titan's Guard" },
  { id: 14, name: "Royal Trident", class: "Hoplite", desc: "Trident — Vanguard Charge + Phalanx Charge" },
];

const STARTER_TOOLS = [
  { id: 1, name: "Bloomweaver", desc: "Plant growth aura, crop farming" },
  { id: 2, name: "Dustwalker", desc: "Vein mining, ore detection" },
  { id: 3, name: "Earthsong", desc: "Instant construct, building" },
  { id: 4, name: "Heartwood", desc: "Tree harvester, woodcutting" },
  { id: 5, name: "Silkgrasp", desc: "Wool collector, textile" },
  { id: 6, name: "Tidecaller", desc: "Fishing magnet, aquatic" },
];

export class NewcomerSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  /** Show starter selection to new player */
  async showStarterSelection(player) {
    const s = StorageManager.forPlayer(player);
    if (s.get("spirit_chosen")) return; // Already chose

    const form = new ActionFormData()
      .title("§d§l✦ Choose Your Spirit Artifact ✦")
      .body("§7Welcome to Forevercraft!\n\n§7Choose your first Spirit Artifact. This weapon or tool will grow with you on your journey.\n\n§eWeapons §7— Combat-focused, unlock via kills and combat.\n§aTools §7— Crafting-focused, unlock via gathering and creating.")
      .button("§e⚔ Spirit Weapon")
      .button("§a⛏ Spirit Tool");

    const res = await form.show(player);
    if (res.canceled) return;

    if (res.selection === 0) {
      await this.showWeaponSelection(player);
    } else {
      await this.showToolSelection(player);
    }
  }

  async showWeaponSelection(player) {
    const form = new ActionFormData()
      .title("§e§lSpirit Weapons");

    let body = "§7Choose your weapon:\n\n";
    for (const w of STARTER_WEAPONS) {
      body += `§f${w.name} §7(${w.class})\n§8${w.desc}\n\n`;
    }
    form.body(body);

    for (const w of STARTER_WEAPONS) {
      form.button(`§f${w.name} §7(${w.class})`);
    }

    const res = await form.show(player);
    if (res.canceled) return;

    const weapon = STARTER_WEAPONS[res.selection];
    this.grantStarter(player, "weapon", weapon.id, weapon.name);
  }

  async showToolSelection(player) {
    const form = new ActionFormData()
      .title("§a§lSpirit Tools");

    let body = "§7Choose your tool:\n\n";
    for (const t of STARTER_TOOLS) {
      body += `§f${t.name}\n§8${t.desc}\n\n`;
    }
    form.body(body);

    for (const t of STARTER_TOOLS) {
      form.button(`§f${t.name}`);
    }

    const res = await form.show(player);
    if (res.canceled) return;

    const tool = STARTER_TOOLS[res.selection];
    this.grantStarter(player, "tool", tool.id, tool.name);
  }

  grantStarter(player, category, id, name) {
    const s = StorageManager.forPlayer(player);
    s.set("spirit_chosen", true);
    s.set("spirit_category", category);

    if (category === "weapon") {
      this.eventBridge.emit("spirit_weapon_obtained", { player, weaponId: id });
    } else {
      s.set("st_tool", id);
      this.eventBridge.emit("spirit_tool_obtained", { player, toolId: id });
    }

    player.sendMessage(`\n§d§l✦ Spirit Artifact Chosen ✦§r`);
    player.sendMessage(`§7You've chosen §d§l${name}§r§7!`);
    player.sendMessage("§7It will grow stronger as you adventure.");
    player.onScreenDisplay.setTitle("§d§l✦ Spirit Artifact ✦", {
      subtitle: `§7${name} has been bound to your soul.`,
      fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20,
    });
    player.playSound("random.totem", { volume: 1.0, pitch: 1.0 });
    try { player.dimension.spawnParticle("minecraft:totem_particle", player.location); } catch {}
  }
}
