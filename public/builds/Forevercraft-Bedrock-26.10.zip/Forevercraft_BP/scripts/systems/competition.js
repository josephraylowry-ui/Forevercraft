/**
 * Competition System — Timed PvP competitions with 6 types and leaderboards.
 * Replaces Java competition/ folder (46 mcfunction files).
 *
 * Types: Cooking, Mining, Forging, Prospecting, Foraging, Fishing
 * Duration: 5 minutes per competition. Delta-tracking for scoring.
 * Head-to-head 1v1 mode available.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const COMP_TYPES = [
  { id: 1, name: "Mining Rush", stat: "blocks_mined", icon: "⛏" },
  { id: 2, name: "Cook-Off", stat: "meals_cooked", icon: "🍳" },
  { id: 3, name: "Forge Frenzy", stat: "items_forged", icon: "🔨" },
  { id: 4, name: "Prospect Hunt", stat: "ores_found", icon: "💎" },
  { id: 5, name: "Foraging Dash", stat: "forages_done", icon: "🌿" },
  { id: 6, name: "Fishing Derby", stat: "fish_caught", icon: "🎣" },
];

const COMP_DURATION = 6000; // 5 min in ticks

export class CompetitionSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.active = null; // { typeId, timer, participants: Map<playerId, {snapshot, score}> }
  }

  async startCompetition(player, typeId) {
    if (this.active) { player.sendMessage("§cA competition is already active!"); return; }

    const type = COMP_TYPES[typeId - 1];
    if (!type) return;

    this.active = { typeId, timer: COMP_DURATION, type, participants: new Map() };

    // Enroll all online players
    for (const p of world.getAllPlayers()) {
      const s = StorageManager.forPlayer(p);
      const snapshot = s.getNumber(type.stat, 0);
      this.active.participants.set(p.id, { snapshot, score: 0, name: p.name });
      p.sendMessage(`\n§6§l✦ ${type.icon} ${type.name} Competition! ✦§r`);
      p.sendMessage("§75 minutes — highest score wins!");
      p.playSound("note.pling", { volume: 0.8, pitch: 1.5 });
    }
  }

  tick() {
    if (!this.active) return;
    this.active.timer--;

    // Update scores every 5 seconds
    if (this.active.timer % 100 === 0) {
      for (const p of world.getAllPlayers()) {
        const data = this.active.participants.get(p.id);
        if (!data) continue;
        const s = StorageManager.forPlayer(p);
        const current = s.getNumber(this.active.type.stat, 0);
        data.score = current - data.snapshot;

        const timeLeft = Math.ceil(this.active.timer / 20);
        p.onScreenDisplay.setActionBar(`§e${this.active.type.icon} §f${data.score} §7| §f${timeLeft}s`);
      }
    }

    // Warnings
    if (this.active.timer === 1200) {
      for (const p of world.getAllPlayers()) p.sendMessage("§e⚠ 1 minute remaining!");
    }

    // End
    if (this.active.timer <= 0) this.endCompetition();
  }

  endCompetition() {
    if (!this.active) return;

    // Sort by score
    const results = [...this.active.participants.values()].sort((a, b) => b.score - a.score);

    for (const p of world.getAllPlayers()) {
      p.sendMessage(`\n§6§l✦ ${this.active.type.icon} ${this.active.type.name} Results ✦§r`);

      for (let i = 0; i < Math.min(results.length, 5); i++) {
        const medals = ["§6🥇", "§f🥈", "§c🥉", "§7 4.", "§7 5."];
        p.sendMessage(`${medals[i]} §f${results[i].name} §7— ${results[i].score}`);
      }

      p.playSound("random.levelup", { volume: 0.8, pitch: 1.0 });
    }

    // Award winner
    if (results.length > 0) {
      const winnerId = [...this.active.participants.entries()].find(([, v]) => v === results[0])?.[0];
      if (winnerId) {
        const winner = world.getAllPlayers().find(p => p.id === winnerId);
        if (winner) {
          const s = StorageManager.forPlayer(winner);
          s.set("comp_wins", s.getNumber("comp_wins", 0) + 1);
          if (results[0].score > s.getNumber("comp_best", 0)) {
            s.set("comp_best", results[0].score);
          }
          this.eventBridge.emit("grant_coins", { player: winner, amount: 10, reason: "Competition Winner" });
          winner.sendMessage("§a✦ You won! +10 Forever Coins");
        }
      }
    }

    this.active = null;
  }

  async openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const form = new ActionFormData()
      .title("§l§6Competitions")
      .body(`§7Wins: §f${s.getNumber("comp_wins", 0)} §7| Best Score: §f${s.getNumber("comp_best", 0)}\n\n§7Start a competition:`);

    for (const type of COMP_TYPES) form.button(`${type.icon} §f${type.name}`);
    form.button("§7Close");

    const res = await form.show(player);
    if (res.canceled || res.selection >= COMP_TYPES.length) return;
    await this.startCompetition(player, res.selection + 1);
  }
}
