/**
 * XP Magnet System — Pulls nearby XP orbs toward the player.
 * Replaces Java xp_magnet/tick.mcfunction (XP orb pull ^0.6).
 * Ticks every 2 ticks for responsive feel.
 */
import { world } from "@minecraft/server";
import { applyCustomPull } from "../utils/knockback.js";

const XP_PULL_RANGE = 8;      // Radius to search for XP orbs
const XP_PULL_STEP_SIZE = 0.6; // Matches Java's ^0.6

export class XpMagnetSystem {
  constructor() {}

  /**
   * Tick — pull XP orbs toward each player.
   * Called every 2 ticks from main tick loop.
   */
  tick(players) {
    for (const player of players) {
      this.pullOrbs(player);
    }
  }

  pullOrbs(player) {
    try {
      const orbs = player.dimension.getEntities({
        type: "minecraft:xp_orb",
        location: player.location,
        maxDistance: XP_PULL_RANGE,
      });

      for (const orb of orbs) {
        applyCustomPull(orb, player, XP_PULL_STEP_SIZE, 1);
      }
    } catch {}
  }
}
