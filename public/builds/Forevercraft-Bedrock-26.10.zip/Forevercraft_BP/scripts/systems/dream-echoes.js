/**
 * Dream Echoes System — Persistent markers at mythical artifact find locations.
 * Players can click to see which artifact was found. Shears to delete.
 * Replaces Java dream_echoes/ folder (8 files).
 */
import { world, system } from "@minecraft/server";

export class DreamEchoSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.echoes = []; // {x, y, z, dim, artifact}

    // Listen for mythical finds
    eventBridge.on("mythical_found_at", (player, artifactName, location) => {
      this.spawnEcho(player.dimension, location, artifactName);
    });

    // Load saved echoes from world properties
    this.loadEchoes();
  }

  loadEchoes() {
    try {
      const data = world.getDynamicProperty("dream_echoes");
      if (data) {
        this.echoes = JSON.parse(data);
      }
    } catch {}
  }

  saveEchoes() {
    try {
      world.setDynamicProperty("dream_echoes", JSON.stringify(this.echoes));
    } catch {}
  }

  spawnEcho(dim, location, artifactName) {
    const echo = {
      x: Math.floor(location.x),
      y: Math.floor(location.y),
      z: Math.floor(location.z),
      dim: dim.id,
      artifact: artifactName,
    };

    this.echoes.push(echo);
    this.saveEchoes();

    // Spawn visual particles
    try {
      dim.runCommandAsync(
        `particle minecraft:endRod ${echo.x} ${echo.y + 1} ${echo.z} 0.3 0.5 0.3 0 10`
      );
    } catch {}
  }

  /**
   * Tick — runs every 60 ticks (3 seconds). Shows particles near players.
   */
  tick(players) {
    for (const player of players) {
      const pos = player.location;
      const dimId = player.dimension.id;

      for (const echo of this.echoes) {
        if (echo.dim !== dimId) continue;

        const dx = Math.abs(echo.x - pos.x);
        const dz = Math.abs(echo.z - pos.z);
        if (dx > 32 || dz > 32) continue;

        // Render particles
        try {
          player.dimension.runCommandAsync(
            `particle minecraft:endRod ${echo.x + 0.5} ${echo.y + 0.5} ${echo.z + 0.5} 0.2 0.3 0.2 0 2`
          );
        } catch {}
      }
    }
  }

  /**
   * Handle player interaction near an echo.
   */
  onInteract(player) {
    const pos = player.location;
    const dimId = player.dimension.id;

    for (let i = 0; i < this.echoes.length; i++) {
      const echo = this.echoes[i];
      if (echo.dim !== dimId) continue;

      const dx = Math.abs(echo.x - pos.x);
      const dy = Math.abs(echo.y - pos.y);
      const dz = Math.abs(echo.z - pos.z);
      if (dx > 3 || dy > 3 || dz > 3) continue;

      // Check for shears (delete echo)
      const equip = player.getComponent("minecraft:equippable");
      const mainhand = equip?.getEquipment("Mainhand");
      if (mainhand?.typeId === "minecraft:shears") {
        this.echoes.splice(i, 1);
        this.saveEchoes();
        player.sendMessage("§7The dream echo fades away...");
        try { player.playSound("mob.endermen.portal", { volume: 0.3, pitch: 1.5 }); } catch {}
        return true;
      }

      // Show artifact info
      player.sendMessage(`§d✦ §7A dream echo whispers: §5"${echo.artifact}" §7was found here...`);
      try { player.playSound("block.amethyst_block.chime", { volume: 0.4, pitch: 1.0 }); } catch {}
      return true;
    }
    return false;
  }
}
