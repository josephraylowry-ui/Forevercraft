/**
 * Forage System — Foraging bush spawning and harvesting.
 * Bushes spawn near players in Overworld, right-click for 3s gathering → loot + XP.
 * Replaces Java forage/ folder (17 files).
 */
import { world, system, ItemStack } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const BUSH_LOOT = [
  { item: "minecraft:sweet_berries", weight: 20, min: 2, max: 4 },
  { item: "minecraft:apple", weight: 15, min: 1, max: 1 },
  { item: "minecraft:carrot", weight: 15, min: 1, max: 3 },
  { item: "minecraft:potato", weight: 10, min: 1, max: 2 },
  { item: "minecraft:brown_mushroom", weight: 10, min: 1, max: 3 },
  { item: "minecraft:melon_slice", weight: 8, min: 1, max: 3 },
  { item: "minecraft:beetroot", weight: 7, min: 1, max: 2 },
  { item: "minecraft:cocoa_beans", weight: 5, min: 1, max: 2 },
  { item: "minecraft:glow_berries", weight: 5, min: 1, max: 2 },
  { item: "minecraft:golden_carrot", weight: 2, min: 1, max: 1 },
];

const TOOL_TYPES = new Set([
  "minecraft:iron_axe", "minecraft:diamond_axe", "minecraft:netherite_axe",
  "minecraft:iron_hoe", "minecraft:diamond_hoe", "minecraft:netherite_hoe",
  "forevercraft:hoe_of_honor",
]);

const GATHER_DURATION = 60;
const MAX_BUSHES = 7;
const MAX_DISTANCE = 120;
const BUSH_LIFETIME = 300; // 5 minutes in seconds
const SPAWN_TIMER_MOVING = 20; // seconds
const SPAWN_TIMER_STILL = 300; // 5 minutes

export class ForageSystem {
  constructor(eventBridge, movementSystem) {
    this.eventBridge = eventBridge;
    this.movementSystem = movementSystem;
    this.bushes = []; // {x, y, z, dim, spawnTime}
    this.gatheringPlayers = new Map(); // playerId → {bushIdx, progress}
  }

  tickSpawn(players) {
    const now = system.currentTick;

    for (const player of players) {
      // Overworld only
      if (player.dimension.id !== "minecraft:overworld") continue;

      const gm = player.getGameMode?.() ?? "survival";
      if (gm === "creative" || gm === "spectator") continue;

      const s = StorageManager.forPlayer(player);
      let timer = s.getNumber("fg_timer", SPAWN_TIMER_MOVING);
      timer--;

      if (timer <= 0) {
        this.trySpawn(player);
        const moving = this.movementSystem?.isMoving(player) ?? false;
        timer = moving ? SPAWN_TIMER_MOVING : SPAWN_TIMER_STILL;
      }

      s.set("fg_timer", timer);
    }

    this.tickDespawn(now);
  }

  trySpawn(player) {
    const nearby = this.countNearby(player.location, MAX_DISTANCE);
    if (nearby >= MAX_BUSHES) return;

    const pos = player.location;
    const dim = player.dimension;

    const angle = Math.random() * Math.PI * 2;
    const dist = 15 + Math.random() * 65;
    const nx = Math.floor(pos.x + Math.cos(angle) * dist);
    const nz = Math.floor(pos.z + Math.sin(angle) * dist);

    const ny = this.findGround(dim, nx, Math.floor(pos.y), nz);
    if (ny === null) return;

    this.bushes.push({
      x: nx, y: ny, z: nz,
      dim: dim.id,
      spawnTime: system.currentTick,
    });

    // Place dead bush visual
    try {
      dim.runCommandAsync(`setblock ${nx} ${ny} ${nz} deadbush`);
    } catch {}

    // Cluster spawn
    const roll = Math.random();
    if (roll > 0.5 && nearby + 1 < MAX_BUSHES) {
      this.spawnCluster(dim, nx, ny, nz, pos.y);
    }
    if (roll > 0.85 && nearby + 2 < MAX_BUSHES) {
      this.spawnCluster(dim, nx, ny, nz, pos.y);
    }
  }

  spawnCluster(dim, bx, by, bz, playerY) {
    const ox = bx + Math.floor(Math.random() * 6) - 3;
    const oz = bz + Math.floor(Math.random() * 6) - 3;
    const oy = this.findGround(dim, ox, Math.floor(playerY), oz);
    if (oy === null) return;

    this.bushes.push({ x: ox, y: oy, z: oz, dim: dim.id, spawnTime: system.currentTick });
    try { dim.runCommandAsync(`setblock ${ox} ${oy} ${oz} deadbush`); } catch {}
  }

  findGround(dim, x, refY, z) {
    for (let y = refY; y >= refY - 50 && y >= -64; y--) {
      try {
        const block = dim.getBlock({ x, y, z });
        const above = dim.getBlock({ x, y: y + 1, z });
        if (block && !block.isAir && above && above.isAir) return y + 1;
      } catch { break; }
    }
    for (let y = refY; y <= refY + 30 && y <= 320; y++) {
      try {
        const block = dim.getBlock({ x, y, z });
        const above = dim.getBlock({ x, y: y + 1, z });
        if (block && !block.isAir && above && above.isAir) return y + 1;
      } catch { break; }
    }
    return null;
  }

  countNearby(pos, maxDist) {
    return this.bushes.filter((b) =>
      Math.abs(b.x - pos.x) + Math.abs(b.z - pos.z) <= maxDist
    ).length;
  }

  tickDespawn(now) {
    const expiredTicks = BUSH_LIFETIME * 20;
    for (let i = this.bushes.length - 1; i >= 0; i--) {
      if (now - this.bushes[i].spawnTime >= expiredTicks) {
        const bush = this.bushes[i];
        try {
          world.getDimension(bush.dim).runCommandAsync(`setblock ${bush.x} ${bush.y} ${bush.z} air`);
        } catch {}
        this.bushes.splice(i, 1);
      }
    }
  }

  onBlockInteract(player, block) {
    if (!block) return false;

    const bushIdx = this.bushes.findIndex(
      (b) => b.x === block.location.x && b.y === block.location.y &&
             b.z === block.location.z && b.dim === player.dimension.id
    );
    if (bushIdx === -1) return false;

    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (!mainhand || !TOOL_TYPES.has(mainhand.typeId)) {
      player.sendMessage("§c§l[Foraging] §7You need an iron axe or hoe!");
      return true;
    }

    if (this.gatheringPlayers.has(player.id)) return true;

    this.gatheringPlayers.set(player.id, {
      bushIdx,
      progress: 0,
      bushX: this.bushes[bushIdx].x,
      bushY: this.bushes[bushIdx].y,
      bushZ: this.bushes[bushIdx].z,
    });

    player.sendMessage("§7§l[Foraging] §7Gathering...");
    try { player.playSound("step.grass", { volume: 0.6, pitch: 0.8 }); } catch {}
    return true;
  }

  tickGathering(players) {
    for (const player of players) {
      const gather = this.gatheringPlayers.get(player.id);
      if (!gather) continue;

      const pos = player.location;
      if (Math.abs(pos.x - gather.bushX) > 4 || Math.abs(pos.z - gather.bushZ) > 4) {
        this.cancelGathering(player);
        continue;
      }

      gather.progress++;

      const pct = Math.floor((gather.progress / GATHER_DURATION) * 100);
      const filled = Math.floor(gather.progress / GATHER_DURATION * 10);
      const bar = "█".repeat(filled) + "░".repeat(10 - filled);
      player.onScreenDisplay.setActionBar(`§a🌿 Gathering... [${bar}] ${pct}%`);

      if (gather.progress >= GATHER_DURATION) {
        this.completeGathering(player, gather);
      }
    }
  }

  cancelGathering(player) {
    this.gatheringPlayers.delete(player.id);
    player.sendMessage("§c§l[Foraging] §7You moved too far away!");
    player.onScreenDisplay.setActionBar("");
  }

  completeGathering(player, gather) {
    this.gatheringPlayers.delete(player.id);

    // Remove bush
    const bush = this.bushes[gather.bushIdx];
    if (bush) {
      try {
        world.getDimension(bush.dim).runCommandAsync(`setblock ${bush.x} ${bush.y} ${bush.z} air`);
      } catch {}
      this.bushes.splice(gather.bushIdx, 1);
    }

    // Roll loot
    const loot = this.rollLoot();
    if (loot) {
      try {
        const stack = new ItemStack(loot.item, loot.count);
        const inv = player.getComponent("minecraft:inventory")?.container;
        if (inv) {
          for (let i = 0; i < inv.size; i++) {
            if (!inv.getItem(i)) { inv.setItem(i, stack); break; }
          }
        }
      } catch {}
    }

    // Track stats
    const s = StorageManager.forPlayer(player);
    s.set("stat_harvest", (s.getNumber("stat_harvest", 0)) + 4);
    s.set("forages_done", (s.getNumber("forages_done", 0)) + 1);

    player.onScreenDisplay.setActionBar("§a🌿 Harvest complete!");
    player.sendMessage("§a§l[Foraging] §7Bush harvested!");
    try {
      player.playSound("item.sweet_berries.pick", { volume: 0.8, pitch: 1.2 });
      player.playSound("random.orb", { volume: 0.5, pitch: 0.8 });
    } catch {}

    this.eventBridge.emit("forage_complete", player);
  }

  rollLoot() {
    const total = BUSH_LOOT.reduce((s, l) => s + l.weight, 0);
    let roll = Math.random() * total;
    for (const entry of BUSH_LOOT) {
      roll -= entry.weight;
      if (roll <= 0) {
        const count = entry.min + Math.floor(Math.random() * (entry.max - entry.min + 1));
        return { item: entry.item, count };
      }
    }
    return { item: "minecraft:sweet_berries", count: 2 };
  }
}
