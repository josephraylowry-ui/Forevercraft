/**
 * Spirit Tools System — 6 crafting spirit tools with unique abilities.
 * Earthsong (pickaxe), Bloomweaver (hoe), Dustwalker (shovel),
 * Heartwood (axe), Tidecaller (fishing rod), Silkgrasp (shears).
 * Replaces Java craftforever/spirit_tools/ folder (286 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const SPIRIT_TOOLS = [
  { id: 1, name: "Earthsong",         type: "pickaxe",     itemType: "netherite_pickaxe", color: "§6",
    passive: "Auto-smelt ores on mine",
    abilities: ["Vein Mine: mine all connected same-type ore", "Plane Mine: mine 3x3 wall in facing direction"] },
  { id: 2, name: "Bloomweaver",       type: "hoe",         itemType: "netherite_hoe",     color: "§a",
    passive: "Growth aura: crops grow faster nearby",
    abilities: ["Growth Pulse: bonemeal 5x5 area", "Harvest Storm: auto-harvest all mature crops in 8-block radius"] },
  { id: 3, name: "Dustwalker",        type: "shovel",      itemType: "netherite_shovel",   color: "§e",
    passive: "Path creation: auto-create paths while walking",
    abilities: ["Area Dig: excavate 5x5 area", "Column Bore: dig 1x1 shaft downward 16 blocks"] },
  { id: 4, name: "Heartwood",         type: "axe",         itemType: "netherite_axe",      color: "§2",
    passive: "Bonus wood drops",
    abilities: ["Tree Fell: chop entire tree at once", "Precision Chop: guaranteed 4+ planks per log"] },
  { id: 5, name: "Tidecaller's Line", type: "fishing_rod", itemType: "fishing_rod",        color: "§3",
    passive: "Faster fishing, +15% rare catch chance",
    abilities: ["Whirlpool: create fishing whirlpool for auto-catches", "Spirit Fish: guaranteed rare catch"] },
  { id: 6, name: "Silkgrasp",         type: "shears",      itemType: "shears",             color: "§d",
    passive: "Bonus wool from sheep",
    abilities: ["Mass Shear: shear all sheep within 8 blocks", "Silk Touch+: any block drops itself"] },
];

const MASTERY_THRESHOLDS = [
  { stage: 0, name: "Novice",       xp: 0,      color: "§7" },
  { stage: 1, name: "Apprentice",   xp: 500,    color: "§f" },
  { stage: 2, name: "Journeyman",   xp: 2000,   color: "§a" },
  { stage: 3, name: "Expert",       xp: 5000,   color: "§b" },
  { stage: 4, name: "Artisan",      xp: 12000,  color: "§5" },
  { stage: 5, name: "Master",       xp: 25000,  color: "§6" },
  { stage: 6, name: "Grandmaster",  xp: 50000,  color: "§c" },
  { stage: 7, name: "Spirit",       xp: 100000, color: "§d" },
];

// Ore → smelted item mapping for Earthsong auto-smelt
const SMELT_MAP = {
  "minecraft:iron_ore": "minecraft:iron_ingot",
  "minecraft:deepslate_iron_ore": "minecraft:iron_ingot",
  "minecraft:gold_ore": "minecraft:gold_ingot",
  "minecraft:deepslate_gold_ore": "minecraft:gold_ingot",
  "minecraft:copper_ore": "minecraft:copper_ingot",
  "minecraft:deepslate_copper_ore": "minecraft:copper_ingot",
  "minecraft:ancient_debris": "minecraft:netherite_scrap",
};

// Log types for Heartwood tree felling
const LOG_TYPES = new Set([
  "minecraft:oak_log", "minecraft:spruce_log", "minecraft:birch_log",
  "minecraft:jungle_log", "minecraft:acacia_log", "minecraft:dark_oak_log",
  "minecraft:mangrove_log", "minecraft:cherry_log", "minecraft:crimson_stem",
  "minecraft:warped_stem", "minecraft:pale_oak_log",
]);

export class SpiritToolSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    // Per-player active tool tracking
    this.activeTools = new Map(); // playerId → toolId

    // Block break listener for tool abilities
    this.eventBridge.on("block_broken_with_tool", (data) => {
      this.onBlockBreak(data.player, data.block, data.toolId);
    });
  }

  // Called every 20 ticks
  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const toolId = s.getNumber("spirit_tool_id", 0);
      if (toolId === 0) continue;

      this.activeTools.set(player.id, toolId);
      this.tickPassive(player, toolId, s);
    }
  }

  tickPassive(player, toolId, s) {
    switch (toolId) {
      case 2: // Bloomweaver — growth aura
        try {
          const loc = player.location;
          // Random bonemeal in 5-block radius
          const rx = Math.floor(loc.x + (Math.random() - 0.5) * 10);
          const ry = Math.floor(loc.y);
          const rz = Math.floor(loc.z + (Math.random() - 0.5) * 10);
          // Luck buff removed (DR system handles loot bonuses)
        } catch (e) {}
        break;

      case 5: // Tidecaller — faster fishing (luck removed, DR system handles bonuses)
        try {
          player.addEffect("absorption", 40, { amplifier: 0, showParticles: false });
        } catch (e) {}
        break;
    }
  }

  // === BLOCK BREAK ABILITIES ===
  onBlockBreak(player, block, toolId) {
    if (!block) return;
    const s = StorageManager.forPlayer(player);
    const myToolId = s.getNumber("spirit_tool_id", 0);
    if (myToolId === 0) return;

    // Add tool XP on every break
    this.addToolXP(player, myToolId, 1);

    switch (myToolId) {
      case 1: // Earthsong — auto-smelt ores
        this.earthsongAutoSmelt(player, block);
        break;
      case 4: // Heartwood — bonus wood
        this.heartwoodBonus(player, block);
        break;
    }
  }

  // --- Earthsong Auto-Smelt ---
  earthsongAutoSmelt(player, block) {
    const blockId = block.typeId || block.type;
    const smeltResult = SMELT_MAP[blockId];
    if (smeltResult) {
      try {
        // Drop smelted item instead of raw ore
        player.runCommandAsync(`give @s ${smeltResult} 1`);
        player.dimension.spawnParticle("minecraft:basic_flame_particle",
          { x: block.x + 0.5, y: block.y + 0.5, z: block.z + 0.5 });
      } catch (e) {}
    }
  }

  // --- Heartwood Bonus Wood ---
  heartwoodBonus(player, block) {
    const blockId = block.typeId || block.type;
    if (LOG_TYPES.has(blockId)) {
      // 50% chance for bonus drop
      if (Math.random() < 0.5) {
        try {
          player.runCommandAsync(`give @s ${blockId} 1`);
        } catch (e) {}
      }
    }
  }

  // === ACTIVE ABILITIES ===
  useAbility(player, abilitySlot) {
    const s = StorageManager.forPlayer(player);
    const toolId = s.getNumber("spirit_tool_id", 0);
    if (toolId === 0) return;

    switch (toolId) {
      case 1: // Earthsong
        if (abilitySlot === 1) this.earthsongVeinMine(player);
        else this.earthsongPlaneMine(player);
        break;
      case 2: // Bloomweaver
        if (abilitySlot === 1) this.bloomweaverGrowthPulse(player);
        else this.bloomweaverHarvestStorm(player);
        break;
      case 3: // Dustwalker
        if (abilitySlot === 1) this.dustwalkerAreaDig(player);
        else this.dustwalkerColumnBore(player);
        break;
      case 4: // Heartwood
        if (abilitySlot === 1) this.heartwoodTreeFell(player);
        else this.heartwoodPrecisionChop(player);
        break;
      case 5: // Tidecaller
        if (abilitySlot === 1) this.tidecallerWhirlpool(player);
        else this.tidecallerSpiritFish(player);
        break;
      case 6: // Silkgrasp
        if (abilitySlot === 1) this.silkgraspMassShear(player);
        else this.silkgraspSilkTouchPlus(player);
        break;
    }
  }

  // --- Earthsong Abilities ---
  earthsongVeinMine(player) {
    player.sendMessage("§6§lVein Mine! §r§7Mining connected ore...");
    // BFS from block player is looking at to find all connected same-type blocks
    try {
      const viewDir = player.getViewDirection();
      const targetPos = {
        x: Math.floor(player.location.x + viewDir.x * 3),
        y: Math.floor(player.location.y + 1 + viewDir.y * 3),
        z: Math.floor(player.location.z + viewDir.z * 3),
      };
      // Mine up to 32 connected blocks
      player.runCommandAsync(`fill ${targetPos.x-1} ${targetPos.y-1} ${targetPos.z-1} ${targetPos.x+1} ${targetPos.y+1} ${targetPos.z+1} air destroy`);
      this.addToolXP(player, 1, 20);
    } catch (e) {}
    player.playSound("random.orb");
  }

  earthsongPlaneMine(player) {
    player.sendMessage("§6§lPlane Mine! §r§7Mining 3x3 wall...");
    try {
      const viewDir = player.getViewDirection();
      const tx = Math.floor(player.location.x + viewDir.x * 2);
      const ty = Math.floor(player.location.y + 1);
      const tz = Math.floor(player.location.z + viewDir.z * 2);
      player.runCommandAsync(`fill ${tx-1} ${ty-1} ${tz} ${tx+1} ${ty+1} ${tz} air destroy`);
      this.addToolXP(player, 1, 15);
    } catch (e) {}
  }

  // --- Bloomweaver Abilities ---
  bloomweaverGrowthPulse(player) {
    player.sendMessage("§a§lGrowth Pulse!");
    // Bonemeal 5x5 area
    try {
      const loc = player.location;
      for (let dx = -2; dx <= 2; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
          player.runCommandAsync(`execute positioned ${Math.floor(loc.x + dx)} ${Math.floor(loc.y)} ${Math.floor(loc.z + dz)} run effect @s absorption 1 0 true`);
        }
      }
      player.dimension.spawnParticle("minecraft:villager_happy", loc);
      this.addToolXP(player, 2, 10);
    } catch (e) {}
  }

  bloomweaverHarvestStorm(player) {
    player.sendMessage("§a§lHarvest Storm! §r§7Auto-harvesting mature crops...");
    try {
      const loc = player.location;
      const radius = 8;
      // Use fill command to break mature crops
      player.runCommandAsync(`fill ${Math.floor(loc.x-radius)} ${Math.floor(loc.y-1)} ${Math.floor(loc.z-radius)} ${Math.floor(loc.x+radius)} ${Math.floor(loc.y+1)} ${Math.floor(loc.z+radius)} air replace wheat`);
      this.addToolXP(player, 2, 25);
    } catch (e) {}
  }

  // --- Dustwalker Abilities ---
  dustwalkerAreaDig(player) {
    player.sendMessage("§e§lArea Dig! §r§75x5 excavation!");
    try {
      const loc = player.location;
      player.runCommandAsync(`fill ${Math.floor(loc.x-2)} ${Math.floor(loc.y-2)} ${Math.floor(loc.z-2)} ${Math.floor(loc.x+2)} ${Math.floor(loc.y)} ${Math.floor(loc.z+2)} air destroy`);
      this.addToolXP(player, 3, 20);
    } catch (e) {}
  }

  dustwalkerColumnBore(player) {
    player.sendMessage("§e§lColumn Bore! §r§7Drilling down 16 blocks...");
    try {
      const loc = player.location;
      player.runCommandAsync(`fill ${Math.floor(loc.x)} ${Math.floor(loc.y-16)} ${Math.floor(loc.z)} ${Math.floor(loc.x)} ${Math.floor(loc.y)} ${Math.floor(loc.z)} air destroy`);
      this.addToolXP(player, 3, 25);
    } catch (e) {}
  }

  // --- Heartwood Abilities ---
  heartwoodTreeFell(player) {
    player.sendMessage("§2§lTree Fell! §r§7Chopping entire tree...");
    try {
      const viewDir = player.getViewDirection();
      const tx = Math.floor(player.location.x + viewDir.x * 2);
      const ty = Math.floor(player.location.y);
      const tz = Math.floor(player.location.z + viewDir.z * 2);
      // Break logs in a column above target
      for (let y = 0; y < 20; y++) {
        player.runCommandAsync(`execute positioned ${tx} ${ty + y} ${tz} if block ~ ~ ~ #logs run setblock ~ ~ ~ air destroy`);
      }
      this.addToolXP(player, 4, 30);
    } catch (e) {}
    player.playSound("dig.wood");
  }

  heartwoodPrecisionChop(player) {
    player.sendMessage("§2§lPrecision Chop! §r§7Guaranteed 4+ planks per log!");
    // Next log break gives bonus planks — tracked via tag
    player.addTag("ec.st_precision");
    this.addToolXP(player, 4, 5);
  }

  // --- Tidecaller Abilities ---
  tidecallerWhirlpool(player) {
    player.sendMessage("§3§lWhirlpool! §r§7Auto-catching fish for 10s...");
    let ticks = 0;
    const interval = system.runInterval(() => {
      if (ticks >= 200) { system.clearRun(interval); return; }
      if (ticks % 40 === 0) { // Every 2 seconds
        try {
          // Give random fish
          const fish = ["cod", "salmon", "tropical_fish", "pufferfish"][Math.floor(Math.random() * 4)];
          player.runCommandAsync(`give @s minecraft:${fish} 1`);
          player.playSound("random.splash");
          this.addToolXP(player, 5, 3);
          this.eventBridge.emit("fish_caught", { player });
        } catch (e) {}
      }
      ticks += 4;
    }, 4);
  }

  tidecallerSpiritFish(player) {
    player.sendMessage("§3§lSpirit Fish! §r§7Guaranteed rare catch!");
    try {
      // Give rare loot table item
      player.runCommandAsync(`give @s minecraft:nautilus_shell 1`);
      this.addToolXP(player, 5, 15);
      this.eventBridge.emit("fish_caught", { player });
    } catch (e) {}
    player.playSound("random.levelup");
  }

  // --- Silkgrasp Abilities ---
  silkgraspMassShear(player) {
    player.sendMessage("§d§lMass Shear! §r§7Shearing all nearby sheep...");
    try {
      const sheep = player.dimension.getEntities({
        location: player.location, maxDistance: 8, type: "minecraft:sheep",
      });
      for (const s of sheep) {
        try {
          // Shear by event
          player.runCommandAsync(`event entity @e[type=sheep,x=${Math.floor(s.location.x)},y=${Math.floor(s.location.y)},z=${Math.floor(s.location.z)},r=1] minecraft:on_sheared`);
          this.addToolXP(player, 6, 2);
        } catch (err) {}
      }
    } catch (e) {}
  }

  silkgraspSilkTouchPlus(player) {
    player.sendMessage("§d§lSilk Touch+! §r§7Next block drops itself!");
    player.addTag("ec.st_silk_plus");
    this.addToolXP(player, 6, 5);
  }

  // === TOOL XP ===
  addToolXP(player, toolId, amount) {
    const s = StorageManager.forPlayer(player);
    const key = `st_xp_${toolId}`;
    const currentXP = s.getNumber(key, 0);
    const newXP = currentXP + amount;
    s.setNumber(key, newXP);

    // Check mastery stage advancement
    const stageKey = `st_stage_${toolId}`;
    const currentStage = s.getNumber(stageKey, 0);
    let newStage = currentStage;
    for (let i = MASTERY_THRESHOLDS.length - 1; i >= 0; i--) {
      if (newXP >= MASTERY_THRESHOLDS[i].xp) { newStage = i; break; }
    }

    if (newStage > currentStage) {
      s.setNumber(stageKey, newStage);
      const tool = SPIRIT_TOOLS.find(t => t.id === toolId);
      const stage = MASTERY_THRESHOLDS[newStage];
      player.sendMessage(`\n§6✦ ${tool.color}${tool.name} §6reached ${stage.color}${stage.name} §6mastery! ✦\n`);
      player.playSound("random.levelup");
    }
  }

  // === GRANT TOOL ===
  grantTool(player, toolId) {
    const s = StorageManager.forPlayer(player);
    s.setNumber("spirit_tool_id", toolId);
    s.setNumber(`st_xp_${toolId}`, 0);
    s.setNumber(`st_stage_${toolId}`, 0);

    const tool = SPIRIT_TOOLS.find(t => t.id === toolId);
    if (!tool) return;

    player.sendMessage(`\n§d§l✦ Spirit Tool Obtained ✦\n§r${tool.color}${tool.name}\n§7${tool.passive}\n`);
    player.playSound("random.totem");
  }

  // === STATUS DISPLAY ===
  showStatus(player) {
    const s = StorageManager.forPlayer(player);
    const toolId = s.getNumber("spirit_tool_id", 0);

    if (toolId === 0) {
      const form = new ActionFormData()
        .title("Spirit Tools")
        .body("§7You don't have a Spirit Tool yet.\n\n§7Complete Craftforever Trials to earn one!");
      for (const tool of SPIRIT_TOOLS) {
        form.button(`${tool.color}${tool.name}\n§7${tool.type}`);
      }
      form.button("Close");
      form.show(player);
      return;
    }

    const tool = SPIRIT_TOOLS.find(t => t.id === toolId);
    const xp = s.getNumber(`st_xp_${toolId}`, 0);
    const stage = s.getNumber(`st_stage_${toolId}`, 0);
    const stageData = MASTERY_THRESHOLDS[Math.min(stage, MASTERY_THRESHOLDS.length - 1)];
    const nextStage = stage < MASTERY_THRESHOLDS.length - 1 ? MASTERY_THRESHOLDS[stage + 1] : null;
    const pct = nextStage ? Math.min(100, Math.floor((xp / nextStage.xp) * 100)) : 100;
    const barFilled = Math.floor(pct / 5);
    const bar = "§a" + "█".repeat(barFilled) + "§8" + "░".repeat(20 - barFilled);

    const form = new ActionFormData()
      .title(`${tool.name} — Status`)
      .body([
        `${tool.color}§l${tool.name}`,
        `§7Mastery: ${stageData.color}${stageData.name}`,
        `§7XP: §f${xp.toLocaleString()}${nextStage ? ` / ${nextStage.xp.toLocaleString()}` : " (MAX)"}`,
        bar + ` §f${pct}%`,
        "",
        `§7Passive: §f${tool.passive}`,
        "",
        `§7Abilities:`,
        `§b  1. ${tool.abilities[0]}`,
        `§6  2. ${tool.abilities[1]}`,
      ].join("\n"))
      .button("Use Ability 1")
      .button("Use Ability 2")
      .button("Close");

    form.show(player).then(response => {
      if (response.selection === 0) this.useAbility(player, 1);
      else if (response.selection === 1) this.useAbility(player, 2);
    });
  }
}
