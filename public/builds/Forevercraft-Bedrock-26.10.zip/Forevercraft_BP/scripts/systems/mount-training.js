/**
 * Mount Training System — Horse/mount leveling, bond tiers, charge attacks.
 * Track riding distance for bond XP, speed bonuses per tier, sprint charge damage.
 * Replaces Java mount_training/ folder + buddy/mount/ systems.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const BOND_TIERS = [
  { tier: 0, name: "Unbroken",    xp: 0,     speedBonus: 0,   chargeBaseDmg: 0,   color: "§7" },
  { tier: 1, name: "Saddled",     xp: 500,   speedBonus: 0.1, chargeBaseDmg: 5,   color: "§f" },
  { tier: 2, name: "Bonded",      xp: 2000,  speedBonus: 0.2, chargeBaseDmg: 8,   color: "§a" },
  { tier: 3, name: "Trusted",     xp: 5000,  speedBonus: 0.3, chargeBaseDmg: 10,  color: "§b" },
  { tier: 4, name: "Soulbound",   xp: 12000, speedBonus: 0.4, chargeBaseDmg: 15,  color: "§6" },
  { tier: 5, name: "Legendary",   xp: 25000, speedBonus: 0.5, chargeBaseDmg: 20,  color: "§d" },
];

// Rideable mob types
const RIDEABLE_TYPES = new Set([
  "minecraft:horse", "minecraft:donkey", "minecraft:mule",
  "minecraft:llama", "minecraft:trader_llama", "minecraft:camel",
  "minecraft:strider", "minecraft:pig",
]);

// Charge attack constants
const CHARGE_SPEED_THRESHOLD = 12; // blocks/second
const CHARGE_COOLDOWN = 60;        // 3 seconds
const CHARGE_RADIUS = 3;           // blocks

export class MountTrainingSystem {
  constructor(eventBridge, buddySystem) {
    this.eventBridge = eventBridge;
    this.buddy = buddySystem;

    // Per-player riding state: Map<playerId, { prevX, prevZ, riding, chargeCd, rideTicks, breathCd, breathNotified }>
    this.rideState = new Map();
  }

  // Called every 20 ticks
  tick(players) {
    for (const player of players) {
      try {
        const riding = player.getComponent("minecraft:riding");
        if (riding) {
          this.tickRiding(player);
        } else {
          // Clear ride state when dismounted
          if (this.rideState.has(player.id)) {
            this.rideState.delete(player.id);
          }
        }
      } catch (e) {}
    }
  }

  tickRiding(player) {
    let state = this.rideState.get(player.id);
    if (!state) {
      state = {
        prevX: player.location.x,
        prevZ: player.location.z,
        riding: true,
        chargeCd: 0,
        rideTicks: 0,
        breathCd: 0,
        breathNotified: false,
      };
      this.rideState.set(player.id, state);
    }

    // Calculate distance traveled (per 20 ticks = 1 second)
    const dx = player.location.x - state.prevX;
    const dz = player.location.z - state.prevZ;
    const distance = Math.sqrt(dx * dx + dz * dz);

    state.prevX = player.location.x;
    state.prevZ = player.location.z;
    state.rideTicks++;

    // Decrement cooldowns
    if (state.chargeCd > 0) state.chargeCd--;
    if (state.breathCd > 0) state.breathCd--;

    // Add bond XP based on distance
    if (distance >= 1) {
      const xpGain = Math.floor(distance);
      this.addBondXP(player, xpGain);
    }

    // Charge attack detection
    const speed = distance; // blocks per second (since tick is every 20 ticks = 1s)
    if (speed >= CHARGE_SPEED_THRESHOLD && state.chargeCd <= 0) {
      this.detectCharge(player, state);
    }

    // Breath mechanic — every 600 ticks (30s) of continuous riding, slow down briefly
    if (state.rideTicks % 600 === 0 && state.rideTicks > 0) {
      state.breathCd = 100; // 5 seconds of slowdown
      if (!state.breathNotified) {
        player.sendMessage("§7Your mount needs to catch its breath...");
        state.breathNotified = true;
      }
      try {
        player.addEffect("slowness", 100, { amplifier: 1, showParticles: false });
      } catch (e) {}
    }

    // Apply speed bonus from bond tier
    if (state.breathCd <= 0) {
      const s = StorageManager.forPlayer(player);
      const tier = s.getNumber("mount_bond_tier", 0);
      const tierData = BOND_TIERS[Math.min(tier, BOND_TIERS.length - 1)];
      if (tierData.speedBonus > 0) {
        try {
          player.addEffect("speed", 40, { amplifier: Math.floor(tierData.speedBonus * 2), showParticles: false });
        } catch (e) {}
      }
    }
  }

  detectCharge(player, state) {
    const s = StorageManager.forPlayer(player);
    const tier = s.getNumber("mount_bond_tier", 0);
    if (tier < 1) return; // Need at least Saddled tier

    const tierData = BOND_TIERS[Math.min(tier, BOND_TIERS.length - 1)];
    let damage = tierData.chargeBaseDmg;

    // Buddy mount bonus
    if (this.buddy) {
      const buddyTier = s.getNumber("bd_tier", 0);
      if (buddyTier >= 3) damage = Math.floor(damage * 1.5);  // Buddy mount +50%
      if (s.getNumber("bd_best_type", 0) >= 4) damage = Math.floor(damage * 1.33); // Best buddy mount +33%
    }

    // Find hostiles in charge path
    const dim = player.dimension;
    try {
      const entities = dim.getEntities({
        location: player.location,
        maxDistance: CHARGE_RADIUS,
        excludeTypes: ["minecraft:player"],
        excludeFamilies: ["inanimate"],
      });

      let hitCount = 0;
      for (const e of entities) {
        try {
          if (!e.hasTag("ec.bd_charge_hit")) {
            e.applyDamage(damage, { cause: "entityAttack" });
            e.applyKnockback(0, 0, 0, 0.8); // Launch upward
            e.addTag("ec.bd_charge_hit");
            hitCount++;
            // Clear hit tag after 3 seconds
            system.runTimeout(() => { try { e.removeTag("ec.bd_charge_hit"); } catch (err) {} }, 60);
          }
        } catch (err) {}
      }

      if (hitCount > 0) {
        player.sendMessage(`§c§lCharge Attack! §r§7${damage} damage to ${hitCount} enemies!`);
        dim.spawnParticle("minecraft:critical_hit_emitter", player.location);
        player.playSound("mob.horse.angry");
        state.chargeCd = CHARGE_COOLDOWN;
      }
    } catch (e) {}
  }

  // === BOND XP ===
  addBondXP(player, amount) {
    const s = StorageManager.forPlayer(player);
    const xp = s.getNumber("mount_bond_xp", 0) + amount;
    s.setNumber("mount_bond_xp", xp);

    // Check tier advancement
    const currentTier = s.getNumber("mount_bond_tier", 0);
    let newTier = currentTier;
    for (let i = BOND_TIERS.length - 1; i >= 0; i--) {
      if (xp >= BOND_TIERS[i].xp) { newTier = i; break; }
    }

    if (newTier > currentTier) {
      s.setNumber("mount_bond_tier", newTier);
      const tier = BOND_TIERS[newTier];
      player.sendMessage(`\n§6✦ Mount Bond: ${tier.color}${tier.name} §6✦\n§7Charge damage: ${tier.chargeBaseDmg} | Speed: +${Math.floor(tier.speedBonus * 100)}%\n`);
      player.playSound("random.levelup");
    }
  }

  // === STATUS ===
  showBondStatus(player) {
    const s = StorageManager.forPlayer(player);
    const xp = s.getNumber("mount_bond_xp", 0);
    const tier = s.getNumber("mount_bond_tier", 0);
    const tierData = BOND_TIERS[Math.min(tier, BOND_TIERS.length - 1)];
    const nextTier = tier < BOND_TIERS.length - 1 ? BOND_TIERS[tier + 1] : null;
    const pct = nextTier ? Math.min(100, Math.floor((xp / nextTier.xp) * 100)) : 100;
    const bar = "§a" + "█".repeat(Math.floor(pct / 5)) + "§8" + "░".repeat(20 - Math.floor(pct / 5));

    const form = new ActionFormData()
      .title("Mount Training")
      .body([
        `§7Bond: ${tierData.color}§l${tierData.name}`,
        `§7XP: §f${xp.toLocaleString()}${nextTier ? ` / ${nextTier.xp.toLocaleString()}` : " (MAX)"}`,
        bar + ` §f${pct}%`,
        "",
        `§7Speed Bonus: §a+${Math.floor(tierData.speedBonus * 100)}%`,
        `§7Charge Damage: §c${tierData.chargeBaseDmg}`,
        "",
        `§7Ride your mount to earn bond XP!`,
        `§7Sprint into enemies for charge attacks.`,
      ].join("\n"))
      .button("Close");
    form.show(player);
  }

  // === HORSE UPGRADE CONSUMABLES ===
  // Speed Sugar Cube: +0.05 movement_speed to nearest tamed horse
  // Jump Carrot: +0.1 jump_strength to nearest tamed horse
  // Health Apple: +4 max_health to nearest tamed horse
  // All grant +50 mount bond XP
  applyHorseUpgrade(player, upgradeType) {
    const s = StorageManager.forPlayer(player);
    const entities = player.dimension.getEntities({
      location: player.location, maxDistance: 8,
      type: "minecraft:horse", closest: 1
    });
    const horse = entities.find(e => {
      try { return e.getComponent("minecraft:tameable")?.isTamed; } catch { return false; }
    });
    if (!horse) {
      player.sendMessage("§cNo tamed horse nearby!");
      return;
    }

    try {
      switch (upgradeType) {
        case "speed":
          horse.runCommandAsync("attribute @s minecraft:movement_speed modifier add evercraft:speed_boost 0.05 add_value");
          player.onScreenDisplay?.setActionBar("§b§lHorse speed increased!");
          break;
        case "jump":
          horse.runCommandAsync("attribute @s minecraft:jump_strength modifier add evercraft:jump_boost 0.1 add_value");
          player.onScreenDisplay?.setActionBar("§b§lHorse jump increased!");
          break;
        case "health":
          horse.runCommandAsync("attribute @s minecraft:max_health modifier add evercraft:health_boost 4 add_value");
          player.onScreenDisplay?.setActionBar("§b§lHorse health increased!");
          break;
      }
      horse.dimension.spawnParticle("minecraft:happy_villager_particle", horse.location);
      player.playSound("mob.horse.eat");
    } catch {}

    // +50 mount bond XP
    const bondXp = s.getNumber("mount_bond_xp", 0);
    s.setNumber("mount_bond_xp", bondXp + 50);
    player.sendMessage("§a  +50 Mount Bond XP");
    this.checkBondTier(player);
  }
}
