/**
 * Consumables System — Permanent Dream Rate boosters and horse enhancements.
 * 18 DR items (+1 luck each, single-use) + 3 horse stat carrots.
 * Replaces Java items/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// All Dream Rate consumable items
const DR_ITEMS = [
  { typeId: "forevercraft:astral_codex_page", key: "codex_page_count", name: "Astral Codex Page", color: "§b" },
  { typeId: "forevercraft:blacksmiths_dreaming_ember", key: "ember_count", name: "Blacksmith's Dreaming Ember", color: "§c" },
  { typeId: "forevercraft:chorus_dreaming_fruit", key: "chorus_count", name: "Chorus Dreaming Fruit", color: "§5" },
  { typeId: "forevercraft:collectors_dream_relic", key: "dream_relic_count", name: "Collector's Dream Relic", color: "§6" },
  { typeId: "forevercraft:crystal_of_dreams", key: "crystal_count", name: "Crystal of Dreams", color: "§5" },
  { typeId: "forevercraft:crystalized_dream_droppings", key: "droppings_count", name: "Crystalized Dream Droppings", color: "§5" },
  { typeId: "forevercraft:dream_inducing_mushroom", key: "mushroom_count", name: "Dream Inducing Mushroom", color: "§c" },
  { typeId: "forevercraft:dreamers_quill", key: "quill_count", name: "Dreamer's Quill", color: "§6" },
  { typeId: "forevercraft:dreamweavers_thread", key: "thread_count", name: "Dreamweaver's Thread", color: "§d" },
  { typeId: "forevercraft:fishermans_dozing_lure", key: "lure_count", name: "Fisherman's Dozing Lure", color: "§9" },
  { typeId: "forevercraft:harvesters_dreamy_seed", key: "seed_count", name: "Harvester's Dreamy Seed", color: "§a" },
  { typeId: "forevercraft:miners_slumbering_geode", key: "geode_count", name: "Miner's Slumbering Geode", color: "§6" },
  { typeId: "forevercraft:patrons_dream_essence", key: "patron_dream_count", name: "Patron's Dream Essence", color: "§4" },
  { typeId: "forevercraft:prospectors_dream_ore", key: "dream_ore_count", name: "Prospector's Dream Ore", color: "§e" },
  { typeId: "forevercraft:tillers_dream_petal", key: "dream_petal_count", name: "Tiller's Dream Petal", color: "§2" },
  { typeId: "forevercraft:wanderers_dream_map", key: "map_count", name: "Wanderer's Dream Map", color: "§3" },
];

// Horse enhancement items
const HORSE_ITEMS = [
  { typeId: "forevercraft:vital_carrot", stat: "health", value: 4, name: "Vital Carrot", color: "§c", msg: "+4 Max Health" },
  { typeId: "forevercraft:swift_carrot", stat: "speed", value: 0.05, name: "Swift Carrot", color: "§b", msg: "+5% Speed" },
  { typeId: "forevercraft:jump_carrot", stat: "jump", value: 0.2, name: "Jump Carrot", color: "§a", msg: "+20% Jump" },
];

// Rabbit's Dreaming Foot (no single-use limit)
const RABBIT_FOOT = "forevercraft:rabbits_dreaming_foot";

export class ConsumableSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Build lookup maps
    this.drItemMap = new Map();
    for (const item of DR_ITEMS) {
      this.drItemMap.set(item.typeId, item);
    }
    this.horseItemMap = new Map();
    for (const item of HORSE_ITEMS) {
      this.horseItemMap.set(item.typeId, item);
    }

    // Listen for item use
    world.afterEvents.itemUse.subscribe((event) => {
      const item = event.itemStack;
      if (!item) return;
      this.handleUse(event.source, item);
    });
  }

  /**
   * Handle item use events.
   */
  handleUse(player, item) {
    // Check DR consumables
    const drDef = this.drItemMap.get(item.typeId);
    if (drDef) {
      this.consumeDRItem(player, drDef);
      return;
    }

    // Check horse enhancements
    const horseDef = this.horseItemMap.get(item.typeId);
    if (horseDef) {
      this.consumeHorseItem(player, horseDef);
      return;
    }

    // Rabbit's Dreaming Foot (no limit)
    if (item.typeId === RABBIT_FOOT) {
      this.consumeRabbitFoot(player);
    }
  }

  /**
   * Consume a Dream Rate item — permanent +1 luck, single-use per player.
   */
  consumeDRItem(player, def) {
    const storage = StorageManager.forPlayer(player);
    const used = storage.getNumber(def.key, 0);

    if (used >= 1) {
      player.sendMessage(`§7You have already consumed a ${def.name}.`);
      return;
    }

    storage.set(def.key, 1);
    storage.increment("dream_rate", 1);

    // Remove item from hand
    this.removeOneFromHand(player);

    const newDR = storage.getNumber("dream_rate", 0);
    player.sendMessage(`${def.color}§l✦ ${def.name} consumed!`);
    player.sendMessage(`§7Dream Rate increased by §a+1.0§7. Current: §a${newDR}`);

    try {
      player.playSound("random.levelup", { volume: 0.5, pitch: 1.0 });
      player.playSound("block.amethyst_block.chime", { volume: 0.4, pitch: 0.8 });
      player.dimension.runCommandAsync(
        `particle minecraft:endRod ${player.location.x} ${player.location.y + 1} ${player.location.z} 0.5 1 0.5 0 15`
      );
    } catch {}

    this.eventBridge.emit("dr_changed", player);
    this.eventBridge.emit("artifact_consumed", player, def.typeId);
  }

  /**
   * Consume a horse enhancement item — buff nearest tamed horse.
   */
  consumeHorseItem(player, def) {
    // Find nearest tamed horse within 8 blocks
    const dim = player.dimension;
    const pos = player.location;

    let target = null;
    try {
      const horses = dim.getEntities({
        location: pos,
        maxDistance: 8,
        type: "minecraft:horse",
      });

      for (const horse of horses) {
        // Check if tamed (has owner component)
        if (horse.getComponent("minecraft:is_tamed")) {
          target = horse;
          break;
        }
      }
    } catch {}

    if (!target) {
      player.sendMessage("§cNo tamed horse found nearby (within 8 blocks).");
      return;
    }

    // Apply stat boost via command
    try {
      if (def.stat === "health") {
        dim.runCommandAsync(
          `attribute @e[type=horse,r=8,c=1] minecraft:health base set ${20 + def.value}`
        );
      }
    } catch {}

    this.removeOneFromHand(player);

    player.sendMessage(`§6§l✦ ${def.name} fed! §r§7Horse gained ${def.msg}`);
    try {
      player.playSound("mob.horse.eat", { volume: 0.6, pitch: 1.0 });
    } catch {}
  }

  /**
   * Consume Rabbit's Dreaming Foot — +1 DR, no single-use limit.
   */
  consumeRabbitFoot(player) {
    const storage = StorageManager.forPlayer(player);
    storage.increment("dream_rate", 1);

    this.removeOneFromHand(player);

    const newDR = storage.getNumber("dream_rate", 0);
    player.sendMessage("§2§l✦ Rabbit's Dreaming Foot consumed!");
    player.sendMessage(`§7Dream Rate: §a${newDR}`);

    try {
      player.playSound("random.levelup", { volume: 0.5, pitch: 1.0 });
    } catch {}

    this.eventBridge.emit("dr_changed", player);
  }

  /**
   * Remove one item from the player's hand (checks both mainhand and offhand).
   * Uses 1-tick delay to avoid conflicting with consume logic.
   */
  removeOneFromHand(player) {
    system.runTimeout(() => {
      try {
        const equip = player.getComponent("minecraft:equippable");
        // Check mainhand first
        const mainhand = equip?.getEquipment("Mainhand");
        if (mainhand && this.isOurItem(mainhand)) {
          if (mainhand.amount > 1) {
            mainhand.amount--;
            equip.setEquipment("Mainhand", mainhand);
          } else {
            equip.setEquipment("Mainhand", undefined);
          }
          return;
        }
        // Check offhand
        const offhand = equip?.getEquipment("Offhand");
        if (offhand && this.isOurItem(offhand)) {
          if (offhand.amount > 1) {
            offhand.amount--;
            equip.setEquipment("Offhand", offhand);
          } else {
            equip.setEquipment("Offhand", undefined);
          }
        }
      } catch {}
    }, 1);
  }

  /** Check if an item is one of our consumables */
  isOurItem(item) {
    if (!item) return false;
    return this.drItemMap.has(item.typeId) ||
           this.horseItemMap.has(item.typeId) ||
           item.typeId === RABBIT_FOOT;
  }
}
