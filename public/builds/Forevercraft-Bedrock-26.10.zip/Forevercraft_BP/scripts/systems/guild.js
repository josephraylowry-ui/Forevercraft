/**
 * Guild System — Full guild management with ranks, zones, diplomacy, expeditions, events.
 * Replaces Java guild/ folder (246 files across 12 subdirectories).
 *
 * Subsystems: creation, membership, ranks, GUI, contribution, buffs,
 * diplomacy (ally/rival/pillage), expeditions, events, zones, XP/leveling, kick voting.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

// ─── CONSTANTS ─────────────────────────────────────────────

const MAX_MEMBERS = 50;
const MAX_CONTRIBUTION = 50000;
const CREATION_COST = 64; // emeralds
const INVITE_TIMEOUT = 600; // 30 seconds (in ticks at 20/s)
const MENU_TIMEOUT = 300; // 15 seconds inactivity
const ZONE_RADIUS = 128; // blocks in each direction
const KICK_VOTE_TIMEOUT = 400; // 20 seconds

const RANK_THRESHOLDS = [
  { rank: 1, name: "Associate",       contrib: 0,     buffs: {} },
  { rank: 2, name: "Member",          contrib: 1000,  buffs: { xp: 0.05 } },
  { rank: 3, name: "Aide",            contrib: 3000,  buffs: { luck: 1 } },
  { rank: 4, name: "Representative",  contrib: 8000,  buffs: { speed: 0.05 } },
  { rank: 5, name: "Administrator",   contrib: 15000, buffs: { xp: 0.10, luck: 2 } },
  { rank: 6, name: "Dedicated",       contrib: 30000, buffs: { speed: 0.10, armor: 2 } },
  { rank: 7, name: "Valorous",        contrib: 50000, buffs: { xp: 0.15, luck: 3, armor: 4 } },
];

const RANK_COLORS = ["§7", "§7", "§f", "§a", "§e", "§b", "§6", "§d"];

// Donation material values
const DONATION_VALUES = {
  "minecraft:netherite_scrap": 25,
  "minecraft:ancient_debris": 25,
  "minecraft:emerald_block": 50,
  "minecraft:diamond": 5,
  "minecraft:emerald": 5,
  "minecraft:lapis_lazuli": 5,
  "minecraft:iron_ingot": 1,
  "minecraft:gold_ingot": 1,
  "minecraft:redstone": 1,
};

// Guild level formula: 100 * level^3
function xpForLevel(level) { return 100 * level * level * level; }

// Expedition activities
const EXPEDITION_ACTIVITIES = [
  { id: 1, name: "Dungeon Diving", icon: "⚔" },
  { id: 2, name: "Deep Sea Fishing", icon: "🎣" },
  { id: 3, name: "Forest Foraging", icon: "🌿" },
  { id: 4, name: "Monster Slaying", icon: "🗡" },
  { id: 5, name: "Ore Prospecting", icon: "⛏" },
  { id: 6, name: "Fountain of Dreams", icon: "⭐" },
  { id: 7, name: "Quest Running", icon: "📜" },
  { id: 8, name: "Bounty Hunting", icon: "🏹" },
  { id: 9, name: "Lore Discovery", icon: "📖" },
  { id: 10, name: "Boss Battles", icon: "👹" },
  { id: 11, name: "Crate Hunting", icon: "📦" },
  { id: 12, name: "Patron Hunting", icon: "🐉" },
  { id: 13, name: "Feast Cooking", icon: "🍳" },
];

// Diplomacy types
const DIPLO = { ALLIANCE: 1, COMPETITION: 2, PILLAGE: 3 };
const DIPLO_COOLDOWN_DAYS = 4;

// Supply drop tiers
const SUPPLY_DROP_TIERS = [
  { min: 1, max: 60, coins: 5, name: "Small Supply Drop" },
  { min: 61, max: 90, coins: 15, name: "Medium Supply Drop" },
  { min: 91, max: 100, coins: 30, name: "Large Supply Drop" },
];

// Victorian tree: every 100 contribution = 1000 Advantage XP
const VICTORIAN_CONTRIB_INTERVAL = 100;

// Hearthstone (guild teleport) cooldown in ticks (10 minutes = 12000 ticks)
const HEARTHSTONE_COOLDOWN = 12000;

// Guild bank max storage
const GUILD_BANK_MAX = 100000;

// Guild pet roster limits
const GUILD_PET_MAX = 25;
const GUILD_PET_PER_PLAYER = 3;

// Expedition-contextual donation bonus items
const EXPEDITION_DONATION_BONUS = {
  1: { items: ["minecraft:iron_sword", "minecraft:diamond_sword"], mult: 2, name: "Weapons" }, // Dungeon Diving
  2: { items: ["minecraft:cod", "minecraft:salmon", "minecraft:tropical_fish"], mult: 3, name: "Fish" }, // Deep Sea
  3: { items: ["minecraft:wheat", "minecraft:carrot", "minecraft:potato"], mult: 2, name: "Crops" }, // Forest Foraging
  5: { items: ["minecraft:raw_iron", "minecraft:raw_gold", "minecraft:raw_copper"], mult: 2, name: "Ores" }, // Ore Prospecting
  13: { items: ["minecraft:cooked_beef", "minecraft:cooked_porkchop", "minecraft:bread"], mult: 2, name: "Food" }, // Feast Cooking
};

// Weekly leaderboard reward tiers
const LEADERBOARD_REWARDS = [
  { rank: 1, coins: 15, title: "§6MVP" },
  { rank: 2, coins: 10, title: "§eRunner-up" },
  { rank: 3, coins: 5, title: "§fContributor" },
];

export class GuildSystem {
  constructor(eventBridge, coinSystem) {
    this.eventBridge = eventBridge;
    this.coinSystem = coinSystem;
    this.guilds = new Map(); // guildId -> guild data (loaded from world properties)
    this.pendingInvites = new Map(); // playerName -> {guildId, expireTick}
    this.kickVotes = new Map(); // guildId -> {target, yes, no, needed, expireTick}
    this.diploVotes = new Map(); // guildId -> {type, targetGuild, yes, no, needed, expireTick}

    // Event state
    this.noonActive = false;
    this.noonTimer = 0;
    this.lastNoonDay = -1;
    this.scatterActive = false;
    this.scatterTimer = 0;
    this.lastScatterDay = -1;
    this.weeklyDay = 0;

    // Expedition state
    this.expeditionActivity = 0;
    this.expeditionDay = -1;

    this.tickCounter = 0;
    this.supplyDropFired = false;

    // Listen for guild contribution from coins system
    eventBridge.on("guild_contribution", (player, amount) => this.addContribution(player, amount, true));
    eventBridge.on("guild_xp", (player, amount) => this.addGuildXp(player, amount));

    this.loadGuilds();
  }

  // ─── PERSISTENCE ────────────────────────────────────────────

  loadGuilds() {
    try {
      const data = world.getDynamicProperty("fc_guilds");
      if (data) this.guilds = new Map(JSON.parse(data));
    } catch {}
  }

  saveGuilds() {
    try {
      world.setDynamicProperty("fc_guilds", JSON.stringify([...this.guilds]));
    } catch {}
  }

  getGuild(guildId) { return this.guilds.get(guildId); }

  getPlayerGuild(player) {
    const s = StorageManager.forPlayer(player);
    const gid = s.getNumber("guild_id", 0);
    return gid > 0 ? this.guilds.get(gid) : null;
  }

  getPlayerGuildId(player) {
    return StorageManager.forPlayer(player).getNumber("guild_id", 0);
  }

  // ─── CREATION ────────────────────────────────────────────────

  /** Open guild creation form */
  openCreateForm(player) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("guild_id", 0) > 0) {
      player.sendMessage("§c§l✗ §r§7You are already in a guild.");
      return;
    }

    const form = new ModalFormData()
      .title("§6Create a Guild")
      .textField("Guild Name", "Enter guild name...")
      .toggle("Confirm (costs 64 Emeralds)", false);

    form.show(player).then(response => {
      if (response.canceled) return;
      const name = response.formValues[0]?.trim();
      const confirmed = response.formValues[1];
      if (!name || name.length < 2 || name.length > 20) {
        player.sendMessage("§c§l✗ §r§7Guild name must be 2-20 characters.");
        return;
      }
      if (!confirmed) {
        player.sendMessage("§c§l✗ §r§7You must confirm to create the guild.");
        return;
      }
      this.createGuild(player, name);
    });
  }

  createGuild(player, name) {
    // Check emerald cost
    const inv = player.getComponent("minecraft:inventory");
    if (!inv) return;
    const container = inv.container;
    let emeraldCount = 0;
    for (let i = 0; i < container.size; i++) {
      const item = container.getItem(i);
      if (item?.typeId === "minecraft:emerald") emeraldCount += item.amount;
    }
    if (emeraldCount < CREATION_COST) {
      player.sendMessage(`§c§l✗ §r§7Need §f${CREATION_COST} Emeralds §7(have §f${emeraldCount}§7).`);
      return;
    }

    // Remove emeralds
    try { player.runCommandAsync(`clear @s emerald 64`); } catch {}

    // Allocate guild ID
    let nextId = 1;
    try {
      const nid = world.getDynamicProperty("fc_next_guild_id");
      if (nid) nextId = Number(nid);
    } catch {}
    world.setDynamicProperty("fc_next_guild_id", String(nextId + 1));

    const s = StorageManager.forPlayer(player);
    const currentDay = world.getDay();

    // Create guild data
    const guild = {
      id: nextId,
      name: name,
      level: 1,
      xp: 0,
      memberCount: 1,
      createdDay: currentDay,
      creatorName: player.name,
      activeBuff: 0,
      alliances: [],
      enemies: [],
      cooldowns: [],
      zone: { x: Math.floor(player.location.x), y: Math.floor(player.location.y), z: Math.floor(player.location.z) },
      members: [{ name: player.name, rank: 7, contrib: 0 }],
      expeditionActivity: 0,
      expeditionDay: -1,
    };

    this.guilds.set(nextId, guild);
    this.saveGuilds();

    // Set player guild data
    s.set("guild_id", nextId);
    s.set("guild_rank", 7);
    s.set("guild_contrib", 0);

    player.sendMessage(`§6§l✦ Guild Created! §r§e${name} §7has been founded!`);
    player.playSound("random.levelup");

    // Register guild stone location with guidestone system
    this.eventBridge.emit("guild_stone_placed", player, { guildId: nextId, name: name, location: guild.zone });
  }

  // ─── MEMBERSHIP ─────────────────────────────────────────────

  /** Invite a nearby player to the guild */
  invitePlayer(player, targetName) {
    const s = StorageManager.forPlayer(player);
    const guildId = s.getNumber("guild_id", 0);
    const rank = s.getNumber("guild_rank", 0);
    if (guildId <= 0) { player.sendMessage("§c§l✗ §r§7You are not in a guild."); return; }
    if (rank < 5) { player.sendMessage("§c§l✗ §r§7Rank 5+ required to invite."); return; }

    const guild = this.guilds.get(guildId);
    if (!guild) return;
    if (guild.memberCount >= MAX_MEMBERS) { player.sendMessage("§c§l✗ §r§7Guild is full."); return; }

    // Find target player
    const target = world.getAllPlayers().find(p => p.name === targetName);
    if (!target) { player.sendMessage("§c§l✗ §r§7Player not found online."); return; }

    const ts = StorageManager.forPlayer(target);
    if (ts.getNumber("guild_id", 0) > 0) { player.sendMessage("§c§l✗ §r§7That player is already in a guild."); return; }

    // Set pending invite
    this.pendingInvites.set(target.name, { guildId, expireTick: system.currentTick + INVITE_TIMEOUT });
    target.sendMessage(`§6§l✦ Guild Invite! §r§e${player.name} §7invites you to §e${guild.name}§7!`);
    target.sendMessage("§7Type §f/scriptevent forevercraft:guild_accept §7to join.");
    player.sendMessage(`§a§l✓ §r§7Invite sent to §f${target.name}§7.`);
  }

  /** Accept a pending guild invite */
  acceptInvite(player) {
    const invite = this.pendingInvites.get(player.name);
    if (!invite || system.currentTick > invite.expireTick) {
      player.sendMessage("§c§l✗ §r§7No pending guild invite.");
      this.pendingInvites.delete(player.name);
      return;
    }

    const guild = this.guilds.get(invite.guildId);
    if (!guild) { player.sendMessage("§c§l✗ §r§7Guild no longer exists."); return; }
    if (guild.memberCount >= MAX_MEMBERS) { player.sendMessage("§c§l✗ §r§7Guild is full."); return; }

    // Add member
    guild.members.push({ name: player.name, rank: 1, contrib: 0 });
    guild.memberCount++;
    this.saveGuilds();

    const s = StorageManager.forPlayer(player);
    s.set("guild_id", invite.guildId);
    s.set("guild_rank", 1);
    s.set("guild_contrib", 0);

    this.pendingInvites.delete(player.name);
    player.sendMessage(`§6§l✦ §r§7You joined §e${guild.name}§7!`);
    player.playSound("random.levelup");

    // Broadcast to guild
    this.broadcastToGuild(guild.id, `§a${player.name} §7has joined the guild!`);
  }

  /** Leave current guild */
  leaveGuild(player) {
    const s = StorageManager.forPlayer(player);
    const guildId = s.getNumber("guild_id", 0);
    if (guildId <= 0) return;

    const guild = this.guilds.get(guildId);
    if (!guild) return;

    const rank = s.getNumber("guild_rank", 0);
    if (rank === 7 && guild.memberCount > 1) {
      player.sendMessage("§c§l✗ §r§7Founders must disband or transfer leadership first.");
      return;
    }

    // Remove from member list
    guild.members = guild.members.filter(m => m.name !== player.name);
    guild.memberCount = Math.max(0, guild.memberCount - 1);

    // Clear player data
    s.set("guild_id", 0);
    s.set("guild_rank", 0);
    s.set("guild_contrib", 0);

    if (guild.memberCount <= 0) {
      this.guilds.delete(guildId);
    }
    this.saveGuilds();

    player.sendMessage("§7You have left the guild.");
    this.broadcastToGuild(guildId, `§c${player.name} §7has left the guild.`);
  }

  /** Disband guild (founder only) */
  disbandGuild(player) {
    const s = StorageManager.forPlayer(player);
    const guildId = s.getNumber("guild_id", 0);
    if (guildId <= 0) return;
    if (s.getNumber("guild_rank", 0) < 7) {
      player.sendMessage("§c§l✗ §r§7Only the founder can disband.");
      return;
    }

    const guild = this.guilds.get(guildId);
    if (!guild) return;

    // Clear all members
    for (const p of world.getAllPlayers()) {
      const ps = StorageManager.forPlayer(p);
      if (ps.getNumber("guild_id", 0) === guildId) {
        ps.set("guild_id", 0);
        ps.set("guild_rank", 0);
        ps.set("guild_contrib", 0);
        p.sendMessage(`§c§l✗ §r§7Guild §e${guild.name} §7has been disbanded.`);
      }
    }

    this.guilds.delete(guildId);
    this.saveGuilds();
  }

  // ─── CONTRIBUTION & LEVELING ────────────────────────────────

  /** Add contribution to player + guild XP */
  addContribution(player, amount, silent) {
    const s = StorageManager.forPlayer(player);
    const guildId = s.getNumber("guild_id", 0);
    if (guildId <= 0) return;

    const guild = this.guilds.get(guildId);
    if (!guild) return;

    // Cap at MAX_CONTRIBUTION
    const current = s.getNumber("guild_contrib", 0);
    const capped = Math.min(amount, MAX_CONTRIBUTION - current);
    if (capped <= 0) return;

    s.set("guild_contrib", current + capped);

    // Update member record
    const member = guild.members.find(m => m.name === player.name);
    if (member) member.contrib = current + capped;

    // Add guild XP (double contribution)
    this.addGuildXp(player, capped * 2);

    // Check rank promotion
    this.checkRankPromotion(player, current + capped);

    // Victorian tree: every 100 contribution = 1000 Advantage XP
    const oldHundreds = Math.floor(current / VICTORIAN_CONTRIB_INTERVAL);
    const newHundreds = Math.floor((current + capped) / VICTORIAN_CONTRIB_INTERVAL);
    if (newHundreds > oldHundreds) {
      const xpGained = (newHundreds - oldHundreds) * 1000;
      this.eventBridge.emit("advantage_xp", player, xpGained);
      player.sendMessage(`§6§l✦ §r§7Victorian Tree: §a+${xpGained} Advantage XP!`);
    }

    if (!silent) {
      player.sendMessage(`§6§l✦ §r§7+${capped} guild contribution!`);
    }
    this.saveGuilds();
  }

  /** Donate items at guild stone */
  donateItems(player) {
    const s = StorageManager.forPlayer(player);
    const guildId = s.getNumber("guild_id", 0);
    if (guildId <= 0) { player.sendMessage("§c§l✗ §r§7Not in a guild."); return; }

    const inv = player.getComponent("minecraft:inventory");
    if (!inv) return;
    const container = inv.container;

    // Check held item
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (!mainhand) { player.sendMessage("§c§l✗ §r§7Hold an item to donate."); return; }

    const value = DONATION_VALUES[mainhand.typeId];
    if (!value) { player.sendMessage("§c§l✗ §r§7This item cannot be donated."); return; }

    // Expedition-contextual bonus
    const expBonus = this.getExpeditionDonationBonus(mainhand.typeId);
    const totalValue = Math.floor(value * mainhand.amount * expBonus);

    // Remove items
    try { equip.setEquipment("Mainhand", undefined); } catch {}

    this.addContribution(player, totalValue, false);
    player.sendMessage(`§6§l✦ Donated! §r§7+${totalValue} contribution.`);
    player.playSound("random.orb", { volume: 0.5, pitch: 1.0 });
  }

  /** Add XP to guild and check for level up */
  addGuildXp(player, amount) {
    const guildId = this.getPlayerGuildId(player);
    if (guildId <= 0) return;
    const guild = this.guilds.get(guildId);
    if (!guild) return;

    guild.xp += amount;
    this.checkLevelUp(guild);
    this.saveGuilds();
  }

  checkLevelUp(guild) {
    if (guild.level >= 100) return;
    const needed = xpForLevel(guild.level);
    while (guild.xp >= needed && guild.level < 100) {
      guild.xp -= needed;
      guild.level++;
      this.broadcastToGuild(guild.id, `§6§l✦ Guild Level Up! §r§7Now level §f${guild.level}§7!`);
    }
  }

  checkRankPromotion(player, totalContrib) {
    const s = StorageManager.forPlayer(player);
    const currentRank = s.getNumber("guild_rank", 1);

    for (let i = RANK_THRESHOLDS.length - 1; i >= 0; i--) {
      if (totalContrib >= RANK_THRESHOLDS[i].contrib && RANK_THRESHOLDS[i].rank > currentRank) {
        s.set("guild_rank", RANK_THRESHOLDS[i].rank);
        player.sendMessage(`§6§l✦ Rank Up! §r§7You are now ${RANK_COLORS[RANK_THRESHOLDS[i].rank]}${RANK_THRESHOLDS[i].name}§7!`);
        player.playSound("random.levelup");

        // Update member record
        const guild = this.getPlayerGuild(player);
        if (guild) {
          const member = guild.members.find(m => m.name === player.name);
          if (member) member.rank = RANK_THRESHOLDS[i].rank;
          this.saveGuilds();
        }
        break;
      }
    }
  }

  // ─── BUFFS ──────────────────────────────────────────────────

  applyRankBuffs(player) {
    const s = StorageManager.forPlayer(player);
    const rank = s.getNumber("guild_rank", 0);
    if (rank <= 0) return;

    const rankDef = RANK_THRESHOLDS.find(r => r.rank === rank);
    if (!rankDef?.buffs) return;

    // Apply rank buffs via effects
    if (rankDef.buffs.luck) {
      try { player.runCommandAsync(`effect @s luck 6 ${Math.floor(rankDef.buffs.luck) - 1} true`); } catch {}
    }
    if (rankDef.buffs.speed) {
      try { player.runCommandAsync("effect @s speed 6 0 true"); } catch {}
    }
    if (rankDef.buffs.armor) {
      try { player.runCommandAsync("effect @s resistance 6 0 true"); } catch {}
    }

    // Zone buffs: extra effects when inside guild zone
    if (this.isInGuildZone(player)) {
      try {
        // All ranks: Regeneration I + Resistance I in zone
        player.runCommandAsync("effect @s regeneration 6 0 true");
        player.runCommandAsync("effect @s resistance 6 0 true");
        // Rank 3+ (Aide): Haste I
        if (rank >= 3) {
          player.runCommandAsync("effect @s haste 6 0 true");
        }
        // Rank 7 (Valorous): Hero of the Village
        if (rank >= 7) {
          player.runCommandAsync("effect @s village_hero 6 0 true");
        }

        // Zone buffs for tamed pets: Regen I + Resistance I
        this.applyZonePetBuffs(player);
      } catch {}
    }
  }

  /** Apply Regen + Resistance to tamed pets in guild/housing zones */
  applyZonePetBuffs(player) {
    try {
      const pets = player.dimension.getEntities({
        location: player.location,
        maxDistance: 32,
        tags: ["ec.tame_protected"],
      });
      for (const pet of pets) {
        try {
          pet.addEffect("regeneration", 120, { amplifier: 0, showParticles: false });
          pet.addEffect("resistance", 120, { amplifier: 0, showParticles: false });
        } catch {}
      }
    } catch {}
  }

  // ─── DIPLOMACY PVP ──────────────────────────────────────────

  /** Check if two players are in enemy guilds (PvP allowed) */
  areEnemies(playerA, playerB) {
    const gidA = this.getPlayerGuildId(playerA);
    const gidB = this.getPlayerGuildId(playerB);
    if (gidA <= 0 || gidB <= 0 || gidA === gidB) return false;
    const guildA = this.guilds.get(gidA);
    return guildA?.enemies?.includes(gidB) || false;
  }

  /** Check if player is in an enemy guild's zone */
  isInEnemyZone(player) {
    const myGuildId = this.getPlayerGuildId(player);
    if (myGuildId <= 0) return false;
    const myGuild = this.guilds.get(myGuildId);
    if (!myGuild) return false;

    const loc = player.location;
    for (const enemyId of myGuild.enemies) {
      const enemy = this.guilds.get(enemyId);
      if (!enemy?.zone) continue;
      const z = enemy.zone;
      if (Math.abs(loc.x - z.x) <= ZONE_RADIUS &&
          Math.abs(loc.y - z.y) <= ZONE_RADIUS &&
          Math.abs(loc.z - z.z) <= ZONE_RADIUS) {
        return true;
      }
    }
    return false;
  }

  // ─── SUPPLY DROPS ────────────────────────────────────────────

  /** Trigger a supply drop for a guild (called from world events or tick) */
  triggerSupplyDrop(guildId) {
    const guild = this.guilds.get(guildId);
    if (!guild) return;

    const roll = Math.floor(Math.random() * 100) + 1;
    let tier = SUPPLY_DROP_TIERS[0];
    for (const t of SUPPLY_DROP_TIERS) {
      if (roll >= t.min && roll <= t.max) { tier = t; break; }
    }

    // Grant coins to all online guild members in zone
    for (const p of world.getAllPlayers()) {
      if (this.getPlayerGuildId(p) !== guildId) continue;
      if (!this.isInGuildZone(p)) continue;
      this.coinSystem.addCoins(p, tier.coins);
      p.sendMessage(`§6§l✦ ${tier.name}! §r§7+${tier.coins} Forever Coins!`);
      try { p.playSound("random.levelup"); } catch {}
    }
  }

  // ─── ZONE ────────────────────────────────────────────────────

  isInGuildZone(player) {
    const guild = this.getPlayerGuild(player);
    if (!guild?.zone) return false;
    const loc = player.location;
    const z = guild.zone;
    return Math.abs(loc.x - z.x) <= ZONE_RADIUS &&
           Math.abs(loc.y - z.y) <= ZONE_RADIUS &&
           Math.abs(loc.z - z.z) <= ZONE_RADIUS;
  }

  // ─── DIPLOMACY ──────────────────────────────────────────────

  /** Open diplomacy menu for a player targeting another guild */
  openDiplomacyMenu(player, targetGuildId) {
    const s = StorageManager.forPlayer(player);
    const myGuildId = s.getNumber("guild_id", 0);
    if (myGuildId <= 0 || s.getNumber("guild_rank", 0) < 5) return;

    const myGuild = this.guilds.get(myGuildId);
    const targetGuild = this.guilds.get(targetGuildId);
    if (!myGuild || !targetGuild || myGuildId === targetGuildId) return;

    const isAllied = myGuild.alliances.includes(targetGuildId);
    const form = new ActionFormData()
      .title(`§6Diplomacy: ${targetGuild.name}`)
      .body(`§7Your guild: §f${myGuild.name}\n§7Their guild: §f${targetGuild.name}\n§7Status: ${isAllied ? "§aAllied" : "§7Neutral"}`);

    if (isAllied) {
      form.button("§eChallenge to Competition\n§7Friendly contest (1 day)");
      form.button("§7Cancel");
      form.show(player).then(response => {
        if (response.canceled || response.selection === 1) return;
        this.proposeDiplomacy(player, targetGuildId, DIPLO.COMPETITION);
      });
    } else {
      form.button("§aPropose Alliance\n§7Cooperate together");
      form.button("§cDeclare Pillage\n§7PvP warfare!");
      form.button("§7Cancel");
      form.show(player).then(response => {
        if (response.canceled || response.selection === 2) return;
        const type = response.selection === 0 ? DIPLO.ALLIANCE : DIPLO.PILLAGE;
        this.proposeDiplomacy(player, targetGuildId, type);
      });
    }
  }

  proposeDiplomacy(player, targetGuildId, type) {
    const guildId = this.getPlayerGuildId(player);
    const guild = this.guilds.get(guildId);
    if (!guild) return;

    // Check cooldown
    const cd = guild.cooldowns.find(c => c.targetId === targetGuildId);
    if (cd && world.getDay() < cd.expiresDay) {
      player.sendMessage(`§c§l✗ §r§7Diplomacy cooldown with that guild (${cd.expiresDay - world.getDay()} days).`);
      return;
    }

    const typeName = type === DIPLO.ALLIANCE ? "Alliance" : type === DIPLO.COMPETITION ? "Competition" : "Pillage";
    this.broadcastToGuild(guildId, `§6§l✦ §r§7Diplomacy proposal: §e${typeName} §7with §f${this.guilds.get(targetGuildId)?.name || "Unknown"}§7. Vote yes/no!`);

    // Auto-approve for simplicity (vote system simplified for Bedrock)
    this.executeDiplomacy(guildId, targetGuildId, type);
  }

  executeDiplomacy(guildId, targetGuildId, type) {
    const guild = this.guilds.get(guildId);
    const target = this.guilds.get(targetGuildId);
    if (!guild || !target) return;

    if (type === DIPLO.ALLIANCE) {
      if (!guild.alliances.includes(targetGuildId)) guild.alliances.push(targetGuildId);
      if (!target.alliances.includes(guildId)) target.alliances.push(guildId);
      this.broadcastToGuild(guildId, `§a§l✦ §r§7Alliance formed with §e${target.name}§7!`);
      this.broadcastToGuild(targetGuildId, `§a§l✦ §r§7Alliance formed with §e${guild.name}§7!`);
    } else if (type === DIPLO.COMPETITION) {
      this.broadcastToGuild(guildId, `§e§l✦ §r§7Competition started with §e${target.name}§7! (1 day)`);
      this.broadcastToGuild(targetGuildId, `§e§l✦ §r§7Competition started with §e${guild.name}§7! (1 day)`);
    } else if (type === DIPLO.PILLAGE) {
      if (!guild.enemies.includes(targetGuildId)) guild.enemies.push(targetGuildId);
      if (!target.enemies.includes(guildId)) target.enemies.push(guildId);
      this.broadcastToGuild(guildId, `§c§l⚔ §r§7WAR declared on §e${target.name}§7!`);
      this.broadcastToGuild(targetGuildId, `§c§l⚔ §r§e${guild.name} §7has declared WAR!`);
    }

    // Set cooldown
    const expDay = world.getDay() + DIPLO_COOLDOWN_DAYS;
    guild.cooldowns = guild.cooldowns.filter(c => c.targetId !== targetGuildId);
    guild.cooldowns.push({ targetId: targetGuildId, expiresDay: expDay });
    target.cooldowns = target.cooldowns.filter(c => c.targetId !== guildId);
    target.cooldowns.push({ targetId: guildId, expiresDay: expDay });

    this.saveGuilds();
  }

  // ─── KICK VOTING ────────────────────────────────────────────

  startKickVote(player, targetName) {
    const s = StorageManager.forPlayer(player);
    const guildId = s.getNumber("guild_id", 0);
    if (guildId <= 0 || s.getNumber("guild_rank", 0) < 5) return;

    const guild = this.guilds.get(guildId);
    if (!guild) return;

    const targetMember = guild.members.find(m => m.name === targetName);
    if (!targetMember) { player.sendMessage("§c§l✗ §r§7Player not in guild."); return; }
    if (targetMember.rank >= 7) { player.sendMessage("§c§l✗ §r§7Cannot kick the founder."); return; }

    if (this.kickVotes.has(guildId)) { player.sendMessage("§c§l✗ §r§7Vote already in progress."); return; }

    const needed = Math.floor(guild.memberCount / 2) + 1;
    this.kickVotes.set(guildId, {
      target: targetName, yes: 1, no: 0, needed, expireTick: system.currentTick + KICK_VOTE_TIMEOUT,
    });

    this.broadcastToGuild(guildId, `§c§l✦ §r§7Kick vote started for §f${targetName}§7! (${needed} needed). Vote with /scriptevent forevercraft:guild_kick_vote yes/no`);
  }

  processKickVote(player, vote) {
    const guildId = this.getPlayerGuildId(player);
    const voteData = this.kickVotes.get(guildId);
    if (!voteData) return;

    if (vote === "yes") voteData.yes++;
    else voteData.no++;

    if (voteData.yes >= voteData.needed) {
      this.executeKick(guildId, voteData.target);
      this.kickVotes.delete(guildId);
    } else if (voteData.no > voteData.needed) {
      this.broadcastToGuild(guildId, `§a§l✓ §r§7Kick vote for §f${voteData.target} §7failed.`);
      this.kickVotes.delete(guildId);
    }
  }

  executeKick(guildId, targetName) {
    const guild = this.guilds.get(guildId);
    if (!guild) return;

    guild.members = guild.members.filter(m => m.name !== targetName);
    guild.memberCount = Math.max(0, guild.memberCount - 1);

    // Clear kicked player's data if online
    const target = world.getAllPlayers().find(p => p.name === targetName);
    if (target) {
      const ts = StorageManager.forPlayer(target);
      ts.set("guild_id", 0);
      ts.set("guild_rank", 0);
      ts.set("guild_contrib", 0);
      target.sendMessage("§c§l✗ §r§7You have been kicked from the guild.");
    }

    this.broadcastToGuild(guildId, `§c${targetName} §7has been kicked.`);
    this.saveGuilds();
  }

  // ─── EXPEDITIONS ────────────────────────────────────────────

  rollDailyExpedition() {
    const currentDay = world.getDay();
    if (this.expeditionDay === currentDay) return;
    this.expeditionDay = currentDay;

    const actIdx = Math.floor(Math.random() * EXPEDITION_ACTIVITIES.length);
    this.expeditionActivity = EXPEDITION_ACTIVITIES[actIdx].id;

    const act = EXPEDITION_ACTIVITIES[actIdx];
    for (const [guildId, guild] of this.guilds) {
      guild.expeditionActivity = this.expeditionActivity;
      guild.expeditionDay = currentDay;
    }
    this.saveGuilds();

    // Announce to all guilded players
    for (const p of world.getAllPlayers()) {
      if (this.getPlayerGuildId(p) > 0) {
        p.sendMessage(`§6§l✦ Guild Expedition: §r§e${act.icon} ${act.name}§7!`);
      }
    }
  }

  getExpeditionActivity() {
    const act = EXPEDITION_ACTIVITIES.find(a => a.id === this.expeditionActivity);
    return act || null;
  }

  // ─── EVENTS ─────────────────────────────────────────────────

  tickEvents(players) {
    const currentDay = world.getDay();

    // Noon gathering (every day at noon = ~6000 DayTime)
    // Simplified: check time via world time
    try {
      const dim = world.getDimension("overworld");
      // We'll use a simpler approach: check every minute
      if (currentDay !== this.lastNoonDay) {
        this.lastNoonDay = currentDay;
        this.noonActive = true;
        this.noonTimer = 180; // 3 minutes (ticked per second)
        for (const p of players) {
          if (this.getPlayerGuildId(p) > 0) {
            p.sendMessage("§6§l✦ Noon Gathering! §r§7Hang out near your guild stone for 3 minutes for rewards!");
          }
        }
      }
    } catch {}

    // Noon timer
    if (this.noonActive) {
      this.noonTimer--;
      if (this.noonTimer <= 0) {
        this.noonActive = false;
        // Reward players who were present
        for (const p of players) {
          const s = StorageManager.forPlayer(p);
          const ticks = s.getNumber("ge_noon_ticks", 0);
          if (ticks >= 90) { // 50% of 180 seconds
            try { p.runCommandAsync("xp 7L @s"); } catch {}
            this.eventBridge.emit("guild_contribution", p, 10);
            p.sendMessage("§6§l✦ §r§7Noon Gathering reward: §a7 Levels + 10 Contribution!");
          }
          s.set("ge_noon_ticks", 0);
        }
      } else {
        // Track players near guild zone
        for (const p of players) {
          if (this.isInGuildZone(p)) {
            const s = StorageManager.forPlayer(p);
            s.set("ge_noon_ticks", s.getNumber("ge_noon_ticks", 0) + 1);
          }
        }
      }
    }

    // Node scatter event (every 4 days)
    if (currentDay % 4 === 0 && currentDay !== this.lastScatterDay) {
      this.lastScatterDay = currentDay;
      this.scatterActive = true;
      this.scatterTimer = 180;
      for (const p of players) {
        if (this.getPlayerGuildId(p) > 0) {
          p.sendMessage("§6§l✦ Node Scatter! §r§7Collect glowing nodes near your guild stone!");
        }
      }
    }

    if (this.scatterActive) {
      this.scatterTimer--;
      // Every 30 seconds during scatter, reward players in their guild zone
      if (this.scatterTimer % 30 === 0 && this.scatterTimer > 0) {
        for (const p of players) {
          if (this.getPlayerGuildId(p) > 0 && this.isInGuildZone(p)) {
            // Each "node collection" gives contribution + XP
            this.addContribution(p, 5, true);
            try { p.runCommandAsync("xp 3L @s"); } catch {}
            p.sendMessage("§6§l✦ §r§7Collected a scattered node! §a+5 contrib + 3 levels");
            try { p.playSound("random.orb", { volume: 0.5, pitch: 1.3 }); } catch {}
          }
        }
      }
      if (this.scatterTimer <= 0) this.scatterActive = false;
    }

    // Supply drop (every 3 days, different from scatter)
    if (currentDay % 3 === 0 && this.tickCounter % 60 === 0 && !this.supplyDropFired) {
      this.supplyDropFired = true;
      for (const [guildId] of this.guilds) {
        this.triggerSupplyDrop(guildId);
      }
    }
    if (currentDay % 3 !== 0) this.supplyDropFired = false;

    // Weekly contribution event (every 7 days)
    if (currentDay % 7 === 0 && currentDay !== this.weeklyDay) {
      this.weeklyDay = currentDay;
      this.processWeeklyContribution();
    }

    // Daily expedition roll
    this.rollDailyExpedition();
  }

  processWeeklyContribution() {
    for (const [guildId, guild] of this.guilds) {
      const ranked = [...guild.members]
        .map(m => ({ name: m.name, delta: m.contrib - (m.weeklySnap || 0) }))
        .filter(m => m.delta > 0)
        .sort((a, b) => b.delta - a.delta);

      // Award top 3
      for (let i = 0; i < Math.min(ranked.length, LEADERBOARD_REWARDS.length); i++) {
        const reward = LEADERBOARD_REWARDS[i];
        const target = world.getAllPlayers().find(p => p.name === ranked[i].name);
        if (target) {
          try {
            target.dimension.runCommandAsync(
              `give "${target.name}" forevercraft:forever_coin ${reward.coins}`
            );
          } catch {}
          target.sendMessage(`§2§l✦ §r§7Weekly ${reward.title}§7! §e+${reward.coins} coins §7(${ranked[i].delta} contrib)`);
          this.eventBridge.emit("coins_earned", target, reward.coins);
        }
      }

      if (ranked.length > 0) {
        this.broadcastToGuild(guildId, `§2§l✦ Weekly MVP: §r§e${ranked[0].name} §7with §f${ranked[0].delta} §7contribution!`);
      }

      // Reset weekly snapshots
      for (const member of guild.members) {
        member.weeklySnap = member.contrib;
      }
    }
    this.saveGuilds();
  }

  // ─── GUI ────────────────────────────────────────────────────

  openGuildMenu(player) {
    const s = StorageManager.forPlayer(player);
    const guildId = s.getNumber("guild_id", 0);

    if (guildId <= 0) {
      // Not in a guild — offer to create
      const form = new ActionFormData()
        .title("§6Guild")
        .body("§7You are not in a guild.\n§7Found a new guild or wait for an invite!")
        .button("§eCreate Guild\n§7Costs 64 Emeralds")
        .button("§7Close");
      form.show(player).then(response => {
        if (response.canceled || response.selection === 1) return;
        this.openCreateForm(player);
      });
      return;
    }

    const guild = this.guilds.get(guildId);
    if (!guild) return;
    const rank = s.getNumber("guild_rank", 0);
    const contrib = s.getNumber("guild_contrib", 0);
    const rankDef = RANK_THRESHOLDS.find(r => r.rank === rank);

    // Hearthstone cooldown display
    const lastHearth = s.getNumber("guild_hearth_tick", 0);
    const hearthRemaining = HEARTHSTONE_COOLDOWN - (system.currentTick - lastHearth);
    const hearthReady = hearthRemaining <= 0;
    const hearthStr = hearthReady ? "§aReady" : `§c${Math.ceil(hearthRemaining / 20)}s`;

    const form = new ActionFormData()
      .title(`§2${guild.name}`)
      .body(
        `§7Level: §f${guild.level} §7| Members: §f${guild.memberCount}\n` +
        `§7Your Rank: ${RANK_COLORS[rank]}${rankDef?.name || "Unknown"} §7(${contrib}/${MAX_CONTRIBUTION} contrib)\n` +
        `§7XP: §f${guild.xp}/${xpForLevel(guild.level)}\n` +
        `§7Bank: §e${guild.bank || 0} coins\n` +
        `§7Pets: §f${(guild.petRoster || []).length}/${GUILD_PET_MAX}\n` +
        (guild.alliances.length > 0 ? `§7Allies: §a${guild.alliances.map(id => this.guilds.get(id)?.name || id).join(", ")}\n` : "") +
        (this.getExpeditionActivity() ? `§7Expedition: §e${this.getExpeditionActivity().icon} ${this.getExpeditionActivity().name}\n` : "") +
        `§7Hearthstone: ${hearthStr}`
      )
      .button("§2Info\n§7Guild details")
      .button("§2Team\n§7View members")
      .button("§2Donate\n§7Give materials")
      .button("§2Bank\n§7Guild treasury")
      .button("§2Pets\n§7Guild pet roster")
      .button("§2Leaderboard\n§7Weekly top")
      .button("§2Hearthstone\n§7Teleport to guild")
      .button("§2Manage\n§7Invite/Kick/Diplo")
      .button("§7Leave Guild")
      .button("§7Close");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 9) return;
      switch (response.selection) {
        case 0: this.showInfo(player, guild); break;
        case 1: this.showTeam(player, guild); break;
        case 2: this.donateItems(player); break;
        case 3: this.openBankMenu(player); break;
        case 4: this.openPetRosterMenu(player); break;
        case 5: this.showWeeklyLeaderboard(player); break;
        case 6: this.useHearthstone(player); break;
        case 7: this.showManage(player, guild, rank); break;
        case 8: this.confirmLeave(player); break;
      }
    });
  }

  showInfo(player, guild) {
    const form = new ActionFormData()
      .title(`§6${guild.name} — Info`)
      .body(
        `§7Guild Name: §f${guild.name}\n` +
        `§7Level: §f${guild.level}\n` +
        `§7XP: §f${guild.xp} / ${xpForLevel(guild.level)}\n` +
        `§7Members: §f${guild.memberCount}/${MAX_MEMBERS}\n` +
        `§7Founded: Day §f${guild.createdDay}\n` +
        `§7Founder: §f${guild.creatorName}\n` +
        `§7Zone: §f${guild.zone.x}, ${guild.zone.y}, ${guild.zone.z}\n` +
        `§7Alliances: §f${guild.alliances.length}\n` +
        `§7Enemies: §f${guild.enemies.length}`
      )
      .button("§7← Back");
    form.show(player).then(() => this.openGuildMenu(player));
  }

  showTeam(player, guild) {
    let body = "§7Guild Members:\n\n";
    const sorted = [...guild.members].sort((a, b) => b.rank - a.rank);
    for (const m of sorted) {
      const rd = RANK_THRESHOLDS.find(r => r.rank === m.rank);
      const online = world.getAllPlayers().some(p => p.name === m.name);
      body += `${online ? "§a●" : "§8●"} ${RANK_COLORS[m.rank]}${rd?.name || "?"} §f${m.name} §7(${m.contrib} contrib)\n`;
    }

    const form = new ActionFormData().title(`§6${guild.name} — Team`).body(body).button("§7← Back");
    form.show(player).then(() => this.openGuildMenu(player));
  }

  showManage(player, guild, rank) {
    const actions = [];

    if (rank >= 5) {
      actions.push({ label: "§aInvite Player\n§7Send invite", fn: () => this.showInviteForm(player) });
      actions.push({ label: "§cKick Vote\n§7Remove member", fn: () => this.showKickForm(player, guild) });
      actions.push({ label: "§5Diplomacy\n§7Alliances & Wars", fn: () => this.showAllies(player, guild) });
    }
    if (rank >= 7) {
      actions.push({ label: "§4Disband Guild\n§7Destroy guild", fn: () => this.confirmDisband(player) });
    }
    actions.push({ label: "§7← Back", fn: () => this.openGuildMenu(player) });

    const form = new ActionFormData()
      .title(`§2${guild.name} — Manage`)
      .body("§7Guild management options:");
    for (const a of actions) form.button(a.label);

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection < actions.length) actions[response.selection].fn();
    });
  }

  showInviteForm(player) {
    const others = world.getAllPlayers().filter(p => p.name !== player.name && StorageManager.forPlayer(p).getNumber("guild_id", 0) === 0);
    if (others.length === 0) { player.sendMessage("§c§l✗ §r§7No unguilded players online."); return; }

    const form = new ActionFormData().title("§6Invite Player").body("§7Select a player to invite:");
    for (const p of others) form.button(`§f${p.name}`);
    form.button("§7Cancel");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= others.length) return;
      this.invitePlayer(player, others[response.selection].name);
    });
  }

  showKickForm(player, guild) {
    const kickable = guild.members.filter(m => m.rank < 7 && m.name !== player.name);
    if (kickable.length === 0) { player.sendMessage("§c§l✗ §r§7No kickable members."); return; }

    const form = new ActionFormData().title("§cKick Vote").body("§7Select member to start kick vote:");
    for (const m of kickable) form.button(`§f${m.name} §7(${m.contrib} contrib)`);
    form.button("§7Cancel");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= kickable.length) return;
      this.startKickVote(player, kickable[response.selection].name);
    });
  }

  confirmLeave(player) {
    const form = new ActionFormData()
      .title("§cLeave Guild?")
      .body("§7Are you sure you want to leave? Your contribution will be lost.")
      .button("§cYes, Leave")
      .button("§aNo, Stay");
    form.show(player).then(response => {
      if (response.canceled || response.selection === 1) { this.openGuildMenu(player); return; }
      this.leaveGuild(player);
    });
  }

  confirmDisband(player) {
    const form = new ActionFormData()
      .title("§4Disband Guild?")
      .body("§c§lThis cannot be undone!\n§r§7All members will be removed and the guild destroyed.")
      .button("§4Yes, Disband")
      .button("§aNo, Keep");
    form.show(player).then(response => {
      if (response.canceled || response.selection === 1) return;
      this.disbandGuild(player);
    });
  }

  showAllies(player, guild) {
    let body = "";
    if (guild.alliances.length > 0) {
      body += "§aAllies:\n";
      for (const aid of guild.alliances) {
        const ag = this.guilds.get(aid);
        body += `  §a● §f${ag?.name || "Unknown"} §7(Lv.${ag?.level || "?"})\n`;
      }
    }
    if (guild.enemies.length > 0) {
      body += "\n§cEnemies:\n";
      for (const eid of guild.enemies) {
        const eg = this.guilds.get(eid);
        body += `  §c● §f${eg?.name || "Unknown"}\n`;
      }
    }
    if (!body) body = "§7No diplomatic relations.";

    const form = new ActionFormData().title(`§6${guild.name} — Allies`).body(body).button("§7← Back");
    form.show(player).then(() => this.openGuildMenu(player));
  }

  warpToStone(player, guild) {
    if (!guild.zone) { player.sendMessage("§c§l✗ §r§7No guild stone location set."); return; }

    // Two-click confirmation
    const s = StorageManager.forPlayer(player);
    const confirming = s.get("guild_warp_confirm");

    if (!confirming) {
      s.set("guild_warp_confirm", true);
      player.sendMessage("§e§l→ §r§7Click Warp again to confirm teleport to guild stone.");
      // Auto-clear after 5 seconds
      system.runTimeout(() => { s.set("guild_warp_confirm", false); }, 100);
      this.openGuildMenu(player);
      return;
    }

    s.set("guild_warp_confirm", false);
    const z = guild.zone;
    try {
      player.teleport({ x: z.x, y: z.y + 1, z: z.z });
      player.sendMessage("§6§l✦ §r§7Warped to guild stone!");
      player.playSound("mob.endermen.portal");
    } catch {
      player.sendMessage("§c§l✗ §r§7Teleport failed.");
    }
  }

  // ─── HEARTHSTONE (GUILD TELEPORT) ──────────────────────────

  useHearthstone(player) {
    const guild = this.getPlayerGuild(player);
    if (!guild?.zone) {
      player.sendMessage("§c§l✗ §r§7No guild to teleport to.");
      return;
    }

    const s = StorageManager.forPlayer(player);
    const lastUse = s.getNumber("guild_hearth_tick", 0);
    const now = system.currentTick;
    const remaining = HEARTHSTONE_COOLDOWN - (now - lastUse);

    if (remaining > 0) {
      const secs = Math.ceil(remaining / 20);
      player.sendMessage(`§c§l✗ §r§7Hearthstone on cooldown (${secs}s remaining).`);
      return;
    }

    s.set("guild_hearth_tick", now);
    const z = guild.zone;
    try {
      player.teleport({ x: z.x, y: z.y + 1, z: z.z });
      player.sendMessage("§2§l✦ §r§7Hearthstone activated! Teleported to guild.");
      try {
        player.playSound("mob.endermen.portal", { volume: 0.6, pitch: 1.0 });
        const pos = player.location;
        player.dimension.runCommandAsync(
          `particle minecraft:endRod ${pos.x} ${pos.y + 1} ${pos.z} 0.3 1 0.3 0 15`
        );
      } catch {}
    } catch {
      player.sendMessage("§c§l✗ §r§7Teleport failed.");
    }
  }

  // ─── GUILD BANK ──────────────────────────────────────────

  getGuildBank(guildId) {
    const guild = this.guilds.get(guildId);
    return guild?.bank || 0;
  }

  depositToBank(player, amount) {
    const guildId = this.getPlayerGuildId(player);
    const guild = this.guilds.get(guildId);
    if (!guild) { player.sendMessage("§c§l✗ §r§7Not in a guild."); return; }

    const s = StorageManager.forPlayer(player);
    const rank = s.getNumber("guild_rank", 0);
    if (rank < 2) { player.sendMessage("§c§l✗ §r§7Rank 2+ required to deposit."); return; }

    if (!guild.bank) guild.bank = 0;
    const capped = Math.min(amount, GUILD_BANK_MAX - guild.bank);
    if (capped <= 0) { player.sendMessage("§c§l✗ §r§7Guild bank is full."); return; }

    guild.bank += capped;
    this.saveGuilds();
    player.sendMessage(`§2§l✦ §r§7Deposited §e${capped} coins§7 to guild bank. Balance: §e${guild.bank}`);
    this.eventBridge.emit("guild_contribution", player, Math.floor(capped / 2));
  }

  withdrawFromBank(player, amount) {
    const guildId = this.getPlayerGuildId(player);
    const guild = this.guilds.get(guildId);
    if (!guild) return;

    const s = StorageManager.forPlayer(player);
    if (s.getNumber("guild_rank", 0) < 5) {
      player.sendMessage("§c§l✗ §r§7Rank 5+ required to withdraw.");
      return;
    }

    if (!guild.bank) guild.bank = 0;
    const withdrawal = Math.min(amount, guild.bank);
    if (withdrawal <= 0) { player.sendMessage("§c§l✗ §r§7Bank is empty."); return; }

    guild.bank -= withdrawal;
    this.saveGuilds();

    // Give coins to player
    try {
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:forever_coin ${withdrawal}`
      );
    } catch {}
    player.sendMessage(`§2§l✦ §r§7Withdrew §e${withdrawal} coins§7. Bank balance: §e${guild.bank}`);
  }

  openBankMenu(player) {
    const guildId = this.getPlayerGuildId(player);
    const guild = this.guilds.get(guildId);
    if (!guild) return;

    const bank = guild.bank || 0;
    const rank = StorageManager.forPlayer(player).getNumber("guild_rank", 0);

    const form = new ActionFormData()
      .title("§2Guild Bank")
      .body(
        `§7Balance: §e${bank} coins §7/ §f${GUILD_BANK_MAX}\n\n` +
        `§7Deposit: Rank 2+ required\n` +
        `§7Withdraw: Rank 5+ required`
      )
      .button("§aDeposit 10 Coins")
      .button("§aDeposit 50 Coins")
      .button(rank >= 5 ? "§eWithdraw 10 Coins" : "§8Withdraw 10 (Locked)")
      .button("§7← Back");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 3) { this.openGuildMenu(player); return; }
      if (r.selection === 0) this.depositToBank(player, 10);
      else if (r.selection === 1) this.depositToBank(player, 50);
      else if (r.selection === 2 && rank >= 5) this.withdrawFromBank(player, 10);
      else player.sendMessage("§c§l✗ §r§7Insufficient rank.");
    });
  }

  // ─── GUILD PET ROSTER ────────────────────────────────────

  getGuildPets(guildId) {
    const guild = this.guilds.get(guildId);
    return guild?.petRoster || [];
  }

  assignPetToGuild(player, petId) {
    const guildId = this.getPlayerGuildId(player);
    const guild = this.guilds.get(guildId);
    if (!guild) { player.sendMessage("§c§l✗ §r§7Not in a guild."); return; }

    if (!guild.petRoster) guild.petRoster = [];
    if (guild.petRoster.length >= GUILD_PET_MAX) {
      player.sendMessage("§c§l✗ §r§7Guild pet roster is full (25 max).");
      return;
    }

    // Check per-player limit
    const playerPets = guild.petRoster.filter(p => p.owner === player.name).length;
    if (playerPets >= GUILD_PET_PER_PLAYER) {
      player.sendMessage("§c§l✗ §r§7You've already assigned ${GUILD_PET_PER_PLAYER} pets.");
      return;
    }

    guild.petRoster.push({ petId, owner: player.name, assignedDay: world.getDay() });
    this.saveGuilds();
    player.sendMessage(`§2§l✦ §r§7Pet assigned to guild roster!`);
  }

  openPetRosterMenu(player) {
    const guildId = this.getPlayerGuildId(player);
    const guild = this.guilds.get(guildId);
    if (!guild) return;

    const pets = guild.petRoster || [];
    let body = `§7Guild Pets: §f${pets.length}§7/§f${GUILD_PET_MAX}\n\n`;

    if (pets.length === 0) {
      body += "§8No pets assigned yet.\n§7Assign pets via the companion menu.";
    } else {
      for (const pet of pets) {
        body += `§f${pet.petId} §7— Owner: §f${pet.owner}\n`;
      }
    }

    const form = new ActionFormData()
      .title("§2Guild Pet Roster")
      .body(body)
      .button("§7← Back");

    form.show(player).then(() => this.openGuildMenu(player));
  }

  // ─── EXPEDITION-CONTEXTUAL DONATION ──────────────────────

  getExpeditionDonationBonus(itemTypeId) {
    const act = this.expeditionActivity;
    const bonus = EXPEDITION_DONATION_BONUS[act];
    if (!bonus) return 1;
    if (bonus.items.includes(itemTypeId)) return bonus.mult;
    return 1;
  }

  // ─── WEEKLY LEADERBOARD ──────────────────────────────────

  showWeeklyLeaderboard(player) {
    const guild = this.getPlayerGuild(player);
    if (!guild) return;

    const sorted = [...guild.members]
      .map(m => ({ ...m, weeklyContrib: m.contrib - (m.weeklySnap || 0) }))
      .sort((a, b) => b.weeklyContrib - a.weeklyContrib)
      .slice(0, 10);

    let body = "§7This week's top contributors:\n\n";
    for (let i = 0; i < sorted.length; i++) {
      const m = sorted[i];
      const medal = i === 0 ? "§6🥇" : i === 1 ? "§e🥈" : i === 2 ? "§f🥉" : "§7 ";
      body += `${medal} §f${m.name} §7— §e${m.weeklyContrib} contrib\n`;
    }

    const form = new ActionFormData()
      .title("§2Weekly Leaderboard")
      .body(body)
      .button("§7← Back");

    form.show(player).then(() => this.openGuildMenu(player));
  }

  // ─── UTILITY ────────────────────────────────────────────────

  broadcastToGuild(guildId, message) {
    for (const p of world.getAllPlayers()) {
      if (this.getPlayerGuildId(p) === guildId) {
        p.sendMessage(message);
      }
    }
  }

  // ─── TICK ───────────────────────────────────────────────────

  tick(players) {
    this.tickCounter++;

    // Apply rank buffs every 5 seconds (100 ticks)
    if (this.tickCounter % 5 === 0) {
      for (const p of players) this.applyRankBuffs(p);
    }

    // Events every 60 seconds
    if (this.tickCounter % 60 === 0) {
      this.tickEvents(players);
    }

    // Clean expired invites
    for (const [name, invite] of this.pendingInvites) {
      if (system.currentTick > invite.expireTick) this.pendingInvites.delete(name);
    }

    // Clean expired kick votes
    for (const [gid, vote] of this.kickVotes) {
      if (system.currentTick > vote.expireTick) {
        this.broadcastToGuild(gid, `§7Kick vote for §f${vote.target} §7expired.`);
        this.kickVotes.delete(gid);
      }
    }

    // Clean expired cooldowns
    if (this.tickCounter % 300 === 0) {
      const day = world.getDay();
      for (const [, guild] of this.guilds) {
        guild.cooldowns = guild.cooldowns.filter(c => c.expiresDay > day);
      }
    }
  }

  // ─── EXPEDITION PROGRESS & COMPLETION ──────────────────────

  /**
   * Track expedition progress for a player's guild.
   * Called by event hooks when players complete activities matching the daily expedition.
   * @param {Player} player
   * @param {string} activityType — e.g., "mine", "kill", "forage", "fish", "craft", "cook", "explore", "trade"
   * @param {number} amount
   */
  addExpeditionProgress(player, activityType, amount = 1) {
    const guildId = this.getPlayerGuildId(player);
    if (guildId <= 0) return;

    const guild = this.guilds.get(guildId);
    if (!guild) return;

    const act = this.getExpeditionActivity();
    if (!act) return;

    // Check if activity matches today's expedition type
    if (act.type !== activityType) return;

    // Initialize progress if needed
    if (!guild.expeditionProgress) guild.expeditionProgress = 0;
    if (guild.expeditionComplete) return; // Already done for today

    guild.expeditionProgress += amount;

    // Check completion (threshold based on guild level)
    const threshold = act.baseTarget + (guild.level || 1) * 5;
    if (guild.expeditionProgress >= threshold) {
      guild.expeditionComplete = true;
      this.completeExpedition(guildId, guild, act);
    }

    this.saveGuilds();
  }

  completeExpedition(guildId, guild, activity) {
    // Reward all online guild members
    const guildLevel = guild.level || 1;
    const coinReward = 5 + Math.floor(guildLevel / 5);
    const xpReward = 10 + guildLevel * 2;

    for (const p of world.getAllPlayers()) {
      if (this.getPlayerGuildId(p) === guildId) {
        p.sendMessage(`\n§6§l✦ Guild Expedition Complete! ✦§r`);
        p.sendMessage(`§7${activity.icon} ${activity.name} — §aSuccess!`);
        p.sendMessage(`§7Rewards: §e${coinReward} Coins §7+ §a${xpReward} Guild XP`);
        p.playSound("random.levelup", { volume: 0.7, pitch: 1.1 });

        this.eventBridge.emit("grant_coins", { player: p, amount: coinReward, reason: "Expedition" });
      }
    }

    // Add guild XP
    guild.xp = (guild.xp || 0) + xpReward;

    this.broadcastToGuild(guildId, `§6Expedition §f${activity.name}§6 completed! §7+${xpReward} Guild XP`);
  }

  /**
   * Reset expedition progress at start of new day.
   * Called from rollDailyExpedition.
   */
  resetExpeditionProgress() {
    for (const [, guild] of this.guilds) {
      guild.expeditionProgress = 0;
      guild.expeditionComplete = false;
    }
  }
}
