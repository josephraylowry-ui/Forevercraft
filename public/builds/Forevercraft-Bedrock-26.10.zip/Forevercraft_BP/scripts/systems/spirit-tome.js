/**
 * Spirit Tome System — 100-quest progression chain per spirit weapon.
 * Auto-granted when player receives a spirit artifact.
 * Scaling mastery XP rewards (Part N = N levels worth of XP).
 * Replaces Java spirit_tome/ folder (156 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// Quest type definitions
const QUEST_TYPES = {
  KILL: "kill",           // Kill N of entity type
  KILL_ANY: "kill_any",   // Kill N of any mob
  MINE: "mine",           // Mine N blocks
  CRAFT: "craft",         // Craft N items
  FISH: "fish",           // Catch N fish
  TRADE: "trade",         // Complete N trades
  EXPLORE: "explore",     // Visit N biomes
  DUNGEON: "dungeon",     // Complete N dungeon floors
  BOSS: "boss",           // Defeat N bosses
  WALK: "walk",           // Walk N blocks
  COOK: "cook",           // Cook N meals
  FORAGE: "forage",       // Forage N items
  PROSPECT: "prospect",   // Prospect N nodes
  SLEEP: "sleep",         // Sleep N nights
  SURVIVE: "survive",     // Survive N minutes without dying
};

// 100 quest templates (shared across all weapons with minor variation)
// Difficulty is intentionally random — some easy, some brutal
function generateQuests() {
  const quests = [];
  const templates = [
    // Easy starters (1-10)
    { type: QUEST_TYPES.KILL_ANY, target: 10, desc: "Slay 10 hostile mobs" },
    { type: QUEST_TYPES.MINE, target: 50, desc: "Mine 50 blocks" },
    { type: QUEST_TYPES.WALK, target: 1000, desc: "Travel 1,000 blocks" },
    { type: QUEST_TYPES.FISH, target: 5, desc: "Catch 5 fish" },
    { type: QUEST_TYPES.KILL, target: 20, desc: "Slay 20 zombies", entityType: "minecraft:zombie" },
    { type: QUEST_TYPES.COOK, target: 3, desc: "Cook 3 meals" },
    { type: QUEST_TYPES.SLEEP, target: 3, desc: "Sleep through 3 nights" },
    { type: QUEST_TYPES.TRADE, target: 5, desc: "Complete 5 trades" },
    { type: QUEST_TYPES.FORAGE, target: 10, desc: "Forage 10 items" },
    { type: QUEST_TYPES.KILL_ANY, target: 50, desc: "Slay 50 hostile mobs" },
    // Medium difficulty (11-30)
    { type: QUEST_TYPES.MINE, target: 500, desc: "Mine 500 blocks" },
    { type: QUEST_TYPES.KILL, target: 50, desc: "Slay 50 skeletons", entityType: "minecraft:skeleton" },
    { type: QUEST_TYPES.DUNGEON, target: 1, desc: "Complete a dungeon" },
    { type: QUEST_TYPES.FISH, target: 25, desc: "Catch 25 fish" },
    { type: QUEST_TYPES.PROSPECT, target: 15, desc: "Prospect 15 nodes" },
    { type: QUEST_TYPES.WALK, target: 5000, desc: "Travel 5,000 blocks" },
    { type: QUEST_TYPES.KILL_ANY, target: 100, desc: "Slay 100 hostile mobs" },
    { type: QUEST_TYPES.COOK, target: 10, desc: "Cook 10 meals" },
    { type: QUEST_TYPES.EXPLORE, target: 5, desc: "Visit 5 different biomes" },
    { type: QUEST_TYPES.TRADE, target: 20, desc: "Complete 20 trades" },
    { type: QUEST_TYPES.KILL, target: 30, desc: "Slay 30 creepers", entityType: "minecraft:creeper" },
    { type: QUEST_TYPES.MINE, target: 1000, desc: "Mine 1,000 blocks" },
    { type: QUEST_TYPES.FORAGE, target: 30, desc: "Forage 30 items" },
    { type: QUEST_TYPES.SLEEP, target: 10, desc: "Sleep through 10 nights" },
    { type: QUEST_TYPES.KILL, target: 25, desc: "Slay 25 spiders", entityType: "minecraft:spider" },
    { type: QUEST_TYPES.DUNGEON, target: 3, desc: "Complete 3 dungeons" },
    { type: QUEST_TYPES.FISH, target: 50, desc: "Catch 50 fish" },
    { type: QUEST_TYPES.KILL_ANY, target: 200, desc: "Slay 200 hostile mobs" },
    { type: QUEST_TYPES.PROSPECT, target: 30, desc: "Prospect 30 nodes" },
    { type: QUEST_TYPES.WALK, target: 10000, desc: "Travel 10,000 blocks" },
    // Hard (31-60)
    { type: QUEST_TYPES.KILL, target: 100, desc: "Slay 100 endermen", entityType: "minecraft:enderman" },
    { type: QUEST_TYPES.MINE, target: 5000, desc: "Mine 5,000 blocks" },
    { type: QUEST_TYPES.BOSS, target: 1, desc: "Defeat a world boss" },
    { type: QUEST_TYPES.DUNGEON, target: 5, desc: "Complete 5 dungeons" },
    { type: QUEST_TYPES.COOK, target: 25, desc: "Cook 25 meals" },
    { type: QUEST_TYPES.TRADE, target: 50, desc: "Complete 50 trades" },
    { type: QUEST_TYPES.KILL, target: 50, desc: "Slay 50 blazes", entityType: "minecraft:blaze" },
    { type: QUEST_TYPES.FISH, target: 100, desc: "Catch 100 fish" },
    { type: QUEST_TYPES.EXPLORE, target: 10, desc: "Visit 10 different biomes" },
    { type: QUEST_TYPES.FORAGE, target: 50, desc: "Forage 50 items" },
    { type: QUEST_TYPES.KILL_ANY, target: 500, desc: "Slay 500 hostile mobs" },
    { type: QUEST_TYPES.PROSPECT, target: 50, desc: "Prospect 50 nodes" },
    { type: QUEST_TYPES.WALK, target: 25000, desc: "Travel 25,000 blocks" },
    { type: QUEST_TYPES.DUNGEON, target: 10, desc: "Complete 10 dungeons" },
    { type: QUEST_TYPES.KILL, target: 75, desc: "Slay 75 witches", entityType: "minecraft:witch" },
    { type: QUEST_TYPES.MINE, target: 10000, desc: "Mine 10,000 blocks" },
    { type: QUEST_TYPES.BOSS, target: 3, desc: "Defeat 3 world bosses" },
    { type: QUEST_TYPES.COOK, target: 50, desc: "Cook 50 meals" },
    { type: QUEST_TYPES.SLEEP, target: 30, desc: "Sleep through 30 nights" },
    { type: QUEST_TYPES.KILL, target: 100, desc: "Slay 100 wither skeletons", entityType: "minecraft:wither_skeleton" },
    // Very hard (61-80)
    { type: QUEST_TYPES.KILL_ANY, target: 1000, desc: "Slay 1,000 hostile mobs" },
    { type: QUEST_TYPES.MINE, target: 25000, desc: "Mine 25,000 blocks" },
    { type: QUEST_TYPES.DUNGEON, target: 20, desc: "Complete 20 dungeons" },
    { type: QUEST_TYPES.BOSS, target: 5, desc: "Defeat 5 world bosses" },
    { type: QUEST_TYPES.TRADE, target: 100, desc: "Complete 100 trades" },
    { type: QUEST_TYPES.FISH, target: 200, desc: "Catch 200 fish" },
    { type: QUEST_TYPES.WALK, target: 50000, desc: "Travel 50,000 blocks" },
    { type: QUEST_TYPES.COOK, target: 100, desc: "Cook 100 meals" },
    { type: QUEST_TYPES.FORAGE, target: 100, desc: "Forage 100 items" },
    { type: QUEST_TYPES.PROSPECT, target: 100, desc: "Prospect 100 nodes" },
    { type: QUEST_TYPES.KILL, target: 200, desc: "Slay 200 guardians", entityType: "minecraft:guardian" },
    { type: QUEST_TYPES.MINE, target: 50000, desc: "Mine 50,000 blocks" },
    { type: QUEST_TYPES.DUNGEON, target: 30, desc: "Complete 30 dungeons" },
    { type: QUEST_TYPES.EXPLORE, target: 15, desc: "Visit 15 different biomes" },
    { type: QUEST_TYPES.KILL_ANY, target: 2000, desc: "Slay 2,000 hostile mobs" },
    { type: QUEST_TYPES.BOSS, target: 7, desc: "Defeat 7 world bosses" },
    { type: QUEST_TYPES.TRADE, target: 200, desc: "Complete 200 trades" },
    { type: QUEST_TYPES.WALK, target: 100000, desc: "Travel 100,000 blocks" },
    { type: QUEST_TYPES.FISH, target: 500, desc: "Catch 500 fish" },
    { type: QUEST_TYPES.COOK, target: 200, desc: "Cook 200 meals" },
    // Brutal endgame (81-100)
    { type: QUEST_TYPES.KILL_ANY, target: 5000, desc: "Slay 5,000 hostile mobs" },
    { type: QUEST_TYPES.MINE, target: 100000, desc: "Mine 100,000 blocks" },
    { type: QUEST_TYPES.DUNGEON, target: 50, desc: "Complete 50 dungeons" },
    { type: QUEST_TYPES.BOSS, target: 10, desc: "Defeat 10 world bosses" },
    { type: QUEST_TYPES.TRADE, target: 500, desc: "Complete 500 trades" },
    { type: QUEST_TYPES.WALK, target: 250000, desc: "Travel 250,000 blocks" },
    { type: QUEST_TYPES.KILL_ANY, target: 10000, desc: "Slay 10,000 hostile mobs" },
    { type: QUEST_TYPES.MINE, target: 250000, desc: "Mine 250,000 blocks" },
    { type: QUEST_TYPES.FORAGE, target: 500, desc: "Forage 500 items" },
    { type: QUEST_TYPES.PROSPECT, target: 500, desc: "Prospect 500 nodes" },
    { type: QUEST_TYPES.FISH, target: 1000, desc: "Catch 1,000 fish" },
    { type: QUEST_TYPES.DUNGEON, target: 75, desc: "Complete 75 dungeons" },
    { type: QUEST_TYPES.BOSS, target: 13, desc: "Defeat all 13 raid bosses" },
    { type: QUEST_TYPES.KILL_ANY, target: 25000, desc: "Slay 25,000 hostile mobs" },
    { type: QUEST_TYPES.MINE, target: 500000, desc: "Mine 500,000 blocks" },
    { type: QUEST_TYPES.COOK, target: 500, desc: "Cook 500 meals" },
    { type: QUEST_TYPES.TRADE, target: 1000, desc: "Complete 1,000 trades" },
    { type: QUEST_TYPES.WALK, target: 500000, desc: "Travel 500,000 blocks" },
    { type: QUEST_TYPES.DUNGEON, target: 100, desc: "Complete 100 dungeons" },
    { type: QUEST_TYPES.KILL_ANY, target: 50000, desc: "Slay 50,000 hostile mobs" },
  ];

  for (let i = 0; i < 100; i++) {
    quests.push({ ...templates[i], part: i + 1 });
  }
  return quests;
}

const QUESTS = generateQuests();

// Storage key mapping for quest types → tracked stats
const STAT_KEYS = {
  [QUEST_TYPES.KILL_ANY]: "stat_mob_kills",
  [QUEST_TYPES.MINE]: "stat_blocks_mined",
  [QUEST_TYPES.FISH]: "stat_fish_caught",
  [QUEST_TYPES.TRADE]: "stat_trades",
  [QUEST_TYPES.WALK]: "stat_distance_walked",
  [QUEST_TYPES.COOK]: "stat_meals_cooked",
  [QUEST_TYPES.FORAGE]: "stat_forages",
  [QUEST_TYPES.PROSPECT]: "stat_prospects",
  [QUEST_TYPES.SLEEP]: "stat_nights_slept",
  [QUEST_TYPES.DUNGEON]: "stat_dungeons",
  [QUEST_TYPES.BOSS]: "stat_bosses_killed",
  [QUEST_TYPES.EXPLORE]: "stat_biomes_visited",
};

export class SpiritTomeSystem {
  constructor(eventBridge, spiritWeaponSystem) {
    this.eventBridge = eventBridge;
    this.spiritWeapons = spiritWeaponSystem;

    // Auto-grant tome when spirit weapon obtained
    this.eventBridge.on("spirit_weapon_obtained", (data) => {
      this.grantTome(data.player);
    });

    // Listen for events that advance quests
    this.eventBridge.on("player_killed_entity", (data) => this.onEvent(data.player, QUEST_TYPES.KILL_ANY, 1));
    this.eventBridge.on("block_mined", (data) => this.onEvent(data.player, QUEST_TYPES.MINE, 1));
    this.eventBridge.on("fish_caught", (data) => this.onEvent(data.player, QUEST_TYPES.FISH, 1));
    this.eventBridge.on("trade_completed", (data) => this.onEvent(data.player, QUEST_TYPES.TRADE, 1));
    this.eventBridge.on("meal_cooked", (data) => this.onEvent(data.player, QUEST_TYPES.COOK, 1));
    this.eventBridge.on("forage_complete", (data) => this.onEvent(data.player, QUEST_TYPES.FORAGE, 1));
    this.eventBridge.on("prospect_complete", (data) => this.onEvent(data.player, QUEST_TYPES.PROSPECT, 1));
    this.eventBridge.on("dungeon_complete", (data) => this.onEvent(data.player, QUEST_TYPES.DUNGEON, 1));
    this.eventBridge.on("boss_killed", (data) => this.onEvent(data.player, QUEST_TYPES.BOSS, 1));
    this.eventBridge.on("sleep_complete", (data) => this.onEvent(data.player, QUEST_TYPES.SLEEP, 1));
  }

  grantTome(player) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("tome_quest_part", 0) > 0) return; // Already has a tome

    s.setNumber("tome_quest_part", 1);
    s.setNumber("tome_quest_progress", 0);
    s.setNumber("tome_quest_baseline", 0);

    player.sendMessage("\n§d§l✦ Spirit Tome Received ✦\n§r§7A mystical tome has appeared in your mind.\n§7100 quests await — each one rewards mastery XP.\n§7Type /scriptevent forevercraft:spirit_tome to view progress.\n");
    player.playSound("random.orb");
  }

  onEvent(player, questType, amount) {
    if (!player) return;
    const s = StorageManager.forPlayer(player);
    const currentPart = s.getNumber("tome_quest_part", 0);
    if (currentPart <= 0 || currentPart > 100) return;

    const quest = QUESTS[currentPart - 1];
    if (!quest || quest.type !== questType) return;

    // Increment progress
    const progress = s.getNumber("tome_quest_progress", 0) + amount;
    s.setNumber("tome_quest_progress", progress);

    // Check completion
    if (progress >= quest.target) {
      this.advanceQuest(player, currentPart);
    }
  }

  advanceQuest(player, completedPart) {
    const s = StorageManager.forPlayer(player);

    // Grant mastery XP: Part N = N * 100 XP
    const xpReward = completedPart * 100;
    this.spiritWeapons.addMasteryXP(player, xpReward);

    player.sendMessage(`\n§d✦ Spirit Tome — Part ${completedPart}/100 Complete! ✦\n§7+${xpReward} mastery XP\n`);
    player.playSound("random.levelup");

    if (completedPart >= 100) {
      // All 100 quests complete!
      player.sendMessage("\n§d§l✦ ✦ ✦ SPIRIT TOME COMPLETE ✦ ✦ ✦\n§r§dAll 100 quests fulfilled.\n§dYour spirit weapon resonates with unimaginable power.\n");
      player.playSound("ui.toast.challenge_complete");
      s.setNumber("tome_quest_part", 101); // Mark complete
      return;
    }

    // Advance to next quest
    s.setNumber("tome_quest_part", completedPart + 1);
    s.setNumber("tome_quest_progress", 0);

    const nextQuest = QUESTS[completedPart]; // 0-indexed, completedPart is already +1
    if (nextQuest) {
      player.sendMessage(`§7Next Quest (Part ${completedPart + 1}): §f${nextQuest.desc}`);
    }
  }

  showTomeStatus(player) {
    const s = StorageManager.forPlayer(player);
    const part = s.getNumber("tome_quest_part", 0);

    if (part <= 0) {
      player.sendMessage("§7You don't have a Spirit Tome. Obtain a Spirit Artifact first!");
      return;
    }

    if (part > 100) {
      const form = new ActionFormData()
        .title("Spirit Tome — COMPLETE")
        .body("§d§l✦ All 100 quests complete! ✦\n\n§7Your dedication has been rewarded with immense mastery XP.\n§7The tome's power flows through your spirit weapon.")
        .button("Close");
      form.show(player);
      return;
    }

    const quest = QUESTS[part - 1];
    const progress = s.getNumber("tome_quest_progress", 0);
    const pct = Math.min(100, Math.floor((progress / quest.target) * 100));
    const barFilled = Math.floor(pct / 5);
    const progressBar = "§a" + "█".repeat(barFilled) + "§8" + "░".repeat(20 - barFilled);

    const form = new ActionFormData()
      .title(`Spirit Tome — Part ${part}/100`)
      .body([
        `§lCurrent Quest:`,
        `§f${quest.desc}`,
        "",
        `§7Progress: §f${progress.toLocaleString()} / ${quest.target.toLocaleString()}`,
        progressBar + ` §f${pct}%`,
        "",
        `§7XP on completion: §a+${part * 100}`,
        "",
        `§7Parts completed: §f${part - 1}/100`,
      ].join("\n"))
      .button("Close");
    form.show(player);
  }
}
