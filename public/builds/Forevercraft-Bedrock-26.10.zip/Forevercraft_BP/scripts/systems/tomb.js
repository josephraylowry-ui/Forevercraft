/**
 * Tomb System — Death item recovery + Totem Death Save mechanics.
 * Replaces Java tomb/ folder + totem_save logic across dungeon/duel/castle/heist.
 *
 * Totem Save: Intercepts death at ≤2 HP in special game modes.
 * - Duels: Heal + totem visual + Darkness/Nausea 7s + teleport to bed
 * - Castle: Heal + totem visual + -30 levels + teleport to bed
 * - Heist: Heal + totem visual + teleport home (no penalties)
 * - Dungeons: NO self-revive (disclaimer shown)
 *
 * Healer Revive: Healers can revive dead players by right-clicking tombs.
 * - Healer gets Slowness + Blindness for 7s, 15s healing lockout
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const TOTEM_SAVE_HEALTH_THRESHOLD = 4; // 2 hearts = 4 half-hearts

export class TombSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    eventBridge.on("player_respawn", (player) => this.showTombLocation(player));
  }

  /**
   * Check if player should be totem-saved instead of dying.
   * Called from main death handler BEFORE tomb creation.
   * Returns true if death was intercepted.
   */
  checkTotemSave(player) {
    // Duel totem save
    if (player.hasTag("ec.duel_active_tag")) {
      this.totemSaveDuel(player);
      return true;
    }

    // Castle totem save
    if (player.hasTag("ec.castle_active")) {
      this.totemSaveCastle(player);
      return true;
    }

    // Heist totem save
    if (player.hasTag("ec.heist_active")) {
      this.totemSaveHeist(player);
      return true;
    }

    // Dungeon — NO self-revive (player dies normally, tomb created)
    // Disclaimer is shown when entering dungeon

    return false;
  }

  /** Duel totem save — heal + visual + debuffs + teleport */
  totemSaveDuel(player) {
    try {
      // Heal to full
      player.addEffect("instant_health", 1, { amplifier: 5, showParticles: false });
      player.addEffect("resistance", 60, { amplifier: 4, showParticles: false });

      // Totem visual
      this.playTotemVisual(player);

      // Debuffs
      player.addEffect("darkness", 140, { amplifier: 0, showParticles: false }); // 7s
      player.addEffect("nausea", 140, { amplifier: 0, showParticles: false });   // 7s

      // Notify
      player.sendMessage("§c§lKnockout! §r§7You were saved by the duel totem.");
      player.onScreenDisplay.setTitle("§c§lKnocked Out!", {
        fadeInDuration: 5, stayDuration: 40, fadeOutDuration: 10,
      });

      // Teleport to spawn/bed after brief delay
      system.runTimeout(() => {
        try {
          player.runCommandAsync("tp @s @s"); // Reset position (bed spawn)
          player.removeTag("ec.duel_active_tag");
        } catch {}
      }, 40);

      this.eventBridge.emit("duel_knockout", { player });
    } catch {}
  }

  /** Castle totem save — heal + visual + -30 levels + remove from castle */
  totemSaveCastle(player) {
    try {
      player.addEffect("instant_health", 1, { amplifier: 5, showParticles: false });
      player.addEffect("resistance", 100, { amplifier: 4, showParticles: false });

      this.playTotemVisual(player);

      // Debuffs
      player.addEffect("darkness", 100, { amplifier: 0, showParticles: false });  // 5s
      player.addEffect("nausea", 100, { amplifier: 0, showParticles: false });    // 5s

      // XP penalty: -30 levels
      try {
        player.runCommandAsync("xp -30l @s");
      } catch {}

      player.sendMessage("§c§lDefeated! §r§7The castle claims 30 levels. You have been expelled.");
      player.removeTag("ec.castle_active");

      // Teleport to bed after delay
      system.runTimeout(() => {
        try { player.runCommandAsync("tp @s @s"); } catch {}
      }, 40);

      this.eventBridge.emit("castle_defeat", { player });
    } catch {}
  }

  /** Heist totem save — heal + visual + teleport home (no penalties) */
  totemSaveHeist(player) {
    try {
      player.addEffect("instant_health", 1, { amplifier: 5, showParticles: false });
      player.addEffect("resistance", 60, { amplifier: 4, showParticles: false });

      this.playTotemVisual(player);

      player.sendMessage("§e§lHeist Failed! §r§7You were caught and returned home.");
      player.removeTag("ec.heist_active");

      system.runTimeout(() => {
        try { player.runCommandAsync("tp @s @s"); } catch {}
      }, 20);

      this.eventBridge.emit("heist_failed", { player });
    } catch {}
  }

  /** Play totem-of-undying visual/sound */
  playTotemVisual(player) {
    try {
      const pos = player.location;
      player.dimension.runCommandAsync(
        `particle minecraft:totem_particle ${pos.x} ${pos.y + 1} ${pos.z}`
      );
      player.playSound("random.totem", { volume: 1.0, pitch: 1.0 });
    } catch {}
  }

  /** Standard death handling — creates tomb for item recovery */
  onPlayerDeath(player) {
    if (player.hasTag("dr.in_realm")) return;

    // Check totem save first
    if (this.checkTotemSave(player)) return;

    const location = player.location;
    const dimension = player.dimension;
    const inventory = player.getComponent("minecraft:inventory");
    if (!inventory?.container) return;

    const items = [];
    for (let i = 0; i < inventory.container.size; i++) {
      const item = inventory.container.getItem(i);
      if (item) items.push(JSON.stringify({ slot: i, typeId: item.typeId, amount: item.amount }));
    }

    const equip = player.getComponent("minecraft:equippable");
    const equipment = [];
    if (equip) {
      for (const slot of ["Head", "Chest", "Legs", "Feet", "Offhand"]) {
        const item = equip.getEquipment(slot);
        if (item) equipment.push(JSON.stringify({ slot, typeId: item.typeId, amount: item.amount }));
      }
    }

    system.run(() => {
      try {
        const tomb = dimension.spawnEntity("forevercraft:marker", location);
        tomb.nameTag = `§c${player.name}'s Tomb`;
        tomb.addTag("ec.tomb");
        tomb.addTag(`ec.tomb_owner_${player.name}`);
        const storage = StorageManager.forEntity(tomb);
        storage.set("owner", player.name);
        storage.set("items", items.join("|"));
        storage.set("equipment", equipment.join("|"));
        dimension.runCommandAsync(`particle minecraft:totem_particle ${location.x} ${location.y + 1} ${location.z}`);
      } catch (e) { console.error("[Tomb] Failed:", e); }
    });
  }

  showTombLocation(player) {
    const tombs = player.dimension.getEntities({ type: "forevercraft:marker", tags: [`ec.tomb_owner_${player.name}`] });
    if (tombs.length > 0) {
      const loc = tombs[0].location;
      player.onScreenDisplay.setTitle("§cYou Died", {
        subtitle: `§7Tomb at §e${Math.floor(loc.x)}, ${Math.floor(loc.y)}, ${Math.floor(loc.z)}`,
        fadeInDuration: 10, stayDuration: 70, fadeOutDuration: 20,
      });
    }
  }
}
