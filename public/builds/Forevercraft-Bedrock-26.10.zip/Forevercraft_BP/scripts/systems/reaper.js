/**
 * Reaper System — Dual-axis morality (Infamy vs Renown) with passive effects.
 * Replaces Java reaper/ folder (38 mcfunction files).
 *
 * Player kills → Infamy. Trades/helps → Renown. Both decay over time.
 * High infamy → Hunting Party spawns. High renown → Bandit protectors.
 * Tiers determine passive effects (glowing, particles, potion effects).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const DECAY_RATE = 12;     // Points per 60 seconds
const INFAMY_HUNT = 1000;  // Threshold for hunting party
const RENOWN_BANDIT = 1000; // Threshold for bandits

const DEED_VALUES = {
  player_kill: 150,
  villager_kill: 100,
  golem_kill: 50,
  trade: 10, // Daily cap: 100
};

export class ReaperSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.decayTimer = 0;

    eventBridge.on("player_killed_entity", (data) => {
      if (!data.player || !data.entity) return;
      const type = data.entity.typeId;
      if (type === "minecraft:player") this.addInfamy(data.player, DEED_VALUES.player_kill);
      else if (type === "minecraft:villager") this.addInfamy(data.player, DEED_VALUES.villager_kill);
      else if (type === "minecraft:iron_golem") this.addInfamy(data.player, DEED_VALUES.golem_kill);
    });

    eventBridge.on("villager_traded", (data) => {
      if (data.player) {
        const s = StorageManager.forPlayer(data.player);
        const dailyTrades = s.getNumber("rp_daily_trade", 0);
        if (dailyTrades < 100) {
          this.addRenown(data.player, DEED_VALUES.trade);
          s.set("rp_daily_trade", dailyTrades + DEED_VALUES.trade);
        }
      }
    });
  }

  addInfamy(player, amount) {
    const s = StorageManager.forPlayer(player);
    const infamy = Math.min(5000, s.getNumber("rp_infamy", 0) + amount);
    s.set("rp_infamy", infamy);
    if (amount >= 50) player.sendMessage(`§c+${amount} Infamy`);
  }

  addRenown(player, amount) {
    const s = StorageManager.forPlayer(player);
    const renown = Math.min(5000, s.getNumber("rp_renown", 0) + amount);
    s.set("rp_renown", renown);
    if (amount >= 50) player.sendMessage(`§a+${amount} Renown`);
  }

  /** Tick — decay + passive effects (called every 60 ticks / 3 seconds) */
  tick(players) {
    this.decayTimer++;

    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const infamy = s.getNumber("rp_infamy", 0);
      const renown = s.getNumber("rp_renown", 0);

      // Decay every ~60 seconds (20 tick calls at 3s each)
      if (this.decayTimer % 20 === 0) {
        if (infamy > 0) s.set("rp_infamy", Math.max(0, infamy - DECAY_RATE));
        if (renown > 0) s.set("rp_renown", Math.max(0, renown - DECAY_RATE));
      }

      // Passive effects based on alignment
      const alignment = renown - infamy;

      try {
        if (infamy >= INFAMY_HUNT) {
          // Dark aura — hostile mobs target player more
          player.addEffect("glowing", 80, { amplifier: 0, showParticles: false });
        }

        if (renown >= RENOWN_BANDIT) {
          // Light aura — luck bonus
          player.addEffect("luck", 80, { amplifier: 0, showParticles: false });
        }

        // Tier effects
        if (Math.abs(alignment) >= 2000) {
          if (alignment > 0) {
            player.addEffect("regeneration", 80, { amplifier: 0, showParticles: false });
          } else {
            player.addEffect("strength", 80, { amplifier: 0, showParticles: false });
          }
        }
      } catch {}

      // Spawn hunting party/bandits (rare, every ~5 minutes)
      if (this.decayTimer % 100 === 0 && Math.random() < 0.05) {
        if (infamy >= INFAMY_HUNT) this.spawnHuntingParty(player);
        if (renown >= RENOWN_BANDIT) this.spawnBandits(player);
      }
    }
  }

  spawnHuntingParty(player) {
    try {
      const loc = player.location;
      for (let i = 0; i < 3; i++) {
        const mob = player.dimension.spawnEntity("minecraft:vindicator", {
          x: loc.x + (Math.random() - 0.5) * 10,
          y: loc.y,
          z: loc.z + (Math.random() - 0.5) * 10,
        });
        mob.addTag("ec.hunting_party");
        mob.nameTag = "§c§lHunter";
        system.runTimeout(() => { try { mob.kill(); } catch {} }, 1200); // 1 min despawn
      }
      player.sendMessage("§c§l⚠ A hunting party has found you!");
      player.playSound("mob.vindicator.celebrate", { volume: 1.0, pitch: 0.8 });
    } catch {}
  }

  spawnBandits(player) {
    try {
      const loc = player.location;
      for (let i = 0; i < 2; i++) {
        const mob = player.dimension.spawnEntity("minecraft:iron_golem", {
          x: loc.x + (Math.random() - 0.5) * 8,
          y: loc.y,
          z: loc.z + (Math.random() - 0.5) * 8,
        });
        mob.addTag("ec.bandit_protector");
        mob.nameTag = "§a§lProtector";
        system.runTimeout(() => { try { mob.kill(); } catch {} }, 1200);
      }
      player.sendMessage("§a§l✦ Protectors have arrived to aid you!");
      player.playSound("mob.iron_golem.repair", { volume: 1.0, pitch: 1.0 });
    } catch {}
  }

  getDisplay(player) {
    const s = StorageManager.forPlayer(player);
    const infamy = s.getNumber("rp_infamy", 0);
    const renown = s.getNumber("rp_renown", 0);
    const alignment = renown - infamy;

    let title;
    if (alignment >= 2000) title = "§a§lParagon";
    else if (alignment >= 500) title = "§aHero";
    else if (alignment <= -2000) title = "§c§lVillain";
    else if (alignment <= -500) title = "§cOutlaw";
    else title = "§7Neutral";

    return { title, infamy, renown };
  }

  /** Reset daily trade counter at dawn */
  dailyReset() {
    for (const player of world.getAllPlayers()) {
      const s = StorageManager.forPlayer(player);
      s.setNumber("rp_daily_trade", 0);
    }
  }
}
