/**
 * Seasons System (compiled JS)
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const SEASON_NAMES = { spring: "§aSpring", summer: "§eSummer", autumn: "§6Autumn", winter: "§bWinter" };
const DAYS_PER_YEAR = 365;

export class SeasonSystem {
  constructor(daylightManager) {
    this.storage = StorageManager.world();
    this.currentSeason = this.storage.getString("current_season", "spring");
    this.daylightManager = daylightManager;

    // Feed initial season to daylight manager for rate switching
    if (daylightManager) {
      daylightManager.setSeason(this.currentSeason);
    }
  }

  getSeason(day) {
    const d = day % DAYS_PER_YEAR;
    if (d < 91) return "spring";
    if (d < 182) return "summer";
    if (d < 273) return "autumn";
    return "winter";
  }

  onDayChange(day) {
    const newSeason = this.getSeason(day);
    if (newSeason !== this.currentSeason) {
      this.currentSeason = newSeason;
      this.storage.set("current_season", newSeason);

      // Update daylight manager seasonal time rates
      if (this.daylightManager) {
        this.daylightManager.setSeason(newSeason);
      }

      for (const player of world.getAllPlayers()) {
        try {
          player.onScreenDisplay.setTitle(`${SEASON_NAMES[newSeason]}§r §7has arrived`, {
            subtitle: "§7The world transforms around you...",
            fadeInDuration: 20, stayDuration: 100, fadeOutDuration: 20,
          });
        } catch {}
      }
    }
  }

  getCurrentSeason() { return this.currentSeason; }
  getSeasonName() { return SEASON_NAMES[this.currentSeason]; }
}
