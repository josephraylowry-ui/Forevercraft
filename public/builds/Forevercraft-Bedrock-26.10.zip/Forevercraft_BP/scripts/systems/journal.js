/**
 * Journal System — Exploration discovery tracking with region bonuses.
 * Replaces Java journal/ folder.
 *
 * Tracks: 25 biomes, 18 structures, villages, 5 secrets, 4 region completions.
 * Region bonuses: +10% Speed (OW Surface), DR +1.0 per region (up to +5.0).
 * Village milestones: 5 → 10 → 20 (Master Cartographer)
 * Forever Coins reward: +5 per region completion
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// ─── BIOME DEFINITIONS ─────────────────────────────────────
const BIOMES = [
  // Overworld Surface (0-15)
  { id: 0, name: "Plains", region: "ow_surface" },
  { id: 1, name: "Forest", region: "ow_surface" },
  { id: 2, name: "Flower Forest", region: "ow_surface" },
  { id: 3, name: "Dark Forest", region: "ow_surface" },
  { id: 4, name: "Taiga", region: "ow_surface" },
  { id: 5, name: "Mountains", region: "ow_surface" },
  { id: 6, name: "Jungle", region: "ow_surface" },
  { id: 7, name: "Desert", region: "ow_surface" },
  { id: 8, name: "Savanna", region: "ow_surface" },
  { id: 9, name: "Ocean", region: "ow_surface" },
  { id: 10, name: "River", region: "ow_surface" },
  { id: 11, name: "Swamp", region: "ow_surface" },
  { id: 12, name: "Mushroom Island", region: "ow_surface" },
  { id: 13, name: "Ice Plains", region: "ow_surface" },
  { id: 14, name: "Badlands", region: "ow_surface" },
  { id: 15, name: "Pale Garden", region: "ow_surface" },
  // Caves (16-18)
  { id: 16, name: "Lush Caves", region: "ow_caves" },
  { id: 17, name: "Dripstone Caves", region: "ow_caves" },
  { id: 18, name: "Deep Dark", region: "ow_caves" },
  // Nether (19-23)
  { id: 19, name: "Nether Wastes", region: "nether" },
  { id: 20, name: "Crimson Forest", region: "nether" },
  { id: 21, name: "Warped Forest", region: "nether" },
  { id: 22, name: "Basalt Deltas", region: "nether" },
  { id: 23, name: "Soul Sand Valley", region: "nether" },
  // End (24)
  { id: 24, name: "The End", region: "end" },
];

// Bedrock biome ID → journal biome index
const BEDROCK_BIOME_MAP = {
  "minecraft:plains": 0, "minecraft:sunflower_plains": 0, "minecraft:meadow": 0,
  "minecraft:forest": 1, "minecraft:birch_forest": 1,
  "minecraft:flower_forest": 2,
  "minecraft:dark_forest": 3,
  "minecraft:taiga": 4, "minecraft:old_growth_spruce_taiga": 4, "minecraft:old_growth_pine_taiga": 4,
  "minecraft:windswept_hills": 5, "minecraft:stony_peaks": 5, "minecraft:jagged_peaks": 5,
  "minecraft:frozen_peaks": 5, "minecraft:snowy_slopes": 5,
  "minecraft:jungle": 6, "minecraft:bamboo_jungle": 6, "minecraft:sparse_jungle": 6,
  "minecraft:desert": 7,
  "minecraft:savanna": 8, "minecraft:savanna_plateau": 8,
  "minecraft:ocean": 9, "minecraft:deep_ocean": 9, "minecraft:warm_ocean": 9,
  "minecraft:lukewarm_ocean": 9, "minecraft:cold_ocean": 9, "minecraft:frozen_ocean": 9,
  "minecraft:river": 10, "minecraft:frozen_river": 10,
  "minecraft:swamp": 11, "minecraft:mangrove_swamp": 11,
  "minecraft:mushroom_fields": 12,
  "minecraft:snowy_plains": 13, "minecraft:ice_spikes": 13, "minecraft:snowy_taiga": 13,
  "minecraft:badlands": 14, "minecraft:eroded_badlands": 14, "minecraft:wooded_badlands": 14,
  "minecraft:pale_garden": 15,
  "minecraft:lush_caves": 16,
  "minecraft:dripstone_caves": 17,
  "minecraft:deep_dark": 18,
  "minecraft:nether_wastes": 19, "minecraft:hell": 19,
  "minecraft:crimson_forest": 20,
  "minecraft:warped_forest": 21,
  "minecraft:basalt_deltas": 22,
  "minecraft:soul_sand_valley": 23,
  "minecraft:the_end": 24,
};

// ─── SECRETS ────────────────────────────────────────────────
const SECRETS = [
  { id: 0, name: "Depths of the World", desc: "Reach Y < -48" },
  { id: 1, name: "Sky Wanderer", desc: "Reach Y > 300" },
  { id: 2, name: "Dimensional Traveler", desc: "Visit all 3 dimensions" },
  { id: 3, name: "Lore Collector", desc: "Collect all 6 anecdotes" },
  { id: 4, name: "World Explorer", desc: "Discover 15+ unique structures" },
];

// ─── REGIONS & BONUSES ──────────────────────────────────────
const REGIONS = {
  ow_surface: { name: "Overworld Surface", biomeCount: 16, desc: "+10% Speed, +1.0 DR" },
  ow_caves:   { name: "Overworld Caves",   biomeCount: 3,  desc: "+1.0 DR" },
  nether:     { name: "The Nether",         biomeCount: 5,  desc: "+1.0 DR" },
  end:        { name: "The End",            biomeCount: 1,  desc: "+2.0 DR" },
};

// 18 structures organized by tier
const STRUCTURES = [
  { id: 1, name: "Ancient City", tier: "Ornate" },
  { id: 2, name: "End City", tier: "Ornate" },
  { id: 3, name: "Bastion Remnant", tier: "Ornate" },
  { id: 4, name: "Trial Chambers", tier: "Rare" },
  { id: 5, name: "Stronghold", tier: "Rare" },
  { id: 6, name: "Woodland Mansion", tier: "Rare" },
  { id: 7, name: "Nether Fortress", tier: "Rare" },
  { id: 8, name: "Ocean Monument", tier: "Rare" },
  { id: 9, name: "Desert Pyramid", tier: "Uncommon" },
  { id: 10, name: "Jungle Pyramid", tier: "Uncommon" },
  { id: 11, name: "Mineshaft", tier: "Uncommon" },
  { id: 12, name: "Shipwreck", tier: "Common" },
  { id: 13, name: "Ocean Ruin", tier: "Common" },
  { id: 14, name: "Igloo", tier: "Common" },
  { id: 15, name: "Pillager Outpost", tier: "Common" },
  { id: 16, name: "Trail Ruins", tier: "Common" },
  { id: 17, name: "Village", tier: "Common" },
  { id: 18, name: "Ruined Portal", tier: "Common" },
];

// Village milestone thresholds
const VILLAGE_MILESTONES = [
  { count: 5, title: "Village Finder", reward: "§e+3 Forever Coins" },
  { count: 10, title: "Seasoned Traveler", reward: "§e+5 Forever Coins" },
  { count: 20, title: "Master Cartographer", reward: "§6+10 Forever Coins" },
];

export class JournalSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Dimension visit tracking via events
    eventBridge.on("player_dimension_change", (player, newDim) => {
      this.onDimensionChange(player, newDim);
    });

    // Anecdote collection tracking (for Secret 3)
    eventBridge.on("anecdote_found", (data) => {
      if (data.player) {
        const s = StorageManager.forPlayer(data.player);
        s.set(`jn_anec_${data.anecdoteId}`, 1);
      }
    });

    // Village entry tracking
    eventBridge.on("village_entered", (data) => {
      if (data.player) {
        this.discoverVillage(data.player, data.villageId);
      }
    });
  }

  // ─── BIOME DETECTION (called every 10 seconds) ────────────

  tick(players) {
    for (const player of players) {
      this.detectBiome(player);
      this.checkSecrets(player);
    }
  }

  detectBiome(player) {
    try {
      const block = player.dimension.getBlock(player.location);
      if (!block) return;
      // Bedrock 1.21+ exposes biome via block
      // Fallback: dimension-based detection
      const dimId = player.dimension.id;
      let biomeIndex = -1;

      // Use dimension as coarse biome detector
      if (dimId === "minecraft:the_nether") {
        // Check Y level / block types for nether biome hints
        biomeIndex = 19; // Default nether wastes
        const below = player.dimension.getBlock({
          x: Math.floor(player.location.x),
          y: Math.floor(player.location.y) - 1,
          z: Math.floor(player.location.z),
        });
        if (below) {
          const bt = below.typeId;
          if (bt === "minecraft:crimson_nylium") biomeIndex = 20;
          else if (bt === "minecraft:warped_nylium") biomeIndex = 21;
          else if (bt === "minecraft:basalt" || bt === "minecraft:blackstone") biomeIndex = 22;
          else if (bt === "minecraft:soul_sand" || bt === "minecraft:soul_soil") biomeIndex = 23;
        }
      } else if (dimId === "minecraft:the_end") {
        biomeIndex = 24;
      } else {
        // Overworld: use block below for biome hints
        const below = player.dimension.getBlock({
          x: Math.floor(player.location.x),
          y: Math.floor(player.location.y) - 1,
          z: Math.floor(player.location.z),
        });
        if (below) {
          const bt = below.typeId;
          if (player.location.y < -20) {
            // Deep underground
            if (bt === "minecraft:moss_block" || bt === "minecraft:clay") biomeIndex = 16; // Lush caves
            else if (bt === "minecraft:dripstone_block" || bt === "minecraft:pointed_dripstone") biomeIndex = 17;
            else if (bt === "minecraft:sculk" || bt === "minecraft:sculk_catalyst") biomeIndex = 18; // Deep dark
          } else {
            // Surface biome hints from ground blocks
            if (bt === "minecraft:sand" || bt === "minecraft:sandstone") biomeIndex = 7; // Desert
            else if (bt === "minecraft:red_sand" || bt === "minecraft:terracotta") biomeIndex = 14; // Badlands
            else if (bt === "minecraft:mycelium") biomeIndex = 12; // Mushroom
            else if (bt === "minecraft:snow_block" || bt === "minecraft:ice" || bt === "minecraft:packed_ice") biomeIndex = 13;
            else if (bt === "minecraft:jungle_log" || bt === "minecraft:bamboo") biomeIndex = 6; // Jungle
            else if (bt === "minecraft:podzol") biomeIndex = 4; // Taiga
            else if (bt === "minecraft:coarse_dirt" || bt === "minecraft:rooted_dirt") biomeIndex = 3; // Dark forest
            else if (bt === "minecraft:pale_moss_block") biomeIndex = 15; // Pale garden
            else if (bt === "minecraft:grass_block" || bt === "minecraft:dirt") biomeIndex = 0; // Plains default
          }
          // Water detection
          if (biomeIndex === -1) {
            const at = player.dimension.getBlock(player.location);
            if (at?.typeId === "minecraft:water") {
              biomeIndex = player.location.y < 50 ? 9 : 10; // Ocean vs River
            }
          }
        }
      }

      if (biomeIndex >= 0 && biomeIndex < BIOMES.length) {
        this.discoverBiome(player, biomeIndex);
      }
    } catch {}
  }

  discoverBiome(player, biomeIndex) {
    const s = StorageManager.forPlayer(player);
    const key = `jn_biome_${biomeIndex}`;
    if (s.getNumber(key)) return; // Already discovered

    s.set(key, 1);
    const biome = BIOMES[biomeIndex];
    const count = this.countDiscoveredBiomes(s);
    s.set("jn_biome_count", count);

    player.sendMessage(`§a§l✦ Biome Discovered: §r§e${biome.name} §7(${count}/25)`);
    player.playSound("random.orb");

    // Check region completion
    this.checkRegionCompletion(player, s, biome.region);

    // Pet memory: New Horizons (biome change while pet active)
    if (s.getString("active_pet")) {
      // Memory bit 4 = New Horizons
      const petId = s.getString("active_pet");
      const memKey = "pet_mem_" + petId;
      const mem = s.getNumber(memKey, 0);
      if (!(mem & (1 << 4))) {
        s.set(memKey, mem | (1 << 4));
        player.sendMessage("§d§l✦ New Memory: §r§5New Horizons");
      }
    }
  }

  countDiscoveredBiomes(s) {
    let count = 0;
    for (let i = 0; i < 25; i++) {
      if (s.getNumber(`jn_biome_${i}`)) count++;
    }
    return count;
  }

  // ─── REGION COMPLETION ─────────────────────────────────────

  checkRegionCompletion(player, s, regionKey) {
    const regionDoneKey = `jn_region_${regionKey}`;
    if (s.getNumber(regionDoneKey)) return;

    const region = REGIONS[regionKey];
    const biomesInRegion = BIOMES.filter(b => b.region === regionKey);
    let discovered = 0;
    for (const b of biomesInRegion) {
      if (s.getNumber(`jn_biome_${b.id}`)) discovered++;
    }

    // Nether region also requires 2+ nether structures (Fortress, Bastion)
    if (regionKey === "nether") {
      let netherStructs = 0;
      if (s.getNumber("jn_struct_3")) netherStructs++; // Bastion
      if (s.getNumber("jn_struct_7")) netherStructs++; // Nether Fortress
      if (netherStructs < 2) return;
    }

    // End region also requires End City
    if (regionKey === "end") {
      if (!s.getNumber("jn_struct_2")) return; // End City
    }

    if (discovered >= region.biomeCount) {
      s.set(regionDoneKey, 1);
      player.sendMessage(`\n§6§l✦ Region Complete: §r§e${region.name}!`);
      player.sendMessage(`§7Bonus: ${region.desc}`);
      player.playSound("entity.player.levelup");

      // Apply DR bonus
      const drBonus = regionKey === "end" ? 2.0 : 1.0;
      const dr = s.getNumber("dream_rate", 0) + drBonus;
      s.set("dream_rate", dr);

      // Speed bonus for OW Surface
      if (regionKey === "ow_surface") {
        try { player.runCommandAsync("effect @s speed 999999 0 true"); } catch {}
      }

      // Forever Coins reward (+5 per region)
      this.eventBridge.emit("grant_coins", { player, amount: 5, reason: `Region: ${region.name}` });

      // Guild contribution if in guild
      this.eventBridge.emit("guild_contribution", { player, amount: 25, reason: "Region completion" });

      // Spirit progression
      const spBiomes = s.getNumber("sp_biomes", 0) + 1;
      s.set("sp_biomes", spBiomes);
    }
  }

  // ─── VILLAGE DISCOVERY ───────────────────────────────────

  discoverVillage(player, villageId) {
    const s = StorageManager.forPlayer(player);
    const key = `jn_village_${villageId}`;
    if (s.getNumber(key)) return; // Already discovered

    s.set(key, 1);
    const count = s.getNumber("jn_village_count", 0) + 1;
    s.set("jn_village_count", count);

    player.sendMessage(`§a§l✦ Village Discovered! §r§7(${count} total)`);
    player.playSound("random.orb", { volume: 0.7, pitch: 1.0 });

    // Check milestones
    for (const milestone of VILLAGE_MILESTONES) {
      if (count === milestone.count) {
        player.sendMessage(`\n§e§l✦ ${milestone.title}! ✦§r`);
        player.sendMessage(`§7Reward: ${milestone.reward}`);
        player.playSound("random.levelup", { volume: 0.8, pitch: 1.1 });

        // Grant coins based on milestone
        const coins = milestone.count === 20 ? 10 : milestone.count === 10 ? 5 : 3;
        this.eventBridge.emit("grant_coins", { player, amount: coins, reason: milestone.title });
      }
    }
  }

  // ─── SECRETS ──────────────────────────────────────────────

  checkSecrets(player) {
    const s = StorageManager.forPlayer(player);

    // Secret 0: Y < -48
    if (!s.getNumber("jn_secret_0") && player.location.y < -48) {
      this.discoverSecret(player, s, 0);
    }

    // Secret 1: Y > 300
    if (!s.getNumber("jn_secret_1") && player.location.y > 300) {
      this.discoverSecret(player, s, 1);
    }

    // Secret 2: Dimensional Traveler (all 3 dims)
    if (!s.getNumber("jn_secret_2")) {
      const ow = s.getNumber("jn_dim_ow");
      const neth = s.getNumber("jn_dim_neth");
      const end = s.getNumber("jn_dim_end");
      if (ow && neth && end) {
        this.discoverSecret(player, s, 2);
      }
    }

    // Secret 3: Lore Collector (all 6 anecdotes)
    if (!s.getNumber("jn_secret_3")) {
      const ANECDOTES = ["elder", "fisher", "miner", "wanderer", "scholar", "beast"];
      const allFound = ANECDOTES.every(a => s.getNumber(`jn_anec_${a}`));
      if (allFound) {
        this.discoverSecret(player, s, 3);
      }
    }

    // Secret 4: 15+ structures
    if (!s.getNumber("jn_secret_4") && s.getNumber("jn_struct_count", 0) >= 15) {
      this.discoverSecret(player, s, 4);
    }
  }

  discoverSecret(player, s, secretIndex) {
    s.set(`jn_secret_${secretIndex}`, 1);
    const count = this.countSecrets(s);
    s.set("jn_secret_count", count);
    const secret = SECRETS[secretIndex];
    player.sendMessage(`§5§l✦ Secret Found: §r§d${secret.name} §7(${count}/5)`);
    player.sendMessage(`§8${secret.desc}`);
    player.playSound("random.levelup");
  }

  countSecrets(s) {
    let count = 0;
    for (let i = 0; i < 5; i++) {
      if (s.getNumber(`jn_secret_${i}`)) count++;
    }
    return count;
  }

  // ─── DIMENSION TRACKING ───────────────────────────────────

  onDimensionChange(player, newDim) {
    const s = StorageManager.forPlayer(player);
    if (newDim === "minecraft:overworld") s.set("jn_dim_ow", 1);
    else if (newDim === "minecraft:the_nether") s.set("jn_dim_neth", 1);
    else if (newDim === "minecraft:the_end") s.set("jn_dim_end", 1);
  }

  // ─── STRUCTURE DISCOVERY (called externally) ───────────────

  discoverStructure(player, structureId, structureName) {
    const s = StorageManager.forPlayer(player);
    const key = `jn_struct_${structureId}`;
    if (s.getNumber(key)) return;

    s.set(key, 1);
    const count = s.getNumber("jn_struct_count", 0) + 1;
    s.set("jn_struct_count", count);
    player.sendMessage(`§a§l✦ Structure Discovered: §r§e${structureName} §7(${count})`);
    player.playSound("random.orb");
  }

  // ─── JOURNAL GUI ──────────────────────────────────────────

  async openJournal(player) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    const s = StorageManager.forPlayer(player);

    const biomeCount = s.getNumber("jn_biome_count", 0);
    const structCount = s.getNumber("jn_struct_count", 0);
    const secretCount = s.getNumber("jn_secret_count", 0);

    const regionsDone = [
      s.getNumber("jn_region_ow_surface") ? "§a✓" : "§c✗",
      s.getNumber("jn_region_ow_caves") ? "§a✓" : "§c✗",
      s.getNumber("jn_region_nether") ? "§a✓" : "§c✗",
      s.getNumber("jn_region_end") ? "§a✓" : "§c✗",
    ];

    const villageCount = s.getNumber("jn_village_count", 0);

    const body = [
      `§eBiomes: §f${biomeCount}/25`,
      `§eStructures: §f${structCount}/18`,
      `§eVillages: §f${villageCount}`,
      `§eSecrets: §f${secretCount}/5`,
      ``,
      `§6Regions:`,
      `${regionsDone[0]} §7Overworld Surface`,
      `${regionsDone[1]} §7Overworld Caves`,
      `${regionsDone[2]} §7The Nether`,
      `${regionsDone[3]} §7The End`,
    ].join("\n");

    const form = new ActionFormData()
      .title("§l§eExploration Journal")
      .body(body)
      .button("§eBiome List")
      .button("§eStructures")
      .button("§aVillages")
      .button("§5Secrets")
      .button("§6Region Bonuses")
      .button("§dDream Journal")
      .button("§7Close");

    const res = await form.show(player);
    if (res.canceled) return;

    switch (res.selection) {
      case 0: await this.showBiomeList(player, s); break;
      case 1: await this.showStructureList(player, s); break;
      case 2: await this.showVillages(player, s); break;
      case 3: await this.showSecrets(player, s); break;
      case 4: await this.showBonuses(player, s); break;
      case 5: await this.showDreamJournal(player, s); break;
    }
  }

  async showBiomeList(player, s) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    let body = "";
    for (const biome of BIOMES) {
      const discovered = s.getNumber(`jn_biome_${biome.id}`);
      body += discovered ? `§a✓ ${biome.name}\n` : `§8✗ ???\n`;
    }
    const form = new ActionFormData().title("§eBiome Discoveries").body(body).button("Close");
    await form.show(player);
  }

  async showStructureList(player, s) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    let body = "";
    const tiers = ["Ornate", "Rare", "Uncommon", "Common"];
    const tierColors = { Ornate: "§5", Rare: "§b", Uncommon: "§9", Common: "§f" };
    for (const tier of tiers) {
      body += `\n${tierColors[tier]}§l${tier}§r\n`;
      for (const structure of STRUCTURES.filter(st => st.tier === tier)) {
        const found = s.getNumber(`jn_struct_${structure.id}`);
        body += found ? `  §a✓ ${structure.name}\n` : `  §8✗ ???\n`;
      }
    }
    const form = new ActionFormData().title("§eStructures").body(body).button("Close");
    await form.show(player);
  }

  async showVillages(player, s) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    const count = s.getNumber("jn_village_count", 0);
    let body = `§eVillages Discovered: §f${count}\n\n`;

    body += "§6Milestones:\n";
    for (const m of VILLAGE_MILESTONES) {
      const achieved = count >= m.count;
      body += achieved
        ? `  §a✓ ${m.title} §7(${m.count} villages) — ${m.reward}\n`
        : `  §8✗ ${m.title} §7(${m.count} villages)\n`;
    }

    if (count >= 20) {
      body += "\n§6§lMaster Cartographer §r§7— You've mapped the world!";
    }

    const form = new ActionFormData().title("§aVillages").body(body).button("Close");
    await form.show(player);
  }

  async showSecrets(player, s) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    let body = "";
    for (const secret of SECRETS) {
      const found = s.getNumber(`jn_secret_${secret.id}`);
      body += found ? `§a✓ ${secret.name}\n§7  ${secret.desc}\n` : `§8✗ ???\n`;
    }
    const form = new ActionFormData().title("Secrets").body(body).button("Close");
    await form.show(player);
  }

  async showBonuses(player, s) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    let body = "";
    for (const [key, region] of Object.entries(REGIONS)) {
      const done = s.getNumber(`jn_region_${key}`);
      body += done
        ? `§a✓ ${region.name}\n§7  ${region.desc}\n\n`
        : `§c✗ ${region.name}\n§8  ${region.desc}\n\n`;
    }
    const form = new ActionFormData().title("Region Bonuses").body(body).button("Close");
    await form.show(player);
  }

  // ─── DREAM JOURNAL ──────────────────────────────────────────

  /** Record a dream journal entry (called when significant DR events happen) */
  addDreamEntry(player, text) {
    const s = StorageManager.forPlayer(player);
    const count = s.getNumber("dj_count", 0);
    const day = world.getDay();
    // Store up to 20 entries
    if (count < 20) {
      s.set(`dj_${count}_day`, day);
      s.set(`dj_${count}_text`, text);
      s.set("dj_count", count + 1);
    }
  }

  async showDreamJournal(player, s) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    const count = s.getNumber("dj_count", 0);
    const dr = s.getNumber("dream_rate", 0);

    let body = `§d§lDream Journal\n\n`;
    body += `§7Current Dream Rate: §d${dr}\n`;
    body += `§7Entries: §f${count}\n\n`;

    if (count === 0) {
      body += "§8Your dream journal is empty...\n";
      body += "§8Progress through the world to fill it.\n";
    } else {
      for (let i = count - 1; i >= Math.max(0, count - 10); i--) {
        const day = s.getNumber(`dj_${i}_day`, 0);
        const text = s.getString(`dj_${i}_text`, "");
        body += `§7Day ${day}: §f${text}\n`;
      }
    }

    const form = new ActionFormData().title("§dDream Journal").body(body).button("Close");
    await form.show(player);
  }
}
