/**
 * Claimable Rewards Engine — Universal reward claim tracking across all progression systems.
 * Replaces Java claim/ folder (~25 files).
 *
 * Tracks unclaimed rewards across:
 * - Bestiary stage rewards (63 mobs × 7 stages)
 * - Class affinity stage rewards (14 classes × 7 stages)
 * - Personal milestone stage rewards (100 milestones)
 * - CraftForever milestone stage rewards (12 milestones)
 * - Completed lore set rewards (25 sets)
 * - Biome mastery stage rewards
 * - Realm milestones (34 milestones)
 *
 * Notification: checks every 60s, plays sound + message when new rewards available.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const NOTIFY_INTERVAL = 1200; // 60 seconds

// Coin reward tiers for different claim types
const AFFINITY_COINS = [5, 10, 15, 25, 35, 50, 75]; // per stage 1-7
const BESTIARY_COINS = [3, 5, 8, 12, 18, 25, 40]; // per stage 1-7
const PERSONAL_COINS = [10, 15, 20, 25, 30, 40, 50]; // per stage 1-7
const LORE_COINS = { common: 5, uncommon: 10, rare: 15 };

// Crate tier per stage (for claim crate rewards)
const STAGE_TIERS = ["common", "uncommon", "rare", "ornate", "exquisite", "mythical", "mythical"];

// 34 realm milestones organized by category
const REALM_MILESTONES = {
  origins:   { ids: [1, 3, 5, 6, 7, 8, 9, 10, 11, 12], tiers: ["rare","common","ornate","exquisite","mythical","rare","uncommon","ornate","exquisite","mythical"] },
  social:    { ids: [13, 14, 15, 16, 17], tiers: ["ornate","exquisite","mythical","ornate","exquisite"] },
  guild:     { ids: [18, 19, 20, 21, 22], tiers: ["rare","exquisite","ornate","mythical","exquisite"] },
  adventure: { ids: [23, 24, 25, 26], tiers: ["exquisite","ornate","exquisite","ornate"] },
  combat:    { ids: [27, 28, 29, 30], tiers: ["exquisite","mythical","ornate","exquisite"] },
  mastery:   { ids: [31, 32, 33, 34], tiers: ["mythical","ornate","exquisite","mythical"] }, // 34 = 3x mythical
};

// Coins per crate tier
const TIER_COINS = { common: 3, uncommon: 5, rare: 8, ornate: 12, exquisite: 18, mythical: 30 };

export class ClaimRewardSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.notifyCounter = 0;

    // Listen for progression events that might unlock new claims
    eventBridge.on("bestiary_stage_up", () => this.markDirty());
    eventBridge.on("affinity_stage_up", () => this.markDirty());
    eventBridge.on("milestone_completed", () => this.markDirty());
    eventBridge.on("lore_set_completed", () => this.markDirty());
    eventBridge.on("biome_mastery_up", () => this.markDirty());

    this.dirty = true;
  }

  markDirty() {
    this.dirty = true;
  }

  /** Count unclaimed rewards for a player across all categories */
  countUnclaimed(player) {
    const s = StorageManager.forPlayer(player);
    let total = 0;

    // Bestiary unclaimed
    const bstUnclaimed = s.getNumber("claim_bst_unclaimed", 0);
    // Affinity unclaimed
    const affUnclaimed = s.getNumber("claim_aff_unclaimed", 0);
    // Personal milestones unclaimed
    const prsUnclaimed = s.getNumber("claim_prs_unclaimed", 0);
    // CraftForever unclaimed
    const cftUnclaimed = s.getNumber("claim_cft_unclaimed", 0);
    // Lore unclaimed
    const loreUnclaimed = s.getNumber("claim_lore_unclaimed", 0);
    // Biome unclaimed
    const biomeUnclaimed = s.getNumber("claim_biome_unclaimed", 0);
    // Realm milestones unclaimed
    const rmUnclaimed = s.getNumber("claim_rm_unclaimed", 0);

    total = bstUnclaimed + affUnclaimed + prsUnclaimed + cftUnclaimed +
            loreUnclaimed + biomeUnclaimed + rmUnclaimed;

    return {
      total,
      bestiary: bstUnclaimed,
      affinity: affUnclaimed,
      personal: prsUnclaimed,
      craftforever: cftUnclaimed,
      lore: loreUnclaimed,
      biome: biomeUnclaimed,
      realm: rmUnclaimed,
    };
  }

  /** Claim a single reward (called from GUI) */
  claimReward(player, category, id, coins = 0) {
    const s = StorageManager.forPlayer(player);
    const claimKey = `claimed_${category}_${id}`;

    if (s.get(claimKey)) return false; // Already claimed

    s.set(claimKey, true);

    // Award coins
    if (coins > 0) {
      const currentCoins = s.getNumber("forever_coins", 0);
      s.set("forever_coins", currentCoins + coins);
      player.sendMessage(`§e+${coins} Forever Coins!`);
    }

    // Decrement unclaimed counter
    const unclaimedKey = `claim_${category}_unclaimed`;
    const current = s.getNumber(unclaimedKey, 0);
    if (current > 0) {
      s.set(unclaimedKey, current - 1);
    }

    player.playSound("random.orb", { volume: 0.5, pitch: 1.2 });
    this.eventBridge.emit("reward_claimed", { player, category, id, coins });

    return true;
  }

  /** Bulk claim all rewards in a category */
  bulkClaim(player, category) {
    const s = StorageManager.forPlayer(player);
    const unclaimedKey = `claim_${category}_unclaimed`;
    const unclaimed = s.getNumber(unclaimedKey, 0);

    if (unclaimed <= 0) {
      player.sendMessage("§7No unclaimed rewards in this category.");
      return 0;
    }

    // Mark all as claimed and award coins
    let totalCoins = 0;
    // For simplicity, award a flat rate per claim
    const coinsPerClaim = category === "aff" ? 25 : category === "bst" ? 10 : 15;
    totalCoins = unclaimed * coinsPerClaim;

    const currentCoins = s.getNumber("forever_coins", 0);
    s.set("forever_coins", currentCoins + totalCoins);
    s.set(unclaimedKey, 0);

    player.sendMessage(`§a§lClaimed ${unclaimed} rewards! §r§e+${totalCoins} Forever Coins`);
    player.playSound("random.levelup", { volume: 0.5, pitch: 1.0 });

    this.eventBridge.emit("bulk_claimed", { player, category, count: unclaimed, coins: totalCoins });

    return unclaimed;
  }

  /** Claim all rewards across ALL categories at once */
  claimAll(player) {
    const counts = this.countUnclaimed(player);
    if (counts.total === 0) {
      player.sendMessage("§7No unclaimed rewards.");
      return;
    }

    let totalClaimed = 0;
    let totalCoins = 0;
    const categories = ["bst", "aff", "prs", "cft", "lore", "biome", "rm"];
    for (const cat of categories) {
      const claimed = this.bulkClaim(player, cat, true); // silent mode
      if (claimed > 0) {
        totalClaimed += claimed.count;
        totalCoins += claimed.coins;
      }
    }

    if (totalClaimed > 0) {
      player.sendMessage(`\n§a§l✦ Claimed ${totalClaimed} rewards! ✦§r`);
      player.sendMessage(`§e+${totalCoins} Forever Coins`);
      player.playSound("random.levelup", { volume: 0.7, pitch: 1.0 });
    }
  }

  /** Increment unclaimed count when player earns a new claimable reward */
  addUnclaimed(player, category, amount = 1) {
    const s = StorageManager.forPlayer(player);
    const key = `claim_${category}_unclaimed`;
    const current = s.getNumber(key, 0);
    s.set(key, current + amount);
  }

  /** Notification tick — checks for new unclaimed and notifies */
  tick() {
    this.notifyCounter++;
    if (this.notifyCounter < NOTIFY_INTERVAL) return;
    this.notifyCounter = 0;

    const players = world.getAllPlayers();
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const counts = this.countUnclaimed(player);
      const prevTotal = s.getNumber("claim_prev_total", 0);

      if (counts.total > 0 && counts.total > prevTotal) {
        player.sendMessage(`§e⭐ You have §l${counts.total}§r§e unclaimed rewards! Open your Codex to claim them.`);
        player.playSound("random.orb", { volume: 0.5, pitch: 1.2 });
      }

      s.set("claim_prev_total", counts.total);
    }
  }
}
