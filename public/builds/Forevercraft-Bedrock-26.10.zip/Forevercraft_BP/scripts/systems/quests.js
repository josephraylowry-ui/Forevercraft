/**
 * Quest System — 75+ quests across 6 tiers + heroic + bounty hunt.
 * Replaces Java quests/ folder (quest board, tracking, completion, cancel).
 *
 * Features:
 * - 6 quest tiers: Errand, Task, Contract, Commission, Expedition, Heroic
 * - 11 quest types: gather, kill, forage, prospect, craft, cook,
 *   find_lore, find_structure, complete_dungeon, forge_rune, transmute
 * - Depth multiplier (Y-level based XP/rep scaling)
 * - Quest cancellation with per-tier confirmation
 * - Village quest board placement detection
 * - Bounty hunt (7-day timed special quests)
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const QUEST_TIERS = [
  { id: 1, name: "Errand",      color: "§f", xpBase: 50,  coinBase: 3,  cancelPenalty: 0 },
  { id: 2, name: "Task",        color: "§e", xpBase: 100, coinBase: 5,  cancelPenalty: -5 },
  { id: 3, name: "Contract",    color: "§b", xpBase: 200, coinBase: 8,  cancelPenalty: -10 },
  { id: 4, name: "Commission",  color: "§5", xpBase: 350, coinBase: 12, cancelPenalty: -15 },
  { id: 5, name: "Expedition",  color: "§d", xpBase: 500, coinBase: 18, cancelPenalty: -25 },
  { id: 6, name: "Heroic",      color: "§6", xpBase: 1000, coinBase: 30, cancelPenalty: -50 },
];

// Quest type definitions
const QUEST_TYPES = {
  gather: "Gather items",
  kill: "Kill mobs",
  forage: "Forage ingredients",
  prospect: "Prospect ores",
  craft: "Craft items",
  cook: "Cook dishes",
  find_lore: "Find lore",
  find_structure: "Find a structure",
  complete_dungeon: "Complete a dungeon",
  forge_rune: "Forge a rune",
  transmute: "Transmute an item",
};

// Depth multiplier tiers (Y-level → XP/Rep multiplier)
const DEPTH_TIERS = [
  { minY: 64,   mult: 1.0 },
  { minY: 32,   mult: 1.1 },
  { minY: 0,    mult: 1.2 },
  { minY: -32,  mult: 1.3 },
  { minY: -48,  mult: 1.4 },
  { minY: -999, mult: 1.5 },
];

export class QuestSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    eventBridge.on("player_killed_entity", (data) => {
      if (data.player && data.entity) this.onMobKill(data.player, data.entity.typeId);
    });
    eventBridge.on("block_break", (data) => {
      if (data.player && data.blockId) this.onBlockBreak(data.player, data.blockId);
    });
    eventBridge.on("forage_complete", (data) => {
      if (data.player) this.onObjectiveProgress(data.player, "forage", 1);
    });
    eventBridge.on("craft_complete", (data) => {
      if (data.player) this.onObjectiveProgress(data.player, "craft", 1);
    });
    eventBridge.on("cook_complete", (data) => {
      if (data.player) this.onObjectiveProgress(data.player, "cook", 1);
    });
    eventBridge.on("rune_forged", (data) => {
      if (data.player) this.onObjectiveProgress(data.player, "forge_rune", 1);
    });
    eventBridge.on("transmute_complete", (data) => {
      if (data.player) this.onObjectiveProgress(data.player, "transmute", 1);
    });
  }

  // =====================================================
  // DEPTH MULTIPLIER
  // =====================================================

  getDepthMultiplier(player) {
    const y = player.location.y;
    for (const tier of DEPTH_TIERS) {
      if (y >= tier.minY) return tier.mult;
    }
    return 1.5;
  }

  // =====================================================
  // OBJECTIVE TRACKING
  // =====================================================

  onMobKill(player, mobType) {
    this.onObjectiveProgress(player, "kill", 1, mobType);
  }

  onBlockBreak(player, blockId) {
    this.onObjectiveProgress(player, "mine", 1, blockId);
    this.onObjectiveProgress(player, "prospect", 1, blockId);
  }

  onObjectiveProgress(player, type, amount, target) {
    const s = StorageManager.forPlayer(player);

    // Check all 6 tier slots for active quests
    for (let tier = 1; tier <= 6; tier++) {
      const questId = s.getNumber(`quest_id_${tier}`, 0);
      if (questId === 0) continue;

      const questType = s.getString(`quest_type_${tier}`, "");
      if (questType !== type) continue;

      // If target-specific, check match
      if (target) {
        const questTarget = s.getString(`quest_target_mob_${tier}`, "");
        if (questTarget && !target.includes(questTarget)) continue;
      }

      const current = s.getNumber(`quest_prog_${tier}`, 0) + amount;
      const required = s.getNumber(`quest_required_${tier}`, 10);
      s.set(`quest_prog_${tier}`, current);

      if (current >= required) {
        this.completeQuest(player, tier);
      } else {
        const questName = s.getString(`quest_name_${tier}`, "Quest");
        player.onScreenDisplay.setActionBar(`§e${questName}: §f${current}/${required}`);
      }
    }
  }

  // =====================================================
  // QUEST COMPLETION
  // =====================================================

  completeQuest(player, tier) {
    const s = StorageManager.forPlayer(player);
    const questName = s.getString(`quest_name_${tier}`, "Quest");
    const tierInfo = QUEST_TIERS[tier - 1];

    // Calculate rewards with depth multiplier
    const depthMult = this.getDepthMultiplier(player);
    const xpReward = Math.floor(tierInfo.xpBase * depthMult);
    const coinReward = Math.floor(tierInfo.coinBase * depthMult);

    // Clear quest slot
    s.set(`quest_id_${tier}`, 0);
    s.set(`quest_prog_${tier}`, 0);

    // Track completion
    const completed = s.getNumber("quests_completed", 0) + 1;
    s.set("quests_completed", completed);
    s.set(`quests_done_tier${tier}`, s.getNumber(`quests_done_tier${tier}`, 0) + 1);

    // Grant rewards
    this.eventBridge.emit("grant_coins", { player, amount: coinReward, reason: `Quest: ${questName}` });
    this.eventBridge.emit("grant_xp", { player, amount: xpReward });

    // Depth bonus display
    const depthStr = depthMult > 1.0 ? ` §7(${Math.round(depthMult * 100)}% depth bonus!)` : "";

    player.sendMessage(`\n§a§l✦ Quest Complete! ✦§r`);
    player.sendMessage(`§7${questName}`);
    player.sendMessage(`§7Rewards: §e${coinReward} Coins §7+ §a${xpReward} XP${depthStr}`);

    player.onScreenDisplay.setTitle("§a§lQuest Complete!", {
      subtitle: `§7${questName}`,
      fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20,
    });

    player.playSound("random.levelup", { volume: 0.8, pitch: 1.1 });

    // Reputation gain
    this.eventBridge.emit("reputation_change", { player, renown: tier * 5, reason: "Quest completion" });

    this.eventBridge.emit("quest_completed", { player, tier, questName });
  }

  // =====================================================
  // QUEST CANCELLATION
  // =====================================================

  async cancelQuest(player, tier) {
    const s = StorageManager.forPlayer(player);
    const questId = s.getNumber(`quest_id_${tier}`, 0);
    if (questId === 0) {
      player.sendMessage("§cNo active quest in this tier.");
      return;
    }

    const questName = s.getString(`quest_name_${tier}`, "Quest");
    const tierInfo = QUEST_TIERS[tier - 1];

    // Confirmation dialog
    const form = new ActionFormData()
      .title("§cCancel Quest?")
      .body(`§7Cancel §f${questName}§7?\n\n${tierInfo.cancelPenalty < 0 ? `§cReputation Penalty: ${tierInfo.cancelPenalty}` : "§aNo penalty"}`)
      .button("§cYes, Cancel")
      .button("§aKeep Quest");

    const res = await form.show(player);
    if (res.canceled || res.selection !== 0) return;

    // Apply cancellation
    s.set(`quest_id_${tier}`, 0);
    s.set(`quest_prog_${tier}`, 0);
    s.set(`quest_name_${tier}`, "");
    s.set(`quest_type_${tier}`, "");

    // Reputation penalty
    if (tierInfo.cancelPenalty < 0) {
      this.eventBridge.emit("reputation_change", {
        player,
        renown: tierInfo.cancelPenalty,
        reason: "Quest cancelled"
      });
    }

    // Cancel cooldown (prevent spam)
    s.set(`quest_cancel_cd_${tier}`, 600); // 30s cooldown

    player.sendMessage(`§c✗ Quest cancelled: §7${questName}`);
    player.playSound("note.bass", { volume: 0.5, pitch: 0.5 });
  }

  // =====================================================
  // QUEST BOARD GUI
  // =====================================================

  async openQuestBoard(player) {
    const s = StorageManager.forPlayer(player);
    const completed = s.getNumber("quests_completed", 0);

    let body = `§7Quests Completed: §f${completed}\n\n`;

    // Show active quests per tier
    for (const tier of QUEST_TIERS) {
      const qId = s.getNumber(`quest_id_${tier.id}`, 0);
      if (qId > 0) {
        const name = s.getString(`quest_name_${tier.id}`, "Unknown");
        const prog = s.getNumber(`quest_prog_${tier.id}`, 0);
        const req = s.getNumber(`quest_required_${tier.id}`, 10);
        body += `${tier.color}${tier.name}: §f${name} §7(${prog}/${req})\n`;
      } else {
        body += `${tier.color}${tier.name}: §8(available)\n`;
      }
    }

    const form = new ActionFormData()
      .title("§l§6Quest Board")
      .body(body);

    // Add tier buttons for accepting
    for (const tier of QUEST_TIERS) {
      const qId = s.getNumber(`quest_id_${tier.id}`, 0);
      if (qId > 0) {
        form.button(`${tier.color}Cancel ${tier.name}`);
      } else {
        form.button(`${tier.color}Accept ${tier.name}`);
      }
    }
    form.button("§7Close");

    const res = await form.show(player);
    if (res.canceled || res.selection === QUEST_TIERS.length) return;

    const selectedTier = QUEST_TIERS[res.selection];
    const existingQuest = s.getNumber(`quest_id_${selectedTier.id}`, 0);

    if (existingQuest > 0) {
      await this.cancelQuest(player, selectedTier.id);
    } else {
      await this.acceptQuest(player, selectedTier.id);
    }
  }

  async acceptQuest(player, tierId) {
    const s = StorageManager.forPlayer(player);
    const tierInfo = QUEST_TIERS[tierId - 1];

    // Generate 3 random quest options for this tier
    const options = this.generateQuestOptions(tierId, player);

    const form = new ActionFormData()
      .title(`${tierInfo.color}${tierInfo.name} Quests`);

    let body = "§7Choose a quest:\n\n";
    for (let i = 0; i < options.length; i++) {
      body += `§f${i + 1}. ${options[i].name}\n`;
      body += `§7   ${QUEST_TYPES[options[i].type] || options[i].type}: §e${options[i].target}\n\n`;
    }
    form.body(body);

    for (const opt of options) {
      form.button(`§f${opt.name}`);
    }
    form.button("§7Back");

    const res = await form.show(player);
    if (res.canceled || res.selection >= options.length) return;

    const chosen = options[res.selection];

    // Assign quest
    s.set(`quest_id_${tierId}`, chosen.id);
    s.set(`quest_name_${tierId}`, chosen.name);
    s.set(`quest_type_${tierId}`, chosen.type);
    s.set(`quest_prog_${tierId}`, 0);
    s.set(`quest_required_${tierId}`, chosen.required);
    if (chosen.targetMob) s.set(`quest_target_mob_${tierId}`, chosen.targetMob);

    // Heroic quests have 7-day expiry
    if (tierId === 6) {
      s.set(`quest_expiry_${tierId}`, 504000); // 7 days in ticks at 1/sec
    }

    player.sendMessage(`\n§a✦ Quest Accepted: §f${chosen.name}`);
    player.sendMessage(`§7Objective: ${QUEST_TYPES[chosen.type] || chosen.type}`);
    player.playSound("random.orb", { volume: 0.7, pitch: 1.2 });

    this.eventBridge.emit("quest_accepted", { player, tierId, quest: chosen });
  }

  /** Generate 3 random quest options for a tier */
  generateQuestOptions(tierId, player) {
    const options = [];
    const questPool = this.getQuestPool(tierId);

    // Pick 3 unique random quests
    const shuffled = [...questPool].sort(() => Math.random() - 0.5);
    for (let i = 0; i < Math.min(3, shuffled.length); i++) {
      options.push(shuffled[i]);
    }

    return options;
  }

  /** Quest pools per tier */
  getQuestPool(tierId) {
    const pools = {
      1: [ // Errand
        { id: 101, name: "Pest Control", type: "kill", targetMob: "zombie", required: 10 },
        { id: 102, name: "Spider Hunt", type: "kill", targetMob: "spider", required: 8 },
        { id: 103, name: "Stone Gathering", type: "mine", targetMob: "stone", required: 32 },
        { id: 104, name: "Iron Rush", type: "mine", targetMob: "iron_ore", required: 8 },
        { id: 105, name: "Wood Chopping", type: "gather", targetMob: "log", required: 16 },
        { id: 106, name: "Field Forager", type: "forage", required: 5 },
        { id: 107, name: "Simple Craft", type: "craft", required: 3 },
        { id: 108, name: "Camp Cook", type: "cook", required: 2 },
      ],
      2: [ // Task
        { id: 201, name: "Skeleton Sweep", type: "kill", targetMob: "skeleton", required: 15 },
        { id: 202, name: "Deep Mining", type: "mine", targetMob: "deepslate", required: 48 },
        { id: 203, name: "Diamond Hunt", type: "mine", targetMob: "diamond_ore", required: 3 },
        { id: 204, name: "Night Watch", type: "kill", targetMob: "phantom", required: 5 },
        { id: 205, name: "Herb Collector", type: "forage", required: 10 },
        { id: 206, name: "Feast Prep", type: "cook", required: 5 },
        { id: 207, name: "Ore Survey", type: "prospect", required: 8 },
        { id: 208, name: "Rune Apprentice", type: "forge_rune", required: 1 },
      ],
      3: [ // Contract
        { id: 301, name: "Creeper Clearing", type: "kill", targetMob: "creeper", required: 20 },
        { id: 302, name: "Enderman Hunt", type: "kill", targetMob: "enderman", required: 8 },
        { id: 303, name: "Witch Coven", type: "kill", targetMob: "witch", required: 6 },
        { id: 304, name: "Lore Recovery", type: "find_lore", required: 1 },
        { id: 305, name: "Transmutation", type: "transmute", required: 2 },
        { id: 306, name: "Master Chef", type: "cook", required: 10 },
        { id: 307, name: "Rune Smith", type: "forge_rune", required: 3 },
        { id: 308, name: "Emerald Seeker", type: "mine", targetMob: "emerald_ore", required: 5 },
      ],
      4: [ // Commission
        { id: 401, name: "Pillager Raid", type: "kill", targetMob: "pillager", required: 25 },
        { id: 402, name: "Guardian Depths", type: "kill", targetMob: "guardian", required: 10 },
        { id: 403, name: "Dungeon Dive", type: "complete_dungeon", required: 1 },
        { id: 404, name: "Structure Scout", type: "find_structure", required: 1 },
        { id: 405, name: "Ancient Runes", type: "forge_rune", required: 5 },
        { id: 406, name: "Grand Feast", type: "cook", required: 15 },
      ],
      5: [ // Expedition
        { id: 501, name: "Nether Expedition", type: "kill", targetMob: "blaze", required: 15 },
        { id: 502, name: "Wither Hunt", type: "kill", targetMob: "wither_skeleton", required: 20 },
        { id: 503, name: "Ancient City Delve", type: "complete_dungeon", required: 1 },
        { id: 504, name: "End Explorer", type: "kill", targetMob: "shulker", required: 10 },
        { id: 505, name: "Master Transmuter", type: "transmute", required: 5 },
      ],
      6: [ // Heroic
        { id: 601, name: "Dragon Slayer", type: "kill", targetMob: "ender_dragon", required: 1 },
        { id: 602, name: "Wither Vanquisher", type: "kill", targetMob: "wither", required: 1 },
        { id: 603, name: "Elder Guardian", type: "kill", targetMob: "elder_guardian", required: 3 },
      ],
    };
    return pools[tierId] || pools[1];
  }

  // =====================================================
  // DAILY RESET (called from main.js on day change)
  // =====================================================

  dailyReset() {
    for (const player of world.getAllPlayers()) {
      const s = StorageManager.forPlayer(player);

      // Penalty for incomplete tier 2-5 quests (errands exempt)
      for (let tier = 2; tier <= 5; tier++) {
        const qId = s.getNumber(`quest_id_${tier}`, 0);
        if (qId > 0) {
          const prog = s.getNumber(`quest_prog_${tier}`, 0);
          const req = s.getNumber(`quest_required_${tier}`, 10);
          if (prog < req) {
            // Penalty: -10 village reputation per incomplete quest
            this.eventBridge.emit("village_rep_change", { player, amount: -10 });
          }
        }
      }

      // Reset tier 1-5 quests (heroic tier 6 persists)
      for (let tier = 1; tier <= 5; tier++) {
        s.set(`quest_id_${tier}`, 0);
        s.set(`quest_prog_${tier}`, 0);
        s.set(`quest_required_${tier}`, 0);
        s.set(`quest_name_${tier}`, "");
        s.set(`quest_complete_${tier}`, 0);
        s.set(`quest_cancel_cd_${tier}`, 0);
      }

      // Reset daily flags
      s.set("quest_rerolls_today", 0);
      s.set("first_quest_bonus", 0);
    }
  }

  // =====================================================
  // TICK (heroic expiry, cancel cooldowns)
  // =====================================================

  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);

      // Heroic quest expiry countdown
      const heroicExpiry = s.getNumber("quest_expiry_6", 0);
      if (heroicExpiry > 0) {
        s.set("quest_expiry_6", heroicExpiry - 1);
        if (heroicExpiry <= 1) {
          // Expire heroic quest
          s.set("quest_id_6", 0);
          s.set("quest_expiry_6", 0);
          player.sendMessage("§c§l✗ Heroic Quest Expired! §r§7Time ran out.");
          player.playSound("note.bass", { volume: 0.5, pitch: 0.3 });
        }
      }

      // Decrement cancel cooldowns
      for (let tier = 1; tier <= 6; tier++) {
        const cd = s.getNumber(`quest_cancel_cd_${tier}`, 0);
        if (cd > 0) s.set(`quest_cancel_cd_${tier}`, cd - 1);
      }
    }
  }

  // =====================================================
  // ACTIVE QUEST DISPLAY
  // =====================================================

  async showActiveQuests(player) {
    const s = StorageManager.forPlayer(player);
    let body = "";
    let hasQuest = false;

    for (const tier of QUEST_TIERS) {
      const qId = s.getNumber(`quest_id_${tier.id}`, 0);
      if (qId > 0) {
        hasQuest = true;
        const name = s.getString(`quest_name_${tier.id}`, "Unknown");
        const prog = s.getNumber(`quest_prog_${tier.id}`, 0);
        const req = s.getNumber(`quest_required_${tier.id}`, 10);
        body += `${tier.color}§l${tier.name}§r\n`;
        body += `§f${name} §7— ${prog}/${req}\n\n`;
      }
    }

    if (!hasQuest) {
      player.sendMessage("§7No active quests. Visit the Quest Board to pick one up!");
      return;
    }

    const form = new ActionFormData()
      .title("§cActive Quests")
      .body(body)
      .button("§7Close");

    await form.show(player);
  }
}
