/**
 * Title System — Custom display name prefixes from dream journal + reputation + bosses.
 * Replaces Java titles/ folder (3 mcfunction files).
 *
 * Players earn titles from various systems and can equip one active title.
 * Title shows as prefix in chat via nameTag manipulation.
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const TITLE_SOURCES = {
  // Dream milestones
  dreamer_50: { name: "Dreamer", color: "§d", req: "50+ Dream Rate" },
  dreamer_200: { name: "Dreamwalker", color: "§5", req: "200+ Dream Rate" },
  dreamer_500: { name: "Dream Sage", color: "§d§l", req: "500+ Dream Rate" },
  dreamer_1000: { name: "Dream Ascendant", color: "§6§l", req: "1000+ Dream Rate" },

  // Reputation
  hero: { name: "Hero", color: "§a", req: "500+ Renown" },
  paragon: { name: "Paragon", color: "§a§l", req: "2000+ Renown" },
  outlaw: { name: "Outlaw", color: "§c", req: "500+ Infamy" },
  villain: { name: "Villain", color: "§c§l", req: "2000+ Infamy" },

  // Crafting
  master_crafter: { name: "Master Crafter", color: "§6", req: "Artisan Rank 50" },
  eternal_crafter: { name: "Eternal Crafter", color: "§6§l", req: "Artisan Rank 100" },

  // Trials
  trial_master: { name: "Trial Master", color: "§e", req: "All 6 trial categories mastered" },

  // Exploration
  cartographer: { name: "Master Cartographer", color: "§a", req: "20+ villages discovered" },
  explorer: { name: "World Explorer", color: "§b", req: "15+ structures found" },

  // Boss (these overlap with world-boss title system but are stored separately)
  champion: { name: "World Boss Champion", color: "§6§l", req: "Defeat all 11 bosses" },
};

export class TitleSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  /** Check all title unlock conditions for a player */
  checkUnlocks(player) {
    const s = StorageManager.forPlayer(player);
    const unlocked = [];

    const dr = s.getNumber("dream_rate", 0);
    if (dr >= 50) unlocked.push("dreamer_50");
    if (dr >= 200) unlocked.push("dreamer_200");
    if (dr >= 500) unlocked.push("dreamer_500");
    if (dr >= 1000) unlocked.push("dreamer_1000");

    const renown = s.getNumber("rp_renown", 0);
    const infamy = s.getNumber("rp_infamy", 0);
    if (renown >= 500) unlocked.push("hero");
    if (renown >= 2000) unlocked.push("paragon");
    if (infamy >= 500) unlocked.push("outlaw");
    if (infamy >= 2000) unlocked.push("villain");

    const rank = s.getNumber("cf_rank", 0);
    if (rank >= 50) unlocked.push("master_crafter");
    if (rank >= 100) unlocked.push("eternal_crafter");

    if (s.getNumber("tt_mastery", 0) >= 6) unlocked.push("trial_master");
    if (s.getNumber("jn_village_count", 0) >= 20) unlocked.push("cartographer");
    if (s.getNumber("jn_struct_count", 0) >= 15) unlocked.push("explorer");
    if (s.get("wb_champion")) unlocked.push("champion");

    // Store unlocked titles
    s.set("titles_unlocked", JSON.stringify(unlocked));

    // Check for new unlocks
    const prev = JSON.parse(s.get("titles_prev") || "[]");
    for (const id of unlocked) {
      if (!prev.includes(id)) {
        const title = TITLE_SOURCES[id];
        player.sendMessage(`\n${title.color}§l✦ Title Unlocked: ${title.name} ✦§r`);
        player.playSound("random.levelup", { volume: 0.6, pitch: 1.2 });
      }
    }
    s.set("titles_prev", JSON.stringify(unlocked));
  }

  /** Open title selection menu */
  async openMenu(player) {
    this.checkUnlocks(player);
    const s = StorageManager.forPlayer(player);
    const unlocked = JSON.parse(s.get("titles_unlocked") || "[]");
    const current = s.get("active_title") || "";

    const form = new ActionFormData()
      .title("§l§eTitle Selection");

    let body = `§7Active Title: ${current ? TITLE_SOURCES[current]?.color + TITLE_SOURCES[current]?.name : "§8None"}\n\n`;
    body += `§7Unlocked: §f${unlocked.length}/${Object.keys(TITLE_SOURCES).length}\n\n`;
    form.body(body);

    form.button("§8Remove Title");
    for (const id of unlocked) {
      const t = TITLE_SOURCES[id];
      const equipped = id === current ? " §a✓" : "";
      form.button(`${t.color}${t.name}${equipped}`);
    }
    form.button("§7Close");

    const res = await form.show(player);
    if (res.canceled) return;

    if (res.selection === 0) {
      s.set("active_title", "");
      player.sendMessage("§7Title removed.");
    } else if (res.selection <= unlocked.length) {
      const titleId = unlocked[res.selection - 1];
      s.set("active_title", titleId);
      const t = TITLE_SOURCES[titleId];
      player.sendMessage(`§7Title equipped: ${t.color}${t.name}`);
    }
  }

  /** Get player's active title display string */
  getActiveTitle(player) {
    const s = StorageManager.forPlayer(player);
    const titleId = s.get("active_title");
    if (!titleId) return null;
    const t = TITLE_SOURCES[titleId];
    return t ? `${t.color}[${t.name}]§r` : null;
  }
}
