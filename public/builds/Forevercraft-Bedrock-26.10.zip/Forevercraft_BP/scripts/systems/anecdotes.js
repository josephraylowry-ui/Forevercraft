/**
 * Anecdotes System — 6 collectible lore books, one-time per player.
 * Triggered from crate systems (~15% chance) and structure loot.
 * Replaces Java anecdotes/ folder (12 files) + loot tables.
 */
import { world, ItemStack } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// The 6 anecdotes with their content
const ANECDOTES = {
  wanderer: {
    name: "Wanderer's Anecdote",
    author: "The Nomad Sage",
    color: "§e",
    storageKey: "anec_wanderer",
    lore: "A traveler's tale of distant lands",
    pages: [
      "In ages past, before the walls of villages rose high, there were those who walked the endless roads between the wild places.",
      "They called themselves Wayfarers — not lost, but choosing. Every sunrise was a new compass bearing, every sunset a story earned.",
      "The Nomad Sage was the last of the great Wayfarers. She mapped paths that shifted with the seasons, trails that appeared only under certain stars.",
      "She wrote: 'The world is not a place you arrive at. It is a journey you become. Every block placed is a memory. Every horizon crossed is a promise kept.'",
      "Her compass, they say, did not point north. It pointed to wherever she needed to be. Some say it still works, waiting for the next wanderer brave enough to trust it.",
      "The Wayfarers believed that every biome held a secret — a word whispered by the wind, a color hidden in the stone, a sound buried in the water.",
      "If you have read this far, perhaps you are a Wayfarer too. The road does not end. It only changes. Walk well, traveler.",
    ],
  },
  beast: {
    name: "Beastkeeper's Anecdote",
    author: "The Old Shepherd",
    color: "§a",
    storageKey: "anec_beast",
    lore: "Wisdom from a keeper of creatures",
    pages: [
      "There was a time when animals spoke — not in words, but in a language older than speech. The first Beastkeepers understood this tongue.",
      "They learned that wolves howl not from loneliness, but from joy. That cats purr not to please, but to heal. That parrots repeat not to mock, but to remember.",
      "The Old Shepherd tended flocks that spanned three biomes. His sheep knew his voice from a thousand blocks away.",
      "He wrote: 'A companion is not a tool or a trophy. It is a mirror. What you give, you receive. What you neglect, you lose.'",
      "The Beastkeepers believed every creature had a dreaming self — a version that existed in the Dreaming Realm, watching its waking counterpart.",
      "To earn a creature's trust was to bridge the gap between waking and dreaming. The bond was not ownership. It was recognition.",
      "The Old Shepherd's last words were: 'They do not follow us. They walk beside us. Always remember the difference.'",
    ],
  },
  miner: {
    name: "Miner's Anecdote",
    author: "The Old Prospector",
    color: "§7",
    storageKey: "anec_miner",
    lore: "Stories from the deep places of the world",
    pages: [
      "Deep beneath the surface, where daylight is a memory and stone whispers secrets, the first miners carved their legacy.",
      "They did not dig for riches alone. They dug for truth. Every vein of ore was a sentence in the earth's autobiography.",
      "The Old Prospector spent sixty years underground. He claimed the stone spoke to him — warned him of collapses, guided him to deposits.",
      "He wrote: 'The earth does not give freely. It trades. Your sweat for its treasures. Your courage for its secrets. Your patience for its beauty.'",
      "The deepest mine, they say, reaches below Y-negative sixty. There, the stone glows with an inner light — not redstone, not glowstone, but something older.",
      "The Prospector called it 'dreamstone' — ore that existed simultaneously in the waking world and the Dreaming Realm. Mining it could yield... unexpected things.",
      "His final note read: 'If you find the dreamstone, do not be afraid. It is only the world remembering what it used to be.'",
    ],
  },
  fisher: {
    name: "Fisherman's Anecdote",
    author: "Old Seadog",
    color: "§b",
    storageKey: "anec_fisher",
    lore: "Tales from the depths of the sea",
    pages: [
      "The sea remembers everything. Every ship that sailed, every storm that raged, every creature that swam through its depths.",
      "Old Seadog fished for forty years. He caught things that had no names and things that should not have existed.",
      "He claimed the ocean had moods — not tides, but actual emotions. On full moons, it was generous. On new moons, it was hungry.",
      "He wrote: 'Cast your line with patience and respect. The sea knows your intentions. It rewards the humble and punishes the greedy.'",
      "Seadog spoke of a fish made entirely of moonlight — it appeared only during Harvest Moons and granted wishes to whoever caught it.",
      "Whether this was truth or tavern talk, no one knows. But fishermen still cast their lines on Harvest Moon nights, just in case.",
      "His last entry: 'The sea is not empty water. It is liquid memory. Every wave carries a story. Listen.'",
    ],
  },
  elder: {
    name: "Elder's Anecdote",
    author: "The Village Elder",
    color: "§6",
    storageKey: "anec_elder",
    lore: "Ancient wisdom of the village councils",
    pages: [
      "Before there were kingdoms, there were councils. Before there were councils, there were elders. Before there were elders, there was simply wisdom.",
      "The Village Elder served seven villages over nine decades. She remembered when the first Guidestone was placed — a beacon of hope in a wild world.",
      "She wrote: 'A village is not buildings. It is promises. Every wall says: I will shelter you. Every farm says: I will feed you. Every light says: I will guide you home.'",
      "The Elder spoke of a time when villages could speak to each other across vast distances — through the Guidestone network, now half-forgotten.",
      "She believed that every village had a 'heart-block' — a single block placed by the first settler that anchored the village to the world.",
      "Remove the heart-block, and the village would slowly fade. Not physically, but spiritually. The villagers would forget why they stayed.",
      "Her final teaching: 'Build not for yourself, but for those who come after. The greatest structures are the ones that outlive their builders.'",
    ],
  },
  scholar: {
    name: "Scholar's Anecdote",
    author: "The Archivist",
    color: "§5",
    storageKey: "anec_scholar",
    lore: "Knowledge preserved from forgotten libraries",
    pages: [
      "The Archivist spent her life cataloging the uncatalogable — artifacts that defied explanation, creatures that shouldn't exist, places that appeared on no map.",
      "She maintained the Great Index, a record of every significant discovery in the known world. It filled seventeen stronghold libraries.",
      "She wrote: 'Knowledge is not power. Knowledge is responsibility. Every secret uncovered demands a choice: share it, or guard it.'",
      "The Archivist discovered that artifacts were not crafted — they were remembered. The world dreamed them into existence based on the needs of its inhabitants.",
      "She theorized that the Dreaming Realm was not a separate dimension, but a layer of reality — the world's subconscious, where potential became actual.",
      "Her most controversial claim: 'We do not find artifacts. They find us. Each one is a message from the world, waiting for the right reader.'",
      "The Archivist's final entry: 'The codex is never complete. Every answer spawns three questions. This is not a flaw. It is a feature.'",
    ],
  },
};

// Mapping of crate types to anecdote keys
const CRATE_ANECDOTE_MAP = {
  achievement: ["wanderer", "scholar"], // Wanderer first, Scholar fallback
  fishing: ["fisher"],
  harvest: ["elder"],
  mob: ["beast"],
  structure_mineshaft: ["miner"],
  structure_shipwreck: ["fisher"],
  structure_village: ["beast"],
  structure_stronghold: ["scholar"],
  structure_general: ["elder", "wanderer"],
};

export class AnecdoteSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Listen for crate reward events to roll anecdote drops
    eventBridge.on("crate_reward", (player, crateType) => {
      this.rollAnecdote(player, crateType);
    });
  }

  /**
   * Roll for an anecdote drop from a crate reward (15% chance).
   */
  rollAnecdote(player, crateType) {
    // 15% chance to attempt anecdote drop
    if (Math.random() > 0.15) return;

    const candidates = CRATE_ANECDOTE_MAP[crateType];
    if (!candidates) return;

    const s = StorageManager.forPlayer(player);

    for (const key of candidates) {
      const anecdote = ANECDOTES[key];
      if (!anecdote) continue;

      // Check if player already has this anecdote
      if (s.getNumber(anecdote.storageKey, 0) === 1) continue;

      // Give the anecdote!
      this.giveAnecdote(player, key);
      return;
    }
  }

  /**
   * Give a specific anecdote to a player.
   */
  giveAnecdote(player, key) {
    const anecdote = ANECDOTES[key];
    if (!anecdote) return;

    const s = StorageManager.forPlayer(player);

    // Mark as found
    s.set(anecdote.storageKey, 1);

    // Give the written book
    try {
      const book = new ItemStack("minecraft:written_book", 1);
      // Set custom name and lore via nameTag
      book.nameTag = anecdote.name;

      // Give to player
      const inv = player.getComponent("minecraft:inventory");
      if (inv) {
        const container = inv.container;
        // Find first empty slot
        for (let i = 0; i < container.size; i++) {
          if (!container.getItem(i)) {
            container.setItem(i, book);
            break;
          }
        }
      }
    } catch {}

    // Notify player
    player.sendMessage(`§8[§5Anecdote§8] §7You found a ${anecdote.color}${anecdote.name}§7!`);
    try {
      player.playSound("item.book.page_turn", { volume: 1, pitch: 0.8 });
      player.playSound("block.amethyst_block.step", { volume: 0.5, pitch: 1.2 });
    } catch {}

    // Emit event for other systems (achievements, journal)
    this.eventBridge.emit("anecdote_found", player, key);
  }

  /**
   * Check if a player has found a specific anecdote.
   */
  hasAnecdote(player, key) {
    const anecdote = ANECDOTES[key];
    if (!anecdote) return false;
    return StorageManager.forPlayer(player).getNumber(anecdote.storageKey, 0) === 1;
  }

  /**
   * Get total anecdotes found by a player.
   */
  getFoundCount(player) {
    const s = StorageManager.forPlayer(player);
    let count = 0;
    for (const anecdote of Object.values(ANECDOTES)) {
      if (s.getNumber(anecdote.storageKey, 0) === 1) count++;
    }
    return count;
  }

  /**
   * Open anecdote collection menu.
   */
  openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const found = this.getFoundCount(player);

    let body = `§6§lAnecdote Collection\n§7Found: §f${found}/6\n\n`;

    for (const [key, anecdote] of Object.entries(ANECDOTES)) {
      const hasIt = s.getNumber(anecdote.storageKey, 0) === 1;
      if (hasIt) {
        body += `${anecdote.color}✔ ${anecdote.name} §7— by ${anecdote.author}\n`;
      } else {
        body += `§8✘ ??? §7— ???\n`;
      }
    }

    if (found === 6) {
      body += `\n§a§lAll anecdotes collected! §7The stories of the world are yours.`;
    }

    const { ActionFormData } = require("@minecraft/server-ui");
    const form = new ActionFormData()
      .title("§5☖ Anecdotes")
      .body(body)
      .button("§7Close");

    form.show(player).then(() => {});
  }
}
