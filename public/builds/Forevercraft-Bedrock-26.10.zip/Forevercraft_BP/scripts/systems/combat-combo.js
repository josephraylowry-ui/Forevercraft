/**
 * Mob Kill Combo Counter — Rapid kills within 5 seconds stack a combo.
 * At 5x/10x/15x, grant bonus XP bursts.
 * Replaces Java combat/combo_*.mcfunction files.
 */
import { world, system } from "@minecraft/server";

const COMBO_TIMEOUT_TICKS = 100; // 5 seconds
const COMBO_MILESTONES = [
  { count: 5, xp: 25, label: "§e§lCombo x5!" },
  { count: 10, xp: 50, label: "§6§lCombo x10!!" },
  { count: 15, xp: 100, label: "§c§lCOMBO x15!!!" },
  { count: 20, xp: 200, label: "§d§l✦ MEGA COMBO x20 ✦" },
];

export class CombatComboSystem {
  constructor(eventBridge) {
    /** @type {Map<string, {count: number, lastKillTick: number}>} */
    this.combos = new Map();

    eventBridge.on("player_killed_entity", (player, deadEntity) => {
      // Only count hostile/neutral mobs, not passive animals
      if (deadEntity.typeId === "minecraft:player") return;
      this.onKill(player);
    });
  }

  onKill(player) {
    const now = system.currentTick;
    const key = player.id;
    const data = this.combos.get(key);

    if (data && (now - data.lastKillTick) <= COMBO_TIMEOUT_TICKS) {
      // Continue combo
      data.count++;
      data.lastKillTick = now;

      // Check milestones
      for (const ms of COMBO_MILESTONES) {
        if (data.count === ms.count) {
          try {
            player.runCommandAsync(`xp ${ms.xp} @s`);
            player.sendMessage(ms.label);
            player.playSound("random.orb", { volume: 0.6, pitch: 1.0 + data.count * 0.05 });
          } catch {}
          break;
        }
      }

      // Show combo count on actionbar for non-milestone kills
      if (data.count >= 3 && !COMBO_MILESTONES.some(ms => ms.count === data.count)) {
        try {
          player.runCommandAsync(`titleraw @s actionbar {"rawtext":[{"text":"§eCombo: x${data.count}"}]}`);
        } catch {}
      }
    } else {
      // Start new combo
      this.combos.set(key, { count: 1, lastKillTick: now });
    }
  }

  tick() {
    // Clean up expired combos (every ~5 seconds is fine)
    const now = system.currentTick;
    if (now % 100 !== 0) return;
    for (const [key, data] of this.combos) {
      if (now - data.lastKillTick > COMBO_TIMEOUT_TICKS) {
        // Notify player combo ended if it was notable
        this.combos.delete(key);
      }
    }
  }
}
