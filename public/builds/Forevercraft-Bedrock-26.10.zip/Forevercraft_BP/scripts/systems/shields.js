/**
 * Shield Abilities System — 9 shield artifacts with bash, taunt, block passives, offhand abilities.
 * Replaces Java artifacts/shields/ folder.
 *
 * Shield types: Deku, Tower, Trial, Dragonslayer, Drowned King,
 *   Golden Goliath, Dragonmaster, Command Block, Ender Dragon
 *
 * Mechanics:
 * - Mainhand: Resistance passive, shield bash (shift+use), taunt on hit
 * - Offhand: Per-shield unique ability (shift+use)
 * - Block passives: Effects on successful shield block
 * - Weapon mastery type 11 (tank class)
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { applyKnockback } from "../utils/knockback.js";

// ─── SHIELD DEFINITIONS ────────────────────────────────
const SHIELDS = {
  common_deku_shield: {
    name: "Deku Shield", tier: 1,
    offhand: { name: "Forest's Vigor", effect: "haste", duration: 4, amplifier: 1, cooldown: 25 },
  },
  tower_shield: {
    name: "Tower Shield", tier: 3,
    offhand: { name: "Fortify", effects: [{ e: "resistance", d: 5, a: 1 }, { e: "slowness", d: 5, a: 0 }], cooldown: 20 },
  },
  trial_shield: {
    name: "Trial Shield", tier: 2,
    offhand: { name: "Challenger's Resolve", effect: "absorption", duration: 6, amplifier: 1, cooldown: 25 },
  },
  dragonslayer_shield: {
    name: "Dragonslayer Shield", tier: 4,
    offhand: {
      name: "Dragon's Breath", cooldown: 20,
      aoe: { radius: 4, fireTicks: 60, damage: 6 },
      selfEffect: { e: "fire_resistance", d: 5, a: 4 },
    },
  },
  drowned_king_shield: {
    name: "Drowned King Shield", tier: 3,
    offhand: {
      name: "Tidal Curse", cooldown: 25,
      aoeEffect: { e: "slowness", d: 5, a: 1, radius: 5 },
      selfEffect: { e: "conduit_power", d: 6, a: 5 },
    },
  },
  golden_goliath_shield: {
    name: "Golden Goliath Shield", tier: 6,
    offhand: { name: "Goliath's Fury", effect: "haste", duration: 5, amplifier: 2, cooldown: 20 },
  },
  dragonmaster_shield: {
    name: "Dragonmaster Shield", tier: 6,
    offhand: {
      name: "Paladin's Grace", cooldown: 20,
      selfHeal: 8, partyHeal: 4, partyRadius: 6,
      selfDebuff: { e: "weakness", d: 7, a: 1 },
    },
  },
  command_block_shield: {
    name: "Command Block Shield", tier: 6,
    offhand: {
      name: "Admin Override", cooldown: 18,
      selfEffects: [{ e: "strength", d: 4, a: 1 }, { e: "speed", d: 4, a: 1 }],
      selfDebuff: { e: "mining_fatigue", d: 8, a: 0 },
    },
  },
  ender_dragon_shield: {
    name: "Ender Dragon Shield", tier: 6,
    offhand: { name: "Void Barrier", effect: "resistance", duration: 5, amplifier: 2, cooldown: 25 },
  },
};

// Shield bash scaling by tier
const BASH_TIERS = {
  1: { damage: 3, kb: 3, cooldown: 15 },  // Common: 3 steps (1.2 blocks)
  2: { damage: 4, kb: 3, cooldown: 13 },  // Uncommon
  3: { damage: 5, kb: 4, cooldown: 11 },  // Rare
  4: { damage: 6, kb: 5, cooldown: 9 },   // Ornate
  5: { damage: 8, kb: 6, cooldown: 7 },   // Exquisite
  6: { damage: 10, kb: 7, cooldown: 5 },  // Mythical
};

// Block passive effects by tier
const BLOCK_EFFECTS = {
  1: { name: "Shield Brace", effect: "absorption", duration: 4, amplifier: 0 },
  2: { name: "Quick Recovery", effect: "speed", duration: 3, amplifier: 0 },
  3: { name: "Counter Stance", effect: "strength", duration: 3, amplifier: 0 },
  4: { name: "Counter Stance", effect: "strength", duration: 3, amplifier: 0 },
  5: { name: "Arcane Ward", effects: [{ e: "absorption", d: 4, a: 1 }, { e: "regeneration", d: 4, a: 0 }] },
  6: { name: "Titan's Resolve", effects: [{ e: "absorption", d: 5, a: 2 }, { e: "strength", d: 5, a: 0 }], partyAbsorption: true },
};

// Taunt tier scaling
const TAUNT_TIERS = {
  1: { duration: 400, pullInterval: 15 },   // Common: 20s, pull every 15s
  2: { duration: 500, pullInterval: 12 },   // Uncommon
  3: { duration: 600, pullInterval: 10 },   // Rare
  4: { duration: 800, pullInterval: 7 },    // Ornate
  5: { duration: 1000, pullInterval: 5 },   // Exquisite
  6: { duration: 1200, pullInterval: 3 },   // Mythical: 60s, pull every 3s
};

export class ShieldSystem {
  constructor(eventBridge) {
    // Taunt on hit with mainhand shield
    eventBridge.on("player_dealt_damage", (player, target, damage) => {
      this.onPlayerHitWithShield(player, target);
    });

    // Block passive on damage taken
    eventBridge.on("player_hurt", (player, source, damage) => {
      this.onPlayerBlocked(player, source, damage);
    });

    // Item use for bash/offhand ability
    eventBridge.on("item_use", (player, item) => {
      this.onShieldUse(player, item);
    });
  }

  /** Detect shield in slot, returns shield data or null */
  detectShield(player, slot = "Mainhand") {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return null;
    const item = equip.getEquipment(slot);
    if (!item) return null;
    const tags = item.getTags?.() || [];

    // Check for tank tag
    if (!tags.some(t => t.includes("tank"))) return null;

    // Find specific shield
    for (const [id, shield] of Object.entries(SHIELDS)) {
      if (tags.some(t => t.includes(id))) return { ...shield, id };
    }

    // Generic shield with tier detection
    let tier = 1;
    if (tags.some(t => t.includes("mythical"))) tier = 6;
    else if (tags.some(t => t.includes("exquisite"))) tier = 5;
    else if (tags.some(t => t.includes("ornate"))) tier = 4;
    else if (tags.some(t => t.includes("rare"))) tier = 3;
    else if (tags.some(t => t.includes("uncommon"))) tier = 2;
    return { name: "Shield", tier, id: "generic" };
  }

  /** Shield use (bash or offhand ability) */
  onShieldUse(player, item) {
    if (!item) return;
    const tags = item.getTags?.() || [];
    if (!tags.some(t => t.includes("tank"))) return;

    const s = StorageManager.forPlayer(player);

    // Check if mainhand or offhand
    const mainShield = this.detectShield(player, "Mainhand");
    const offShield = this.detectShield(player, "Offhand");

    if (mainShield && player.isSneaking) {
      this.shieldBash(player, mainShield, s);
    } else if (offShield && player.isSneaking) {
      this.offhandAbility(player, offShield, s);
    }
  }

  /** Shield bash: AoE damage + knockback */
  shieldBash(player, shield, s) {
    const bashData = BASH_TIERS[shield.tier] || BASH_TIERS[1];
    if (s.getNumber("tk_bash_cd") > 0) {
      player.sendMessage(`§7Shield Bash on cooldown: §f${s.getNumber("tk_bash_cd")}s`);
      return;
    }

    s.set("tk_bash_cd", bashData.cooldown);

    // AoE damage + knockback to nearby entities
    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 3,
        excludeTypes: ["minecraft:player"],
        excludeFamilies: ["inanimate"],
      });
      for (const entity of nearby) {
        try {
          entity.applyDamage(bashData.damage, { cause: "entityAttack", damagingEntity: player });
          applyKnockback(entity, player, bashData.kb);
        } catch {}
      }
    } catch {}

    player.sendMessage(`§6§l🛡 Shield Bash! §r§7${bashData.damage} damage, ${bashData.kb} KB`);
    player.playSound("entity.iron_golem.attack");
  }

  /** Offhand shield ability */
  offhandAbility(player, shield, s) {
    const ability = shield.offhand;
    if (!ability) return;

    if (s.getNumber("tk_off_cd") > 0) {
      player.sendMessage(`§7${ability.name} on cooldown: §f${s.getNumber("tk_off_cd")}s`);
      return;
    }

    s.set("tk_off_cd", ability.cooldown);

    // Simple single effect
    if (ability.effect) {
      try { player.runCommandAsync(`effect @s ${ability.effect} ${ability.duration} ${ability.amplifier} true`); } catch {}
    }

    // Multiple effects
    if (ability.effects) {
      for (const eff of ability.effects) {
        try { player.runCommandAsync(`effect @s ${eff.e} ${eff.d} ${eff.a} true`); } catch {}
      }
    }

    // Self effects list
    if (ability.selfEffects) {
      for (const eff of ability.selfEffects) {
        try { player.runCommandAsync(`effect @s ${eff.e} ${eff.d} ${eff.a} true`); } catch {}
      }
    }

    // Self effect (single)
    if (ability.selfEffect) {
      const se = ability.selfEffect;
      try { player.runCommandAsync(`effect @s ${se.e} ${se.d} ${se.a} true`); } catch {}
    }

    // Self debuff
    if (ability.selfDebuff) {
      const db = ability.selfDebuff;
      try { player.runCommandAsync(`effect @s ${db.e} ${db.d} ${db.a} true`); } catch {}
    }

    // AoE damage (Dragonslayer)
    if (ability.aoe) {
      try {
        const nearby = player.dimension.getEntities({
          location: player.location,
          maxDistance: ability.aoe.radius,
          excludeTypes: ["minecraft:player"],
          excludeFamilies: ["inanimate"],
        });
        for (const entity of nearby) {
          try {
            entity.applyDamage(ability.aoe.damage, { cause: "magic", damagingEntity: player });
            entity.setOnFire(ability.aoe.fireTicks / 20);
          } catch {}
        }
      } catch {}
    }

    // AoE effect (Drowned King)
    if (ability.aoeEffect) {
      const ae = ability.aoeEffect;
      try {
        const nearby = player.dimension.getEntities({
          location: player.location,
          maxDistance: ae.radius,
          excludeTypes: ["minecraft:player"],
          excludeFamilies: ["inanimate"],
        });
        for (const entity of nearby) {
          try { entity.runCommandAsync(`effect @s ${ae.e} ${ae.d} ${ae.a} true`); } catch {}
        }
      } catch {}
    }

    // Self heal + party heal (Dragonmaster)
    if (ability.selfHeal) {
      try {
        const health = player.getComponent("minecraft:health");
        if (health) health.setCurrentValue(Math.min(health.currentValue + ability.selfHeal, health.effectiveMax));
      } catch {}
      if (ability.partyHeal && ability.partyRadius) {
        try {
          const nearbyPlayers = player.dimension.getEntities({
            type: "minecraft:player",
            location: player.location,
            maxDistance: ability.partyRadius,
            excludeNames: [player.name],
          });
          for (const p of nearbyPlayers) {
            try {
              const h = p.getComponent("minecraft:health");
              if (h) h.setCurrentValue(Math.min(h.currentValue + ability.partyHeal, h.effectiveMax));
            } catch {}
          }
        } catch {}
      }
    }

    player.sendMessage(`§6§l🛡 ${ability.name}! §r§7activated`);
    player.playSound("entity.player.attack.strong");
  }

  /** Mainhand shield: Resistance passive + taunt on hit */
  onPlayerHitWithShield(player, target) {
    const shield = this.detectShield(player, "Mainhand");
    if (!shield) return;

    // Taunt the target
    this.applyTaunt(player, target, shield);
  }

  /** Apply taunt to a mob */
  applyTaunt(player, target, shield) {
    if (target.typeId === "minecraft:player") return;
    const s = StorageManager.forPlayer(player);
    const tauntData = TAUNT_TIERS[shield.tier] || TAUNT_TIERS[1];

    // Tag the entity as taunted
    try {
      target.addTag("ec.taunted");
      target.addTag(`ec.taunt_owner_${player.name}`);
    } catch {}

    // Store taunt expiry
    s.set("tk_taunt_dur", tauntData.duration);
    s.set("tk_pull_cd", tauntData.pullInterval);
    s.set("tk_tier", shield.tier);

    player.playSound("mob.warden.agitated");
  }

  /** Block passive: effects when player blocks with shield */
  onPlayerBlocked(player, source, damage) {
    // Check if player has a shield and is blocking
    const mainShield = this.detectShield(player, "Mainhand");
    const offShield = this.detectShield(player, "Offhand");
    const shield = mainShield || offShield;
    if (!shield) return;

    const s = StorageManager.forPlayer(player);
    if (s.getNumber("tk_block_cd") > 0) return;
    s.set("tk_block_cd", 3); // 3s cooldown

    const blockEffect = BLOCK_EFFECTS[shield.tier] || BLOCK_EFFECTS[1];

    if (blockEffect.effect) {
      try { player.runCommandAsync(`effect @s ${blockEffect.effect} ${blockEffect.duration} ${blockEffect.amplifier} true`); } catch {}
    }

    if (blockEffect.effects) {
      for (const eff of blockEffect.effects) {
        try { player.runCommandAsync(`effect @s ${eff.e} ${eff.d} ${eff.a} true`); } catch {}
      }
    }

    // Mythical: party absorption
    if (blockEffect.partyAbsorption) {
      try {
        const nearbyPlayers = player.dimension.getEntities({
          type: "minecraft:player",
          location: player.location,
          maxDistance: 8,
          excludeNames: [player.name],
        });
        for (const p of nearbyPlayers) {
          try { p.runCommandAsync("effect @s absorption 5 0 true"); } catch {}
        }
      } catch {}
    }
  }

  /**
   * Per-second tick: mainhand resistance passive, taunt pulls, cooldowns.
   * Called from main tick loop every 20 ticks (1 second).
   */
  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const mainShield = this.detectShield(player, "Mainhand");

      // Mainhand resistance passive
      if (mainShield) {
        const amp = mainShield.tier >= 6 ? 2 : 1; // Mythical: Resistance III
        try { player.runCommandAsync(`effect @s resistance 3 ${amp} true`); } catch {}
      }

      // Decrement cooldowns
      for (const key of ["tk_bash_cd", "tk_off_cd", "tk_block_cd"]) {
        const cd = s.getNumber(key);
        if (cd > 0) s.set(key, cd - 1);
      }

      // Taunt pull
      let pullCd = s.getNumber("tk_pull_cd");
      if (pullCd > 0) {
        pullCd--;
        s.set("tk_pull_cd", pullCd);
        if (pullCd <= 0 && mainShield) {
          this.executeTauntPull(player, s);
          const tauntData = TAUNT_TIERS[mainShield.tier] || TAUNT_TIERS[1];
          s.set("tk_pull_cd", tauntData.pullInterval);
        }
      }

      // Taunt duration
      let tauntDur = s.getNumber("tk_taunt_dur");
      if (tauntDur > 0) {
        tauntDur -= 20; // 1 second in ticks
        s.set("tk_taunt_dur", Math.max(0, tauntDur));
        if (tauntDur <= 0) {
          this.clearTaunts(player);
        }
      }
    }
  }

  /** Pull taunted mobs toward the player */
  executeTauntPull(player, s) {
    try {
      const taunted = player.dimension.getEntities({
        location: player.location,
        maxDistance: 48,
        tags: [`ec.taunt_owner_${player.name}`],
      });
      for (const entity of taunted) {
        try {
          entity.teleport(player.location, { dimension: player.dimension });
        } catch {}
      }
      if (taunted.length > 0) {
        player.playSound("mob.warden.heartbeat");
      }
    } catch {}
  }

  /** Clear all taunts from this player's mobs */
  clearTaunts(player) {
    try {
      const taunted = player.dimension.getEntities({
        location: player.location,
        maxDistance: 128,
        tags: [`ec.taunt_owner_${player.name}`],
      });
      for (const entity of taunted) {
        try {
          entity.removeTag("ec.taunted");
          entity.removeTag(`ec.taunt_owner_${player.name}`);
        } catch {}
      }
    } catch {}
  }
}
