/**
 * Class Affinity System — Tracks combat class mastery across 14 weapon classes.
 * Replaces Java affinity/ folder (15 files + 98 advancements).
 *
 * 14 Combat Classes:
 *   Rogue, Berserker, Dancer, Striker, Sentinel, Healer,
 *   Beastlord, Javelin, Hoplite, Archer, Hunter, Tank, Knight, Dual Swordsman
 *
 * 7 Stages: Common(1M), Uncommon(3M), Rare(6M), Ornate(10M),
 *           Exquisite(15M), Mythical(22.5M), Spirit(30M)
 *
 * Damage boost per stage: 0%, +10%, +20%, +30%, +40%, +50%, +75%
 * Spirit stage + Spirit Twin = +100%
 *
 * XP sources: passive (7/3.6s), mob kills (+1200), patrons, dungeons (+60k),
 *   bosses (+90k), castle (+12k), raids (+120k), bounties (+30k)
 * Daily cap: 1,000,000 XP per class (Spirit holders bypass cap)
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const STAGE_THRESHOLDS = [0, 1000000, 3000000, 6000000, 10000000, 15000000, 22500000, 30000000];
const STAGE_NAMES = ["None", "Common", "Uncommon", "Rare", "Ornate", "Exquisite", "Mythical", "Spirit"];
const STAGE_COLORS = ["§8", "§f", "§9", "§b", "§5", "§d", "§6", "§e"];
const STAGE_BOOST = [0, 0, 10, 20, 30, 40, 50, 75]; // % damage boost per stage
const DAILY_CAP = 1000000;

const CLASSES = [
  { id: 1,  abbr: "rg", name: "Rogue",           icon: "🗡" },
  { id: 2,  abbr: "bk", name: "Berserker",       icon: "⚔" },
  { id: 3,  abbr: "dn", name: "Dancer",          icon: "💃" },
  { id: 4,  abbr: "sk", name: "Striker",         icon: "👊" },
  { id: 5,  abbr: "kt", name: "Sentinel",        icon: "🛡" },
  { id: 6,  abbr: "hl", name: "Healer",          icon: "💚" },
  { id: 7,  abbr: "bl", name: "Beastlord",       icon: "🐺" },
  { id: 8,  abbr: "jv", name: "Javelin",         icon: "🔱" },
  { id: 9,  abbr: "hp", name: "Hoplite",         icon: "🏛" },
  { id: 10, abbr: "ar", name: "Archer",          icon: "🏹" },
  { id: 11, abbr: "ht", name: "Hunter",          icon: "🎯" },
  { id: 12, abbr: "tk", name: "Tank",            icon: "🛡" },
  { id: 13, abbr: "kn", name: "Knight",          icon: "⚜" },
  { id: 14, abbr: "ds", name: "Dual Swordsman",  icon: "⚔" },
];

const PASSIVE_INTERVAL = 72; // ticks (~3.6 seconds)

export class ClassAffinitySystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.passiveCounter = 0;

    // XP from combat events
    eventBridge.on("player_killed_entity", (data) => this.grantCurrent(data.player, 1200));
    eventBridge.on("dungeon_completed", (data) => this.grantCurrent(data.player, 60000));
    eventBridge.on("boss_killed", (data) => this.grantCurrent(data.player, 90000));
    eventBridge.on("castle_floor_complete", (data) => this.grantCurrent(data.player, 12000));
    eventBridge.on("raid_boss_killed", (data) => this.grantCurrent(data.player, 120000));
    eventBridge.on("bounty_completed", (data) => this.grantCurrent(data.player, 30000));

    // Patron rewards by rarity
    eventBridge.on("patron_common", (data) => this.grantCurrent(data.player, 6000));
    eventBridge.on("patron_uncommon", (data) => this.grantCurrent(data.player, 9600));
    eventBridge.on("patron_rare", (data) => this.grantCurrent(data.player, 14400));
    eventBridge.on("patron_ornate", (data) => this.grantCurrent(data.player, 24000));
    eventBridge.on("patron_exquisite", (data) => this.grantCurrent(data.player, 36000));
    eventBridge.on("patron_mythical", (data) => this.grantCurrent(data.player, 60000));
  }

  /** Detect current combat class from held weapon tags */
  detectClass(player) {
    const s = StorageManager.forPlayer(player);

    // Check active class tags (priority order)
    const tagChecks = [
      { tag: "ec.rg_active", id: 1 }, { tag: "ec.bk_active", id: 2 },
      { tag: "ec.dn_active", id: 3 }, { tag: "ec.sk_active", id: 4 },
      { tag: "ec.kt_active", id: 5 }, { tag: "ec.bl_active", id: 7 },
      { tag: "ec.jv_active", id: 8 }, { tag: "ec.ar_active", id: 10 },
      { tag: "ec.ht_active", id: 11 }, { tag: "ec.ds_active", id: 14 },
    ];

    for (const check of tagChecks) {
      if (player.hasTag(check.tag)) {
        s.set("aff_class", check.id);
        return check.id;
      }
    }

    // Fallback: check held item custom_data for non-tag classes
    // (Healer=6, Hoplite=9, Tank=12, Knight=13)
    // These would need item inspection — simplified to tag check
    if (player.hasTag("ec.hl_active")) { s.set("aff_class", 6); return 6; }
    if (player.hasTag("ec.hp_active")) { s.set("aff_class", 9); return 9; }
    if (player.hasTag("ec.tk_active")) { s.set("aff_class", 12); return 12; }
    if (player.hasTag("ec.kn_active")) { s.set("aff_class", 13); return 13; }

    s.set("aff_class", 0);
    return 0;
  }

  /** Grant XP to player's currently active class */
  grantCurrent(player, delta) {
    if (!player) return;
    const classId = this.detectClass(player);
    if (classId === 0) return;
    this.grantXP(player, classId, delta);
  }

  /** Grant XP to a specific class */
  grantXP(player, classId, delta) {
    const cls = CLASSES.find(c => c.id === classId);
    if (!cls) return;

    const s = StorageManager.forPlayer(player);
    const totalKey = `aff_${cls.abbr}`;
    const dailyKey = `aff_daily_${cls.abbr}`;
    const stageKey = `aff_stage_${cls.abbr}`;

    // Daily cap check (Spirit holders bypass)
    const isSpirit = player.hasTag("ec.sp_active");
    if (!isSpirit) {
      const daily = s.getNumber(dailyKey, 0);
      if (daily >= DAILY_CAP) return;
      const remaining = DAILY_CAP - daily;
      delta = Math.min(delta, remaining);
      s.set(dailyKey, daily + delta);
    }

    // Add to total
    const oldTotal = s.getNumber(totalKey, 0);
    const newTotal = oldTotal + delta;
    s.set(totalKey, newTotal);

    // Check stage up
    const oldStage = this.getStage(oldTotal);
    const newStage = this.getStage(newTotal);

    if (newStage > oldStage) {
      s.set(stageKey, newStage);
      this.onStageUp(player, cls, newStage);
    }
  }

  /** Get stage (0-7) from total XP */
  getStage(totalXP) {
    for (let i = STAGE_THRESHOLDS.length - 1; i >= 0; i--) {
      if (totalXP >= STAGE_THRESHOLDS[i]) return i;
    }
    return 0;
  }

  /** Calculate damage boost percentage */
  getDamageBoost(player) {
    const classId = this.detectClass(player);
    if (classId === 0) return 0;

    const cls = CLASSES.find(c => c.id === classId);
    if (!cls) return 0;

    const s = StorageManager.forPlayer(player);
    const stage = s.getNumber(`aff_stage_${cls.abbr}`, 0);
    let boost = STAGE_BOOST[stage] || 0;

    // Spirit stage + Twin = 100%
    if (stage >= 7 && player.hasTag("ec.sp_active") && player.hasTag("ec.sp_twin")) {
      boost = 100;
    }

    return boost;
  }

  /** Apply boosted damage (called from weapon class systems) */
  boostDamage(baseDamage, player) {
    const boost = this.getDamageBoost(player);
    if (boost <= 0) return baseDamage;
    return Math.floor(baseDamage + (baseDamage * boost / 100));
  }

  /** Handle stage up */
  onStageUp(player, cls, stage) {
    const stageName = STAGE_NAMES[stage];
    const color = STAGE_COLORS[stage];
    const boost = STAGE_BOOST[stage];

    player.sendMessage(`\n${color}§l${cls.icon} ${cls.name} — ${stageName}! §r`);
    if (boost > 0) {
      player.sendMessage(`§7Damage boost: §a+${boost}%`);
    }
    player.playSound("random.levelup", { volume: 0.8, pitch: 1.0 });

    try {
      player.onScreenDisplay.setTitle(`${color}§l${stageName}`, {
        subtitle: `§7Class Affinity Increased`,
        fadeInDuration: 5, stayDuration: 40, fadeOutDuration: 10,
      });
    } catch {}

    this.eventBridge.emit("affinity_stage_up", { player, classId: cls.id, stage, stageName });
  }

  /** Passive tick — grant 7 XP every 72 ticks while holding class weapon */
  tick(players) {
    this.passiveCounter++;
    if (this.passiveCounter < PASSIVE_INTERVAL) return;
    this.passiveCounter = 0;

    for (const player of players) {
      const classId = this.detectClass(player);
      if (classId === 0) continue;

      // +7 XP passive, 14 if Spirit Twin active
      const amount = player.hasTag("ec.sp_twin") ? 14 : 7;
      this.grantXP(player, classId, amount);
    }
  }

  /** Reset daily caps (called at dawn) */
  resetDailyCaps(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      for (const cls of CLASSES) {
        s.set(`aff_daily_${cls.abbr}`, 0);
      }
    }
  }

  /** Get top affinity class for display */
  getTopAffinity(player) {
    const s = StorageManager.forPlayer(player);
    let topClass = null;
    let topXP = 0;

    for (const cls of CLASSES) {
      const xp = s.getNumber(`aff_${cls.abbr}`, 0);
      if (xp > topXP) {
        topXP = xp;
        topClass = cls;
      }
    }

    if (!topClass) return null;

    const stage = this.getStage(topXP);
    return {
      className: topClass.name,
      stageName: STAGE_NAMES[stage],
      stageColor: STAGE_COLORS[stage],
      xp: topXP,
      boost: STAGE_BOOST[stage],
    };
  }

  /** Show affinity overview */
  showOverview(player) {
    const s = StorageManager.forPlayer(player);
    let msg = "\n§e§l✦ Class Affinities ✦§r\n";
    for (const cls of CLASSES) {
      const xp = s.getNumber(`aff_${cls.abbr}`, 0);
      const stage = this.getStage(xp);
      const color = STAGE_COLORS[stage];
      const name = STAGE_NAMES[stage];
      const boost = STAGE_BOOST[stage];
      const boostStr = boost > 0 ? ` §a+${boost}%` : "";
      msg += `${color}${cls.icon} ${cls.name}: ${name}${boostStr} §8(${(xp / 1000000).toFixed(1)}M)\n`;
    }
    player.sendMessage(msg);
  }

  // Reset all 14 daily affinity caps at dawn
  dailyReset() {
    for (const player of world.getAllPlayers()) {
      const s = StorageManager.forPlayer(player);
      for (const cls of CLASSES) {
        s.setNumber(`daff_${cls.abbr}`, 0);
      }
    }
  }
}
