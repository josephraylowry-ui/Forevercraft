/**
 * Luck Buffs System — Dynamic Dream Rate modifiers from time, weather, moon, enchants.
 * Purely attribute-based. Runs every 20 ticks (1 second).
 * Replaces Java luck_buffs/ folder.
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Tool type sets for conditional buffs
const FISHING_RODS = new Set(["minecraft:fishing_rod", "forevercraft:lucky_rod"]);
const MINING_TOOLS = new Set([
  "minecraft:wooden_pickaxe", "minecraft:stone_pickaxe", "minecraft:iron_pickaxe",
  "minecraft:golden_pickaxe", "minecraft:diamond_pickaxe", "minecraft:netherite_pickaxe",
  "minecraft:wooden_hoe", "minecraft:stone_hoe", "minecraft:iron_hoe",
  "minecraft:golden_hoe", "minecraft:diamond_hoe", "minecraft:netherite_hoe",
  "minecraft:wooden_axe", "minecraft:stone_axe", "minecraft:iron_axe",
  "minecraft:golden_axe", "minecraft:diamond_axe", "minecraft:netherite_axe",
  "minecraft:wooden_shovel", "minecraft:stone_shovel", "minecraft:iron_shovel",
  "minecraft:golden_shovel", "minecraft:diamond_shovel", "minecraft:netherite_shovel",
  "forevercraft:hoe_of_honor",
]);
const SWORDS = new Set([
  "minecraft:wooden_sword", "minecraft:stone_sword", "minecraft:iron_sword",
  "minecraft:golden_sword", "minecraft:diamond_sword", "minecraft:netherite_sword",
]);

// Luck enchantments to check
const LUCK_ENCHANTS = ["fortune", "looting", "luck_of_the_sea"];

export class LuckBuffSystem {
  constructor(eventBridge, moonSystem) {
    this.eventBridge = eventBridge;
    this.moonSystem = moonSystem;
  }

  /**
   * Tick — runs every 20 ticks (1 second). Applies/removes luck modifiers.
   */
  tick(players) {
    const dayTime = world.getTimeOfDay(); // 0-24000
    const isNight = dayTime >= 13000 && dayTime < 23000;
    const isMorning = dayTime >= 0 && dayTime < 6000;
    const isNoon = dayTime >= 6000 && dayTime < 13000;

    // Weather check
    let isRaining = false;
    try {
      const dim = world.getDimension("overworld");
      // Use command-based check since weather API may not be available
      isRaining = false; // Will rely on weather events when available
    } catch {}

    // Moon phase
    const moonPhase = this.moonSystem?.getPhase?.() ?? ((globalThis._fc_daylight?.getDay?.() ?? 0) % 8);
    const isFullMoon = moonPhase === 0;
    const isNewMoon = moonPhase === 4;
    const isHarvestMoon = this.moonSystem?.isHarvestMoon?.() ?? false;

    for (const player of players) {
      if (player.getGameMode() === "creative" || player.getGameMode() === "spectator") continue;
      this.applyBuffs(player, {
        dayTime, isNight, isMorning, isNoon,
        isRaining, isFullMoon, isNewMoon, isHarvestMoon,
      });
    }
  }

  /**
   * Apply luck buffs for a single player.
   */
  applyBuffs(player, ctx) {
    const storage = StorageManager.forPlayer(player);
    let totalBonus = 0;

    // Get mainhand item
    let mainhandType = "";
    try {
      const equip = player.getComponent("minecraft:equippable");
      const mainhand = equip?.getEquipment("Mainhand");
      mainhandType = mainhand?.typeId || "";
    } catch {}

    const hasFishingRod = FISHING_RODS.has(mainhandType);
    const hasMiningTool = MINING_TOOLS.has(mainhandType);
    const hasSword = SWORDS.has(mainhandType);

    // === Time-of-Day Buffs ===
    if (ctx.isMorning && hasFishingRod) {
      totalBonus += 0.5; // Morning Fishing
    }
    if (ctx.isNoon && hasMiningTool) {
      totalBonus += 1.0; // Noon Harvest
    }
    if (ctx.isNight && hasSword) {
      totalBonus += 0.5; // Night Mob Loot
    }

    // === Moon Phase Buffs ===
    if (ctx.isFullMoon && ctx.isNight && hasFishingRod) {
      totalBonus += 0.5; // Full Moon Fishing
    }
    if (ctx.isNewMoon && ctx.isNight && hasSword) {
      totalBonus += 0.5; // New Moon Mob Loot
    }

    // === Harvest Moon (universal) ===
    if (ctx.isHarvestMoon) {
      totalBonus += 1.5;
    }

    // === Weather Buff ===
    if (ctx.isRaining && hasFishingRod) {
      totalBonus += 0.5; // Rain Fishing
    }

    // === Enchantment Dream Rate ===
    let enchantBonus = 0;
    try {
      const equip = player.getComponent("minecraft:equippable");
      const mainhand = equip?.getEquipment("Mainhand");
      if (mainhand) {
        const enchComp = mainhand.getComponent("minecraft:enchantable");
        if (enchComp) {
          for (const enchName of LUCK_ENCHANTS) {
            const ench = enchComp.getEnchantment(enchName);
            if (ench && ench.level > enchantBonus) {
              enchantBonus = ench.level;
            }
          }
        }
      }
    } catch {}
    if (enchantBonus > 0) {
      totalBonus += Math.min(enchantBonus * 0.25, 2.5);
    }

    // === Luck Potion Bonus (using absorption as Bedrock proxy for luck) ===
    try {
      const luckEffect = player.getEffect("absorption");
      if (luckEffect) {
        totalBonus += luckEffect.amplifier + 1;
      }
    } catch {}

    // Store the calculated luck bonus
    storage.set("luck_bonus", totalBonus);

    // Also store total effective DR for other systems
    const baseDR = storage.getNumber("dream_rate", 0);
    const cnBonus = storage.getNumber("cn_dr_bonus", 0);
    const hsatchBonus = storage.getNumber("hsatch_luck", 0);
    const effectiveDR = baseDR + cnBonus + hsatchBonus + totalBonus;
    storage.set("effective_dr", effectiveDR);
  }
}
