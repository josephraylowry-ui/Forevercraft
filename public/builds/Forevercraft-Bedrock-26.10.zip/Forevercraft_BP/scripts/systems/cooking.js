/**
 * Cooking System — 7 recipe categories, 3 quality tiers, seasonal ingredients,
 * mastery progression, Well-Fed buff, prestige perks.
 * Replaces Java cooking/ folder.
 */
import { world, system, EffectTypes } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// OPT: Pre-cached effect types for cooking buff tick
const _CFX = {
  saturation: EffectTypes.get("saturation"),
  luck: EffectTypes.get("absorption"),
};
import { ActionFormData } from "@minecraft/server-ui";

// ─── RECIPE CATEGORIES ─────────────────────────────────────
const CATEGORIES = [
  { id: "combat", name: "Combat Cuisine", color: "§c", icon: "⚔" },
  { id: "mining", name: "Mining Meals", color: "§e", icon: "⛏" },
  { id: "fortune", name: "Fortune Foods", color: "§a", icon: "☘" },
  { id: "wayfarer", name: "Wayfarer Fare", color: "§b", icon: "🧭" },
  { id: "delicacy", name: "Delicacies", color: "§d", icon: "✦" },
  { id: "seasonal", name: "Seasonal Specials", color: "§6", icon: "☀" },
  { id: "treats", name: "Companion Treats", color: "§e", icon: "🍖" },
];

// Quality tiers
const TIERS = [
  { id: "hearty", name: "Hearty", color: "§f", durationMult: 1, wellFedDur: 60 },
  { id: "gourmet", name: "Gourmet", color: "§b", durationMult: 2, wellFedDur: 120 },
  { id: "feast", name: "Feast", color: "§5", durationMult: 3, wellFedDur: 180 },
];

// ─── RECIPES ────────────────────────────────────────────────
const RECIPES = {
  combat: [
    { name: "Warrior's Stew", ingredients: ["cooked_beef", "potato"], effect: "strength", amp: 0 },
    { name: "Battle Roast", ingredients: ["cooked_beef", "blaze_powder", "carrot"], effect: "strength", amp: 1 },
    { name: "Conqueror's Feast", ingredients: ["cooked_beef", "golden_carrot", "blaze_powder"], effect: "strength", amp: 1, extra: "resistance" },
    { name: "Berserker's Brew", ingredients: ["spider_eye", "blaze_powder"], effect: "strength", amp: 0 },
    { name: "Iron Rations", ingredients: ["cooked_porkchop", "bread"], effect: "strength", amp: 0 },
    { name: "Champion's Plate", ingredients: ["cooked_beef", "golden_apple", "bread"], effect: "strength", amp: 1, extra: "absorption" },
  ],
  mining: [
    { name: "Miner's Gruel", ingredients: ["cooked_beef", "glow_berries"], effect: "haste", amp: 0 },
    { name: "Deeprock Stew", ingredients: ["cooked_beef", "glow_berries", "golden_carrot"], effect: "haste", amp: 1 },
    { name: "Spelunker's Feast", ingredients: ["cooked_beef", "glow_berries", "golden_carrot"], effect: "haste", amp: 1, extra: "night_vision" },
    { name: "Torchlight Soup", ingredients: ["glow_berries", "carrot"], effect: "night_vision", amp: 0 },
    { name: "Cavern Porridge", ingredients: ["mushroom_stew", "bread"], effect: "haste", amp: 0 },
    { name: "Subterranean Steak", ingredients: ["cooked_beef", "brown_mushroom", "glow_berries"], effect: "haste", amp: 0, extra: "night_vision" },
  ],
  fortune: [
    { name: "Lucky Biscuit", ingredients: ["wheat", "sugar"], effect: "absorption", amp: 0 },
    { name: "Golden Delight", ingredients: ["golden_carrot", "sugar", "wheat"], effect: "absorption", amp: 1 },
    { name: "Fortune's Banquet", ingredients: ["golden_apple", "golden_carrot", "sugar"], effect: "absorption", amp: 2 },
    { name: "Emerald Tea", ingredients: ["emerald", "sugar"], effect: "absorption", amp: 0 },
    { name: "Treasure Truffle", ingredients: ["cocoa_beans", "golden_carrot"], effect: "absorption", amp: 1 },
    { name: "Wish Cake", ingredients: ["golden_apple", "wheat", "egg"], effect: "absorption", amp: 2 },
  ],
  wayfarer: [
    { name: "Traveler's Ration", ingredients: ["dried_kelp", "bread"], effect: "speed", amp: 0 },
    { name: "Pathfinder's Pie", ingredients: ["cooked_rabbit", "carrot", "wheat"], effect: "speed", amp: 1, extra: "jump_boost" },
    { name: "Windstrider's Feast", ingredients: ["cooked_rabbit", "golden_carrot", "sugar"], effect: "speed", amp: 1, extra: "jump_boost" },
    { name: "Scout's Snack", ingredients: ["cooked_chicken", "sweet_berries"], effect: "speed", amp: 0 },
    { name: "Nomad's Bowl", ingredients: ["cooked_mutton", "potato"], effect: "speed", amp: 0 },
    { name: "Horizon Cake", ingredients: ["cooked_rabbit", "sugar", "wheat"], effect: "speed", amp: 1 },
  ],
  delicacy: [
    { name: "Gentle Broth", ingredients: ["cooked_chicken", "carrot"], effect: "regeneration", amp: 0 },
    { name: "Restorative Soup", ingredients: ["cooked_chicken", "golden_carrot", "beetroot"], effect: "regeneration", amp: 1, extra: "absorption" },
    { name: "Healing Banquet", ingredients: ["golden_apple", "cooked_salmon", "golden_carrot"], effect: "regeneration", amp: 1, extra: "absorption" },
    { name: "Elderberry Wine", ingredients: ["sweet_berries", "sugar"], effect: "absorption", amp: 0 },
    { name: "Ambrosia", ingredients: ["honey_bottle", "golden_carrot"], effect: "regeneration", amp: 0, extra: "absorption" },
    { name: "Celestial Nectar", ingredients: ["golden_apple", "honey_bottle", "glow_berries"], effect: "regeneration", amp: 1, extra: "absorption" },
  ],
  seasonal: {
    // Spring (season 2)
    spring: [
      { name: "Blossom Tea", ingredients: ["sweet_berries", "sugar"], effect: "regeneration", amp: 0 },
      { name: "Spring Roll", ingredients: ["carrot", "wheat", "sweet_berries"], effect: "speed", amp: 0 },
      { name: "Meadow Pie", ingredients: ["wheat", "honey_bottle", "egg"], effect: "saturation", amp: 0 },
      { name: "Garden Salad", ingredients: ["carrot", "beetroot", "potato"], effect: "regeneration", amp: 0, extra: "saturation" },
    ],
    // Summer (season 3)
    summer: [
      { name: "Chilled Melon Drink", ingredients: ["melon_slice", "snowball", "sugar"], effect: "speed", amp: 0 },
      { name: "Grilled Fish Platter", ingredients: ["cooked_cod", "cooked_salmon", "blaze_powder"], effect: "strength", amp: 0 },
      { name: "Tropical Smoothie", ingredients: ["chorus_fruit", "melon_slice", "glow_berries"], effect: "regeneration", amp: 1 },
      { name: "Sun-Dried Jerky", ingredients: ["cooked_beef", "blaze_powder", "sugar"], effect: "resistance", amp: 0 },
    ],
    // Autumn (season 0)
    autumn: [
      { name: "Pumpkin Soup", ingredients: ["pumpkin", "sugar", "wheat"], effect: "absorption", amp: 1 },
      { name: "Harvest Stew", ingredients: ["cooked_beef", "potato", "carrot"], effect: "strength", amp: 0, extra: "saturation" },
      { name: "Mushroom Risotto", ingredients: ["brown_mushroom", "red_mushroom", "wheat"], effect: "saturation", amp: 0 },
      { name: "Apple Crumble", ingredients: ["apple", "wheat", "sugar"], effect: "regeneration", amp: 0 },
    ],
    // Winter (season 1)
    winter: [
      { name: "Hot Cocoa", ingredients: ["cocoa_beans", "sugar", "milk_bucket"], effect: "fire_resistance", amp: 0 },
      { name: "Frost Stew", ingredients: ["cooked_cod", "snowball", "potato"], effect: "resistance", amp: 0 },
      { name: "Polar Bear Roast", ingredients: ["cooked_beef", "snowball", "blaze_powder"], effect: "strength", amp: 1 },
      { name: "Warming Broth", ingredients: ["cooked_chicken", "carrot", "snowball"], effect: "regeneration", amp: 0, extra: "fire_resistance" },
    ],
  },
  treats: [
    { name: "Honey Cake", ingredients: ["honey_bottle", "wheat"], rpGain: 150 },
    { name: "Meadow Biscuit", ingredients: ["wheat", "sweet_berries"], rpGain: 100 },
    { name: "Golden Morsel", ingredients: ["golden_carrot", "wheat"], rpGain: 200 },
    { name: "Savory Bone Broth", ingredients: ["bone", "cooked_beef"], rpGain: 120 },
    { name: "Berry Delight", ingredients: ["sweet_berries", "glow_berries", "sugar"], rpGain: 180 },
    { name: "Feast Biscuit", ingredients: ["golden_apple", "wheat", "honey_bottle"], rpGain: 300 },
  ],
};

// Mastery milestones
const MASTERY_MILESTONES = [
  { count: 10, title: "Apprentice", color: "§a" },
  { count: 25, title: "Journeyman", color: "§b" },
  { count: 50, title: "Expert", color: "§6" },
  { count: 100, title: "Master Chef", color: "§d" },
];

const SEASON_NAMES = ["autumn", "winter", "spring", "summer"];

// Seasonal ingredient scarcity — certain ingredients cost double outside their season
const SEASONAL_INGREDIENTS = {
  spring: ["sweet_berries", "honey_bottle", "egg"],
  summer: ["melon_slice", "chorus_fruit", "cooked_cod", "cooked_salmon"],
  autumn: ["pumpkin", "apple", "brown_mushroom", "red_mushroom"],
  winter: ["snowball", "cocoa_beans", "milk_bucket"],
};

export class CookingSystem {
  constructor() {
    // No event dependencies
  }

  /** Check if an ingredient is scarce this season (costs 2x) */
  isIngredientScarce(ingredient) {
    const seasonId = StorageManager.world().getNumber("season_id", 0);
    const currentSeason = SEASON_NAMES[seasonId] || "autumn";
    // Ingredient is scarce if it belongs to a DIFFERENT season
    for (const [season, items] of Object.entries(SEASONAL_INGREDIENTS)) {
      if (season !== currentSeason && items.includes(ingredient)) return true;
    }
    return false;
  }

  // ─── GUI ──────────────────────────────────────────────────

  async openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const totalCooked = s.getNumber("ck_total", 0);

    const form = new ActionFormData()
      .title("§6✦ Campfire Kitchen ✦")
      .body(`§7Total meals cooked: §f${totalCooked}\n§7Select a category:`);

    for (const cat of CATEGORIES) {
      const mastery = s.getNumber(`ck_m_${cat.id}`, 0);
      form.button(`${cat.color}${cat.icon} ${cat.name}\n§7Mastery: ${mastery}`);
    }

    form.show(player).then(response => {
      if (response.canceled) return;
      const cat = CATEGORIES[response.selection];
      if (cat) this.showCategoryRecipes(player, cat);
    });
  }

  showCategoryRecipes(player, category) {
    const s = StorageManager.forPlayer(player);

    let recipes;
    if (category.id === "seasonal") {
      const seasonId = StorageManager.world().getNumber("season_id", 0);
      const seasonName = SEASON_NAMES[seasonId] || "autumn";
      recipes = RECIPES.seasonal[seasonName] || [];
    } else {
      recipes = RECIPES[category.id] || [];
    }

    if (!recipes || recipes.length === 0) {
      player.sendMessage("§7No recipes available.");
      return;
    }

    const discovered = s.getNumber(`ck_disc_${category.id}`, 1); // bitfield, slot 0 always discovered

    const form = new ActionFormData()
      .title(`${category.color}${category.name}`)
      .body("§7Select a recipe to cook:");

    for (let i = 0; i < recipes.length; i++) {
      const isDiscovered = (discovered & (1 << i)) !== 0;
      if (isDiscovered) {
        form.button(`§e${recipes[i].name}\n§7${this.getIngredientList(recipes[i])}`);
      } else {
        form.button("§8??? Unknown Recipe\n§7Cook more to discover!");
      }
    }

    form.show(player).then(response => {
      if (response.canceled) return;
      const idx = response.selection;
      if (idx >= 0 && idx < recipes.length) {
        const isDiscovered = (discovered & (1 << idx)) !== 0;
        if (isDiscovered) {
          this.showTierSelect(player, category, recipes[idx], idx);
        }
      }
    });
  }

  showTierSelect(player, category, recipe, slotIdx) {
    const form = new ActionFormData()
      .title(`§e${recipe.name}`)
      .body(`§7Choose quality tier:\n§7Ingredients: ${this.getIngredientList(recipe)}`);

    for (const tier of TIERS) {
      const dur = (recipe.effect ? 60 * tier.durationMult : 0);
      form.button(`${tier.color}${tier.name}\n§7Duration: ${dur}s | Well-Fed: ${tier.wellFedDur}s`);
    }

    form.show(player).then(response => {
      if (response.canceled) return;
      const tier = TIERS[response.selection];
      if (tier) this.cook(player, category, recipe, tier, slotIdx);
    });
  }

  getIngredientList(recipe) {
    return (recipe.ingredients || []).map(i => {
      const name = i.replace(/_/g, " ");
      return this.isIngredientScarce(i) ? `${name} §c(x2)` : name;
    }).join(" + ");
  }

  // ─── COOKING LOGIC ────────────────────────────────────────

  cook(player, category, recipe, tier, slotIdx) {
    const s = StorageManager.forPlayer(player);

    // Check ingredients (simplified — check inventory for items)
    const inv = player.getComponent("minecraft:inventory");
    if (!inv) return;
    const container = inv.container;

    const missing = [];
    for (const ing of recipe.ingredients) {
      const needed = this.isIngredientScarce(ing) ? 2 : 1;
      let count = 0;
      for (let i = 0; i < container.size; i++) {
        const item = container.getItem(i);
        if (item && item.typeId === `minecraft:${ing}`) {
          count += item.amount;
        }
      }
      if (count < needed) missing.push(`${ing.replace(/_/g, " ")}${needed > 1 ? " (x2 — scarce)" : ""}`);
    }

    if (missing.length > 0) {
      player.sendMessage(`§cMissing ingredients: §f${missing.join(", ")}`);
      return;
    }

    // Prestige P2: Double Portion — 15% chance to preserve ingredients
    const hasDoublePortion = s.getNumber("adv_pa_culi2", 0) >= 1;
    const preserved = hasDoublePortion && Math.random() < 0.15;

    // Consume ingredients (unless preserved) — scarce ingredients cost 2x
    if (!preserved) {
      for (const ing of recipe.ingredients) {
        const amount = this.isIngredientScarce(ing) ? 2 : 1;
        try {
          player.runCommandAsync(`clear @s minecraft:${ing} 0 ${amount}`);
        } catch {}
      }
    } else {
      player.sendMessage("§a§l[Double Portion] §r§7Ingredients preserved!");
    }

    // Apply effects
    const hasCulinaryMastery = s.getNumber("adv_pa_culi3", 0) >= 1;
    const durMult = hasCulinaryMastery ? 2 : 1;
    const baseDur = 60 * tier.durationMult * durMult;

    if (recipe.effect) {
      try { player.runCommandAsync(`effect @s ${recipe.effect} ${baseDur} ${recipe.amp || 0} true`); } catch {}
      if (recipe.extra) {
        try { player.runCommandAsync(`effect @s ${recipe.extra} ${baseDur} 0 true`); } catch {}
      }
    }

    // Treat: RP gain for companions
    if (recipe.rpGain) {
      s.set("ck_treat_rp", recipe.rpGain);
      player.sendMessage(`§e§l✦ ${recipe.name} §r§7cooked! +${recipe.rpGain} Companion RP`);
    }

    // Well-Fed buff
    s.set("ck_wellfed", tier.wellFedDur);
    try { player.addEffect(_CFX.saturation, 60, { amplifier: 0, showParticles: false }); } catch {} // initial saturation burst

    // Fortune meal (luck category)
    if (category.id === "fortune") {
      const fortuneDur = tier.wellFedDur;
      s.set("ck_fortune", fortuneDur);
    }

    // Discovery
    const discKey = `ck_disc_${category.id}`;
    const disc = s.getNumber(discKey, 1);
    if ((disc & (1 << slotIdx)) === 0) {
      s.set(discKey, disc | (1 << slotIdx));
      player.sendMessage(`§6§l✦ Recipe Discovered: §r§e${recipe.name}`);
      // Discover next slot
      if (slotIdx + 1 < 6) {
        const newDisc = s.getNumber(discKey, 1) | (1 << (slotIdx + 1));
        s.set(discKey, newDisc);
      }
    }

    // Mastery tracking
    const masteryKey = `ck_m_${category.id}`;
    const mastery = s.getNumber(masteryKey, 0) + 1;
    s.set(masteryKey, mastery);
    s.set("ck_total", s.getNumber("ck_total", 0) + 1);

    // Check mastery milestones
    for (const m of MASTERY_MILESTONES) {
      if (mastery === m.count) {
        player.sendMessage(`${m.color}§l✦ ${category.name} Mastery: ${m.title}!`);
        player.playSound("random.levelup");
      }
    }

    player.sendMessage(`§a§l✦ §r§7Cooked §e${recipe.name} §7(${tier.name})!`);
    player.playSound("block.campfire.crackle");
  }

  // ─── BUFF TICK (called every 1 second) ────────────────────

  tickBuffs(player) {
    const s = StorageManager.forPlayer(player);

    // Well-Fed timer
    let wellFed = s.getNumber("ck_wellfed", 0);
    if (wellFed > 0) {
      s.set("ck_wellfed", wellFed - 1);
      // Apply +0.5 DR equivalent via saturation refresh
      try { player.addEffect(_CFX.saturation, 60, { amplifier: 0, showParticles: false }); } catch {}
      if (wellFed - 1 <= 0) {
        player.sendMessage("§7Well-Fed effect has worn off.");
      }
    }

    // Fortune timer
    let fortune = s.getNumber("ck_fortune", 0);
    if (fortune > 0) {
      s.set("ck_fortune", fortune - 1);
      try { player.addEffect(_CFX.luck, 60, { amplifier: 1, showParticles: false }); } catch {}
      if (fortune - 1 <= 0) {
        player.sendMessage("§7Fortune meal effect has worn off.");
      }
    }
  }

  // =====================================================
  // CHEF'S TOUCH MINIGAME (3-Phase Cooking)
  // =====================================================

  /**
   * Start the Chef's Touch minigame for a recipe.
   * Phases: 1=Chop (timing), 2=Simmer (gauge), 3=Plate (precision)
   */
  async startMinigame(player, recipe, tier) {
    const s = StorageManager.forPlayer(player);
    s.set("ck_phase", 1);
    s.set("ck_quality", 0);
    s.set("ck_tier", tier);

    player.sendMessage("\n§e§l✦ Chef's Touch! ✦§r");
    player.sendMessage("§7Three phases determine your dish quality.\n");

    // Phase 1: Chop
    const chopQuality = await this.phaseChop(player, tier);
    s.set("ck_quality", chopQuality);

    // Phase 2: Simmer
    const simmerQuality = await this.phaseSimmer(player, tier);
    s.set("ck_quality", s.getNumber("ck_quality", 0) + simmerQuality);

    // Phase 3: Plate
    const plateQuality = await this.phasePlate(player, tier);
    const totalQuality = s.getNumber("ck_quality", 0) + plateQuality;

    // Home kitchen bonus
    const homeBonus = player.hasTag("ec.in_home") ? 1 : 0;
    const finalQuality = totalQuality + homeBonus;

    // Resolve
    this.resolveMinigame(player, recipe, finalQuality);
  }

  async phaseChop(player, tier) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    const chopsNeeded = 2 + tier; // 3-5
    const sweetMin = 40 - tier * 2;
    const sweetMax = 60 + tier * 2;

    player.sendMessage("§e§lPhase 1: CHOP §r§7— Time your cuts in the sweet zone!");

    // Simplified for Bedrock: prompt with timing feedback
    let quality = 0;
    for (let i = 0; i < chopsNeeded; i++) {
      const form = new ActionFormData()
        .title(`§eChop! (${i + 1}/${chopsNeeded})`)
        .body(`§7Click when ready!\n§aSweet zone: ${sweetMin}-${sweetMax}`)
        .button("§e§l✦ CHOP! ✦");

      const res = await form.show(player);
      if (res.canceled) return quality;

      // Simulate timing (random success based on zone width)
      const zoneWidth = sweetMax - sweetMin;
      const hitChance = zoneWidth / 100;
      if (Math.random() < hitChance) {
        quality++;
        player.sendMessage(`§a✓ Good chop! §7(+1 quality)`);
        try { player.playSound("random.click", { volume: 0.5, pitch: 1.5 }); } catch {}
      } else {
        player.sendMessage("§c✗ Missed the zone!");
        try { player.playSound("note.bass", { volume: 0.3, pitch: 0.5 }); } catch {}
      }
    }
    return quality;
  }

  async phaseSimmer(player, tier) {
    const { ActionFormData } = await import("@minecraft/server-ui");

    player.sendMessage("\n§c§lPhase 2: SIMMER §r§7— Keep the temperature in the safe zone!");

    // Simplified: 3 decision points
    let inZone = 0;
    const rounds = 3;

    for (let i = 0; i < rounds; i++) {
      const temp = 20 + Math.floor(Math.random() * 60); // 20-80
      const inSafe = temp >= 40 && temp <= 60;
      const action = inSafe ? "maintain" : (temp < 40 ? "stoke" : "cool");

      const form = new ActionFormData()
        .title(`§cSimmer (${i + 1}/${rounds})`)
        .body(`§7Temperature: §f${temp}°\n§aSafe zone: 40-60°\n\n§7${temp < 40 ? "Too cold!" : temp > 60 ? "Too hot!" : "Perfect temperature!"}`)
        .button("§c🔥 Stoke (heat up)")
        .button("§b❄ Cool (cool down)")
        .button("§a✓ Maintain");

      const res = await form.show(player);
      if (res.canceled) return inZone;

      // Check if player chose correctly
      const correctAction = temp < 40 ? 0 : temp > 60 ? 1 : 2;
      if (res.selection === correctAction) {
        inZone++;
        player.sendMessage("§a✓ Good control!");
      } else if (inSafe) {
        inZone++; // Any choice is fine in safe zone
        player.sendMessage("§a✓ Temperature stable.");
      } else {
        player.sendMessage("§c✗ Temperature drifted!");
      }
    }

    // Score: 0-4 based on control
    if (inZone >= 3) return 4;
    if (inZone >= 2) return 2;
    if (inZone >= 1) return 1;
    return 0;
  }

  async phasePlate(player, tier) {
    const { ActionFormData } = await import("@minecraft/server-ui");

    player.sendMessage("\n§b§lPhase 3: PLATE §r§7— Click at the perfect moment!");

    const form = new ActionFormData()
      .title("§bPlate!")
      .body("§7The wave is rising...\n§7Click §lnow§r§7 for perfect plating!\n\n§a§lGolden zone: 62-78")
      .button("§b§l✦ PLATE! ✦");

    const res = await form.show(player);
    if (res.canceled) return 0;

    // Simulate timing precision
    const roll = Math.floor(Math.random() * 100);
    const dist = Math.abs(roll - 70); // Center is 70

    if (dist <= 3) {
      player.sendMessage("§6§l✦ PERFECT! ✦§r §7(+4 quality)");
      try { player.playSound("random.levelup", { volume: 0.5, pitch: 1.5 }); } catch {}
      return 4;
    } else if (dist <= 8) {
      player.sendMessage("§a✓ Good plating! §7(+2 quality)");
      return 2;
    } else if (dist <= 15) {
      player.sendMessage("§e~ Close! §7(+1 quality)");
      return 1;
    } else {
      player.sendMessage("§c✗ Sloppy plating.");
      return 0;
    }
  }

  resolveMinigame(player, recipe, quality) {
    let grade, gradeColor;
    if (quality >= 12) { grade = "MASTERWORK"; gradeColor = "§6"; }
    else if (quality >= 8) { grade = "FLAVORFUL"; gradeColor = "§a"; }
    else if (quality >= 4) { grade = "BLAND"; gradeColor = "§7"; }
    else { grade = "CHARRED"; gradeColor = "§8"; }

    player.sendMessage(`\n§e§l✦ Cooking Complete! ✦§r`);
    player.sendMessage(`${gradeColor}§l${grade} §r§7— Quality: ${quality}`);
    player.sendMessage(`§7Dish: §f${recipe.name}`);

    // Award based on quality
    const s = StorageManager.forPlayer(player);
    const mastery = s.getNumber(`ck_mastery_${recipe.category}`, 0);
    const masteryGain = quality >= 12 ? 4 : quality >= 8 ? 2 : 1;
    s.set(`ck_mastery_${recipe.category}`, mastery + masteryGain);

    // Discovery tracking
    const discKey = `ck_disc_${recipe.id}`;
    if (!s.get(discKey)) {
      s.set(discKey, true);
      player.sendMessage(`§d✦ New Recipe Discovered: §f${recipe.name}`);
    }

    // Apply buff (quality >= 4 gives Well-Fed)
    if (quality >= 4) {
      const buffDuration = quality >= 12 ? 180 : quality >= 8 ? 120 : 60;
      s.set("ck_wellfed", buffDuration);
      player.sendMessage(`§aWell-Fed for ${buffDuration}s!`);
    }

    player.playSound(quality >= 12 ? "random.levelup" : "random.orb", { volume: 0.7, pitch: 1.0 });
    this.eventBridge.emit("cook_complete", { player, recipe, quality, grade });
    this.eventBridge.emit("meal_cooked", { player }); // Spirit Tome quest tracking
  }
}
