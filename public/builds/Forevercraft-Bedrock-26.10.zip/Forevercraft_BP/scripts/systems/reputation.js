/**
 * Reputation System (Reaper) — Dual-axis morality tracking.
 * Replaces Java reaper/ folder (~30 files).
 *
 * Two axes: Infamy (villain, 0-5000) and Renown (peacemonger, 0-5000)
 * 11 tiers: -5 (Villain) to +5 (Peacemonger), 0 = Neutral
 *
 * Infamy sources: player kills (+150), villager kills (+100), golem kills (+50)
 * Renown sources: trades (+10, 100/day cap), quests (+50-300), bounties (+100), bosses (+200), raids (+300)
 * Decay: both axes -12 per 60 seconds (~7 in-game days to zero from 5000)
 *
 * Villain effects (infamy ≥ 1000): hunting party spawns
 * Villain effects (infamy ≥ 2000): iron golem aggro
 * Villain effects (infamy ≥ 3000): hostile mob pacification
 * Peacemonger effects (renown ≥ 1000): bandit encounters
 * Peacemonger effects (renown ≥ 2000): hero of the village buff
 */
import { world, system, EffectTypes } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const MAX_REP = 5000;
const DECAY_AMOUNT = 12;
const TRADE_DAILY_CAP = 100;
const TICK_INTERVAL = 1200; // 60 seconds

const TIERS = [
  { min: -5000, max: -4001, tier: -5, title: "§4Villain" },
  { min: -4000, max: -3001, tier: -4, title: "§4Outlaw" },
  { min: -3000, max: -2001, tier: -3, title: "§cCriminal" },
  { min: -2000, max: -1001, tier: -2, title: "§cRogue" },
  { min: -1000, max: -1,    tier: -1, title: "§6Troublemaker" },
  { min: 0,     max: 0,     tier: 0,  title: "§7Neutral" },
  { min: 1,     max: 1000,  tier: 1,  title: "§aSamaritan" },
  { min: 1001,  max: 2000,  tier: 2,  title: "§aGuardian" },
  { min: 2001,  max: 3000,  tier: 3,  title: "§2Protector" },
  { min: 3001,  max: 4000,  tier: 4,  title: "§2Champion" },
  { min: 4001,  max: 5000,  tier: 5,  title: "§bPeacemonger" },
];

export class ReputationSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Listen for relevant events
    eventBridge.on("player_killed_entity", (data) => this.onKill(data));
    eventBridge.on("quest_completed", (data) => this.onQuestComplete(data));
    eventBridge.on("bounty_completed", (data) => this.onBountyComplete(data));
    eventBridge.on("boss_killed", (data) => this.onBossKill(data));

    // Player kill tracking
    world.afterEvents.entityDie.subscribe((event) => {
      const victim = event.deadEntity;
      const killer = event.damageSource?.damagingEntity;
      if (!killer || killer.typeId !== "minecraft:player") return;

      if (victim.typeId === "minecraft:player") {
        // Player kill (skip if in duel)
        if (!killer.hasTag("ec.duel_active_tag")) {
          this.addInfamy(killer, 150);
        }
      } else if (victim.typeId === "minecraft:villager") {
        this.addInfamy(killer, 100);
      } else if (victim.typeId === "minecraft:iron_golem") {
        this.addInfamy(killer, 50);
      }
    });

    // Trade tracking
    world.afterEvents.playerInteractWithEntity.subscribe((event) => {
      if (event.target?.typeId === "minecraft:villager") {
        this.onTrade(event.player);
      }
    });
  }

  /** Add infamy points (villain deeds) */
  addInfamy(player, amount) {
    const s = StorageManager.forPlayer(player);
    const infamy = Math.min(MAX_REP, s.getNumber("rp_infamy", 0) + amount);
    s.set("rp_infamy", infamy);
    this.checkTierChange(player);
  }

  /** Add renown points (peacemonger deeds) */
  addRenown(player, amount) {
    const s = StorageManager.forPlayer(player);
    const renown = Math.min(MAX_REP, s.getNumber("rp_renown", 0) + amount);
    s.set("rp_renown", renown);
    this.checkTierChange(player);
  }

  onTrade(player) {
    const s = StorageManager.forPlayer(player);
    const today = s.getNumber("rp_trade_today", 0);
    if (today >= TRADE_DAILY_CAP) return;
    s.set("rp_trade_today", today + 1);
    this.addRenown(player, 10);
  }

  onQuestComplete(data) {
    if (!data.player) return;
    const tier = data.tier || 1;
    const renown = [50, 75, 100, 150, 200, 300][tier - 1] || 50;
    this.addRenown(data.player, renown);
  }

  onBountyComplete(data) {
    if (data.player) this.addRenown(data.player, 100);
  }

  onBossKill(data) {
    if (data.player) this.addRenown(data.player, 200);
  }

  onKill(data) {
    // Already handled by entityDie subscription above
  }

  /** Compute alignment tier from infamy/renown */
  computeTier(player) {
    const s = StorageManager.forPlayer(player);
    const infamy = s.getNumber("rp_infamy", 0);
    const renown = s.getNumber("rp_renown", 0);

    if (infamy < 1000 && renown < 1000) return 0;

    const net = renown - infamy;
    if (net >= 4001) return 5;
    if (net >= 3001) return 4;
    if (net >= 2001) return 3;
    if (net >= 1001) return 2;
    if (net >= 1) return 1;
    if (net <= -4001) return -5;
    if (net <= -3001) return -4;
    if (net <= -2001) return -3;
    if (net <= -1001) return -2;
    if (net <= -1) return -1;
    return 0;
  }

  /** Get tier title for display */
  getTierTitle(tier) {
    const entry = TIERS.find(t => t.tier === tier);
    return entry ? entry.title : "§7Neutral";
  }

  /** Check if tier changed and announce */
  checkTierChange(player) {
    const s = StorageManager.forPlayer(player);
    const oldTier = s.getNumber("rp_tier", 0);
    const newTier = this.computeTier(player);

    if (oldTier !== newTier) {
      s.set("rp_tier", newTier);
      const title = this.getTierTitle(newTier);
      player.sendMessage(`§e§lAlignment Changed! §r§7You are now: ${title}`);
      this.eventBridge.emit("alignment_changed", { player, tier: newTier, title });
    }
  }

  /** Main tick — decay + effects + spawn checks (every 60 seconds) */
  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);

      // Decay both axes
      const infamy = Math.max(0, s.getNumber("rp_infamy", 0) - DECAY_AMOUNT);
      const renown = Math.max(0, s.getNumber("rp_renown", 0) - DECAY_AMOUNT);
      s.set("rp_infamy", infamy);
      s.set("rp_renown", renown);

      // Recompute tier after decay
      this.checkTierChange(player);

      const tier = s.getNumber("rp_tier", 0);

      // === PEACEMONGER EFFECTS ===
      // Hero of the Village buff (tier +2 or higher)
      if (tier >= 2) {
        const amp = tier >= 4 ? 2 : tier >= 3 ? 1 : 0;
        try { player.addEffect("village_hero", 1400, { amplifier: amp, showParticles: false }); } catch {}
      }

      // === VILLAIN EFFECTS ===
      // Mob pacification (tier -3 / infamy >= 3000): hostiles ignore villain
      if (tier <= -3) {
        this.applyMobPacification(player);
      }

      // Iron golem aggro (tier -2 / infamy >= 2000)
      if (tier <= -2) {
        this.applyGolemAggro(player);
      }

      // === HUNTING PARTY SPAWNS (villains, infamy >= 1000) ===
      if (tier <= -1 && !s.get("rp_hunt_active")) {
        this.checkHuntingPartySpawn(player, infamy);
      }

      // === BANDIT SPAWNS (peacemongers, renown >= 1000) ===
      if (tier >= 1 && !s.get("rp_band_active")) {
        this.checkBanditSpawn(player, renown);
      }
    }
  }

  /** Mob Pacification — reduce aggro range of non-undead hostiles near villain */
  // OPT: Single entity query instead of 9 separate type queries
  static PACIFY_SET = new Set([
    "minecraft:creeper", "minecraft:spider", "minecraft:cave_spider",
    "minecraft:pillager", "minecraft:vindicator", "minecraft:evoker",
    "minecraft:witch", "minecraft:slime", "minecraft:magma_cube", "minecraft:hoglin",
  ]);

  applyMobPacification(player) {
    try {
      // One query for ALL entities within 32 blocks, then filter by type
      const allNearby = player.dimension.getEntities({
        location: player.location, maxDistance: 32,
        excludeTypes: ["minecraft:player", "minecraft:item", "minecraft:xp_orb"],
      });
      const weaknessEffect = EffectTypes.get("weakness");
      for (const mob of allNearby) {
        if (ReputationSystem.PACIFY_SET.has(mob.typeId)) {
          try { mob.addEffect(weaknessEffect, 80, { amplifier: 4, showParticles: false }); } catch {}
        }
      }
    } catch {}
  }

  /** Iron Golem Aggro — golems near villain become hostile */
  applyGolemAggro(player) {
    try {
      const golems = player.dimension.getEntities({
        type: "minecraft:iron_golem",
        location: player.location,
        maxDistance: 32,
      });
      for (const golem of golems) {
        if (golem.hasTag("ec.tame_protected")) continue; // Skip companion golems
        try {
          // Make golem angry at player via damage
          golem.runCommandAsync(`execute at @s run tp @s ~ ~ ~ facing ${player.location.x} ${player.location.y} ${player.location.z}`);
        } catch {}
      }
    } catch {}
  }

  /** Check if hunting party should spawn for villain */
  checkHuntingPartySpawn(player, infamy) {
    if (player.hasTag("hs.in_zone") || player.hasTag("ec.guild_in_zone")) return;
    if (player.dimension.id !== "minecraft:overworld") return;

    const s = StorageManager.forPlayer(player);
    const now = system.currentTick;
    const lastSpawn = s.getNumber("rp_hunt_last", 0);

    // Minimum wait based on infamy
    let minWait, chance;
    if (infamy >= 3501) { minWait = 72000; chance = 0.40; }
    else if (infamy >= 2001) { minWait = 108000; chance = 0.25; }
    else { minWait = 144000; chance = 0.15; }

    const elapsed = now - lastSpawn;
    if (elapsed < minWait) return;

    // Day 5 guarantee (360000 ticks)
    const guaranteed = elapsed >= 360000;

    if (guaranteed || Math.random() < chance) {
      this.spawnHuntingParty(player, infamy);
      s.set("rp_hunt_last", now);
      s.set("rp_hunt_active", true);
    }
  }

  /** Spawn a hunting party near the player */
  spawnHuntingParty(player, infamy) {
    const pos = player.location;
    const angle = Math.random() * Math.PI * 2;
    const dist = 15 + Math.random() * 10;
    const spawnPos = { x: pos.x + Math.cos(angle) * dist, y: pos.y, z: pos.z + Math.sin(angle) * dist };

    try {
      const dim = player.dimension;
      const count = infamy >= 3501 ? 4 : infamy >= 2001 ? 3 : 2;

      for (let i = 0; i < count; i++) {
        const offset = { x: spawnPos.x + (Math.random() * 3 - 1.5), y: spawnPos.y, z: spawnPos.z + (Math.random() * 3 - 1.5) };
        try {
          const hunter = dim.spawnEntity("minecraft:vindicator", offset);
          hunter.nameTag = i === 0 ? "§cBounty Captain" : "§cBounty Hunter";
          hunter.addTag("rp.hunter");
          hunter.addTag("rp.spawned");
        } catch {}
      }

      // Spawn iron golem for tier 2+
      if (infamy >= 2001) {
        try {
          const golem = dim.spawnEntity("minecraft:iron_golem", spawnPos);
          golem.nameTag = "§cIron Warden";
          golem.addTag("rp.hunter");
          golem.addTag("rp.spawned");
        } catch {}
      }

      player.sendMessage("§c§l⚔ Bounty Hunters approach! §r§7Your crimes have caught attention...");
      player.playSound("mob.vindicator.celebrate", { volume: 1.0, pitch: 0.8 });
    } catch {}
  }

  /** Check if bandits should spawn for peacemonger */
  checkBanditSpawn(player, renown) {
    if (player.hasTag("hs.in_zone") || player.hasTag("ec.guild_in_zone")) return;
    if (player.dimension.id !== "minecraft:overworld") return;

    const s = StorageManager.forPlayer(player);
    const now = system.currentTick;
    const lastSpawn = s.getNumber("rp_band_last", 0);

    let minWait, chance;
    if (renown >= 3501) { minWait = 72000; chance = 0.40; }
    else if (renown >= 2001) { minWait = 108000; chance = 0.25; }
    else { minWait = 144000; chance = 0.15; }

    const elapsed = now - lastSpawn;
    if (elapsed < minWait) return;

    const guaranteed = elapsed >= 360000;

    if (guaranteed || Math.random() < chance) {
      this.spawnBandits(player, renown);
      s.set("rp_band_last", now);
      s.set("rp_band_active", true);
    }
  }

  /** Spawn bandits near the player */
  spawnBandits(player, renown) {
    const pos = player.location;
    const angle = Math.random() * Math.PI * 2;
    const dist = 15 + Math.random() * 10;
    const spawnPos = { x: pos.x + Math.cos(angle) * dist, y: pos.y, z: pos.z + Math.sin(angle) * dist };

    try {
      const dim = player.dimension;
      const count = renown >= 3501 ? 3 : renown >= 2001 ? 3 : 2;

      for (let i = 0; i < count; i++) {
        const offset = { x: spawnPos.x + (Math.random() * 3 - 1.5), y: spawnPos.y, z: spawnPos.z + (Math.random() * 3 - 1.5) };
        try {
          const bandit = dim.spawnEntity("minecraft:pillager", offset);
          bandit.nameTag = i === 0 ? "§4Bandit Captain" : "§4Highwayman";
          bandit.addTag("rp.bandit");
          bandit.addTag("rp.spawned");
        } catch {}
      }

      // Spawn ravager for tier 1+
      try {
        const ravager = dim.spawnEntity("minecraft:ravager", spawnPos);
        ravager.nameTag = "§4War Beast";
        ravager.addTag("rp.bandit");
        ravager.addTag("rp.spawned");
      } catch {}

      player.sendMessage("§4§l⚔ Bandits approach! §r§7Your renown has attracted thieves...");
      player.playSound("mob.pillager.celebrate", { volume: 1.0, pitch: 0.8 });
    } catch {}
  }

  /** Get reputation display for a player */
  getDisplay(player) {
    const s = StorageManager.forPlayer(player);
    const infamy = s.getNumber("rp_infamy", 0);
    const renown = s.getNumber("rp_renown", 0);
    const tier = this.computeTier(player);
    const title = this.getTierTitle(tier);
    return { infamy, renown, tier, title };
  }

  /** Reset daily trade renown cap at dawn */
  dailyReset() {
    for (const player of world.getAllPlayers()) {
      const s = StorageManager.forPlayer(player);
      s.setNumber("rp_trade_today", 0);
    }
  }
}
