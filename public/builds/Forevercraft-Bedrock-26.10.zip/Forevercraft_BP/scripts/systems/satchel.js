/**
 * Satchel System — Inventory expansion bags with cosmetic effects.
 * Replaces Java satchel/ folder (94 files).
 * Players find satchels of different tiers that provide bag slots and effects.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const SATCHEL_TIERS = [
  { tier: 1, name: "Pouch", slots: 3, color: "§f" },
  { tier: 2, name: "Satchel", slots: 5, color: "§e" },
  { tier: 3, name: "Rucksack", slots: 7, color: "§b" },
  { tier: 4, name: "Pack", slots: 9, color: "§5" },
  { tier: 5, name: "Traveler's Bag", slots: 12, color: "§6" },
  { tier: 6, name: "Dimensional Satchel", slots: 15, color: "§c" },
];

// Cosmetic effects that can be applied to satchels
const SATCHEL_EFFECTS = [
  "Starfall Glow", "Ember Trail", "Frost Sparkle", "Nature's Bloom",
  "Shadow Wisp", "Ocean Shimmer", "Storm Crackle", "Void Pulse",
  "Golden Aura", "Crystal Haze", "Infernal Glow", "Lunar Beam",
  "Solar Flare", "Arcane Script", "Feathered Trail", "Mushroom Spore",
  "Honey Drip", "Prism Light", "Dragon Scale", "Wind Current",
];

export class SatchelSystem {
  constructor() {}

  /** Open satchel menu */
  openSatchelMenu(player) {
    const s = StorageManager.forPlayer(player);
    const bagTier = s.getNumber("satchel_tier");

    if (bagTier <= 0) {
      player.sendMessage("§7You don't have a satchel equipped.");
      return;
    }

    const tierData = SATCHEL_TIERS.find(t => t.tier === bagTier) || SATCHEL_TIERS[0];
    const slots = tierData.slots;
    const usedSlots = s.getNumber("satchel_used") || 0;

    const form = new ActionFormData()
      .title(`${tierData.color}${tierData.name}`)
      .body(`§7Storage: §f${usedSlots}/${slots} slots\n§7Tier: ${tierData.color}${tierData.name}\n\n§7Use your satchel to store overflow items.`)
      .button("§aStore Items")
      .button("§bRetrieve Items")
      .button("§eView Effects")
      .button("§cClose");

    form.show(player).then(response => {
      if (response.canceled) return;
      switch (response.selection) {
        case 0: this.storeItems(player); break;
        case 1: this.retrieveItems(player); break;
        case 2: this.viewEffects(player); break;
      }
    });
  }

  storeItems(player) {
    const s = StorageManager.forPlayer(player);
    const bagTier = s.getNumber("satchel_tier");
    const tierData = SATCHEL_TIERS.find(t => t.tier === bagTier);
    if (!tierData) return;

    const used = s.getNumber("satchel_used");
    if (used >= tierData.slots) {
      player.sendMessage("§c§lSatchel is full!");
      return;
    }

    // Store held item (simplified — actual implementation would need inventory management)
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (!mainhand) {
      player.sendMessage("§7Hold an item in your hand to store it.");
      return;
    }

    // Store item data in dynamic properties
    const slotKey = `satchel_slot_${used}`;
    s.set(slotKey, mainhand.typeId);
    s.set("satchel_used", used + 1);
    player.sendMessage(`§a§l✦ §r§7Stored ${mainhand.typeId} in satchel (${used + 1}/${tierData.slots})`);
    player.playSound("random.orb");
  }

  retrieveItems(player) {
    const s = StorageManager.forPlayer(player);
    const used = s.getNumber("satchel_used");
    if (used <= 0) {
      player.sendMessage("§7Satchel is empty.");
      return;
    }

    const form = new ActionFormData()
      .title("Retrieve Items")
      .body("Select an item to retrieve:");

    for (let i = 0; i < used; i++) {
      const itemId = s.get(`satchel_slot_${i}`) || "unknown";
      form.button(`§f${itemId}`);
    }

    form.show(player).then(response => {
      if (response.canceled) return;
      const slot = response.selection;
      const itemId = s.get(`satchel_slot_${slot}`);
      if (!itemId) return;

      try {
        player.runCommandAsync(`give @s ${itemId} 1`);
        // Shift remaining items down
        for (let i = slot; i < used - 1; i++) {
          s.set(`satchel_slot_${i}`, s.get(`satchel_slot_${i + 1}`));
        }
        s.set(`satchel_slot_${used - 1}`, "");
        s.set("satchel_used", used - 1);
        player.sendMessage(`§a§l✦ §r§7Retrieved ${itemId}`);
      } catch {}
    });
  }

  viewEffects(player) {
    const s = StorageManager.forPlayer(player);
    const effect = s.get("satchel_effect") || "None";
    player.sendMessage(`§6§lSatchel Effect: §r§e${effect}`);
  }

  /** Equip a satchel (called from item use or event) */
  equipSatchel(player, tier) {
    const s = StorageManager.forPlayer(player);
    s.set("satchel_tier", tier);
    const tierData = SATCHEL_TIERS.find(t => t.tier === tier);
    player.sendMessage(`${tierData?.color || "§f"}§l✦ ${tierData?.name || "Satchel"} §r§7equipped! (${tierData?.slots || 3} slots)`);
  }
}
