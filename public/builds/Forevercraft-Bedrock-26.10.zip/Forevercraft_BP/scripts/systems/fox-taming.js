/**
 * Fox & Ocelot Taming System — Makes foxes and ocelots tamable.
 * Replaces Java foxes/ (14 files) + ocelots/ (14 files) folders.
 *
 * Fox Mechanics:
 * - Feed sweet berries to wild fox: taming progress 1-5
 * - Feeds 3-4: 33% tame chance. Feed 5: guaranteed tame.
 * - Tamed foxes follow owner, sit on command (right-click empty hand)
 * - Teleport when >36 blocks, speed boost 18-36 blocks
 *
 * Ocelot Mechanics:
 * - Feed raw cod or salmon to wild ocelot: same 1-5 progress
 * - Same 33% at 3-4, guaranteed at 5
 * - Permanent Strength I (makes ocelots highest DPS tamed mob ~6 dmg/hit)
 * - Same sit/stand, follow, teleport as fox
 *
 * Both tagged ec.tame_protected for friendly-fire immunity.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const TAME_CHANCE_3_4 = 0.33;
const TELEPORT_DIST = 36;
const SPEED_DIST = 18;
const FOLLOW_TICK_INTERVAL = 5;

// Taming food mapping
const TAME_FOODS = {
  "minecraft:fox": ["minecraft:sweet_berries"],
  "minecraft:ocelot": ["minecraft:cod", "minecraft:salmon"],
};

// Progress messages per mob type
const PROGRESS_MSGS = {
  "minecraft:fox": [
    "The fox seems curious...",
    "The fox is warming up to you...",
    "The fox is starting to trust you...",
    "The fox is almost tamed!",
  ],
  "minecraft:ocelot": [
    "The ocelot watches you cautiously...",
    "The ocelot creeps a little closer...",
    "The ocelot is starting to trust you...",
    "The ocelot is almost tamed!",
  ],
};

export class FoxTamingSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    /** @type {Map<string, {ownerId: string, sitting: boolean, tameProgress?: number}>} */
    this.petData = new Map();
    this.tickCounter = 0;

    world.afterEvents.playerInteractWithEntity.subscribe((event) => {
      this.onInteract(event);
    });
  }

  onInteract(event) {
    const player = event.player;
    const entity = event.target;
    const typeId = entity.typeId;

    // Only handle foxes and ocelots
    if (typeId !== "minecraft:fox" && typeId !== "minecraft:ocelot") return;

    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    const itemId = mainhand?.typeId;
    const foods = TAME_FOODS[typeId];
    const isTameFood = foods && foods.includes(itemId);
    const tamedTag = typeId === "minecraft:fox" ? "ec.fox_tamed" : "ec.ocelot_tamed";
    const sittingTag = typeId === "minecraft:fox" ? "ec.fox_sitting" : "ec.ocelot_sitting";

    if (entity.hasTag(tamedTag)) {
      if (isTameFood) return; // Let vanilla breeding handle it
      this.toggleSit(player, entity, tamedTag, sittingTag, typeId);
    } else {
      if (isTameFood) {
        this.tryTame(player, entity, typeId);
      }
    }
  }

  tryTame(player, mob, typeId) {
    const mobId = mob.id;
    let data = this.petData.get(mobId);
    if (!data) {
      data = { ownerId: "", sitting: false, tameProgress: 0 };
      this.petData.set(mobId, data);
    }

    data.tameProgress = (data.tameProgress || 0) + 1;
    const progress = data.tameProgress;

    // Particles (happy_villager, not hearts — to distinguish from breeding)
    try {
      const pos = mob.location;
      mob.dimension.spawnParticle("minecraft:villager_happy", {
        x: pos.x, y: pos.y + 0.5, z: pos.z
      });
    } catch {}

    let success = false;
    if (progress >= 5) {
      success = true;
    } else if (progress >= 3) {
      success = Math.random() < TAME_CHANCE_3_4;
    }

    if (success) {
      this.completeTame(player, mob, typeId);
    } else {
      const msgs = PROGRESS_MSGS[typeId];
      const msg = msgs ? msgs[Math.min(progress - 1, msgs.length - 1)] : "Getting closer...";
      player.sendMessage(`§7${msg} (${progress}/5)`);
    }
  }

  completeTame(player, mob, typeId) {
    const tamedTag = typeId === "minecraft:fox" ? "ec.fox_tamed" : "ec.ocelot_tamed";
    const mobName = typeId === "minecraft:fox" ? "Fox" : "Ocelot";

    mob.addTag(tamedTag);
    mob.addTag("ec.tame_protected");
    mob.addTag(`ec.pet_owner_${player.id}`);

    this.petData.set(mob.id, {
      ownerId: player.id,
      sitting: false,
    });

    mob.nameTag = `§a${player.name}'s ${mobName}`;

    try { mob.addTag("minecraft:persistent"); } catch {}

    // Ocelot gets permanent Strength I
    if (typeId === "minecraft:ocelot") {
      try {
        mob.addEffect("strength", 20000000, { amplifier: 0, showParticles: false });
      } catch {}
    }

    try {
      const pos = mob.location;
      mob.dimension.spawnParticle("minecraft:villager_happy", {
        x: pos.x, y: pos.y + 0.8, z: pos.z
      });
    } catch {}

    player.sendMessage(`§a§l${mobName} Tamed! §r§7Right-click with empty hand to sit/stand.`);
    player.playSound("random.levelup", { volume: 0.5, pitch: 1.5 });

    this.eventBridge.emit("pet_tamed", { player, entity: mob, type: typeId });
  }

  toggleSit(player, mob, tamedTag, sittingTag, typeId) {
    const data = this.petData.get(mob.id);
    if (!data || data.ownerId !== player.id) {
      player.sendMessage(`§7This isn't your ${typeId.replace("minecraft:", "")}.`);
      return;
    }

    data.sitting = !data.sitting;

    if (data.sitting) {
      mob.addTag(sittingTag);
      try { mob.runCommandAsync("effect @s slowness 999999 255 true"); } catch {}
      player.sendMessage(`§7Your ${typeId.replace("minecraft:", "")} sits down.`);
    } else {
      mob.removeTag(sittingTag);
      try { mob.runCommandAsync("effect @s slowness 0 0 true"); } catch {}
      // Re-apply Strength I for ocelots (NoAI toggle may clear effects)
      if (typeId === "minecraft:ocelot") {
        try {
          mob.addEffect("strength", 20000000, { amplifier: 0, showParticles: false });
        } catch {}
      }
      player.sendMessage(`§7Your ${typeId.replace("minecraft:", "")} stands up.`);
    }

    const sound = typeId === "minecraft:fox" ? "mob.fox.ambient" : "mob.cat.purr";
    player.playSound(sound, { volume: 0.5 });
  }

  tick(players) {
    this.tickCounter++;
    if (this.tickCounter < FOLLOW_TICK_INTERVAL) return;
    this.tickCounter = 0;

    for (const player of players) {
      this.followTick(player, "minecraft:fox", "ec.fox_tamed", "ec.fox_sitting");
      this.followTick(player, "minecraft:ocelot", "ec.ocelot_tamed", "ec.ocelot_sitting");
    }
  }

  followTick(player, typeId, tamedTag, sittingTag) {
    const ownerTag = `ec.pet_owner_${player.id}`;

    try {
      const pets = player.dimension.getEntities({
        type: typeId,
        tags: [tamedTag, ownerTag],
        maxDistance: 128,
        location: player.location,
      });

      for (const pet of pets) {
        if (pet.hasTag(sittingTag)) continue;

        const dist = this.distance(player.location, pet.location);

        if (dist > TELEPORT_DIST) {
          const pLoc = player.location;
          try {
            pet.teleport({
              x: pLoc.x + (Math.random() * 2 - 1),
              y: pLoc.y,
              z: pLoc.z + (Math.random() * 2 - 1)
            });
          } catch {}
        } else if (dist > SPEED_DIST) {
          try { pet.addEffect("speed", 10, { amplifier: 1, showParticles: false }); } catch {}
        }
      }
    } catch {}
  }

  distance(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }
}
