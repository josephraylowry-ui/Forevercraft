/**
 * Message in a Bottle System — Write, seal, fish up player messages.
 * 50-message pool with FIFO overflow. 2% catch chance on fishing.
 * Replaces Java bottles/ folder (8 files).
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ModalFormData, ActionFormData } from "@minecraft/server-ui";

const MAX_POOL = 50;
const CATCH_CHANCE = 0.02; // 2%

// Biome name lookup
const BIOME_NAMES = [
  "Plains", "Forest", "Flower Forest", "Dark Forest", "Taiga",
  "Mountain", "Jungle", "Desert", "Savanna", "Ocean",
  "River", "Swamp", "Mushroom Island", "Ice Biome", "Badlands",
  "Lush Caves", "Dripstone Caves", "Deep Dark", "Nether Wastes",
  "Crimson Forest", "Warped Forest", "Basalt Deltas", "Soul Sand Valley",
  "The End", "Windswept Hills",
];

export class BottleSystem {
  constructor(eventBridge, biomeSystem) {
    this.eventBridge = eventBridge;
    this.biomeSystem = biomeSystem;
    this.pool = [];

    // Load pool from world storage
    this.loadPool();

    // Listen for fishing events
    eventBridge.on("fishing_catch", (player) => {
      this.tryCatch(player);
    });
  }

  loadPool() {
    try {
      const data = world.getDynamicProperty("bottle_pool");
      if (data) this.pool = JSON.parse(data);
    } catch {}
  }

  savePool() {
    try {
      world.setDynamicProperty("bottle_pool", JSON.stringify(this.pool));
    } catch {}
  }

  /**
   * Open the write form for a player to compose a message.
   */
  openWriteForm(player) {
    const form = new ModalFormData()
      .title("§6✉ Message in a Bottle")
      .textField("Write your message (max 200 chars):", "Your message here...");

    form.show(player).then((response) => {
      if (response.canceled) return;

      const text = (response.formValues[0] || "").toString().substring(0, 200).trim();
      if (!text) {
        player.sendMessage("§7You sealed an empty bottle. How mysterious.");
        return;
      }

      this.sealMessage(player, text);
    });
  }

  /**
   * Seal a message and add to the pool.
   */
  sealMessage(player, text) {
    const biomeId = this.biomeSystem?.getBiomeId(player) ?? -1;

    const message = {
      text,
      author: player.name,
      day: (globalThis._fc_daylight?.getDay?.() ?? 0),
      biome: biomeId,
    };

    this.pool.push(message);

    // FIFO: trim to max
    while (this.pool.length > MAX_POOL) {
      this.pool.shift();
    }

    this.savePool();

    player.sendMessage("§6§lMessage sealed! §7Your bottle drifts into the current...");
    try {
      player.playSound("item.bottle.fill", { volume: 0.8, pitch: 1.0 });
      player.playSound("random.splash", { volume: 0.5, pitch: 1.2 });
    } catch {}
  }

  /**
   * Roll for catching a bottle while fishing (2% chance).
   */
  tryCatch(player) {
    if (this.pool.length === 0) return;
    if (Math.random() > CATCH_CHANCE) return;

    // Pick random message from pool
    const idx = Math.floor(Math.random() * this.pool.length);
    const msg = this.pool[idx];

    this.displayMessage(player, msg);
  }

  /**
   * Display a caught message to a player.
   */
  displayMessage(player, msg) {
    const biomeName = msg.biome >= 0 && msg.biome < BIOME_NAMES.length
      ? BIOME_NAMES[msg.biome]
      : "Unknown";

    player.sendMessage("§6§l═══════════════════════════");
    player.sendMessage("§6§l  ✉ Message in a Bottle");
    player.sendMessage("§6§l═══════════════════════════");
    player.sendMessage(`§7Written on Day ${msg.day} in the ${biomeName}`);
    player.sendMessage("");
    player.sendMessage(`§f"${msg.text}"`);
    player.sendMessage("");
    player.sendMessage(`§7— §e${msg.author}`);

    try {
      player.playSound("item.bottle.empty", { volume: 0.8, pitch: 0.8 });
      player.playSound("item.book.page_turn", { volume: 0.6, pitch: 1.0 });
    } catch {}
  }

  /**
   * Open bottle menu (write or view pool stats).
   */
  openMenu(player) {
    const form = new ActionFormData()
      .title("§6✉ Messages in Bottles")
      .body(`§7Bottles in the sea: §f${this.pool.length}/${MAX_POOL}\n\n§7Write a message and cast it into the waters.\n§7Others may find it while fishing!`)
      .button("§eWrite a Message")
      .button("§7Close");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 1) return;
      if (r.selection === 0) this.openWriteForm(player);
    });
  }
}
