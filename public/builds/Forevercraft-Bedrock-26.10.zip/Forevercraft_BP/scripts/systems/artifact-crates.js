/**
 * Artifact Crates System — 6-tier loot crates with opening animation.
 * Tiers: Common, Uncommon, Rare, Ornate, Exquisite, Mythical.
 * Replaces Java artifact_crates/ + crate_anim/ folders.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Crate tier definitions
const TIERS = [
  { id: "common", name: "Common", color: "§7", animFrames: 10 },
  { id: "uncommon", name: "Uncommon", color: "§a", animFrames: 10 },
  { id: "rare", name: "Rare", color: "§b", animFrames: 15 },
  { id: "ornate", name: "Ornate", color: "§5", animFrames: 20 },
  { id: "exquisite", name: "Exquisite", color: "§d", animFrames: 25 },
  { id: "mythical", name: "Mythical", color: "§6", animFrames: 30 },
];

const TIER_MAP = new Map(TIERS.map(t => [t.id, t]));

// Dream Aegis pity: 0.01% chance regardless of tier
const DREAM_AEGIS_CHANCE = 0.0001;

// Crate coin drop chance and quantities per tier
const CRATE_COIN_CHANCE = 0.20; // 20% chance
const CRATE_COIN_AMOUNTS = {
  common: 1,
  uncommon: 1,
  rare: 2,
  ornate: 3,
  exquisite: 4,
  mythical: 6,
};

export class ArtifactCrateSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.activeAnimations = new Map(); // playerId → { tier, frame, maxFrames }

    // Listen for crate_give events from other systems
    eventBridge.on("crate_give", (player, tierId) => {
      this.giveCrate(player, tierId);
    });

    // Listen for crate open via item use
    world.afterEvents.itemUse.subscribe((event) => {
      const item = event.itemStack;
      if (!item) return;
      const tierTag = this.getCrateTier(item);
      if (tierTag) {
        this.openCrate(event.source, tierTag);
      }
    });
  }

  /**
   * Check if item is an artifact crate and return its tier.
   */
  getCrateTier(item) {
    if (!item.typeId.startsWith("forevercraft:artifact_crate")) return null;
    // Match forevercraft:artifact_crate_common, etc.
    for (const tier of TIERS) {
      if (item.typeId === `forevercraft:artifact_crate_${tier.id}`) return tier.id;
    }
    // Fallback: check custom data
    try {
      const tags = item.getTags?.() || [];
      for (const tag of tags) {
        if (TIER_MAP.has(tag)) return tag;
      }
    } catch {}
    return null;
  }

  /**
   * Give a crate to a player.
   */
  giveCrate(player, tierId) {
    const tier = TIER_MAP.get(tierId);
    if (!tier) return;

    try {
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:artifact_crate_${tierId} 1`
      );
    } catch {}

    player.sendMessage(`${tier.color}§l✦ ${tier.name} Artifact Crate received!`);
    try { player.playSound("random.toast", { volume: 0.4, pitch: 1.0 }); } catch {}
  }

  /**
   * Open a crate — start animation then give loot.
   */
  openCrate(player, tierId) {
    const tier = TIER_MAP.get(tierId);
    if (!tier) return;

    // Remove crate from hand
    try {
      const equip = player.getComponent("minecraft:equippable");
      const mainhand = equip?.getEquipment("Mainhand");
      if (mainhand) {
        if (mainhand.amount > 1) {
          mainhand.amount--;
          equip.setEquipment("Mainhand", mainhand);
        } else {
          equip.setEquipment("Mainhand", undefined);
        }
      }
    } catch {}

    // Start animation
    this.activeAnimations.set(player.id, {
      tier: tierId,
      frame: 0,
      maxFrames: tier.animFrames,
    });

    player.sendMessage(`${tier.color}§l✦ Opening ${tier.name} Artifact Crate...`);
    try { player.playSound("block.chest.open", { volume: 0.6, pitch: 1.0 }); } catch {}

    // Schedule animation ticks
    const animId = system.runInterval(() => {
      const anim = this.activeAnimations.get(player.id);
      if (!anim || !player?.isValid()) {
        system.clearRun(animId);
        this.activeAnimations.delete(player.id);
        return;
      }

      anim.frame++;

      // Progress particles
      if (anim.frame % 5 === 0) {
        try {
          const pos = player.location;
          player.dimension.runCommandAsync(
            `particle minecraft:endRod ${pos.x} ${pos.y + 1.5} ${pos.z} 0.3 0.3 0.3 0 3`
          );
        } catch {}
      }

      // Complete
      if (anim.frame >= anim.maxFrames) {
        system.clearRun(animId);
        this.activeAnimations.delete(player.id);
        this.completeCrate(player, anim.tier);
      }
    }, 2); // Every 2 ticks
  }

  /**
   * Complete crate opening — give loot.
   */
  completeCrate(player, tierId) {
    const tier = TIER_MAP.get(tierId);
    if (!tier) return;

    // Firework effect
    try {
      const pos = player.location;
      player.dimension.runCommandAsync(
        `particle minecraft:totem_particle ${pos.x} ${pos.y + 1} ${pos.z} 0.5 0.5 0.5 0.1 50`
      );
      player.playSound("firework.blast", { volume: 0.6, pitch: 1.0 });
    } catch {}

    // Roll loot
    player.sendMessage(`${tier.color}§l═══════════════════════`);
    player.sendMessage(`${tier.color}§l  ✦ ${tier.name} Crate Opened!`);
    player.sendMessage(`${tier.color}§l═══════════════════════`);

    // Emit for artifact rolling (handled by loot system)
    this.eventBridge.emit("artifact_crate_opened", player, tierId);

    // Give supplementary items
    try {
      // Mastery stone
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:mastery_stone_${tierId} 1`
      );
      // Universal runes
      const runeCount = tierId === "ornate" || tierId === "exquisite" || tierId === "mythical" ? 2 : 1;
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:universal_rune ${runeCount}`
      );
    } catch {}

    // Crate coin drop (20% chance, quantity scales by tier)
    if (Math.random() < CRATE_COIN_CHANCE) {
      const coinAmount = CRATE_COIN_AMOUNTS[tierId] || 1;
      try {
        player.dimension.runCommandAsync(
          `give "${player.name}" forevercraft:forever_coin ${coinAmount}`
        );
      } catch {}
      player.sendMessage(`§e§l✦ ${coinAmount} Forever Coin${coinAmount > 1 ? "s" : ""}! §r§7(Bonus drop)`);
      this.eventBridge.emit("coins_earned", player, coinAmount);
    }

    // Dream Aegis pity check
    if (Math.random() < DREAM_AEGIS_CHANCE) {
      player.sendMessage("§6§l☄ DREAM AEGIS! §r§7An impossible find!");
      try {
        player.dimension.runCommandAsync(
          `give "${player.name}" forevercraft:dream_aegis 1`
        );
      } catch {}
      this.eventBridge.emit("mythical_found", player, "dream_aegis");
    }

    // Track stats
    const storage = StorageManager.forPlayer(player);
    storage.increment("crates_opened", 1);
    storage.increment(`crates_${tierId}`, 1);

    this.eventBridge.emit("crate_opened", player, tierId);
  }
}
