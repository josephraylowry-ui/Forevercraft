/**
 * Achievements System — 28 categories of trackable achievements.
 * Replaces Java achievements/ folder (advancement-based + scoreboard tracking).
 * Uses dynamic properties for per-player achievement state.
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { showActionForm, showPaginatedMenu } from "./gui-manager.js";

// Achievement definitions
const ACHIEVEMENTS = {
  // Combat
  first_blood: { name: "First Blood", desc: "Kill your first hostile mob", category: "Combat" },
  monster_hunter: { name: "Monster Hunter", desc: "Kill 100 hostile mobs", category: "Combat" },
  boss_slayer: { name: "Boss Slayer", desc: "Defeat a world boss", category: "Combat" },
  dragon_slayer: { name: "Dragon Slayer", desc: "Defeat the Ender Dragon", category: "Combat" },

  // Exploration
  first_steps: { name: "First Steps", desc: "Explore 5 different biomes", category: "Exploration" },
  cartographer: { name: "Cartographer", desc: "Explore 20 different biomes", category: "Exploration" },
  world_traveler: { name: "World Traveler", desc: "Visit all three dimensions", category: "Exploration" },
  structure_finder: { name: "Structure Finder", desc: "Discover 10 unique structures", category: "Exploration" },

  // Collection
  collector: { name: "Collector", desc: "Collect 10 artifacts", category: "Collection" },
  hoarder: { name: "Hoarder", desc: "Collect 50 artifacts", category: "Collection" },
  completionist: { name: "Completionist", desc: "Collect 100 artifacts", category: "Collection" },
  lore_keeper: { name: "Lore Keeper", desc: "Discover 50 lore pieces", category: "Collection" },

  // Companions
  first_friend: { name: "First Friend", desc: "Befriend your first companion", category: "Companions" },
  pet_master: { name: "Pet Master", desc: "Level a pet to max", category: "Companions" },
  menagerie: { name: "Menagerie", desc: "Befriend 20 companions", category: "Companions" },

  // Dreams
  dreamer: { name: "Dreamer", desc: "Reach 100 Dream Rate", category: "Dreams" },
  lucid_dreamer: { name: "Lucid Dreamer", desc: "Reach 500 Dream Rate", category: "Dreams" },
  dream_master: { name: "Dream Master", desc: "Reach 1000 Dream Rate", category: "Dreams" },

  // Cooking
  sous_chef: { name: "Sous Chef", desc: "Discover 10 recipes", category: "Cooking" },
  master_chef: { name: "Master Chef", desc: "Discover all recipes", category: "Cooking" },

  // Economy
  entrepreneur: { name: "Entrepreneur", desc: "Complete 10 trades", category: "Economy" },
  merchant_prince: { name: "Merchant Prince", desc: "Complete 100 trades", category: "Economy" },

  // Social
  party_leader: { name: "Party Leader", desc: "Form a party with other players", category: "Social" },
  quest_master: { name: "Quest Master", desc: "Complete 25 quests", category: "Social" },

  // Mastery
  weapon_master: { name: "Weapon Master", desc: "Max level any weapon mastery", category: "Mastery" },
  armor_master: { name: "Armor Master", desc: "Max level any armor mastery", category: "Mastery" },
  jack_of_all: { name: "Jack of All Trades", desc: "Level 5+ in all weapon types", category: "Mastery" },
  legend: { name: "Legend", desc: "Complete all other achievements", category: "Special" },
};

const CATEGORIES = [...new Set(Object.values(ACHIEVEMENTS).map(a => a.category))];

export class AchievementSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  /** Grant an achievement to a player */
  grant(player, achievementId) {
    const s = StorageManager.forPlayer(player);
    const key = `ach_${achievementId}`;
    if (s.getBool(key)) return; // Already earned

    const ach = ACHIEVEMENTS[achievementId];
    if (!ach) return;

    s.set(key, true);
    const earned = s.getNumber("achievements_earned") + 1;
    s.set("achievements_earned", earned);

    player.onScreenDisplay.setTitle("§a§l✦ Achievement!", {
      subtitle: `§e${ach.name}`,
      fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20,
    });
    player.sendMessage(`§a§l✦ Achievement Unlocked: §r§e${ach.name}§r\n§7${ach.desc}`);

    // Check for "Legend" (all achievements)
    if (earned >= Object.keys(ACHIEVEMENTS).length - 1) {
      this.grant(player, "legend");
    }
  }

  /** Check if player has an achievement */
  has(player, achievementId) {
    return StorageManager.forPlayer(player).getBool(`ach_${achievementId}`);
  }

  /** Open achievement viewer */
  async showAchievements(player) {
    const s = StorageManager.forPlayer(player);
    const earned = s.getNumber("achievements_earned");
    const total = Object.keys(ACHIEVEMENTS).length;

    const sel = await showActionForm(player, "§aAchievements", `§7Earned: §f${earned}/${total}`, [
      ...CATEGORIES.map(c => {
        const catAchs = Object.entries(ACHIEVEMENTS).filter(([, a]) => a.category === c);
        const catEarned = catAchs.filter(([id]) => s.getBool(`ach_${id}`)).length;
        return { text: `§e${c} §7(${catEarned}/${catAchs.length})` };
      }),
      { text: "§7Close" },
    ]);

    if (sel >= 0 && sel < CATEGORIES.length) {
      await this.showCategory(player, CATEGORIES[sel]);
    }
  }

  async showCategory(player, category) {
    const s = StorageManager.forPlayer(player);
    const catAchs = Object.entries(ACHIEVEMENTS).filter(([, a]) => a.category === category);
    const items = catAchs.map(([id, ach]) => {
      const earned = s.getBool(`ach_${id}`);
      return { text: earned ? `§a✓ ${ach.name}` : `§7✗ ${ach.name} — ${ach.desc}` };
    });
    await showPaginatedMenu(player, `§a${category} Achievements`, items);
  }
}
