/**
 * Heist System — Stealth dungeon encounters.
 * Timer-based objectives, detection = failure. Sneak-focused gameplay.
 * Replaces Java heist/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const HEIST_SCENARIOS = [
  { id: 1, name: "The Merchant's Vault",  difficulty: 1, timer: 1200, guards: 3,  objective: "Steal the Golden Apple",  reward_coins: 50,  reward_xp: 200 },
  { id: 2, name: "Castle Armory",         difficulty: 2, timer: 1000, guards: 5,  objective: "Steal the Diamond Armor",  reward_coins: 100, reward_xp: 400 },
  { id: 3, name: "The Dragon's Hoard",    difficulty: 3, timer: 800,  guards: 8,  objective: "Steal the Dragon Egg",     reward_coins: 200, reward_xp: 800 },
  { id: 4, name: "Nether Fortress Vault",  difficulty: 4, timer: 600,  guards: 10, objective: "Steal the Nether Star",   reward_coins: 350, reward_xp: 1200 },
  { id: 5, name: "The End Treasury",       difficulty: 5, timer: 400,  guards: 12, objective: "Steal the Spirit Shard",   reward_coins: 500, reward_xp: 2000 },
];

const DETECTION_RADIUS = 6;     // Guards detect within 6 blocks
const SNEAK_REDUCTION = 0.5;    // Sneaking halves detection radius

export class HeistSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    // Active heists: Map<playerId, { scenario, timer, detected, guards: Set<entityId>, phase, objectiveCollected }>
    this.active = new Map();
  }

  // Called every 20 ticks
  tick(players) {
    for (const player of players) {
      const heist = this.active.get(player.id);
      if (!heist) continue;

      heist.timer--;

      // Check detection
      this.checkDetection(player, heist);

      // Timer expired
      if (heist.timer <= 0) {
        this.failHeist(player, "Time expired!");
        continue;
      }

      // Update HUD
      if (heist.timer % 20 === 0) {
        const timeLeft = Math.ceil(heist.timer / 20);
        const status = heist.objectiveCollected ? "§a✔ Escape!" : `§e${heist.scenario.objective}`;
        player.runCommandAsync(`title @s actionbar §6Heist §7| ${status} §7| Time: ${timeLeft}s`);
      }
    }
  }

  openMenu(player) {
    if (this.active.has(player.id)) {
      player.sendMessage("§cYou're already in a heist!");
      return;
    }

    const s = StorageManager.forPlayer(player);
    const heistsComplete = s.getNumber("heists_complete", 0);

    const form = new ActionFormData()
      .title("Heist Board")
      .body(`§7Choose a heist. Stealth is key — get detected and you fail!\n§7Heists completed: §f${heistsComplete}`);

    for (const scenario of HEIST_SCENARIOS) {
      const stars = "★".repeat(scenario.difficulty) + "☆".repeat(5 - scenario.difficulty);
      form.button(`§f${scenario.name}\n§7${stars} | ${scenario.reward_coins} coins`);
    }
    form.button("§cClose");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= HEIST_SCENARIOS.length) return;
      this.startHeist(player, HEIST_SCENARIOS[response.selection]);
    });
  }

  startHeist(player, scenario) {
    // Teleport to heist area
    const heistY = 350;
    const heistX = 100000 + 200 + scenario.id * 50;
    const heistZ = 0;

    // Save position
    const s = StorageManager.forPlayer(player);
    s.setNumber("heist_save_x", Math.floor(player.location.x));
    s.setNumber("heist_save_y", Math.floor(player.location.y));
    s.setNumber("heist_save_z", Math.floor(player.location.z));

    player.teleport({ x: heistX, y: heistY, z: heistZ });

    // Spawn guards
    const guards = new Set();
    const dim = player.dimension;
    for (let i = 0; i < scenario.guards; i++) {
      try {
        const guard = dim.spawnEntity("minecraft:vindicator", {
          x: heistX + (Math.random() - 0.5) * 20,
          y: heistY,
          z: heistZ + (Math.random() - 0.5) * 20,
        });
        guard.addTag("ec.heist_guard");
        guard.nameTag = "§c§lGuard";
        guard.addEffect("slow_falling", 99999, { amplifier: 0, showParticles: false });
        guards.add(guard.id);
      } catch (e) {}
    }

    this.active.set(player.id, {
      scenario,
      timer: scenario.timer,
      detected: false,
      guards,
      objectiveCollected: false,
    });

    player.addTag("ec.in_heist");
    player.addEffect("invisibility", 20, { amplifier: 0, showParticles: false }); // Brief invis to start
    player.sendMessage(`\n§6§l✦ Heist: ${scenario.name} ✦\n§r§7Objective: ${scenario.objective}\n§7Time: ${Math.ceil(scenario.timer / 20)}s\n§c§lDon't get detected!\n`);
    player.playSound("note.pling");
  }

  checkDetection(player, heist) {
    if (heist.detected) return;

    const isSneaking = player.isSneaking;
    const detectRadius = isSneaking ? DETECTION_RADIUS * SNEAK_REDUCTION : DETECTION_RADIUS;

    // OPT: Collect dead guards first, then delete (safe iteration)
    const deadGuards = [];
    for (const guardId of heist.guards) {
      try {
        const guard = world.getEntity(guardId);
        if (!guard) { deadGuards.push(guardId); continue; }

        const dx = guard.location.x - player.location.x;
        const dz = guard.location.z - player.location.z;
        const dist = Math.sqrt(dx * dx + dz * dz);

        if (dist < detectRadius) {
          // Check line of sight (simplified — guards behind walls shouldn't detect)
          // For now, distance check only
          if (!player.hasEffect("invisibility")) {
            this.failHeist(player, "A guard spotted you!");
            return;
          }
        }
      } catch (e) { deadGuards.push(guardId); }
    }
    // Safe cleanup after iteration
    for (const id of deadGuards) heist.guards.delete(id);
  }

  collectObjective(player) {
    const heist = this.active.get(player.id);
    if (!heist || heist.objectiveCollected) return;

    heist.objectiveCollected = true;
    player.sendMessage("§a§l✔ Objective collected! §r§7Now escape without being detected!");
    player.playSound("random.orb");
  }

  completeHeist(player) {
    const heist = this.active.get(player.id);
    if (!heist) return;

    const scenario = heist.scenario;
    const s = StorageManager.forPlayer(player);

    // Teleport back
    const savedX = s.getNumber("heist_save_x", 0);
    const savedY = s.getNumber("heist_save_y", 64);
    const savedZ = s.getNumber("heist_save_z", 0);
    player.teleport({ x: savedX, y: savedY, z: savedZ });

    // Rewards
    const heistsComplete = s.getNumber("heists_complete", 0) + 1;
    s.setNumber("heists_complete", heistsComplete);

    player.removeTag("ec.in_heist");
    player.sendMessage(`\n§6§l✦ Heist Complete! ✦\n§r§7${scenario.name}\n§7+${scenario.reward_coins} coins | +${scenario.reward_xp} XP\n`);
    player.playSound("ui.toast.challenge_complete");

    this.eventBridge.emit("heist_complete", { player, scenarioId: scenario.id });
    this.cleanupHeist(player.id);
  }

  failHeist(player, reason) {
    const heist = this.active.get(player.id);
    if (!heist) return;

    const s = StorageManager.forPlayer(player);
    const savedX = s.getNumber("heist_save_x", 0);
    const savedY = s.getNumber("heist_save_y", 64);
    const savedZ = s.getNumber("heist_save_z", 0);
    player.teleport({ x: savedX, y: savedY, z: savedZ });

    player.removeTag("ec.in_heist");
    player.addEffect("instant_health", 1, { amplifier: 5, showParticles: false }); // Full heal on fail

    // Totem pop visual
    try {
      player.dimension.spawnParticle("minecraft:totem_particle", player.location);
      player.playSound("random.totem");
    } catch (e) {}

    player.sendMessage(`\n§c§l✦ Heist Failed! ✦\n§r§c${reason}\n`);

    this.cleanupHeist(player.id);
  }

  cleanupHeist(playerId) {
    const heist = this.active.get(playerId);
    if (!heist) return;

    // Kill guards
    for (const guardId of heist.guards) {
      try { world.getEntity(guardId)?.kill(); } catch (e) {}
    }

    // Kill all heist entities
    try {
      const entities = world.getDimension("overworld").getEntities({ tags: ["ec.heist_guard"] });
      for (const e of entities) { try { e.kill(); } catch (err) {} }
    } catch (e) {}

    this.active.delete(playerId);
  }
}
