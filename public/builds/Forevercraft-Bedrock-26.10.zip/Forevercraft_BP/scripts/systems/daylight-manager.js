import { world, system } from "@minecraft/server";
import { CONSTANTS } from "../main.js";
import { StorageManager } from "../utils/storage.js";

/**
 * Daylight Manager — Custom 72,000-tick day cycle with seasonal rate switching.
 *
 * Java 26.1 Migration:
 * - Java now uses native `advance_time true` + `time of minecraft:overworld rate 0.333333`
 * - Bedrock has no equivalent gamerules, so we keep our custom tick-based system
 * - Added: Seasonal rate switching (Winter fast day/slow night, Summer slow day/fast night)
 * - Added: Skyrift Derby sleep blocking
 * - Added: Dreaming realm bed entry detection
 * - Added: Dawn/dusk event emission for other systems
 */

// Seasonal time rate multipliers (how many time ticks to advance per interval)
// Day = time 0-12000, Night = time 12000-24000 (in vanilla scale)
const SEASONAL_RATES = {
  spring: { day: 1, night: 1 },       // Normal balanced
  summer: { day: 0.75, night: 1.25 }, // Longer days, shorter nights
  autumn: { day: 1, night: 1 },       // Normal balanced
  winter: { day: 1.25, night: 0.75 }, // Shorter days, longer nights
};

// Dawn/dusk thresholds (in our 72000-tick cycle)
const DAWN_START = 0;
const DAWN_END = 1200;
const DUSK_START = 12000;
const DUSK_END = 13200;
const NIGHT_START = 13200;
const DAY_END = 12000;

export class DaylightManager {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.counter = 0;
    this.fractionalAccum = 0; // Accumulates fractional time ticks from seasonal rates
    this.sleepWait = 0;
    this.sleepPoll = 0;
    this.sleepSkipCooldown = 0;
    this.sleepBlocked = false; // True during Skyrift Derby or other events
    this.currentSeason = "spring";
    this.wasDawn = false;
    this.wasDusk = false;
    this.wasNight = false;
    const storage = StorageManager.world();
    this.currentTime = storage.getNumber("daylight_time", 0);
    this.currentDay = storage.getNumber("daylight_day", 0);
    this.storage = storage;

    // Listen for events that block sleep
    if (eventBridge) {
      eventBridge.on("skyrift_derby_start", () => { this.sleepBlocked = true; });
      eventBridge.on("skyrift_derby_end", () => { this.sleepBlocked = false; });
      eventBridge.on("world_event_started", (data) => {
        if (data?.event === "skyrift_derby") this.sleepBlocked = true;
      });
      eventBridge.on("world_event_ended", (data) => {
        if (data?.event === "skyrift_derby") this.sleepBlocked = false;
      });
    }
  }

  /** Set current season for rate switching */
  setSeason(season) {
    this.currentSeason = season;
  }

  tick() {
    this.counter++;
    if (this.counter >= CONSTANTS.DAYLIGHT_ADVANCE_INTERVAL) {
      this.counter = 0;
      this.advanceTime();
    }
    if (this.sleepSkipCooldown > 0) this.sleepSkipCooldown--;
    this.sleepPoll++;
    if (this.sleepPoll >= CONSTANTS.SLEEP_POLL_INTERVAL) {
      this.sleepPoll = 0;
      this.checkSleep();
    }
    if (this.sleepWait >= CONSTANTS.SLEEP_THRESHOLD_TICKS) {
      this.doSleepSkip();
    }

    // Dawn/dusk/night edge detection (emit events once per transition)
    this.checkTimeTransitions();
  }

  advanceTime() {
    // Seasonal rate switching: adjust how fast time advances based on day/night + season
    const rates = SEASONAL_RATES[this.currentSeason] || SEASONAL_RATES.spring;
    const isNight = this.currentTime >= NIGHT_START;
    const rate = isNight ? rates.night : rates.day;

    // Use fractional accumulator for sub-tick precision
    this.fractionalAccum += rate;
    const ticksToAdvance = Math.floor(this.fractionalAccum);
    this.fractionalAccum -= ticksToAdvance;

    if (ticksToAdvance > 0) {
      this.currentTime += ticksToAdvance;
    }

    if (this.currentTime >= CONSTANTS.TICKS_PER_DAY_CYCLE) {
      this.currentTime -= CONSTANTS.TICKS_PER_DAY_CYCLE;
      this.currentDay++;
      this.onDayChange();
    }

    try { world.setTimeOfDay(this.currentTime); } catch { try { world.getDimension("overworld").runCommandAsync(`time set ${this.currentTime}`); } catch {} }

    if (this.currentTime % 100 === 0) {
      this.storage.set("daylight_time", this.currentTime);
      this.storage.set("daylight_day", this.currentDay);
    }
  }

  checkSleep() {
    if (this.sleepSkipCooldown > 0) return;
    if (this.sleepBlocked) return; // Skyrift Derby or other event blocks sleep

    const players = world.getAllPlayers();
    if (players.length === 0) return;

    const allSleeping = players.every(p => {
      try { return p.isSleeping; } catch { return false; }
    });

    if (allSleeping) {
      this.sleepWait += CONSTANTS.SLEEP_POLL_INTERVAL;

      // Check for dreaming realm entry on first sleep detection
      if (this.sleepWait === CONSTANTS.SLEEP_POLL_INTERVAL && this.eventBridge) {
        for (const player of players) {
          try {
            if (player.isSleeping) {
              this.eventBridge.emit("player_bed_entry", { player });
            }
          } catch {}
        }
      }
    } else {
      this.sleepWait = 0;
    }
  }

  doSleepSkip() {
    this.sleepWait = 0;
    this.sleepSkipCooldown = 100;
    this.currentTime = 0;
    this.currentDay++;
    this.onDayChange();

    try {
      world.getDimension("overworld").runCommandAsync("time set 0");
    } catch {}

    this.storage.set("daylight_time", this.currentTime);
    this.storage.set("daylight_day", this.currentDay);

    for (const player of world.getAllPlayers()) {
      player.sendMessage("§eThe night has passed...");
    }

    // Emit sleep skip event for buddy system cozy rest, etc.
    if (this.eventBridge) {
      this.eventBridge.emit("sleep_skip", { day: this.currentDay });
    }
  }

  /** Detect dawn/dusk/night transitions and emit events */
  checkTimeTransitions() {
    const isDawn = this.currentTime >= DAWN_START && this.currentTime < DAWN_END;
    const isDusk = this.currentTime >= DUSK_START && this.currentTime < DUSK_END;
    const isNight = this.currentTime >= NIGHT_START;

    if (isDawn && !this.wasDawn && this.eventBridge) {
      this.eventBridge.emit("dawn", { day: this.currentDay, time: this.currentTime });
    }
    if (isDusk && !this.wasDusk && this.eventBridge) {
      this.eventBridge.emit("dusk", { day: this.currentDay, time: this.currentTime });
    }
    if (isNight && !this.wasNight && this.eventBridge) {
      this.eventBridge.emit("nightfall", { day: this.currentDay, time: this.currentTime });
    }

    this.wasDawn = isDawn;
    this.wasDusk = isDusk;
    this.wasNight = isNight;
  }

  onDayChange() {
    const moonPhase = this.currentDay % CONSTANTS.MOON_PHASES;
    this.storage.set("moon_phase", moonPhase);
    this.storage.set("daylight_day", this.currentDay);

    if (this.eventBridge) {
      this.eventBridge.emit("day_change", { day: this.currentDay, moonPhase });
    }
  }

  /** Block or unblock sleep (for events like Skyrift Derby) */
  blockSleep(blocked) { this.sleepBlocked = blocked; }

  getTime() { return this.currentTime; }
  getDay() { return this.currentDay; }
  getMoonPhase() { return this.currentDay % CONSTANTS.MOON_PHASES; }
  isNight() { return this.currentTime >= NIGHT_START; }
  isDawn() { return this.currentTime >= DAWN_START && this.currentTime < DAWN_END; }
}
