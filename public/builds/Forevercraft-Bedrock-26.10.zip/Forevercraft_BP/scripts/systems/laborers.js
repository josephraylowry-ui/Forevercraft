/**
 * Laborer System — Hire NPC workers for passive resource expeditions.
 * Replaces Java laborer/ folder (65 mcfunction files).
 *
 * 6 types: Miner, Farmer, Fisher, Woodcutter, Forager, Prospector
 * Feed quality meals → better expedition quality → better loot.
 * States: Idle → Preparing → On Expedition → Returned (collect loot).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const LABORER_TYPES = [
  { id: 1, name: "Miner", icon: "⛏", mealCat: "mining" },
  { id: 2, name: "Farmer", icon: "🌾", mealCat: "fortune" },
  { id: 3, name: "Fisher", icon: "🎣", mealCat: "wayfarer" },
  { id: 4, name: "Woodcutter", icon: "🪓", mealCat: "combat" },
  { id: 5, name: "Forager", icon: "🌿", mealCat: "delicacy" },
  { id: 6, name: "Prospector", icon: "💎", mealCat: "feast" },
];

const STATES = { IDLE: 0, PREPARING: 1, ON_EXPEDITION: 2, RETURNED: 3 };
const MAX_LABORERS = 6;
const BASE_DURATION = 72000; // 1 hour in ticks
const MIN_DURATION = 18000;  // 15 min at max quality
const PREPARE_TIME = 600;    // 30 seconds
const IDLE_COOLDOWN = 6000;  // 5 min between expeditions

// Loot tiers by quality
const LOOT_TIERS = [
  { minQ: 0, tier: "common", coins: 1 },
  { minQ: 4, tier: "uncommon", coins: 2 },
  { minQ: 8, tier: "rare", coins: 3 },
  { minQ: 12, tier: "ornate", coins: 5 },
  { minQ: 16, tier: "exquisite", coins: 8 },
];

// Name pools per type
const NAME_POOLS = {
  1: ["Bjorn", "Durin", "Petra", "Slate", "Cobalt", "Flint", "Ruby", "Jasper"],
  2: ["Barley", "Meadow", "Thyme", "Harvest", "Clover", "Sage", "Wheat", "Ivy"],
  3: ["Anchor", "Marina", "Drift", "Reef", "Coral", "Tide", "Gill", "Kelp"],
  4: ["Oakley", "Birch", "Aspen", "Lumber", "Timber", "Cedar", "Maple", "Elm"],
  5: ["Moss", "Fern", "Lichen", "Bramble", "Nettle", "Root", "Berry", "Leaf"],
  6: ["Goldrush", "Claim", "Nugget", "Vanguard", "Pioneer", "Scout", "Ore", "Gem"],
};

export class LaborerSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  /** Main tick — process all laborers (called every 60 ticks / 3 seconds) */
  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const count = s.getNumber("lb_count", 0);
      if (count === 0) continue;

      for (let slot = 0; slot < count; slot++) {
        this.tickLaborer(player, s, slot);
      }
    }
  }

  tickLaborer(player, s, slot) {
    const state = s.getNumber(`lb_${slot}_state`, STATES.IDLE);
    const now = Date.now();

    switch (state) {
      case STATES.IDLE: {
        const lastReturn = s.getNumber(`lb_${slot}_last_return`, 0);
        if (now - lastReturn < IDLE_COOLDOWN * 50) return; // Cooldown

        // Auto-start preparing
        s.set(`lb_${slot}_state`, STATES.PREPARING);
        s.set(`lb_${slot}_prep_start`, now);
        const name = s.get(`lb_${slot}_name`) || "Laborer";
        player.sendMessage(`§e${name} §7is preparing for an expedition...`);
        break;
      }

      case STATES.PREPARING: {
        const prepStart = s.getNumber(`lb_${slot}_prep_start`, now);
        if (now - prepStart > PREPARE_TIME * 50) {
          // Calculate quality and start expedition
          const quality = this.calcQuality(player, s, slot);
          const duration = Math.max(MIN_DURATION, BASE_DURATION - quality * 3600);

          s.set(`lb_${slot}_state`, STATES.ON_EXPEDITION);
          s.set(`lb_${slot}_quality`, quality);
          s.set(`lb_${slot}_exp_start`, now);
          s.set(`lb_${slot}_exp_dur`, duration * 50); // ms

          const name = s.get(`lb_${slot}_name`) || "Laborer";
          const mins = Math.ceil(duration / 1200);
          player.sendMessage(`§6${name} §7departed on expedition! (${mins} min, quality: §f${quality}§7)`);
        }
        break;
      }

      case STATES.ON_EXPEDITION: {
        const expStart = s.getNumber(`lb_${slot}_exp_start`, 0);
        const expDur = s.getNumber(`lb_${slot}_exp_dur`, BASE_DURATION * 50);
        if (now - expStart >= expDur) {
          s.set(`lb_${slot}_state`, STATES.RETURNED);
          const name = s.get(`lb_${slot}_name`) || "Laborer";
          player.sendMessage(`\n§a✦ ${name} has returned! §r§7Click to collect loot.`);
          player.playSound("random.orb", { volume: 0.5, pitch: 1.0 });
        }
        break;
      }

      case STATES.RETURNED:
        // Waiting for player to collect
        break;
    }
  }

  /** Calculate expedition quality */
  calcQuality(player, s, slot) {
    const typeId = s.getNumber(`lb_${slot}_type`, 1);
    let quality = typeId === 6 ? 4 : 2; // Prospector base = 4

    // Food bonus
    const foodTier = s.getNumber(`lb_${slot}_food_tier`, 0);
    quality += foodTier;

    // Category match bonus
    const foodCat = s.get(`lb_${slot}_food_cat`) || "";
    const laborerType = LABORER_TYPES[typeId - 1];
    if (laborerType && foodCat === laborerType.mealCat) quality += 1;

    // Artisan rank bonus
    const rank = s.getNumber("cf_rank", 0);
    quality += Math.min(4, Math.floor(rank / 25));

    // Permanent adventure bonus
    quality += s.getNumber(`lb_${slot}_perm_bonus`, 0);

    // Housing comfort bonus
    const comfort = s.getNumber("hs_decor", 0);
    quality += Math.min(5, Math.floor(comfort / 1000));

    return quality;
  }

  /** Collect expedition loot */
  collectLoot(player, slot) {
    const s = StorageManager.forPlayer(player);
    const state = s.getNumber(`lb_${slot}_state`, 0);
    if (state !== STATES.RETURNED) {
      player.sendMessage("§cLaborer isn't back yet!");
      return;
    }

    const quality = s.getNumber(`lb_${slot}_quality`, 0);
    const typeId = s.getNumber(`lb_${slot}_type`, 1);
    const name = s.get(`lb_${slot}_name`) || "Laborer";
    const type = LABORER_TYPES[typeId - 1];

    // Determine loot tier
    let lootTier = LOOT_TIERS[0];
    for (const t of LOOT_TIERS) {
      if (quality >= t.minQ) lootTier = t;
    }

    // Award loot
    this.eventBridge.emit("grant_coins", { player, amount: lootTier.coins, reason: `${name}'s expedition` });
    this.eventBridge.emit("crate_drop", { player, tier: lootTier.tier, system: "laborer" });

    // Track
    s.set(`lb_${slot}_expeditions`, s.getNumber(`lb_${slot}_expeditions`, 0) + 1);

    // Adventure event (5-10% chance)
    const adventureChance = quality >= 10 ? 0.10 : 0.05;
    if (Math.random() < adventureChance) {
      s.set(`lb_${slot}_perm_bonus`, s.getNumber(`lb_${slot}_perm_bonus`, 0) + 1);
      player.sendMessage(`§d✦ ${name} had an adventure! §7+1 permanent quality bonus`);
    }

    // Reset state
    s.set(`lb_${slot}_state`, STATES.IDLE);
    s.set(`lb_${slot}_last_return`, Date.now());

    player.sendMessage(`§a✦ Collected from ${name}! §7${lootTier.tier} loot (quality ${quality})`);
    player.playSound("random.levelup", { volume: 0.5, pitch: 1.2 });
  }

  /** Feed a laborer */
  feedLaborer(player, slot, mealTier, mealCat) {
    const s = StorageManager.forPlayer(player);
    s.set(`lb_${slot}_food_tier`, mealTier);
    s.set(`lb_${slot}_food_cat`, mealCat);

    const name = s.get(`lb_${slot}_name`) || "Laborer";
    const tierNames = ["", "Hearty", "Gourmet", "Feast", "Artisan"];
    player.sendMessage(`§a${name} §7enjoyed a §f${tierNames[mealTier] || "?"} §7meal!`);
  }

  /** Hire a new laborer */
  async hireLaborer(player, typeId) {
    const s = StorageManager.forPlayer(player);
    const count = s.getNumber("lb_count", 0);
    const maxSlots = Math.min(MAX_LABORERS, 1 + Math.floor(s.getNumber("cf_rank", 0) / 15));

    if (count >= maxSlots) {
      player.sendMessage(`§cMax laborers reached (${maxSlots}). Increase Artisan Rank for more slots.`);
      return;
    }

    const type = LABORER_TYPES[typeId - 1];
    if (!type) return;

    const names = NAME_POOLS[typeId] || ["Worker"];
    const name = names[Math.floor(Math.random() * names.length)];

    const slot = count;
    s.set(`lb_${slot}_type`, typeId);
    s.set(`lb_${slot}_name`, name);
    s.set(`lb_${slot}_state`, STATES.IDLE);
    s.set(`lb_${slot}_food_tier`, 0);
    s.set(`lb_${slot}_expeditions`, 0);
    s.set(`lb_${slot}_perm_bonus`, 0);
    s.set(`lb_${slot}_last_return`, 0);
    s.set("lb_count", count + 1);

    player.sendMessage(`\n§a§l✦ ${name} the ${type.name} hired! ✦§r`);
    player.sendMessage("§7Feed them quality meals to improve expedition loot.");
    player.playSound("random.levelup", { volume: 0.6, pitch: 1.2 });
  }

  /** Open laborer management menu */
  async openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const count = s.getNumber("lb_count", 0);
    const maxSlots = Math.min(MAX_LABORERS, 1 + Math.floor(s.getNumber("cf_rank", 0) / 15));

    const form = new ActionFormData()
      .title("§l§6Laborers");

    let body = `§7Workers: §f${count}/${maxSlots}\n\n`;

    for (let i = 0; i < count; i++) {
      const name = s.get(`lb_${i}_name`) || "Worker";
      const typeId = s.getNumber(`lb_${i}_type`, 1);
      const type = LABORER_TYPES[typeId - 1];
      const state = s.getNumber(`lb_${i}_state`, 0);
      const stateNames = ["§7Idle", "§ePreparing...", "§6On Expedition", "§a✦ RETURNED!"];

      body += `${type?.icon || "?"} §f${name} §7(${type?.name || "?"}) — ${stateNames[state] || "?"}\n`;
    }

    if (count === 0) body += "§8No laborers hired yet.\n";

    form.body(body);

    for (let i = 0; i < count; i++) {
      const state = s.getNumber(`lb_${i}_state`, 0);
      const name = s.get(`lb_${i}_name`) || "Worker";
      if (state === STATES.RETURNED) {
        form.button(`§a✦ Collect from ${name}`);
      } else {
        form.button(`§7${name} (${["Idle", "Preparing", "Expedition", "Ready"][state]})`);
      }
    }

    if (count < maxSlots) form.button("§a+ Hire New Laborer");
    form.button("§7Close");

    const res = await form.show(player);
    if (res.canceled) return;

    if (res.selection < count) {
      const state = s.getNumber(`lb_${res.selection}_state`, 0);
      if (state === STATES.RETURNED) this.collectLoot(player, res.selection);
    } else if (res.selection === count && count < maxSlots) {
      await this.showHireMenu(player);
    }
  }

  async showHireMenu(player) {
    const form = new ActionFormData()
      .title("§aHire Laborer")
      .body("§7Choose a laborer type:");

    for (const type of LABORER_TYPES) {
      form.button(`${type.icon} §f${type.name}`);
    }

    const res = await form.show(player);
    if (res.canceled) return;
    await this.hireLaborer(player, res.selection + 1);
  }
}
