/**
 * Constellations System — 10 themed artifact set completions.
 * Each completed constellation grants +0.25 Dream Rate.
 * Replaces Java constellations/ folder.
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// 10 constellations with their artifact requirements
const CONSTELLATIONS = [
  {
    id: "tide", name: "The Tidewalker", color: "§b", bit: 1, threshold: 10,
    flavor: "The ancient mariners' stars align.",
    artifacts: [
      "ocean_helmet", "ocean_chestplate", "ocean_leggings", "ocean_boots",
      "ocean_pickaxe", "ocean_shovel", "ocean_hoe", "coral_blade",
      "anglers_pearl", "sea_heart_relic",
    ],
  },
  {
    id: "pyre", name: "The Pyreborn", color: "§c", bit: 2, threshold: 11,
    flavor: "From ash and ember, rebirth blazes forth.",
    artifacts: [
      "netherwalker_helmet", "netherwalker_chestplate", "netherwalker_leggings",
      "netherwalker_boots", "netherwalker_pickaxe", "netherwalker_shovel",
      "netherwalker_hoe", "inferno_blade", "blaze_core", "phoenix_feather",
      "nether_star_shard",
    ],
  },
  {
    id: "verd", name: "The Verdant Crown", color: "§a", bit: 4, threshold: 10,
    flavor: "Nature's crown blooms eternal.",
    artifacts: [
      "nature_helmet", "nature_chestplate", "nature_leggings", "nature_boots",
      "nature_pickaxe", "nature_shovel", "nature_hoe", "farmers_almanac",
      "heartstone", "healers_salve",
    ],
  },
  {
    id: "frost", name: "The Frozen Veil", color: "§f", bit: 8, threshold: 10,
    flavor: "Winter's veil descends, serene and absolute.",
    artifacts: [
      "frost_helmet", "frost_chestplate", "frost_leggings", "frost_boots",
      "frost_pickaxe", "frost_shovel", "frost_hoe", "glacial_edge",
      "frostbite_bow", "frostmourne",
    ],
  },
  {
    id: "earth", name: "The Earthshaker", color: "§6", bit: 16, threshold: 10,
    flavor: "The deep stone trembles at your approach.",
    artifacts: [
      "golem_helmet", "golem_chestplate", "golem_leggings", "golem_boots",
      "journey_pickaxe", "journey_shovel", "miners_lantern", "spelunkers_echo",
      "earthshaker", "fantasy_pickaxe",
    ],
  },
  {
    id: "star", name: "The Starweaver", color: "§d", bit: 32, threshold: 8,
    flavor: "The cosmos bends to your will.",
    artifacts: [
      "ender_helmet", "ender_chestplate", "ender_leggings", "ender_boots",
      "void_heart", "call_of_the_void", "prism_of_light", "heart_of_the_void",
    ],
  },
  {
    id: "shade", name: "The Shadow's Edge", color: "§8", bit: 64, threshold: 10,
    flavor: "Darkness embraces its master.",
    artifacts: [
      "shadow_helmet", "shadow_chestplate", "shadow_leggings", "shadow_boots",
      "phantom_helmet", "phantom_chestplate", "phantom_leggings",
      "phantom_boots", "phantom_charm", "helm_of_shadows",
    ],
  },
  {
    id: "dune", name: "The Dune Sovereign", color: "§e", bit: 128, threshold: 10,
    flavor: "The sands bow before their sovereign.",
    artifacts: [
      "dragonslayer_helmet", "dragonslayer_chestplate", "dragonslayer_leggings",
      "dragonslayer_boots", "dragonslayer_shield", "dragonslayer",
      "celestial_helmet", "celestial_chestplate", "celestial_leggings",
      "celestial_boots",
    ],
  },
  {
    id: "storm", name: "The Stormcaller", color: "§3", bit: 256, threshold: 10,
    flavor: "Thunder answers your call.",
    artifacts: [
      "storm_helmet", "storm_chestplate", "storm_leggings", "storm_boots",
      "storm_pickaxe", "storm_shovel", "storm_hoe", "stormcatcher_shard",
      "stormcaller_bow", "wind_chime",
    ],
  },
  {
    id: "soul", name: "The Soulbinder", color: "§5", bit: 512, threshold: 10,
    flavor: "Souls answer to your binding will.",
    artifacts: [
      "wither_helmet", "wither_chestplate", "wither_leggings", "wither_boots",
      "sculk_helmet", "sculk_chestplate", "sculk_leggings", "sculk_boots",
      "soul_lantern_fragment", "wither_rose_crown",
    ],
  },
];

export class ConstellationSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Listen for artifact collection
    eventBridge.on("artifact_collected", (player, artifactId) => {
      this.checkConstellations(player);
    });
  }

  /**
   * Check all constellations for a player after artifact collection.
   */
  checkConstellations(player) {
    const storage = StorageManager.forPlayer(player);
    let doneBits = storage.getNumber("cn_done", 0);

    for (const cn of CONSTELLATIONS) {
      // Skip already completed
      if (doneBits & cn.bit) continue;

      // Count collected artifacts in this constellation
      let count = 0;
      for (const art of cn.artifacts) {
        if (storage.getNumber(`art_${art}`, 0) >= 1) count++;
      }

      storage.set(`cn_${cn.id}`, count);

      // Check threshold
      if (count >= cn.threshold) {
        doneBits |= cn.bit;
        storage.set("cn_done", doneBits);
        this.onComplete(player, cn);
      }
    }
  }

  /**
   * Handle constellation completion.
   */
  onComplete(player, cn) {
    // Count total completed for DR bonus
    const storage = StorageManager.forPlayer(player);
    const doneBits = storage.getNumber("cn_done", 0);
    let completed = 0;
    for (let i = 0; i < 10; i++) {
      if (doneBits & (1 << i)) completed++;
    }

    const drBonus = completed * 0.25;
    storage.set("cn_dr_bonus", drBonus);

    // Announce
    player.sendMessage(`${cn.color}§l═══════════════════════════`);
    player.sendMessage(`${cn.color}§l  ✦ ${cn.name} ✦`);
    player.sendMessage(`${cn.color}§l═══════════════════════════`);
    player.sendMessage(`§7${cn.flavor}`);
    player.sendMessage(`§a+0.25 Dream Rate §7(Total: §a+${drBonus}§7)`);

    // Server-wide announcement
    for (const p of world.getAllPlayers()) {
      if (p.id !== player.id) {
        p.sendMessage(`${cn.color}✦ §e${player.name} §7completed ${cn.color}${cn.name}§7!`);
      }
    }

    try {
      player.playSound("random.levelup", { volume: 0.8, pitch: 1.0 });
      player.playSound("block.amethyst_block.break", { volume: 0.6, pitch: 0.8 });
    } catch {}

    this.eventBridge.emit("constellation_complete", player, cn.id);
  }

  /**
   * Get DR bonus for a player from constellations.
   */
  getDRBonus(player) {
    const storage = StorageManager.forPlayer(player);
    return storage.getNumber("cn_dr_bonus", 0);
  }

  /**
   * Open constellation viewer menu.
   */
  openMenu(player) {
    const storage = StorageManager.forPlayer(player);
    const doneBits = storage.getNumber("cn_done", 0);

    let completed = 0;
    for (let i = 0; i < 10; i++) {
      if (doneBits & (1 << i)) completed++;
    }

    let body = `§7Completed: §e${completed}/10\n`;
    body += `§7Dream Rate Bonus: §a+${(completed * 0.25).toFixed(2)}\n\n`;

    for (const cn of CONSTELLATIONS) {
      const count = storage.getNumber(`cn_${cn.id}`, 0);
      const done = (doneBits & cn.bit) !== 0;
      const icon = done ? "§a✦" : "§7○";
      body += `${icon} ${cn.color}${cn.name} §7— ${count}/${cn.threshold}\n`;
    }

    const form = new ActionFormData()
      .title("§d✦ Constellations")
      .body(body)
      .button("§7Close");

    form.show(player);
  }
}
