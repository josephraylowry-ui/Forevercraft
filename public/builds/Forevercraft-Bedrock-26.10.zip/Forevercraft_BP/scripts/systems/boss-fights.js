/**
 * Boss Fights System — 11 custom world bosses with 3 phases each.
 * DR-scaled HP/damage, moon bonuses, anti-range zones, tiered rewards.
 * Replaces Java bosses/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// 11 boss definitions
const BOSSES = [
  { id: 1, name: "The Hollow King", type: "minecraft:wither_skeleton", baseHP: 300, scale: 1.5,
    color: "§7", minions: { type: "minecraft:zombie", count: 4 },
    abilities: { p1: "slowness_aura", p2: "weakness_aura", p3: "darkness_pulse" } },
  { id: 2, name: "The Verdant Warden", type: "minecraft:vindicator", baseHP: 280, scale: 1.4,
    color: "§2", minions: { type: "minecraft:spider", count: 4 },
    abilities: { p1: "poison_aura", p2: "regen_self", p3: "vine_burst" } },
  { id: 3, name: "The Stormforged", type: "minecraft:skeleton", baseHP: 250, scale: 1.3,
    color: "§b", minions: { type: "minecraft:skeleton", count: 4 },
    abilities: { p1: "lightning_strike", p2: "chain_lightning", p3: "storm_aura" } },
  { id: 4, name: "The Tidecaller", type: "minecraft:drowned", baseHP: 350, scale: 1.6,
    color: "§3", minions: { type: "minecraft:drowned", count: 4 },
    abilities: { p1: "water_pull", p2: "trident_barrage", p3: "whirlpool" } },
  { id: 5, name: "The Earthshaker", type: "minecraft:iron_golem", baseHP: 400, scale: 1.8,
    color: "§6", minions: { type: "minecraft:zombie", count: 4 },
    abilities: { p1: "ground_pound", p2: "falling_anvils", p3: "shockwave" } },
  { id: 6, name: "The Nightmare", type: "minecraft:wither_skeleton", baseHP: 320, scale: 1.2,
    color: "§8", minions: { type: "minecraft:silverfish", count: 4 },
    abilities: { p1: "darkness_aura", p2: "fear_pulse", p3: "shadow_clone" } },
  { id: 7, name: "The Infernal Titan", type: "minecraft:piglin_brute", baseHP: 450, scale: 1.8,
    color: "§c", minions: { type: "minecraft:blaze", count: 4 },
    abilities: { p1: "fire_aura", p2: "explosion_pulse", p3: "fire_trail" } },
  { id: 8, name: "The Soul Warden", type: "minecraft:wither_skeleton", baseHP: 400, scale: 1.5,
    color: "§3", minions: { type: "minecraft:skeleton", count: 4 },
    abilities: { p1: "wither_aura", p2: "soul_drain", p3: "undead_army" } },
  { id: 9, name: "The Crimson Behemoth", type: "minecraft:hoglin", baseHP: 500, scale: 2.0,
    color: "§4", minions: { type: "minecraft:hoglin", count: 4 },
    abilities: { p1: "charge", p2: "ground_slam", p3: "frenzy" } },
  { id: 10, name: "The Void Sovereign", type: "minecraft:vindicator", baseHP: 500, scale: 1.5,
    color: "§5", minions: { type: "minecraft:endermite", count: 4 },
    abilities: { p1: "void_bolt", p2: "levitation_aura", p3: "void_collapse" } },
  { id: 11, name: "The Ender Architect", type: "minecraft:blaze", baseHP: 550, scale: 1.4,
    color: "§d", minions: { type: "minecraft:endermite", count: 4 },
    abilities: { p1: "shulker_summon", p2: "levitation_field", p3: "architect_rage" } },
];

// Reward tiers by Dream Rate
const REWARD_TIERS = [
  { minDR: 0, tier: "rare" },
  { minDR: 13, tier: "ornate" },
  { minDR: 23, tier: "exquisite" },
  { minDR: 30, tier: "mythical" },
];

const DESPAWN_TIMER = 18000; // 15 minutes in ticks
const ABILITY_COOLDOWN = 100; // 5 seconds
const ANTI_RANGE_WARN = 500; // 25 blocks squared
const ANTI_RANGE_DANGER = 1225; // 35 blocks squared
const ANTI_RANGE_EXTREME = 2500; // 50 blocks squared

export class BossFightSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.activeFight = null; // { bossId, bossEntity, phase, timer, abilityCd, center, participants }
    this.naturalTimer = 0;

    // Listen for boss summon via totem
    world.afterEvents.itemUse.subscribe((event) => {
      if (event.itemStack?.typeId === "forevercraft:boss_totem") {
        this.summonBoss(event.source);
      }
    });

    // Listen for boss death
    world.afterEvents.entityDie.subscribe((event) => {
      if (!this.activeFight) return;
      const entity = event.deadEntity;
      if (entity?.hasTag("ec.world_boss")) {
        this.onBossKill(event.damageSource);
      }
    });
  }

  /**
   * Tick — runs every 20 ticks (1 second).
   */
  tick() {
    if (!this.activeFight) {
      this.naturalTimer++;
      // Natural spawn every 7 in-game days (504000 / 20 = 25200 1s ticks)
      if (this.naturalTimer >= 25200) {
        this.tryNaturalSpawn();
        this.naturalTimer = 0;
      }
      return;
    }

    const fight = this.activeFight;
    fight.timer++;
    fight.abilityCd--;

    // Despawn check
    if (fight.timer >= DESPAWN_TIMER / 20) {
      this.despawnBoss("The boss grew bored and vanished...");
      return;
    }

    // Phase checks
    this.checkPhase(fight);

    // Abilities
    if (fight.abilityCd <= 0) {
      this.useAbility(fight);
      fight.abilityCd = ABILITY_COOLDOWN / 20;
    }

    // Anti-range
    this.checkAntiRange(fight);

    // Bossbar update via actionbar
    this.updateBossbar(fight);
  }

  /**
   * Summon a random boss.
   */
  summonBoss(player) {
    if (this.activeFight) {
      player.sendMessage("§cA boss fight is already active!");
      return;
    }

    const bossDef = BOSSES[Math.floor(Math.random() * BOSSES.length)];
    this.spawnBoss(player, bossDef);
  }

  /**
   * Try natural boss spawn.
   */
  tryNaturalSpawn() {
    const players = world.getAllPlayers();
    if (players.length === 0) return;
    const target = players[Math.floor(Math.random() * players.length)];
    if (target.getGameMode() === "creative" || target.getGameMode() === "spectator") return;

    const bossDef = BOSSES[Math.floor(Math.random() * BOSSES.length)];
    this.spawnBoss(target, bossDef, true);
  }

  /**
   * Spawn a boss near a player.
   */
  spawnBoss(player, bossDef, natural = false) {
    const dim = player.dimension;
    const pos = player.location;
    const ox = (Math.random() - 0.5) * 32 + (Math.random() > 0.5 ? 24 : -24);
    const oz = (Math.random() - 0.5) * 32 + (Math.random() > 0.5 ? 24 : -24);

    let bossEntity;
    try {
      bossEntity = dim.spawnEntity(bossDef.type, {
        x: pos.x + ox, y: pos.y, z: pos.z + oz,
      });
    } catch {
      return;
    }

    // Calculate scaling from player DR
    const storage = StorageManager.forPlayer(player);
    const dr = storage.getNumber("dream_rate", 0);
    const hpScale = Math.min(1.0 + dr * 0.07, 3.5);
    const scaledHP = Math.floor(bossDef.baseHP * hpScale);

    // Apply boss properties
    bossEntity.addTag("ec.world_boss");
    bossEntity.addTag(`ec.boss_${bossDef.id}`);
    bossEntity.nameTag = `§c☠ ${bossDef.name} ☠`;

    try {
      bossEntity.addEffect("fire_resistance", 999999, { amplifier: 0, showParticles: false });
      bossEntity.addEffect("glowing", 999999, { amplifier: 0, showParticles: false });
    } catch {}

    // Spawn minions
    for (let i = 0; i < bossDef.minions.count; i++) {
      try {
        const mx = (Math.random() - 0.5) * 8;
        const mz = (Math.random() - 0.5) * 8;
        const minion = dim.spawnEntity(bossDef.minions.type, {
          x: bossEntity.location.x + mx,
          y: bossEntity.location.y,
          z: bossEntity.location.z + mz,
        });
        minion.addTag("ec.boss_minion");
        minion.addEffect("glowing", 999999, { amplifier: 0, showParticles: false });
      } catch {}
    }

    this.activeFight = {
      bossId: bossDef.id,
      bossDef,
      bossEntity,
      phase: 1,
      timer: 0,
      abilityCd: 5,
      center: { ...bossEntity.location },
      dimension: dim,
      scaledHP,
      participants: new Set([player.id]),
    };

    // Announce
    for (const p of world.getAllPlayers()) {
      p.sendMessage(`§c§l☠ ${bossDef.name} §r§7has ${natural ? "appeared" : "been summoned"}!`);
      try { p.playSound("mob.wither.spawn", { volume: 0.5, pitch: 1.0 }); } catch {}
    }
  }

  /**
   * Check phase transitions.
   */
  checkPhase(fight) {
    const boss = fight.bossEntity;
    if (!boss?.isValid()) {
      this.cleanup();
      return;
    }

    const health = boss.getComponent("minecraft:health");
    if (!health) return;

    const current = health.currentValue;
    const max = health.effectiveMax;
    const pct = current / max;

    if (fight.phase === 1 && pct <= 0.66) {
      fight.phase = 2;
      this.announcePhase(fight, 2);
    } else if (fight.phase === 2 && pct <= 0.33) {
      fight.phase = 3;
      this.announcePhase(fight, 3);
    }
  }

  announcePhase(fight, phase) {
    for (const p of world.getAllPlayers()) {
      p.sendMessage(`§c§lPhase ${phase}! §r${fight.bossDef.color}${fight.bossDef.name} §7grows stronger!`);
      try { p.playSound("mob.wither.break_block", { volume: 0.5, pitch: 1.0 }); } catch {}
    }

    // Phase buffs
    const boss = fight.bossEntity;
    try {
      boss.addEffect("speed", 999999, { amplifier: phase - 1, showParticles: false });
      boss.addEffect("strength", 999999, { amplifier: phase - 1, showParticles: false });
    } catch {}
  }

  /**
   * Use boss ability based on phase.
   */
  useAbility(fight) {
    const boss = fight.bossEntity;
    if (!boss?.isValid()) return;

    const pos = boss.location;
    const dim = fight.dimension;

    // Generic ability based on phase
    const nearby = world.getAllPlayers().filter(p => {
      const dx = p.location.x - pos.x;
      const dz = p.location.z - pos.z;
      return (dx * dx + dz * dz) < 900; // 30 blocks
    });

    for (const player of nearby) {
      fight.participants.add(player.id);

      if (fight.phase >= 1) {
        // Phase 1: slowness aura
        try {
          player.addEffect("slowness", 60, { amplifier: 0, showParticles: true });
        } catch {}
      }
      if (fight.phase >= 2) {
        // Phase 2: weakness
        try {
          player.addEffect("weakness", 60, { amplifier: 0, showParticles: true });
        } catch {}
      }
      if (fight.phase >= 3) {
        // Phase 3: darkness pulse
        try {
          player.addEffect("darkness", 60, { amplifier: 0, showParticles: false });
        } catch {}
      }
    }

    // Particles
    try {
      dim.runCommandAsync(
        `particle minecraft:large_explosion ${pos.x} ${pos.y + 1} ${pos.z} 2 1 2 0 5`
      );
    } catch {}
  }

  /**
   * Anti-range zone checks.
   */
  checkAntiRange(fight) {
    const boss = fight.bossEntity;
    if (!boss?.isValid()) return;

    const bpos = boss.location;
    for (const player of world.getAllPlayers()) {
      if (!fight.participants.has(player.id)) continue;

      const dx = player.location.x - bpos.x;
      const dz = player.location.z - bpos.z;
      const distSq = dx * dx + dz * dz;

      if (distSq > ANTI_RANGE_EXTREME) {
        try {
          player.addEffect("slowness", 60, { amplifier: 3, showParticles: false });
          player.addEffect("weakness", 60, { amplifier: 2, showParticles: false });
          player.addEffect("wither", 60, { amplifier: 1, showParticles: false });
          player.addEffect("darkness", 60, { amplifier: 0, showParticles: false });
        } catch {}
      } else if (distSq > ANTI_RANGE_DANGER) {
        try {
          player.addEffect("slowness", 60, { amplifier: 2, showParticles: false });
          player.addEffect("weakness", 60, { amplifier: 1, showParticles: false });
          player.addEffect("wither", 60, { amplifier: 0, showParticles: false });
        } catch {}
      } else if (distSq > ANTI_RANGE_WARN) {
        try {
          player.addEffect("slowness", 60, { amplifier: 1, showParticles: false });
          player.addEffect("glowing", 60, { amplifier: 0, showParticles: false });
        } catch {}
      }
    }
  }

  /**
   * Update bossbar via actionbar.
   */
  updateBossbar(fight) {
    const boss = fight.bossEntity;
    if (!boss?.isValid()) return;

    const health = boss.getComponent("minecraft:health");
    if (!health) return;

    const pct = Math.floor((health.currentValue / health.effectiveMax) * 100);
    const bar = "█".repeat(Math.floor(pct / 5)) + "░".repeat(20 - Math.floor(pct / 5));

    for (const player of world.getAllPlayers()) {
      try {
        player.onScreenDisplay?.setActionBar?.(
          `§c☠ ${fight.bossDef.name} §7[${bar}] §f${pct}% §7P${fight.phase}`
        );
      } catch {}
    }
  }

  /**
   * Handle boss kill — distribute rewards.
   */
  onBossKill(damageSource) {
    const fight = this.activeFight;
    if (!fight) return;

    const killer = damageSource?.damagingEntity;

    for (const player of world.getAllPlayers()) {
      if (!fight.participants.has(player.id)) continue;

      const storage = StorageManager.forPlayer(player);
      const dr = storage.getNumber("dream_rate", 0);

      // Get reward tier
      let reward = REWARD_TIERS[0];
      for (const r of REWARD_TIERS) {
        if (dr >= r.minDR) reward = r;
      }

      // Give rewards
      player.sendMessage("§6§l═══════════════════════════");
      player.sendMessage(`§6§l  ✦ ${fight.bossDef.name} Defeated!`);
      player.sendMessage("§6§l═══════════════════════════");
      player.sendMessage(`§7Reward: §e${reward.tier} crate §7+ §a500 XP`);

      this.eventBridge.emit("crate_give", player, reward.tier);
      try {
        player.dimension.runCommandAsync(`xp 500 "${player.name}"`);
      } catch {}

      // Boss exclusive artifact (guaranteed for killer, 25% for others)
      const isKiller = killer?.id === player.id;
      if (isKiller || Math.random() < 0.25) {
        this.eventBridge.emit("boss_exclusive_drop", player, fight.bossId);
        player.sendMessage("§6§l✦ Boss Exclusive Artifact received!");
      }

      storage.increment("boss_kills", 1);
      storage.increment(`boss_k${fight.bossId}`, 1);

      try { player.playSound("random.levelup", { volume: 0.8, pitch: 1.0 }); } catch {}
    }

    this.eventBridge.emit("boss_killed", fight.bossId);
    this.cleanup();
  }

  /**
   * Despawn boss due to timeout.
   */
  despawnBoss(reason) {
    for (const p of world.getAllPlayers()) {
      p.sendMessage(`§7${reason}`);
    }
    this.cleanup();
  }

  /**
   * Cleanup fight state.
   */
  cleanup() {
    if (!this.activeFight) return;

    // Kill boss and minions
    try {
      const dim = this.activeFight.dimension;
      const center = this.activeFight.center;
      const entities = dim.getEntities({
        location: center, maxDistance: 100,
        tags: ["ec.world_boss"],
      });
      for (const e of entities) { try { e.kill(); } catch {} }

      const minions = dim.getEntities({
        location: center, maxDistance: 150,
        tags: ["ec.boss_minion"],
      });
      for (const m of minions) { try { m.kill(); } catch {} }
    } catch {}

    this.activeFight = null;
  }
}
