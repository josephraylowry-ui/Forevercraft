/**
 * Day Counter System — Dawn announcements with day number and era name.
 * Dawn chorus ambient sounds. 25 cycling RPG eras.
 * Replaces Java day_counter/ folder.
 */
import { world, system } from "@minecraft/server";

// 25 RPG era names (cycle every 365 in-game days)
const ERA_NAMES = [
  "The Age of Dawn", "The Age of Stone", "The Age of Embers",
  "The Age of Tides", "The Age of Whispers", "The Age of Iron",
  "The Age of Storms", "The Age of Roots", "The Age of Crystals",
  "The Age of Shadows", "The Age of Flames", "The Age of Stars",
  "The Age of Frost", "The Age of Spirits", "The Age of Gold",
  "The Age of Thorns", "The Age of Moons", "The Age of Winds",
  "The Age of Depths", "The Age of Light", "The Age of Bones",
  "The Age of Silk", "The Age of Legends", "The Age of Twilight",
  "The Age of Forever",
];

export class DayCounterSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.lastDay = -1; // -1 = uninitialized (skip first dawn detection)
    this.lastDayTime = 0;
    this.duskNotified = false;
  }

  /**
   * Tick — runs every 20 ticks (1 second).
   */
  tick() {
    const dayTime = world.getTimeOfDay(); // 0-24000
    const day = (globalThis._fc_daylight?.getDay?.() ?? 0);
    const players = world.getAllPlayers();
    if (players.length === 0) return;

    // Dawn detection: day number changed (lastDay=-1 on first tick, so -1>=0 is false = skip)
    if (this.lastDay >= 0 && day !== this.lastDay) {
      this.onDawn(players, day);
      this.duskNotified = false;
    }

    // Dusk detection: crossed 13000
    if (this.lastDayTime < 13000 && dayTime >= 13000 && !this.duskNotified) {
      this.onDusk(players, day);
      this.duskNotified = true;
    }

    this.lastDay = day;
    this.lastDayTime = dayTime;
  }

  /**
   * Handle dawn — display title with day number and era.
   */
  onDawn(players, day) {
    const dayNum = day + 1; // 1-indexed
    const eraIndex = Math.floor(dayNum / 365) % 25;
    const eraName = ERA_NAMES[eraIndex];

    for (const player of players) {
      try {
        // Title display
        player.onScreenDisplay?.setTitle?.(`§6§l☀ Day ${dayNum} ☀`, {
          fadeInDuration: 20,
          stayDuration: 80,
          fadeOutDuration: 40,
          subtitle: `§7§o~ ${eraName} ~`,
        });
      } catch {
        // Fallback to chat
        player.sendMessage(`§6§l☀ Day ${dayNum} ☀ §r§7§o~ ${eraName} ~`);
      }
    }

    // Dawn chorus sounds (staggered)
    this.playDawnChorus(players);

    this.eventBridge.emit("new_day", dayNum, eraName);
  }

  /**
   * Handle dusk — emit event for other systems.
   */
  onDusk(players, day) {
    this.eventBridge.emit("dusk", day);
  }

  /**
   * Play dawn chorus — staggered bird chirp sounds.
   */
  playDawnChorus(players) {
    // Immediate chirps
    for (const p of players) {
      try {
        p.playSound("note.flute", { volume: 0.4, pitch: 1.8 });
        p.playSound("note.chime", { volume: 0.3, pitch: 2.0 });
        p.playSound("block.amethyst_block.resonate", { volume: 0.3, pitch: 1.4 });
      } catch {}
    }

    // Staggered second chirp (8 ticks later)
    system.runTimeout(() => {
      for (const p of world.getAllPlayers()) {
        try {
          p.playSound("note.flute", { volume: 0.35, pitch: 1.6 });
          p.playSound("note.bell", { volume: 0.2, pitch: 2.0 });
        } catch {}
      }
    }, 8);

    // Third chirp (20 ticks)
    system.runTimeout(() => {
      for (const p of world.getAllPlayers()) {
        try {
          p.playSound("note.chime", { volume: 0.3, pitch: 1.8 });
          p.playSound("note.flute", { volume: 0.4, pitch: 2.0 });
        } catch {}
      }
    }, 20);

    // Final flourish (35 ticks)
    system.runTimeout(() => {
      for (const p of world.getAllPlayers()) {
        try {
          p.playSound("note.flute", { volume: 0.3, pitch: 1.4 });
          p.playSound("note.chime", { volume: 0.15, pitch: 1.6 });
          p.playSound("note.bell", { volume: 0.15, pitch: 2.0 });
        } catch {}
      }
    }, 35);
  }
}
