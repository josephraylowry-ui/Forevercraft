/**
 * Briefing System — Login briefing + morning announcements.
 * Replaces Java briefing/ folder (10 files).
 * Shows: biome, time, moon phase, season, missed events on login.
 * Morning announcement: daily tip/news broadcast at dawn.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const BIOME_NAMES = {
  "plains": "Plains", "forest": "Forest", "desert": "Desert",
  "taiga": "Taiga", "jungle": "Jungle", "swamp": "Swamp",
  "mountains": "Mountains", "ocean": "Ocean", "savanna": "Savanna",
  "badlands": "Badlands", "snowy_plains": "Snowy Plains", "dark_forest": "Dark Forest",
  "birch_forest": "Birch Forest", "old_growth_spruce_taiga": "Old Growth Spruce Taiga",
  "flower_forest": "Flower Forest", "cherry_grove": "Cherry Grove",
  "deep_ocean": "Deep Ocean", "frozen_peaks": "Frozen Peaks",
  "nether_wastes": "Nether Wastes", "crimson_forest": "Crimson Forest",
  "warped_forest": "Warped Forest", "basalt_deltas": "Basalt Deltas",
  "soul_sand_valley": "Soul Sand Valley", "the_end": "The End",
};

const MOON_PHASES = [
  "New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous",
  "Full Moon", "Waning Gibbous", "Third Quarter", "Waning Crescent",
];

const SEASONS = ["Spring", "Summer", "Autumn", "Winter"];
const SEASON_COLORS = ["§a", "§e", "§6", "§b"];

/** Unified notification prefix for realm-wide announcements */
export const NEWS_PREFIX = "§8[§6Forevercraft News§8] §r";

// Morning announcement pool — random daily tip/news
const MORNING_ANNOUNCEMENTS = [
  "§7Tip: §fGift a friend a Forever Coin to strengthen your bond!",
  "§7Tip: §fVisit the Fountain of Eternal Dreams to wish for rare items.",
  "§7Tip: §fMythical Patrons drop the best artifact crates!",
  "§7Tip: §fExplore new biomes to increase your Dream Rate.",
  "§7Tip: §fJoin or create a Guild for exclusive buffs and expeditions.",
  "§7Tip: §fComplete Realm Milestones for permanent world bonuses!",
  "§7Tip: §fTry the Codex Bestiary to track your mob hunting mastery.",
  "§7Tip: §fCook new recipes for permanent stat buffs!",
  "§7Tip: §fBuild up your Housing decoration score for milestone rewards.",
  "§7Tip: §fComplete Advantage Trees to unlock powerful passive abilities.",
  "§7Tip: §fSend your companion on an Expedition for bonus rewards.",
  "§7Tip: §fDungeon Runs give crate coins — push for higher floors!",
  "§7Tip: §fBest Friends can teleport to each other every 2 days.",
  "§7Tip: §fCampfire stories with friends grant Dream Rate bonuses.",
  "§7Tip: §fComplete constellations for 10 Forever Coins per set!",
  "§7Tip: §fCheck the Black Market for daily rotating deals.",
  "§7Tip: §fHold your companion treat to feed your active pet.",
  "§7Tip: §fMarried couples get a luck bonus when near each other!",
  "§7Tip: §fVisit the Codex for help with any game system.",
  "§7Tip: §fGuild Expeditions reward the whole team — vote on biomes!",
];

export class BriefingSystem {
  constructor(seasonSystem, eventBridge) {
    this.seasonSystem = seasonSystem;
    this.lastMorningDay = -1;

    // Event log: track world events for Welcome Back display
    /** @type {Array<{day: number, text: string}>} */
    this.eventLog = [];
    this.MAX_EVENT_LOG = 20;

    if (eventBridge) {
      // Log major world events
      eventBridge.on("world_event_started", (eventName) => {
        this.logEvent(`§eWorld Event: §f${eventName}`);
      });
      eventBridge.on("boss_spawned", (bossName) => {
        this.logEvent(`§cWorld Boss: §f${bossName} appeared!`);
      });
      eventBridge.on("calendar_event", (eventName) => {
        this.logEvent(`§6Calendar: §f${eventName}`);
      });
      eventBridge.on("milestone_achieved", (msName) => {
        this.logEvent(`§dMilestone: §f${msName} achieved!`);
      });
      eventBridge.on("guild_war_won", (guildName) => {
        this.logEvent(`§2Guild War: §f${guildName} won!`);
      });
    }
  }

  logEvent(text) {
    const day = world.getDay();
    this.eventLog.push({ day, text });
    if (this.eventLog.length > this.MAX_EVENT_LOG) {
      this.eventLog.shift();
    }
  }

  /** Show login briefing to player */
  showBriefing(player) {
    system.runTimeout(() => {
      this.doBriefing(player);
    }, 40);
  }

  doBriefing(player) {
    const s = StorageManager.forPlayer(player);
    const worldStorage = StorageManager.world();

    const timeOfDay = world.getTimeOfDay();
    const timeName = this.getTimeName(timeOfDay);
    const day = world.getDay();
    const moonPhase = day % 8;
    const moonName = MOON_PHASES[moonPhase];
    const seasonIndex = this.seasonSystem?.getSeason?.() || Math.floor((day % 365) / 91.25);
    const seasonName = SEASONS[seasonIndex] || "Unknown";
    const seasonColor = SEASON_COLORS[seasonIndex] || "§f";
    const dreamRate = s.getNumber("dream_rate") || 0;

    const lines = [
      "§6§l═══ Forevercraft ═══",
      `§7Time: §f${timeName}`,
      `§7Day: §f${day}`,
      `${seasonColor}Season: §f${seasonName}`,
      `§7Moon: §f${moonName}`,
      `§dDream Rate: §f${dreamRate}`,
      "§6§l═══════════════════",
    ];

    // Active events
    const activeEvent = worldStorage.get("last_event");
    if (activeEvent) {
      lines.splice(6, 0, `§e§lEvent: §r§e${activeEvent}`);
    }

    // Night terror warning
    if (dreamRate >= 30 && moonPhase === 0) {
      lines.splice(6, 0, "§4§l⚠ Night Terror Warning!");
    }

    // Guild info
    const guildName = s.get("guild_name");
    if (guildName) {
      lines.splice(6, 0, `§aGuild: §f${guildName}`);
    }

    // Welcome Back: show events that happened since last login
    const lastDay = s.getNumber("last_login_day", 0);
    const missedEvents = this.eventLog.filter(e => e.day > lastDay);
    if (missedEvents.length > 0) {
      lines.push("");
      lines.push("§e§lWhile you were away:");
      for (const evt of missedEvents.slice(-5)) {
        lines.push(`  §7Day ${evt.day}: ${evt.text}`);
      }
    }
    s.set("last_login_day", day);

    for (const line of lines) {
      player.sendMessage(line);
    }
  }

  /**
   * Morning announcement — called from main tick when dawn begins (timeOfDay crosses 0).
   * Broadcasts a random tip to all players once per day.
   */
  tickMorningAnnouncement() {
    const day = world.getDay();
    if (day === this.lastMorningDay) return;

    const timeOfDay = world.getTimeOfDay();
    if (timeOfDay < 500) {
      this.lastMorningDay = day;
      const tip = MORNING_ANNOUNCEMENTS[day % MORNING_ANNOUNCEMENTS.length];
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`${NEWS_PREFIX}§eGood morning, Day ${day}!`);
        p.sendMessage(`${NEWS_PREFIX}${tip}`);
        try { p.playSound("note.chime", { volume: 0.3, pitch: 1.2 }); } catch {}
      }
    }
  }

  getTimeName(timeOfDay) {
    if (timeOfDay < 1000) return "Dawn";
    if (timeOfDay < 6000) return "Morning";
    if (timeOfDay < 12000) return "Afternoon";
    if (timeOfDay < 13000) return "Dusk";
    if (timeOfDay < 18000) return "Evening";
    if (timeOfDay < 23000) return "Night";
    return "Late Night";
  }
}
