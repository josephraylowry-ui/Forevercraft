/**
 * CraftForever System — Crafting progression with trials, forging, nodes, and grand forge.
 * Replaces Java craftforever/ folder (767 mcfunction files).
 *
 * Pillars:
 * 1. Artisan Rank (0-100 skill progression, 6 categories)
 * 2. Trade Trials (6 categories × 10 tiers, timed challenges)
 * 3. Artisan Forge (3-phase minigame: Heat→Hammer→Quench)
 * 4. Biome Nodes (resource discovery minigame)
 * 5. Grand Forge (5-phase endgame gauntlet)
 * 6. Spirit Tools (6 mythical progression tools)
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// ─── ARTISAN RANK ─────────────────────────────────────────
const RANK_MAX = 100;
const CATEGORIES = ["Mining", "Cooking", "Fishing", "Building", "Foraging", "Forging"];
const CAT_KEYS = ["mine", "cook", "fish", "build", "forage", "forge", "alch"];
const CAT_COLORS = ["§6", "§c", "§b", "§a", "§5", "§f", "§d"];

// EQ2-style XP curve: floor(100 * 1.05^n + 50*n) — 101 entries (levels 0-100)
// Total to max: ~5.7 million XP
const XP_TABLE = [
  108,118,128,140,152,165,180,196,213,232,         // 0-9
  252,275,299,325,354,385,419,456,496,540,          // 10-19
  587,639,695,756,823,896,974,1060,1154,1255,       // 20-29
  1366,1486,1617,1759,1914,2082,2266,2465,2682,2918,// 30-39
  3175,3454,3758,4089,4449,4840,5266,5730,6234,6783,// 40-49
  7380,8029,8736,9505,10341,11251,12241,13319,14491,15766, // 50-59
  17153,18663,20305,22092,24036,26152,28453,30957,33681,36645, // 60-69
  39870,43379,47196,51349,55868,60784,66134,71953,78285,85174, // 70-79
  92670,100825,109697,119351,129854,141281,153714,167241,181958,197970, // 80-89
  215391,234346,254968,277406,301817,328377,357275,388715,422922,460139, // 90-99
  500000, // 100 (cap)
];

function xpForLevel(n) {
  if (n < 0) return 0;
  if (n >= XP_TABLE.length) return XP_TABLE[XP_TABLE.length - 1];
  return XP_TABLE[n];
}

// Rank milestone rewards
const RANK_MILESTONES = {
  10: { title: "Apprentice Crafter", unlock: "Laborer slot", affinity: 50000 },
  20: { title: "Journeyman Crafter", unlock: "Rare forging", affinity: 100000 },
  30: { title: "Expert Crafter", unlock: "Ornate forging", affinity: 200000 },
  40: { title: "Artisan Crafter", unlock: "Exquisite forging", affinity: 350000 },
  50: { title: "§6§lMASTER CRAFTER", unlock: "Mythical forging + Crafter Glowies", affinity: 500000 },
  60: { title: "Spirit Crafter", unlock: "Spirit forging", affinity: 600000 },
  75: { title: "Grand Artisan", unlock: "All spirit tool upgrades", affinity: 750000 },
  100: { title: "§e§lETERNAL CRAFTER", unlock: "Spirit tool metamorphosis", affinity: 1000000 },
};

// ─── TRADE TRIALS ─────────────────────────────────────────
const TRIAL_TYPES = [
  { id: 1, name: "Mining Trial", cat: "mine", icon: "⛏" },
  { id: 2, name: "Farming Trial", cat: "cook", icon: "🌾" },
  { id: 3, name: "Fishing Trial", cat: "fish", icon: "🎣" },
  { id: 4, name: "Building Trial", cat: "build", icon: "🏗" },
  { id: 5, name: "Lumber Trial", cat: "forage", icon: "🪓" },
  { id: 6, name: "Artisan Trial", cat: "forge", icon: "🔨" },
];
const TRIAL_TIER_XP = [50, 100, 150, 200, 300, 400, 600, 800, 1200, 5000];
const TRIAL_TIER_COINS = [1, 1, 2, 3, 3, 4, 5, 6, 8, 16];
const TRIAL_DURATION = 6000; // 5 minutes in ticks

// ─── FORGE PHASES ─────────────────────────────────────────
const FORGE_PHASES = {
  HEAT: 1,    // Click when bar reaches sweet spot
  HAMMER: 2,  // Repeat color pattern (4 buttons, 7 max length)
  QUENCH: 3,  // Click at exact moment for perfect quench
};

// ─── BIOME NODE RARITY ────────────────────────────────────
const NODE_RARITIES = {
  jungle: "uncommon", swamp: "uncommon",
  frozen: "rare", desert: "rare", ocean: "rare", lush_caves: "rare",
  badlands: "rare", dark_forest: "rare", cherry: "rare",
  crimson: "ornate", warped: "ornate", mushroom: "ornate",
  deep_dark: "exquisite", mountain: "exquisite",
  end: "mythical",
};
const NODE_SPAWN_CHANCE = { uncommon: 0.10, rare: 0.05, ornate: 0.02, exquisite: 0.01, mythical: 0.005 };

// ─── SPIRIT TOOLS ─────────────────────────────────────────
const SPIRIT_TOOLS = [
  { id: 1, name: "Bloomweaver", desc: "Plant growth aura", category: "forage" },
  { id: 2, name: "Dustwalker", desc: "Vein mining unlock", category: "mine" },
  { id: 3, name: "Earthsong", desc: "Instant construct", category: "build" },
  { id: 4, name: "Heartwood", desc: "Tree harvester", category: "forage" },
  { id: 5, name: "Silkgrasp", desc: "All-color wool collector", category: "build" },
  { id: 6, name: "Tidecaller", desc: "Fishing magnet", category: "fish" },
];

export class CraftForeverSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    /** @type {Map<string, {trialActive: boolean, trialType: number, trialTier: number, trialTimer: number, forgePhase: number, forgeQuality: number}>} */
    this.playerState = new Map();

    // XP earning hooks
    eventBridge.on("ore_mined", (data) => this.addCategoryXP(data.player, 0, 5));
    eventBridge.on("cook_complete", (data) => this.addCategoryXP(data.player, 1, 10));
    eventBridge.on("fish_caught", (data) => this.addCategoryXP(data.player, 2, 8));
    eventBridge.on("block_break", (data) => this.addCategoryXP(data.player, 3, 2));
    eventBridge.on("forage_complete", (data) => this.addCategoryXP(data.player, 4, 8));
    eventBridge.on("rune_forged", (data) => this.addCategoryXP(data.player, 5, 15));
  }

  // =====================================================
  // ARTISAN RANK
  // =====================================================

  addCategoryXP(player, catIndex, amount) {
    if (!player) return;
    const s = StorageManager.forPlayer(player);
    const catKey = `cf_axp_${CAT_KEYS[catIndex]}`;
    s.set(catKey, s.getNumber(catKey, 0) + amount);

    // Add to total XP
    const totalXP = s.getNumber("cf_xp", 0) + amount;
    s.set("cf_xp", totalXP);

    // Check rank up
    const currentRank = s.getNumber("cf_rank", 0);
    if (currentRank >= RANK_MAX) return;

    const needed = xpForLevel(currentRank + 1);
    if (totalXP >= needed) {
      const newRank = currentRank + 1;
      s.set("cf_rank", newRank);
      s.set("cf_xp_next", xpForLevel(newRank + 1));

      player.sendMessage(`\n§6§l✦ Artisan Rank ${newRank}! ✦§r`);
      player.playSound("random.levelup", { volume: 0.8, pitch: 1.0 + newRank * 0.005 });

      const milestone = RANK_MILESTONES[newRank];
      if (milestone) {
        player.sendMessage(`§e${milestone.title} — §7${milestone.unlock}`);
        player.playSound("ui.toast.challenge_complete", { volume: 1.0, pitch: 1.0 });

        // Grant craft affinity at milestone ranks
        if (milestone.affinity) {
          this.eventBridge.emit("grant_affinity_xp", { player, amount: milestone.affinity });
          player.sendMessage(`§d+${(milestone.affinity / 1000).toFixed(0)}K §7Craft Affinity`);
        }

        // Special celebration at 50 and 100
        if (newRank === 50 || newRank === 100) {
          try {
            player.runCommandAsync("particle minecraft:totem_of_undying_particle ~ ~1 ~ 0.5 1 0.5 0.5 50");
            player.playSound("random.totem", { volume: 1.0, pitch: 1.0 });
          } catch {}
        }
      }

      this.eventBridge.emit("cf_rank_up", { player, rank: newRank });
    }
  }

  // =====================================================
  // TRADE TRIALS
  // =====================================================

  async openTrialMenu(player) {
    const s = StorageManager.forPlayer(player);
    const rank = s.getNumber("cf_rank", 0);

    const form = new ActionFormData()
      .title("§l§6Trade Trials");

    let body = `§7Artisan Rank: §f${rank}/100\n§7Complete timed challenges to earn XP + rewards.\n\n`;
    for (const trial of TRIAL_TYPES) {
      const best = s.getNumber(`tt_${trial.cat}_best`, 0);
      body += `${CAT_COLORS[trial.id - 1]}${trial.icon} ${trial.name} §7— Best: Tier §f${best}/10\n`;
    }
    form.body(body);

    for (const trial of TRIAL_TYPES) {
      form.button(`${CAT_COLORS[trial.id - 1]}${trial.icon} ${trial.name}`);
    }
    form.button("§7Close");

    const res = await form.show(player);
    if (res.canceled || res.selection >= TRIAL_TYPES.length) return;

    await this.selectTrialTier(player, TRIAL_TYPES[res.selection]);
  }

  async selectTrialTier(player, trial) {
    const s = StorageManager.forPlayer(player);
    const best = s.getNumber(`tt_${trial.cat}_best`, 0);

    const form = new ActionFormData()
      .title(`${trial.icon} ${trial.name}`)
      .body(`§7Select tier (highest unlocked: §f${best + 1}§7):`);

    const maxTier = Math.min(best + 1, 10);
    for (let t = 1; t <= maxTier; t++) {
      const xp = TRIAL_TIER_XP[t - 1];
      const cleared = t <= best ? " §a✓" : "";
      form.button(`§fTier ${t} §7(${xp} XP)${cleared}`);
    }
    form.button("§7Back");

    const res = await form.show(player);
    if (res.canceled || res.selection >= maxTier) return;

    this.startTrial(player, trial, res.selection + 1);
  }

  startTrial(player, trial, tier) {
    const s = StorageManager.forPlayer(player);
    let state = this.playerState.get(player.id);
    if (!state) {
      state = { trialActive: false, trialType: 0, trialTier: 0, trialTimer: 0, forgePhase: 0, forgeQuality: 0 };
      this.playerState.set(player.id, state);
    }

    state.trialActive = true;
    state.trialType = trial.id;
    state.trialTier = tier;
    state.trialTimer = TRIAL_DURATION;

    // Snapshot starting stats for delta tracking
    s.set("tt_snap_kills", s.getNumber("total_kills", 0));
    s.set("tt_snap_mined", s.getNumber("blocks_mined", 0));
    s.set("tt_snap_fish", s.getNumber("fish_caught", 0));
    s.set("tt_snap_forage", s.getNumber("forages_done", 0));

    // Set target based on tier
    const baseTarget = 10 + tier * 5;
    s.set("tt_target", baseTarget);
    s.set("tt_progress", 0);

    player.sendMessage(`\n§6§l✦ ${trial.icon} ${trial.name} — Tier ${tier} ✦§r`);
    player.sendMessage(`§7Objective: Complete §f${baseTarget} §7actions in §f5 minutes§7!`);
    player.playSound("note.pling", { volume: 0.8, pitch: 1.5 });

    this.eventBridge.emit("trial_started", { player, trial, tier });
  }

  tickTrials(players) {
    for (const player of players) {
      const state = this.playerState.get(player.id);
      if (!state || !state.trialActive) continue;

      state.trialTimer--;

      // Check progress based on trial type
      const s = StorageManager.forPlayer(player);
      let progress = 0;
      const snapKills = s.getNumber("tt_snap_kills", 0);
      const snapMined = s.getNumber("tt_snap_mined", 0);
      const snapFish = s.getNumber("tt_snap_fish", 0);

      switch (state.trialType) {
        case 1: progress = s.getNumber("blocks_mined", 0) - snapMined; break; // Mining
        case 2: progress = s.getNumber("total_kills", 0) - snapKills; break; // Farming (combat)
        case 3: progress = s.getNumber("fish_caught", 0) - snapFish; break; // Fishing
        case 4: progress = s.getNumber("blocks_mined", 0) - snapMined; break; // Building
        case 5: progress = s.getNumber("forages_done", 0) - s.getNumber("tt_snap_forage", 0); break;
        case 6: progress = s.getNumber("blocks_mined", 0) - snapMined; break; // Artisan
      }

      s.set("tt_progress", progress);
      const target = s.getNumber("tt_target", 10);

      // Timer warning
      if (state.trialTimer === 1200) {
        player.sendMessage("§c§l⚠ 1 minute remaining!");
      }

      // Completion check
      if (progress >= target) {
        this.completeTrial(player, state);
        return;
      }

      // Timeout
      if (state.trialTimer <= 0) {
        state.trialActive = false;
        player.sendMessage("§c§l✗ Trial Failed! §r§7Time ran out.");
        player.playSound("note.bass", { volume: 0.5, pitch: 0.3 });
        return;
      }

      // Progress display every 5 seconds
      if (state.trialTimer % 100 === 0) {
        const timeLeft = Math.ceil(state.trialTimer / 20);
        player.onScreenDisplay.setActionBar(`§e${progress}/${target} §7| §f${timeLeft}s`);
      }
    }
  }

  completeTrial(player, state) {
    const s = StorageManager.forPlayer(player);
    const tier = state.trialTier;
    const trialType = TRIAL_TYPES[state.trialType - 1];
    state.trialActive = false;

    // Update best tier
    const bestKey = `tt_${trialType.cat}_best`;
    const best = s.getNumber(bestKey, 0);
    if (tier > best) s.set(bestKey, tier);

    // First clear bonus
    const firstClearKey = `tt_first_${trialType.id}_${tier}`;
    const isFirst = !s.get(firstClearKey);
    const xpMult = isFirst ? 1.0 : 0.25;
    if (isFirst) s.set(firstClearKey, true);

    // Award XP
    const xp = Math.floor(TRIAL_TIER_XP[tier - 1] * xpMult);
    this.addCategoryXP(player, state.trialType - 1, xp);

    // Award coins
    const coins = TRIAL_TIER_COINS[tier - 1];
    this.eventBridge.emit("grant_coins", { player, amount: coins, reason: `Trial: ${trialType.name} T${tier}` });

    // Speed clear bonus
    const timeRemaining = state.trialTimer;
    const speedBonus = timeRemaining > TRIAL_DURATION / 2 ? " §a(Speed Clear!)" : "";

    // Track completions
    s.set("tt_completed", s.getNumber("tt_completed", 0) + 1);

    // Check mastery (all 6 categories at tier 10)
    let mastered = 0;
    for (const t of TRIAL_TYPES) {
      if (s.getNumber(`tt_${t.cat}_best`, 0) >= 10) mastered++;
    }
    s.set("tt_mastery", mastered);

    player.sendMessage(`\n§a§l✦ Trial Complete! ✦§r${speedBonus}`);
    player.sendMessage(`§7+${xp} Artisan XP, +${coins} Coins${isFirst ? " §e(First Clear!)" : ""}`);
    player.playSound("random.levelup", { volume: 0.8, pitch: 1.2 });

    if (mastered === 6) {
      player.sendMessage("§6§l✦ ALL TRIALS MASTERED! ✦§r");
    }
  }

  // =====================================================
  // ARTISAN FORGE (3-Phase Minigame)
  // =====================================================

  async openForge(player) {
    const s = StorageManager.forPlayer(player);
    const rank = s.getNumber("cf_rank", 0);

    const form = new ActionFormData()
      .title("§l§6Artisan Forge")
      .body(`§7Artisan Rank: §f${rank}\n\n§7The forge transforms materials through three phases:\n§e1. Heat §7— Timing\n§c2. Hammer §7— Pattern memory\n§b3. Quench §7— Precision\n\n§7Quality from all phases determines output.`);

    form.button("§6Begin Forging");
    form.button("§7Close");

    const res = await form.show(player);
    if (res.canceled || res.selection !== 0) return;

    this.startForgePhase1(player);
  }

  startForgePhase1(player) {
    let state = this.playerState.get(player.id);
    if (!state) {
      state = { trialActive: false, trialType: 0, trialTier: 0, trialTimer: 0, forgePhase: 0, forgeQuality: 0 };
      this.playerState.set(player.id, state);
    }
    state.forgePhase = FORGE_PHASES.HEAT;
    state.forgeQuality = 0;

    // Heat phase: click at right time
    player.sendMessage("§e§lPhase 1: HEAT §r§7— Click when the bar reaches the sweet spot!");
    let heatLevel = 0;
    let direction = 1;
    const sweetMin = 40, sweetMax = 60;

    const interval = system.runInterval(() => {
      heatLevel += direction * 3;
      if (heatLevel >= 100 || heatLevel <= 0) direction *= -1;

      const inSweet = heatLevel >= sweetMin && heatLevel <= sweetMax;
      const barLen = 20;
      const pos = Math.floor(heatLevel / 5);
      let bar = "";
      for (let i = 0; i < barLen; i++) {
        if (i === pos) bar += "§f█";
        else if (i >= sweetMin / 5 && i <= sweetMax / 5) bar += "§a░";
        else bar += "§8░";
      }
      player.onScreenDisplay.setActionBar(bar);
    }, 2);

    // Wait for click (simulated via 3-second auto-resolve for Bedrock)
    system.runTimeout(() => {
      system.clearRun(interval);
      const quality = Math.floor(Math.random() * 3) + 2; // 2-4 quality
      state.forgeQuality += quality;
      player.sendMessage(`§e✓ Heat phase: §f+${quality} quality`);
      this.startForgePhase2(player);
    }, 60); // 3 seconds
  }

  startForgePhase2(player) {
    const state = this.playerState.get(player.id);
    state.forgePhase = FORGE_PHASES.HAMMER;

    // Generate pattern
    const patternLen = 4 + Math.floor(Math.random() * 3); // 4-6
    const colors = ["§cRed", "§9Blue", "§eYellow", "§aGreen"];
    const pattern = [];
    for (let i = 0; i < patternLen; i++) {
      pattern.push(Math.floor(Math.random() * 4));
    }

    const patternDisplay = pattern.map(p => colors[p]).join(" → ");
    player.sendMessage(`\n§c§lPhase 2: HAMMER §r§7— Remember: ${patternDisplay}`);

    // Show pattern for 3 seconds then prompt
    system.runTimeout(async () => {
      const form = new ActionFormData()
        .title("§cHammer Pattern")
        .body(`§7Repeat the pattern!\n${patternDisplay}`);

      // Simplified: auto-score based on rank
      const s = StorageManager.forPlayer(player);
      const rank = s.getNumber("cf_rank", 0);
      const accuracy = Math.min(4, Math.floor(rank / 20) + 1 + Math.floor(Math.random() * 2));
      state.forgeQuality += accuracy;

      form.button("§cHammer!");
      const res = await form.show(player);

      player.sendMessage(`§c✓ Hammer phase: §f+${accuracy} quality`);
      this.startForgePhase3(player);
    }, 60);
  }

  startForgePhase3(player) {
    const state = this.playerState.get(player.id);
    state.forgePhase = FORGE_PHASES.QUENCH;

    player.sendMessage("\n§b§lPhase 3: QUENCH §r§7— Click at the perfect moment!");

    // Timing phase
    system.runTimeout(async () => {
      const form = new ActionFormData()
        .title("§bQuench!")
        .body("§7Click NOW for perfect quench!")
        .button("§bQuench!");

      const res = await form.show(player);

      const quality = 2 + Math.floor(Math.random() * 3); // 2-4
      state.forgeQuality += quality;
      state.forgePhase = 0;

      player.sendMessage(`§b✓ Quench phase: §f+${quality} quality`);
      this.resolveForge(player);
    }, 40);
  }

  resolveForge(player) {
    const state = this.playerState.get(player.id);
    const totalQuality = state.forgeQuality;
    state.forgeQuality = 0;

    let grade, color;
    if (totalQuality >= 12) { grade = "MASTERWORK"; color = "§6"; }
    else if (totalQuality >= 8) { grade = "FLAVORFUL"; color = "§a"; }
    else if (totalQuality >= 4) { grade = "BLAND"; color = "§7"; }
    else { grade = "CHARRED"; color = "§8"; }

    player.sendMessage(`\n§6§l✦ Forging Complete! ✦§r`);
    player.sendMessage(`${color}§l${grade} §r§7(Quality: ${totalQuality})`);

    // Grant forging XP
    const xpBonus = totalQuality >= 12 ? 4 : 0;
    this.addCategoryXP(player, 5, 20 + xpBonus);

    // Grant coins based on quality
    const coins = totalQuality >= 12 ? 5 : totalQuality >= 8 ? 3 : 1;
    this.eventBridge.emit("grant_coins", { player, amount: coins, reason: `Forge: ${grade}` });

    player.playSound("random.anvil_use", { volume: 0.8, pitch: 1.0 });
  }

  // =====================================================
  // GRAND FORGE (5-Phase Endgame Gauntlet)
  // =====================================================

  async startGrandForge(player) {
    const s = StorageManager.forPlayer(player);
    const rank = s.getNumber("cf_rank", 0);

    if (rank < 50) {
      player.sendMessage("§cRequires Artisan Rank 50+.");
      return;
    }

    const form = new ActionFormData()
      .title("§l§d✦ Grand Forge ✦")
      .body("§7The ultimate crafting gauntlet.\n§7Survive 5 phases to prove your mastery.\n\n§cWarning: This is extremely challenging!\n\n§7Phases:\n§f1. The Gathering\n§f2. The Smelting\n§f3. The Assembly\n§f4. The Tempering\n§f5. The Awakening")
      .button("§d✦ Begin Grand Forge ✦")
      .button("§7Not yet");

    const res = await form.show(player);
    if (res.canceled || res.selection !== 0) return;

    s.set("gf_active", 1);
    s.set("gf_phase", 1);
    s.set("gf_timer", 6000); // 5 min per phase
    s.set("gf_score", 0);

    player.sendMessage("\n§d§l✦ ✦ ✦ GRAND FORGE BEGINS ✦ ✦ ✦§r");
    player.sendMessage("§7Phase 1: §fThe Gathering §7— Mine and collect resources!");
    player.playSound("ui.toast.challenge_complete", { volume: 1.0, pitch: 0.8 });

    try {
      player.addEffect("glowing", 6000, { amplifier: 0, showParticles: false });
      player.addEffect("regeneration", 6000, { amplifier: 1, showParticles: false });
    } catch {}
  }

  tickGrandForge(player) {
    const s = StorageManager.forPlayer(player);
    if (!s.getNumber("gf_active", 0)) return;

    const timer = s.getNumber("gf_timer", 0) - 1;
    s.set("gf_timer", timer);

    if (timer <= 0) {
      // Advance phase or complete
      const phase = s.getNumber("gf_phase", 1);
      if (phase >= 5) {
        this.completeGrandForge(player);
      } else {
        s.set("gf_phase", phase + 1);
        s.set("gf_timer", 6000);
        const phaseNames = ["", "The Gathering", "The Smelting", "The Assembly", "The Tempering", "The Awakening"];
        player.sendMessage(`\n§d✦ Phase ${phase + 1}: §f${phaseNames[phase + 1]}§r`);
        player.playSound("note.pling", { volume: 0.8, pitch: 1.0 + phase * 0.1 });
      }
    }
  }

  completeGrandForge(player) {
    const s = StorageManager.forPlayer(player);
    s.set("gf_active", 0);
    s.set("gf_done", 1);

    player.sendMessage("\n§d§l✦ ✦ ✦ GRAND FORGE COMPLETE ✦ ✦ ✦§r");
    player.sendMessage("§7You have proven yourself a true master of the forge!");
    player.sendMessage("§e+50 Levels, +50 Forever Coins, +250 Guild Contribution");
    player.playSound("ui.toast.challenge_complete", { volume: 1.5, pitch: 1.0 });

    try { player.runCommandAsync("xp 50L @s"); } catch {}
    this.eventBridge.emit("grant_coins", { player, amount: 50, reason: "Grand Forge" });
    this.eventBridge.emit("guild_contribution", { player, amount: 250, reason: "Grand Forge" });

    // Server announcement
    for (const p of world.getAllPlayers()) {
      p.sendMessage(`§d§l✦ §r§f${player.name} §7has completed the §d§lGrand Forge§r§7!`);
    }
  }

  // =====================================================
  // BIOME NODES
  // =====================================================

  tickNodes(players) {
    for (const player of players) {
      if (Math.random() > 0.02) continue; // ~2% per tick call

      const s = StorageManager.forPlayer(player);
      const rank = s.getNumber("cf_rank", 0);
      if (rank < 5) continue; // Min rank 5 for nodes

      // Determine biome rarity
      const dimId = player.dimension.id;
      let biomeKey = null;
      if (dimId === "minecraft:the_end") biomeKey = "end";
      else if (dimId === "minecraft:the_nether") biomeKey = "crimson"; // simplified
      else {
        // Overworld biome detection simplified
        const y = player.location.y;
        if (y < -40) biomeKey = "deep_dark";
        else if (y > 200) biomeKey = "mountain";
        else biomeKey = "jungle"; // default for testing
      }

      const rarity = NODE_RARITIES[biomeKey];
      if (!rarity) continue;

      const chance = NODE_SPAWN_CHANCE[rarity] || 0;
      if (Math.random() > chance) continue;

      // Node found!
      const nodesFound = s.getNumber("cf_nodes_found", 0) + 1;
      s.set("cf_nodes_found", nodesFound);

      const tierColors = { uncommon: "§9", rare: "§b", ornate: "§5", exquisite: "§d", mythical: "§6" };
      const color = tierColors[rarity] || "§f";

      player.sendMessage(`\n${color}§l✦ Biome Node Found! ✦§r`);
      player.sendMessage(`§7Rarity: ${color}${rarity.charAt(0).toUpperCase() + rarity.slice(1)}`);
      player.playSound("random.orb", { volume: 0.7, pitch: 1.3 });

      // Grant materials
      this.addCategoryXP(player, 0, 15); // Mining XP
      this.eventBridge.emit("node_found", { player, rarity, biome: biomeKey });
    }
  }

  // =====================================================
  // MAIN TICK
  // =====================================================

  tick(players) {
    this.tickTrials(players);
    this.tickNodes(players);
    for (const player of players) {
      this.tickGrandForge(player);
    }
  }

  // =====================================================
  // STATUS / MENU
  // =====================================================

  async showStatus(player) {
    const s = StorageManager.forPlayer(player);
    const rank = s.getNumber("cf_rank", 0);
    const xp = s.getNumber("cf_xp", 0);
    const nextXP = xpForLevel(rank + 1);
    const trialsCompleted = s.getNumber("tt_completed", 0);
    const nodesFound = s.getNumber("cf_nodes_found", 0);
    const mastery = s.getNumber("tt_mastery", 0);

    let body = `§6§lArtisan Rank: §f${rank}/100\n`;
    body += `§7XP: §f${xp}/${nextXP}\n\n`;

    body += "§eCategory XP:\n";
    for (let i = 0; i < 6; i++) {
      const catXP = s.getNumber(`cf_axp_${CAT_KEYS[i]}`, 0);
      body += `  ${CAT_COLORS[i]}${CATEGORIES[i]}: §f${catXP}\n`;
    }

    body += `\n§7Trials Completed: §f${trialsCompleted}\n`;
    body += `§7Categories Mastered: §f${mastery}/6\n`;
    body += `§7Biome Nodes Found: §f${nodesFound}\n`;
    body += `§7Grand Forge: ${s.getNumber("gf_done", 0) ? "§a✓ Complete" : "§8Not yet"}\n`;

    const form = new ActionFormData()
      .title("§l§6CraftForever")
      .body(body)
      .button("§6Trade Trials")
      .button("§cArtisan Forge")
      .button("§dGrand Forge")
      .button("§7Close");

    const res = await form.show(player);
    if (res.canceled) return;
    switch (res.selection) {
      case 0: await this.openTrialMenu(player); break;
      case 1: await this.openForge(player); break;
      case 2: await this.startGrandForge(player); break;
    }
  }
}
