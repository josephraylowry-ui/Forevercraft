/**
 * Castle Dungeon Runs — Infinite floor roguelike mode.
 * Scaling difficulty per floor. Crate coins per floor cleared.
 * Floor 100 mega-reward. Replaces Java castle_dungeon/ concept.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// Mob pool for castle waves — weighted by floor range
const FLOOR_POOLS = [
  { minFloor: 1, maxFloor: 10, mobs: [
    "minecraft:zombie", "minecraft:skeleton", "minecraft:spider", "minecraft:husk",
  ]},
  { minFloor: 11, maxFloor: 25, mobs: [
    "minecraft:zombie", "minecraft:skeleton", "minecraft:cave_spider", "minecraft:stray",
    "minecraft:witch", "minecraft:creeper",
  ]},
  { minFloor: 26, maxFloor: 50, mobs: [
    "minecraft:wither_skeleton", "minecraft:blaze", "minecraft:piglin", "minecraft:vindicator",
    "minecraft:pillager", "minecraft:evoker",
  ]},
  { minFloor: 51, maxFloor: 75, mobs: [
    "minecraft:wither_skeleton", "minecraft:piglin_brute", "minecraft:ravager",
    "minecraft:evoker", "minecraft:vindicator", "minecraft:blaze",
  ]},
  { minFloor: 76, maxFloor: Infinity, mobs: [
    "minecraft:wither_skeleton", "minecraft:piglin_brute", "minecraft:ravager",
    "minecraft:evoker", "minecraft:hoglin", "minecraft:zoglin",
  ]},
];

// Boss pool — harder bosses appear at higher floors
const BOSS_POOL = [
  { minFloor: 1, type: "minecraft:wither_skeleton", name: "Castle Guardian", baseHP: 80 },
  { minFloor: 10, type: "minecraft:vindicator", name: "Dark Knight", baseHP: 100 },
  { minFloor: 20, type: "minecraft:evoker", name: "Arcane Warden", baseHP: 120 },
  { minFloor: 30, type: "minecraft:ravager", name: "Iron Sentinel", baseHP: 160 },
  { minFloor: 50, type: "minecraft:piglin_brute", name: "Pit Lord", baseHP: 200 },
  { minFloor: 75, type: "minecraft:wither_skeleton", name: "Death Knight", baseHP: 300 },
  { minFloor: 100, type: "minecraft:wither_skeleton", name: "§6§lThe Castellan", baseHP: 500 },
];

// Crate coins per floor tier
const FLOOR_COIN_REWARDS = [
  { minFloor: 1, maxFloor: 10, coins: 1 },
  { minFloor: 11, maxFloor: 25, coins: 2 },
  { minFloor: 26, maxFloor: 50, coins: 3 },
  { minFloor: 51, maxFloor: 75, coins: 5 },
  { minFloor: 76, maxFloor: 99, coins: 8 },
  { minFloor: 100, maxFloor: Infinity, coins: 15 },
];

// Milestone floors with special rewards
const MILESTONE_FLOORS = {
  10: { crate: "rare", msg: "§b§l✦ Floor 10 Cleared! §r§7Rare Crate earned!" },
  25: { crate: "ornate", msg: "§5§l✦ Floor 25 Cleared! §r§7Ornate Crate earned!" },
  50: { crate: "exquisite", msg: "§d§l✦ Floor 50 Cleared! §r§7Exquisite Crate earned!" },
  75: { crate: "exquisite", msg: "§d§l✦ Floor 75 Cleared! §r§7Exquisite Crate + Bonus Key!" },
  100: { crate: "mythical", msg: "§6§l☄ FLOOR 100! §r§7Mythical Crate + 50 Forever Coins + Castellan Title!" },
};

const WAVE_TIMER = 4800; // 4 minutes per floor
const BOUNDARY = 48;
const REST_TICKS = 200; // 10 seconds between floors

export class CastleDungeonSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.active = null;

    world.afterEvents.itemUse.subscribe((event) => {
      if (event.itemStack?.typeId === "forevercraft:castle_key") {
        this.tryStart(event.source);
      }
    });
  }

  tryStart(player) {
    if (this.active) {
      player.sendMessage("§cA castle run is already in progress!");
      return;
    }
    this.openMenu(player);
  }

  openMenu(player) {
    const storage = StorageManager.forPlayer(player);
    const bestFloor = storage.getNumber("castle_best_floor", 0);
    const totalRuns = storage.getNumber("castle_runs", 0);

    const form = new ActionFormData()
      .title("§4⚔ Castle Dungeon Run")
      .body(
        `§7Infinite floors of escalating combat.\n` +
        `§7Each floor cleared earns §eForever Coins§7.\n` +
        `§7Milestone floors: §b10§7, §525§7, §d50§7, §d75§7, §6100§7\n\n` +
        `§7Your best: §f${bestFloor > 0 ? `Floor ${bestFloor}` : "None"}\n` +
        `§7Total runs: §f${totalRuns}`
      )
      .button("§c⚔ Begin Run")
      .button("§7Cancel");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 1) return;
      this.beginRun(player);
    });
  }

  beginRun(player) {
    // Remove castle key from hand
    try {
      const equip = player.getComponent("minecraft:equippable");
      const mainhand = equip?.getEquipment("Mainhand");
      if (mainhand?.typeId === "forevercraft:castle_key") {
        if (mainhand.amount > 1) {
          mainhand.amount--;
          equip.setEquipment("Mainhand", mainhand);
        } else {
          equip.setEquipment("Mainhand", undefined);
        }
      }
    } catch {}

    this.active = {
      floor: 0,
      timer: 60, // countdown
      phase: "countdown", // countdown, combat, rest
      center: { ...player.location },
      dimension: player.dimension,
      players: [player.id],
      mobs: [],
      startTick: system.currentTick,
      totalCoins: 0,
    };

    player.addTag("ec.castle_player");

    // Recruit nearby party members
    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 16,
        type: "minecraft:player",
      });
      for (const p of nearby) {
        if (p.id !== player.id) {
          p.addTag("ec.castle_player");
          this.active.players.push(p.id);
        }
      }
    } catch {}

    player.sendMessage("§4§l═══════════════════════════");
    player.sendMessage("§4§l  ⚔ Castle Dungeon Run");
    player.sendMessage("§4§l═══════════════════════════");
    player.sendMessage("§7Survive as many floors as you can!");
    try { player.playSound("mob.wither.spawn", { volume: 0.5, pitch: 0.9 }); } catch {}
  }

  tick() {
    if (!this.active) return;
    const run = this.active;

    if (run.phase === "countdown") {
      run.timer--;
      if (run.timer === 40) this.announce("§e§l3...");
      if (run.timer === 20) this.announce("§e§l2...");
      if (run.timer === 1) this.announce("§e§l1...");
      if (run.timer <= 0) {
        run.floor = 1;
        run.phase = "combat";
        run.timer = WAVE_TIMER;
        this.spawnFloor(run);
      }
      return;
    }

    if (run.phase === "rest") {
      run.timer--;
      if (run.timer <= 0) {
        run.phase = "combat";
        run.timer = WAVE_TIMER;
        this.spawnFloor(run);
      }
      return;
    }

    // Combat phase
    run.timer--;

    if (run.timer <= 0) {
      this.endRun("Time expired!");
      return;
    }

    // Check mobs every second
    if (run.timer % 20 === 0) {
      this.checkFloorComplete(run);
      this.checkBoundary(run);
      this.updateHUD(run);
    }
  }

  spawnFloor(run) {
    const floor = run.floor;
    const dim = run.dimension;
    const center = run.center;

    // Get mob pool for this floor
    const pool = FLOOR_POOLS.find(p => floor >= p.minFloor && floor <= p.maxFloor) || FLOOR_POOLS[FLOOR_POOLS.length - 1];

    // Mob count scales: 3 + floor/5, capped at 12
    const mobCount = Math.min(3 + Math.floor(floor / 5), 12);
    // HP scales: 20 + floor * 2
    const mobHP = 20 + floor * 2;
    // Speed boost every 10 floors
    const speedAmp = Math.min(Math.floor(floor / 10), 3);

    this.announce(`§c§lFloor ${floor} §r§7— ${mobCount} enemies incoming!`);

    for (let i = 0; i < mobCount; i++) {
      const mobType = pool.mobs[Math.floor(Math.random() * pool.mobs.length)];
      const ox = (Math.random() - 0.5) * 20;
      const oz = (Math.random() - 0.5) * 20;
      try {
        const mob = dim.spawnEntity(mobType, {
          x: center.x + ox, y: center.y, z: center.z + oz,
        });
        mob.addTag("ec.castle_mob");

        const health = mob.getComponent("minecraft:health");
        if (health) {
          try { health.setCurrentValue(mobHP); } catch {}
        }

        if (speedAmp > 0) {
          try { mob.addEffect("speed", 999999, { amplifier: speedAmp - 1, showParticles: false }); } catch {}
        }

        try { mob.addEffect("glowing", 999999, { amplifier: 0, showParticles: false }); } catch {}
      } catch {}
    }

    // Boss every 5 floors
    if (floor % 5 === 0) {
      this.spawnBoss(run, floor);
    }
  }

  spawnBoss(run, floor) {
    // Pick highest-eligible boss
    let bossDef = BOSS_POOL[0];
    for (const b of BOSS_POOL) {
      if (floor >= b.minFloor) bossDef = b;
    }

    const bossHP = bossDef.baseHP + floor * 5;
    try {
      const boss = run.dimension.spawnEntity(bossDef.type, {
        x: run.center.x, y: run.center.y, z: run.center.z + 3,
      });
      boss.addTag("ec.castle_mob");
      boss.addTag("ec.castle_boss");
      boss.nameTag = `§c§l${bossDef.name} §r§7(Floor ${floor})`;

      const health = boss.getComponent("minecraft:health");
      if (health) {
        try { health.setCurrentValue(bossHP); } catch {}
      }

      try {
        boss.addEffect("glowing", 999999, { amplifier: 0, showParticles: false });
        boss.addEffect("resistance", 999999, { amplifier: 0, showParticles: false });
      } catch {}

      this.announce(`§4§l⚔ BOSS: ${bossDef.name}! §r§7(${bossHP} HP)`);
      for (const p of this.getPlayers()) {
        try { p.playSound("mob.warden.angry", { volume: 0.5, pitch: 1.0 }); } catch {}
      }
    } catch {}
  }

  checkFloorComplete(run) {
    try {
      const alive = run.dimension.getEntities({
        location: run.center,
        maxDistance: BOUNDARY + 16,
        tags: ["ec.castle_mob"],
      });

      if (alive.length === 0 && run.phase === "combat") {
        this.onFloorCleared(run);
      }
    } catch {}
  }

  onFloorCleared(run) {
    const floor = run.floor;

    // Award crate coins
    const coinDef = FLOOR_COIN_REWARDS.find(c => floor >= c.minFloor && floor <= c.maxFloor);
    const coins = coinDef ? coinDef.coins : 1;
    run.totalCoins += coins;

    for (const player of this.getPlayers()) {
      try {
        player.dimension.runCommandAsync(
          `give "${player.name}" forevercraft:forever_coin ${coins}`
        );
      } catch {}
      player.sendMessage(`§e+${coins} Forever Coin${coins > 1 ? "s" : ""} §7(Floor ${floor})`);

      // Milestone check
      const milestone = MILESTONE_FLOORS[floor];
      if (milestone) {
        player.sendMessage(milestone.msg);
        this.eventBridge.emit("crate_give", player, milestone.crate);

        if (floor === 75) {
          try {
            player.dimension.runCommandAsync(
              `give "${player.name}" forevercraft:dungeon_key 1`
            );
          } catch {}
        }

        if (floor === 100) {
          // Floor 100 mega reward
          try {
            player.dimension.runCommandAsync(
              `give "${player.name}" forevercraft:forever_coin 50`
            );
          } catch {}
          run.totalCoins += 50;
          player.sendMessage("§6§l☄ THE CASTELLAN FALLS! §r§7You've conquered the castle!");
          try {
            const pos = player.location;
            player.dimension.runCommandAsync(
              `particle minecraft:totem_particle ${pos.x} ${pos.y + 1} ${pos.z} 1 2 1 0.1 100`
            );
            player.playSound("ui.toast.challenge_complete", { volume: 1.0, pitch: 1.0 });
          } catch {}
        }
      }

      this.eventBridge.emit("coins_earned", player, coins);
      try { player.playSound("random.orb", { volume: 0.4, pitch: 1.2 }); } catch {}
    }

    // Advance to next floor
    run.floor++;
    run.phase = "rest";
    run.timer = REST_TICKS;
    this.announce(`§a§lFloor ${floor} cleared! §r§7Next floor in 10 seconds...`);

    // Heal players between floors
    for (const p of this.getPlayers()) {
      try {
        p.addEffect("regeneration", 200, { amplifier: 2, showParticles: true });
        p.addEffect("saturation", 200, { amplifier: 0, showParticles: false });
      } catch {}
    }
  }

  checkBoundary(run) {
    for (const player of this.getPlayers()) {
      const dx = Math.abs(player.location.x - run.center.x);
      const dz = Math.abs(player.location.z - run.center.z);
      if (dx > BOUNDARY || dz > BOUNDARY) {
        try {
          player.teleport(run.center);
          player.sendMessage("§cStay in the arena!");
        } catch {}
      }
    }
  }

  endRun(reason) {
    if (!this.active) return;
    const run = this.active;
    const floorsCleared = run.floor - 1;

    for (const player of this.getPlayers()) {
      const storage = StorageManager.forPlayer(player);
      const bestFloor = storage.getNumber("castle_best_floor", 0);

      player.sendMessage("§4§l═══════════════════════════");
      player.sendMessage("§4§l  ⚔ Run Over!");
      player.sendMessage("§4§l═══════════════════════════");
      player.sendMessage(`§7Reason: §c${reason}`);
      player.sendMessage(`§7Floors cleared: §f${floorsCleared}`);
      player.sendMessage(`§7Total coins earned: §e${run.totalCoins}`);

      if (floorsCleared > bestFloor) {
        storage.set("castle_best_floor", floorsCleared);
        player.sendMessage(`§a§lNew personal best! §r§7(Previous: ${bestFloor})`);
      }

      storage.increment("castle_runs", 1);
      storage.increment("castle_total_floors", floorsCleared);
      player.removeTag("ec.castle_player");
      try { player.playSound("mob.wither.death", { volume: 0.3, pitch: 0.8 }); } catch {}
    }

    this.cleanup();
  }

  /** Player died — end run */
  onPlayerDeath(player) {
    if (!this.active) return;
    if (!player.hasTag("ec.castle_player")) return;

    // Check if any players remain
    const remaining = this.getPlayers().filter(p => p.id !== player.id);
    if (remaining.length === 0) {
      this.endRun("All players defeated");
    }
  }

  cleanup() {
    if (!this.active) return;
    try {
      const mobs = this.active.dimension.getEntities({
        location: this.active.center,
        maxDistance: BOUNDARY + 16,
        tags: ["ec.castle_mob"],
      });
      for (const mob of mobs) {
        try { mob.kill(); } catch {}
      }
    } catch {}
    this.active = null;
  }

  getPlayers() {
    return world.getAllPlayers().filter(p => p.hasTag("ec.castle_player"));
  }

  announce(msg) {
    for (const p of this.getPlayers()) {
      p.sendMessage(msg);
    }
  }

  updateHUD(run) {
    const seconds = Math.floor(run.timer / 20);
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    const timeStr = `${min}:${sec < 10 ? "0" : ""}${sec}`;

    for (const p of this.getPlayers()) {
      try {
        p.onScreenDisplay?.setActionBar?.(
          `§4Floor ${run.floor} §7| §f${timeStr} §7| §eCoins: ${run.totalCoins}`
        );
      } catch {}
    }
  }
}
