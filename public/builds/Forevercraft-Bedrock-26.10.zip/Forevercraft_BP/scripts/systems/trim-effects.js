/**
 * Trim Effects System — Custom armor trim MATERIAL abilities.
 * Replaces Java trim/ and trim_effects/ folders (149 files).
 * 11 trim materials (iron, netherite, emerald, lapis, gold, copper,
 * diamond, redstone, quartz, amethyst, resin) with per-piece + full-set effects.
 *
 * Detection: armor items tagged with forevercraft:trim_{material}
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// ─── TRIM MATERIAL DEFINITIONS ─────────────────────────
const TRIM_MATERIALS = {
  iron: {
    name: "Iron Trim",
    perPiece: { type: "damage", value: 1 }, // +1 attack damage per piece
    fullSet: { effect: "slowness", duration: 3, amplifier: 0, desc: "Slowness I (tradeoff for +4 damage)" },
  },
  netherite: {
    name: "Netherite Trim",
    perPiece: { type: "gravity_jump", gravityMod: -0.017, jumpMod: 0.1, safeFall: 3 },
    fullSet: { effect: "resistance", duration: 3, amplifier: 0, desc: "Resistance I + Float (sneak)" },
    special: "float", // Sneak to float up
  },
  emerald: {
    name: "Emerald Trim",
    perPiece: { type: "dodge", dodgePercent: 2 }, // +2% dodge per piece
    fullSet: { effect: "speed", duration: 3, amplifier: 0, desc: "Speed I" },
    special: "dodge", // Chance to dodge damage
  },
  lapis: {
    name: "Lapis Trim",
    perPiece: null,
    fullSet: { effect: "water_breathing", duration: 5, amplifier: 2, desc: "Water Breathing III" },
  },
  gold: {
    name: "Gold Trim",
    perPiece: null,
    fullSet: { effects: ["fire_resistance", "strength"], duration: 3, amplifier: 0, desc: "Fire Resistance + Strength I (indoors)" },
    special: "indoor", // Only applies when not under open sky
  },
  copper: {
    name: "Copper Trim",
    perPiece: null,
    fullSet: { effects: ["haste", "regeneration"], duration: 3, amplifier: 0, desc: "Haste I + Regeneration (-1 heart max HP)" },
  },
  diamond: {
    name: "Diamond Trim",
    perPiece: null,
    fullSet: { effects: ["slow_falling", "night_vision"], duration: 6, amplifier: 0, desc: "Slow Falling + Night Vision" },
  },
  redstone: {
    name: "Redstone Trim",
    perPiece: null,
    fullSet: { desc: "Prevent crop trampling (farmland protection)" },
    special: "farmland",
  },
  quartz: {
    name: "Quartz Trim",
    perPiece: { type: "xp_mult" }, // XP multiplier scales with count
    fullSet: { desc: "XP orbs worth 1.40x value" },
    special: "xp",
  },
  amethyst: {
    name: "Amethyst Trim",
    perPiece: null,
    fullSet: { effect: "haste", duration: 3, amplifier: 0, desc: "+15% block breaking speed (Haste I)" },
  },
  resin: {
    name: "Resin Trim",
    perPiece: null,
    fullSet: { effect: "absorption", duration: 5, amplifier: 3, desc: "Absorption IV (10 absorption hearts)" },
  },
};

const EQUIPMENT_SLOTS = ["Head", "Chest", "Legs", "Feet"];

export class TrimEffectSystem {
  constructor(eventBridge) {
    this.tickCounter = 0;

    // Dodge mechanic on player hurt
    eventBridge.on("player_hurt", ({ player, damage, damageSource }) => {
      this.onPlayerHurt(player, damageSource, damage);
    });

    // Iron trim damage bonus on attack
    eventBridge.on("player_dealt_damage", ({ player, target, damage }) => {
      this.onPlayerAttack(player, target, damage);
    });
  }

  /** Detect equipped trim materials via item tags */
  detectTrims(player) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return {};

    const trimCounts = {};
    for (const slot of EQUIPMENT_SLOTS) {
      const item = equip.getEquipment(slot);
      if (!item) continue;
      const tags = item.getTags?.() || [];
      for (const tag of tags) {
        const match = tag.match(/forevercraft:trim_(\w+)/);
        if (match) {
          const material = match[1];
          if (TRIM_MATERIALS[material]) {
            trimCounts[material] = (trimCounts[material] || 0) + 1;
          }
        }
      }
    }
    return trimCounts;
  }

  /**
   * Per-second tick: apply passive trim effects.
   * Called from main tick loop every 20 ticks (1 second).
   */
  tick(players) {
    for (const player of players) {
      const trims = this.detectTrims(player);
      if (Object.keys(trims).length === 0) {
        // Remove full set tags if no trims
        this.clearAllTrimTags(player);
        continue;
      }
      this.applyPassiveEffects(player, trims);
    }
  }

  applyPassiveEffects(player, trims) {
    const s = StorageManager.forPlayer(player);

    for (const [material, count] of Object.entries(trims)) {
      const trimDef = TRIM_MATERIALS[material];
      if (!trimDef) continue;

      // Track piece count for systems that need it
      s.set(`te_${material}_count`, count);

      // ─── Per-Piece Effects ───
      if (trimDef.perPiece && count >= 1) {
        switch (trimDef.perPiece.type) {
          case "damage":
            // Iron: +1 damage per piece via Strength scaling
            // Bedrock can't set generic attributes easily; use tag for combat handler
            if (!player.hasTag(`ec.trim_${material}`)) player.addTag(`ec.trim_${material}`);
            s.set("te_iron_bonus", count * trimDef.perPiece.value);
            break;

          case "gravity_jump":
            // Netherite: slow fall effect per piece + jump boost
            if (!player.hasTag(`ec.trim_${material}`)) player.addTag(`ec.trim_${material}`);
            try {
              player.runCommandAsync("effect @s slow_falling 3 0 true");
            } catch {}
            break;

          case "dodge":
            // Emerald: store dodge chance
            if (!player.hasTag(`ec.trim_${material}`)) player.addTag(`ec.trim_${material}`);
            s.set("te_dodge_chance", count * trimDef.perPiece.dodgePercent);
            break;

          case "xp_mult":
            // Quartz: store multiplier level
            if (!player.hasTag(`ec.trim_${material}`)) player.addTag(`ec.trim_${material}`);
            break;
        }
      } else if (trimDef.perPiece && count === 0) {
        if (player.hasTag(`ec.trim_${material}`)) player.removeTag(`ec.trim_${material}`);
      }

      // ─── Full Set Effects (4 pieces) ───
      const fullTag = `ec.trim_full_${material}`;
      if (count >= 4) {
        if (!player.hasTag(fullTag)) {
          player.addTag(fullTag);
          player.sendMessage(`§6§l✦ Full Trim: §r§e${trimDef.name}`);
          player.sendMessage(`§7${trimDef.fullSet?.desc || ""}`);
        }
        this.applyFullSetEffect(player, material, trimDef, s);
      } else if (player.hasTag(fullTag)) {
        player.removeTag(fullTag);
      }
    }

    // Clear tags for materials no longer equipped
    for (const mat of Object.keys(TRIM_MATERIALS)) {
      if (!trims[mat] || trims[mat] === 0) {
        if (player.hasTag(`ec.trim_${mat}`)) player.removeTag(`ec.trim_${mat}`);
        if (player.hasTag(`ec.trim_full_${mat}`)) player.removeTag(`ec.trim_full_${mat}`);
      }
    }
  }

  applyFullSetEffect(player, material, trimDef, s) {
    const fs = trimDef.fullSet;
    if (!fs) return;

    // Single effect
    if (fs.effect) {
      const dur = fs.duration || 3;
      const amp = fs.amplifier || 0;
      try { player.runCommandAsync(`effect @s ${fs.effect} ${dur} ${amp} true`); } catch {}
    }

    // Multiple effects
    if (fs.effects) {
      for (const eff of fs.effects) {
        const dur = fs.duration || 3;
        const amp = fs.amplifier || 0;
        // Gold: indoor-only check
        if (trimDef.special === "indoor") {
          // Check if player is under a block (rough indoor check)
          try {
            const above = player.dimension.getBlock({
              x: Math.floor(player.location.x),
              y: Math.floor(player.location.y) + 3,
              z: Math.floor(player.location.z),
            });
            if (above && !above.isAir) {
              player.runCommandAsync(`effect @s ${eff} ${dur} ${amp} true`);
            }
          } catch {}
          continue;
        }
        try { player.runCommandAsync(`effect @s ${eff} ${dur} ${amp} true`); } catch {}
      }
    }

    // ─── Special Mechanics ───

    // Netherite Float: sneak to float
    if (trimDef.special === "float") {
      try { player.runCommandAsync("effect @s resistance 3 0 true"); } catch {}
      if (player.isSneaking) {
        // Float up: apply levitation briefly
        try { player.runCommandAsync("effect @s levitation 1 0 true"); } catch {}
        if (!player.hasTag("ec.netherite_floating")) {
          player.addTag("ec.netherite_floating");
        }
      } else if (player.hasTag("ec.netherite_floating")) {
        player.removeTag("ec.netherite_floating");
        // Cancel levitation
        try { player.runCommandAsync("effect @s levitation 0"); } catch {}
      }
    }

    // Redstone: farmland protection (fill dirt→farmland)
    if (trimDef.special === "farmland") {
      try {
        const loc = player.location;
        const x = Math.floor(loc.x);
        const y = Math.floor(loc.y) - 1;
        const z = Math.floor(loc.z);
        player.runCommandAsync(`fill ${x - 8} ${y} ${z - 8} ${x + 8} ${y + 1} ${z + 8} farmland replace dirt`);
      } catch {}
    }
  }

  /** Emerald dodge on player hurt */
  onPlayerHurt(player, source, damage) {
    if (!player.hasTag("ec.trim_emerald")) return;
    const s = StorageManager.forPlayer(player);
    const dodgeChance = s.getNumber("te_dodge_chance");
    if (dodgeChance <= 0) return;

    const roll = Math.floor(Math.random() * 100) + 1;
    if (roll <= dodgeChance) {
      // Dodge success — grant brief resistance to negate damage
      try {
        player.runCommandAsync("effect @s resistance 1 4 true"); // Resistance V for 1 tick
      } catch {}
      player.onScreenDisplay.setActionBar("§a§lDodged! §r§7(Emerald Trim)");
      player.playSound("entity.player.attack.sweep");
    }
  }

  /** Iron trim bonus damage on attack */
  onPlayerAttack(player, target, damage) {
    if (!player.hasTag("ec.trim_iron")) return;
    const s = StorageManager.forPlayer(player);
    const bonus = s.getNumber("te_iron_bonus");
    if (bonus > 0) {
      try { target.applyDamage(bonus, { cause: "entityAttack", damagingEntity: player }); } catch {}
    }
  }

  clearAllTrimTags(player) {
    for (const mat of Object.keys(TRIM_MATERIALS)) {
      if (player.hasTag(`ec.trim_${mat}`)) player.removeTag(`ec.trim_${mat}`);
      if (player.hasTag(`ec.trim_full_${mat}`)) player.removeTag(`ec.trim_full_${mat}`);
    }
    if (player.hasTag("ec.netherite_floating")) player.removeTag("ec.netherite_floating");
  }
}
