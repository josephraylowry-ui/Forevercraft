/**
 * Party System — Player grouping with 9 class-based combos matching Java.
 * Replaces Java party/ folder (130 files).
 * Combos: Pack Tactics, Tidal Network, Marked for Death, Blitz,
 *         Shield Wall, Field Medic, Forge Bond, Rally Cry, Shared Fortunes.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// ─── COMBO DEFINITIONS (matching Java) ──────────────────────
const COMBOS = {
  pack_tactics: {
    name: "Pack Tactics", color: "§2",
    type: "passive", // always-on when conditions met
    triggerClass: "beastmaster", triggerLevel: 15,
    benefitClass: null, benefitLevel: 0,
    minTriggers: 2, // needs 2+ beastmasters
    distance: 48,
    desc: "2+ Beastmasters nearby — pet buffs enhanced",
  },
  tidal_network: {
    name: "Tidal Network", color: "§3",
    type: "passive",
    triggerClass: "fisher", triggerLevel: 10,
    benefitClass: "explorer", benefitLevel: 10,
    distance: 48,
    desc: "Fisher + Explorer — +1 Luck for Fisher, +DR for Explorer",
  },
  marked_for_death: {
    name: "Marked for Death", color: "§4",
    type: "state", // triggered by sneaking
    triggerClass: "stealth", triggerLevel: 10,
    benefitClass: "victorian", benefitLevel: 10,
    cooldown: 30, // seconds
    distance: 48,
    desc: "Stealth sneaks near mob — Glowing + 25% bonus damage for Victorian allies",
  },
  blitz: {
    name: "Blitz", color: "§e",
    type: "state", // triggered by sprinting
    triggerClass: "agility", triggerLevel: 10,
    benefitClass: "victorian", benefitLevel: 10,
    cooldown: 20,
    distance: 48,
    desc: "Agility sprints — Haste I for Victorian allies (6s)",
  },
  shield_wall: {
    name: "Shield Wall", color: "§6",
    type: "event", // triggered by blocking
    triggerClass: "vitality", triggerLevel: 15,
    benefitClass: "evasion", benefitLevel: 10,
    cooldown: 45,
    distance: 48,
    desc: "Block with shield — guaranteed dodge for Evasion allies (5s)",
  },
  field_medic: {
    name: "Field Medic", color: "§d",
    type: "event", // triggered by eating golden food
    triggerClass: "vitality", triggerLevel: 15,
    benefitClass: "taskmaster", benefitLevel: 10,
    cooldown: 60,
    distance: 48,
    desc: "Eat golden food — heal + Regen for Taskmaster allies",
  },
  forge_bond: {
    name: "Forge Bond", color: "§7",
    type: "event", // triggered by smithing
    triggerClass: "blacksmith", triggerLevel: 15,
    benefitClass: "dexterity", benefitLevel: 10,
    cooldown: 30,
    distance: 16,
    desc: "Smithing — +50 XP for Blacksmith + nearby Dexterity allies",
  },
  rally_cry: {
    name: "Rally Cry", color: "§a",
    type: "event", // triggered by structure crate
    triggerClass: "explorer", triggerLevel: 15,
    benefitClass: null, benefitLevel: 0,
    cooldown: 0, // gated by one-time crate opens
    distance: 48,
    desc: "Open structure crate — +2 Dream Rate for party (5 min)",
  },
  shared_fortunes: {
    name: "Shared Fortunes", color: "§b",
    type: "event", // triggered by mining/gathering proc
    triggerClass: "mining", triggerLevel: 10,
    benefitClass: "gathering", benefitLevel: 10,
    cooldown: 5,
    distance: 48,
    desc: "Mining/Gathering proc — 20% chance +3 XP levels for complementary allies",
  },
};

// Combo discovery bitfield
const COMBO_BITS = {
  pack_tactics: 0, tidal_network: 1, blitz: 2,
  marked_for_death: 3, forge_bond: 4, shared_fortunes: 5,
  shield_wall: 5, rally_cry: 6, field_medic: 3,
};

// ─── PARTY COLORS (matching Java multi-party color pool) ─────
const PARTY_COLORS = [
  { id: "gold", code: "§6", name: "Gold" },
  { id: "dark_blue", code: "§1", name: "Blue" },
  { id: "dark_green", code: "§2", name: "Green" },
  { id: "dark_aqua", code: "§3", name: "Aqua" },
  { id: "gray", code: "§7", name: "Gray" },
  { id: "light_purple", code: "§d", name: "Purple" },
  { id: "black", code: "§0", name: "Black" },
];

export class PartySystem {
  constructor(eventBridge) {
    this.parties = new Map();     // partyId → { leader, members[], colorIdx }
    this.playerParties = new Map(); // playerName → partyId
    this.comboCooldowns = new Map(); // `playerName_comboId` → secondsRemaining
    this.availableColors = [...Array(PARTY_COLORS.length).keys()]; // [0,1,2,3,4,5,6]

    // Event-based combo triggers
    eventBridge.on("player_block", (player) => {
      this.tryCombo(player, "shield_wall");
    });
    eventBridge.on("item_consumed", (player, item) => {
      const typeId = item?.typeId || "";
      if (typeId.includes("golden_apple") || typeId.includes("golden_carrot") || typeId.includes("enchanted_golden_apple")) {
        this.tryCombo(player, "field_medic");
      }
    });
    eventBridge.on("structure_crate_opened", (player) => {
      this.tryCombo(player, "rally_cry");
    });
    eventBridge.on("smithing_complete", (player) => {
      this.tryCombo(player, "forge_bond");
    });
    eventBridge.on("mining_proc", (player) => {
      this.trySharedFortunes(player, "mining");
    });
    eventBridge.on("gathering_proc", (player) => {
      this.trySharedFortunes(player, "gathering");
    });
  }

  // ─── PARTY MANAGEMENT ─────────────────────────────────────

  openPartyMenu(player) {
    const partyId = this.playerParties.get(player.name);
    if (partyId) {
      this.showPartyInfo(player, partyId);
    } else {
      this.showJoinCreate(player);
    }
  }

  showJoinCreate(player) {
    const form = new ActionFormData()
      .title("Party Menu")
      .body("§7Create or join a party to unlock combo abilities!")
      .button("§aCreate Party")
      .button("§bJoin Party");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection === 0) this.createParty(player);
      if (response.selection === 1) this.showJoinList(player);
    });
  }

  pickColor() {
    if (this.availableColors.length === 0) return 0; // fallback to gold
    const idx = Math.floor(Math.random() * this.availableColors.length);
    return this.availableColors.splice(idx, 1)[0];
  }

  returnColor(colorIdx) {
    if (!this.availableColors.includes(colorIdx)) {
      this.availableColors.push(colorIdx);
    }
  }

  getPartyColor(partyId) {
    const party = this.parties.get(partyId);
    if (!party) return PARTY_COLORS[0];
    return PARTY_COLORS[party.colorIdx] || PARTY_COLORS[0];
  }

  createParty(player) {
    const partyId = `party_${Date.now()}`;
    const colorIdx = this.pickColor();
    this.parties.set(partyId, {
      leader: player.name,
      members: [player.name],
      colorIdx,
    });
    this.playerParties.set(player.name, partyId);
    const color = PARTY_COLORS[colorIdx];
    player.sendMessage(`${color.code}§l✦ Party Created! §r§7(${color.name} team) Invite others to join.`);
    player.addTag("ec.party_leader");
    player.addTag("ec.party_member"); player.addTag("ec.in_party");
  }

  showJoinList(player) {
    const availableParties = [];
    for (const [id, party] of this.parties) {
      if (party.members.length < 6) {
        availableParties.push({ id, party });
      }
    }

    if (availableParties.length === 0) {
      player.sendMessage("§7No open parties found. Create your own!");
      return;
    }

    const form = new ActionFormData()
      .title("Join Party")
      .body("§7Select a party to join:");

    for (const { party } of availableParties) {
      const color = PARTY_COLORS[party.colorIdx] || PARTY_COLORS[0];
      form.button(`${color.code}${party.leader}'s Party §7(${party.members.length}/6)`);
    }

    form.show(player).then(response => {
      if (response.canceled) return;
      const selected = availableParties[response.selection];
      if (selected) this.joinParty(player, selected.id);
    });
  }

  joinParty(player, partyId) {
    const party = this.parties.get(partyId);
    if (!party || party.members.length >= 6) {
      player.sendMessage("§cParty is full or no longer exists.");
      return;
    }

    party.members.push(player.name);
    this.playerParties.set(player.name, partyId);
    player.addTag("ec.party_member"); player.addTag("ec.in_party");

    const color = PARTY_COLORS[party.colorIdx] || PARTY_COLORS[0];
    for (const memberName of party.members) {
      const member = world.getAllPlayers().find(p => p.name === memberName);
      if (member) member.sendMessage(`${color.code}§l✦ §r§f${player.name} §7joined the party!`);
    }
  }

  showPartyInfo(player, partyId) {
    const party = this.parties.get(partyId);
    if (!party) { this.playerParties.delete(player.name); return; }

    const isLeader = party.leader === player.name;
    const color = PARTY_COLORS[party.colorIdx] || PARTY_COLORS[0];
    let body = `${color.code}${color.name} Party\n§7Leader: §f${party.leader}\n§7Members (${party.members.length}/6):\n`;
    for (const m of party.members) {
      const online = world.getAllPlayers().find(p => p.name === m);
      body += `  ${online ? "§a●" : "§c●"} §f${m}\n`;
    }

    const form = new ActionFormData()
      .title("Party")
      .body(body)
      .button("§eCombo Status")
      .button("§cLeave Party");
    if (isLeader) form.button("§4Disband Party");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection === 0) this.showComboStatus(player);
      if (response.selection === 1) this.leaveParty(player);
      if (response.selection === 2 && isLeader) this.disbandParty(partyId);
    });
  }

  leaveParty(player) {
    const partyId = this.playerParties.get(player.name);
    if (!partyId) return;
    const party = this.parties.get(partyId);
    if (!party) return;

    party.members = party.members.filter(m => m !== player.name);
    this.playerParties.delete(player.name);
    player.removeTag("ec.party_leader");
    player.removeTag("ec.party_member"); player.removeTag("ec.in_party");
    player.sendMessage("§c§lLeft party.");

    if (party.leader === player.name && party.members.length > 0) {
      party.leader = party.members[0];
      const newLeader = world.getAllPlayers().find(p => p.name === party.leader);
      if (newLeader) {
        newLeader.addTag("ec.party_leader");
        newLeader.sendMessage("§6§l✦ §r§7You are now the party leader!");
      }
    }
    if (party.members.length === 0) {
      this.returnColor(party.colorIdx);
      this.parties.delete(partyId);
    }
  }

  disbandParty(partyId) {
    const party = this.parties.get(partyId);
    if (!party) return;
    // Return color to pool
    this.returnColor(party.colorIdx);
    for (const memberName of party.members) {
      this.playerParties.delete(memberName);
      const member = world.getAllPlayers().find(p => p.name === memberName);
      if (member) {
        member.removeTag("ec.party_leader");
        member.removeTag("ec.party_member"); member.removeTag("ec.in_party");
        member.sendMessage("§c§lParty disbanded.");
      }
    }
    this.parties.delete(partyId);
  }

  showComboStatus(player) {
    const s = StorageManager.forPlayer(player);
    let body = "§7§lParty Combos§r\n\n";

    for (const [id, combo] of Object.entries(COMBOS)) {
      const cdKey = `${player.name}_${id}`;
      const cd = this.comboCooldowns.get(cdKey) || 0;
      const status = cd > 0 ? `§c[${cd}s]` : "§a[Ready]";
      body += `${combo.color}${combo.name} ${status}\n§7  ${combo.desc}\n\n`;
    }

    const form = new ActionFormData()
      .title("Party Combos")
      .body(body)
      .button("§7Back");

    form.show(player);
  }

  // ─── COMBO HELPERS ────────────────────────────────────────

  getPartyMembers(player) {
    const partyId = this.playerParties.get(player.name);
    if (!partyId) return [];
    const party = this.parties.get(partyId);
    if (!party) return [];
    return party.members;
  }

  getOnlinePartyMembers(player) {
    const members = this.getPartyMembers(player);
    const allPlayers = world.getAllPlayers();
    return members
      .map(name => allPlayers.find(p => p.name === name))
      .filter(p => p != null);
  }

  getNearbyPartyMembers(player, radius) {
    const members = this.getOnlinePartyMembers(player);
    const loc = player.location;
    return members.filter(m => {
      if (m.name === player.name) return false;
      const ml = m.location;
      const dist = Math.sqrt((ml.x - loc.x) ** 2 + (ml.y - loc.y) ** 2 + (ml.z - loc.z) ** 2);
      return dist <= radius;
    });
  }

  getAdvLevel(player, treeName) {
    return StorageManager.forPlayer(player).getNumber(`adv_${treeName}`, 0);
  }

  isOnCooldown(player, comboId) {
    const cdKey = `${player.name}_${comboId}`;
    return (this.comboCooldowns.get(cdKey) || 0) > 0;
  }

  setCooldown(player, comboId, seconds) {
    const cdKey = `${player.name}_${comboId}`;
    this.comboCooldowns.set(cdKey, seconds);
  }

  discoverCombo(player, comboId) {
    const s = StorageManager.forPlayer(player);
    const bit = COMBO_BITS[comboId] ?? 0;
    const unlocked = s.getNumber("pc_unlocked", 0);
    if ((unlocked & (1 << bit)) === 0) {
      s.set("pc_unlocked", unlocked | (1 << bit));
      const combo = COMBOS[comboId];
      player.sendMessage(`§6§l✦ Combo Discovered: §r${combo.color}${combo.name}§r\n§7${combo.desc}`);
      player.playSound("random.orb");
    }
  }

  notifyParty(player, comboId, message) {
    const members = this.getOnlinePartyMembers(player);
    const combo = COMBOS[comboId];
    for (const m of members) {
      m.sendMessage(`${combo.color}§l✦ ${combo.name}! §r§7${message}`);
    }
  }

  // ─── COMBO: PASSIVE CHECKS (run in tick) ──────────────────

  checkPassiveCombos(player) {
    if (!this.playerParties.has(player.name)) return;
    const nearby = this.getNearbyPartyMembers(player, 48);
    if (nearby.length === 0) return;

    // Pack Tactics: 2+ beastmasters
    const beastmasters = [player, ...nearby].filter(
      p => this.getAdvLevel(p, "beastmaster") >= 15
    );
    if (beastmasters.length >= 2) {
      if (!player.hasTag("ec.pc_pack")) {
        player.addTag("ec.pc_pack");
        this.discoverCombo(player, "pack_tactics");
      }
    } else {
      player.removeTag("ec.pc_pack");
    }

    // Tidal Network: Fisher + Explorer
    const isFisher = this.getAdvLevel(player, "fisher") >= 10;
    const isExplorer = this.getAdvLevel(player, "explorer") >= 10;
    const hasComplement = nearby.some(p =>
      (isFisher && this.getAdvLevel(p, "explorer") >= 10) ||
      (isExplorer && this.getAdvLevel(p, "fisher") >= 10)
    );
    if (hasComplement) {
      if (!player.hasTag("ec.pc_tidal")) {
        player.addTag("ec.pc_tidal");
        this.discoverCombo(player, "tidal_network");
        // Fisher gets +1 Luck
        if (isFisher) {
          player.runCommandAsync("effect @s luck 10 0 true");
        }
      }
    } else {
      player.removeTag("ec.pc_tidal");
    }
  }

  // ─── COMBO: STATE-BASED (sneak/sprint) ────────────────────

  checkStateCombos(player) {
    if (!this.playerParties.has(player.name)) return;

    // Marked for Death: stealth + sneaking near mob
    try {
      if (player.isSneaking && this.getAdvLevel(player, "stealth") >= 10 && !this.isOnCooldown(player, "marked_for_death")) {
        const nearby = this.getNearbyPartyMembers(player, 48);
        if (nearby.length > 0) {
          // Find nearby mob
          const mobs = player.dimension.getEntities({
            location: player.location, maxDistance: 8,
            excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
          });
          if (mobs.length > 0) {
            const target = [...mobs][0];
            try {
              target.addTag("ec.party_marked");
              target.runCommandAsync("effect @s glowing 10 0 true");
            } catch {}
            this.setCooldown(player, "marked_for_death", 30);
            this.discoverCombo(player, "marked_for_death");
            this.notifyParty(player, "marked_for_death", `${player.name} marked a target!`);
          }
        }
      }
    } catch {}

    // Blitz: agility + sprinting
    try {
      if (player.isSprinting && this.getAdvLevel(player, "agility") >= 10 && !this.isOnCooldown(player, "blitz")) {
        const nearby = this.getNearbyPartyMembers(player, 48);
        const victorians = nearby.filter(p => this.getAdvLevel(p, "victorian") >= 10);
        if (victorians.length > 0) {
          for (const v of victorians) {
            try { v.runCommandAsync("effect @s haste 6 0 true"); } catch {}
          }
          this.setCooldown(player, "blitz", 20);
          this.discoverCombo(player, "blitz");
          this.notifyParty(player, "blitz", "Haste I for Victorian allies!");
        }
      }
    } catch {}
  }

  // ─── COMBO: EVENT-BASED ───────────────────────────────────

  tryCombo(player, comboId) {
    if (!this.playerParties.has(player.name)) return;
    if (this.isOnCooldown(player, comboId)) return;

    const combo = COMBOS[comboId];
    if (!combo) return;

    // Check trigger class
    if (combo.triggerClass && this.getAdvLevel(player, combo.triggerClass) < combo.triggerLevel) return;

    const nearby = this.getNearbyPartyMembers(player, combo.distance);
    if (nearby.length === 0) return;

    switch (comboId) {
      case "shield_wall": {
        const evasionAllies = nearby.filter(p => this.getAdvLevel(p, "evasion") >= 10);
        if (evasionAllies.length === 0) return;
        for (const a of evasionAllies) {
          StorageManager.forPlayer(a).set("dodge_timer", 100); // 5s guaranteed dodge
        }
        this.setCooldown(player, "shield_wall", 45);
        this.discoverCombo(player, "shield_wall");
        this.notifyParty(player, "shield_wall", "Guaranteed dodge for Evasion allies (5s)!");
        break;
      }

      case "field_medic": {
        const tmAllies = nearby.filter(p => this.getAdvLevel(p, "taskmaster") >= 10);
        if (tmAllies.length === 0) return;
        for (const a of tmAllies) {
          try {
            a.runCommandAsync("effect @s instant_health 1 0 true");
            a.runCommandAsync("effect @s regeneration 5 0 true");
          } catch {}
        }
        this.setCooldown(player, "field_medic", 60);
        this.discoverCombo(player, "field_medic");
        this.notifyParty(player, "field_medic", "Heal + Regen for Taskmaster allies!");
        break;
      }

      case "forge_bond": {
        const dexAllies = nearby.filter(p => this.getAdvLevel(p, "dexterity") >= 10);
        if (dexAllies.length === 0) return;
        // +50 XP to both
        try { player.runCommandAsync("xp 50 @s"); } catch {}
        for (const a of dexAllies) {
          try { a.runCommandAsync("xp 50 @s"); } catch {}
        }
        this.setCooldown(player, "forge_bond", 30);
        this.discoverCombo(player, "forge_bond");
        this.notifyParty(player, "forge_bond", "+50 XP for Blacksmith + Dexterity!");
        break;
      }

      case "rally_cry": {
        // All party members get +2 DR for 5 min
        for (const a of [...nearby, player]) {
          StorageManager.forPlayer(a).set("pc_rally_dr", 300); // 300 seconds = 5 min
        }
        this.discoverCombo(player, "rally_cry");
        this.notifyParty(player, "rally_cry", "+2 Dream Rate for 5 minutes!");
        break;
      }
    }
  }

  trySharedFortunes(player, sourceType) {
    if (!this.playerParties.has(player.name)) return;
    if (this.isOnCooldown(player, "shared_fortunes")) return;

    const triggerLevel = this.getAdvLevel(player, sourceType);
    if (triggerLevel < 10) return;

    const complementary = sourceType === "mining" ? "gathering" : "mining";
    const nearby = this.getNearbyPartyMembers(player, 48);
    const allies = nearby.filter(p => this.getAdvLevel(p, complementary) >= 10);

    if (allies.length === 0) return;

    for (const a of allies) {
      if (Math.random() < 0.2) { // 20% chance
        try { a.runCommandAsync("xp 3L @s"); } catch {}
        a.sendMessage("§b§l✦ Shared Fortunes! §r§7+3 XP levels");
      }
    }

    this.setCooldown(player, "shared_fortunes", 5);
    this.discoverCombo(player, "shared_fortunes");
  }

  // ─── PROXIMITY BUFFS ──────────────────────────────────────

  applyProximityBuffs(player) {
    if (!this.playerParties.has(player.name)) return;
    const nearby = this.getNearbyPartyMembers(player, 48);
    if (nearby.length === 0) return;

    const count = Math.min(nearby.length, 3);

    // Armor bonus: +0.5 per member (max +1.5) — via resistance
    if (count >= 2) {
      player.runCommandAsync("effect @s resistance 3 0 true");
    }
    // Regen I refreshed
    player.runCommandAsync("effect @s regeneration 3 0 true");

    // Rally DR timer
    const s = StorageManager.forPlayer(player);
    const rallyDr = s.getNumber("pc_rally_dr", 0);
    if (rallyDr > 0) {
      s.set("pc_rally_dr", rallyDr - 1);
    }
  }

  // ─── MAIN TICK (called every 1 second from main.js) ───────

  tick(players) {
    // Decrement cooldowns
    for (const [key, value] of this.comboCooldowns) {
      if (value > 0) {
        this.comboCooldowns.set(key, value - 1);
      } else {
        this.comboCooldowns.delete(key);
      }
    }

    // Per-player combo checks
    for (const player of players) {
      if (!this.playerParties.has(player.name)) continue;
      this.checkPassiveCombos(player);
      this.checkStateCombos(player);
      this.applyProximityBuffs(player);
    }
  }
}
