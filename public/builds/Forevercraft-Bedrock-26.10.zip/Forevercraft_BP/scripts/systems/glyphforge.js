/**
 * Glyphforge System — Weapon rune enchanting via physical forge blocks.
 * Replaces Java glyphforge/ folder (33 functions + 27 item modifiers + 20 advancements).
 *
 * Flow: Place forge → deposit glyph → start forging (time-gated) → collect enhanced weapon.
 * 13 unique rune types with attribute modifiers, multi-rune capacity by tier.
 *
 * Forge Duration Formula: (rf_count + 3) * 72000 ticks = (rf_count + 3) Forevercraft days
 */
import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { StorageManager } from "../utils/storage.js";

// ─── RUNE DEFINITIONS ─────────────────────────────────────
const RUNES = [
  { id: 1,  key: "emberheart",  name: "Emberheart",  color: "§c", glyphItem: "ec.ember",    attr: "attack_damage",    value: 1.5,  desc: "+1.5 Attack Damage" },
  { id: 2,  key: "verdant",     name: "Verdant",     color: "§a", glyphItem: "ec.verdant",   attr: "max_health",       value: 4.0,  desc: "+4.0 Max Health" },
  { id: 3,  key: "quicksilver", name: "Quicksilver", color: "§b", glyphItem: "ec.quick",     attr: "attack_speed",     value: 0.2,  desc: "+20% Attack Speed" },
  { id: 4,  key: "obsidian",    name: "Obsidian",    color: "§8", glyphItem: "ec.obsidian",   attr: "attack_damage",    value: 2.5,  desc: "+2.5 Attack Damage" },
  { id: 5,  key: "zephyr",      name: "Zephyr",      color: "§f", glyphItem: "ec.zephyr",    attr: "movement_speed",   value: 0.015, desc: "+15% Move Speed" },
  { id: 6,  key: "briar",       name: "Briar",       color: "§2", glyphItem: "ec.briar",     attr: "armor",            value: 3.0,  desc: "+3 Armor" },
  { id: 7,  key: "stalwart",    name: "Stalwart",    color: "§6", glyphItem: "ec.stalwart",   attr: "attack_damage",    value: 1.0,  desc: "+1 Damage, +1 Armor", attr2: "armor", value2: 1.0 },
  { id: 8,  key: "gilded",      name: "Gilded",      color: "§e", glyphItem: "ec.gilded",    attr: "luck",             value: 1.5,  desc: "+1.5 Luck (Dream Rate)" },
  { id: 9,  key: "tidecall",    name: "Tidecall",    color: "§3", glyphItem: "ec.tide",      attr: "max_health",       value: 6.0,  desc: "+6.0 Max Health" },
  { id: 10, key: "hearthstone", name: "Hearthstone", color: "§6", glyphItem: "ec.hearth",    attr: "armor",            value: 1.0,  desc: "+1 Armor, +1 Toughness", attr2: "armor_toughness", value2: 1.0 },
  { id: 11, key: "prism",       name: "Prism",       color: "§d", glyphItem: "ec.prism",     attr: "armor_toughness",  value: 5.0,  desc: "+5 Armor Toughness" },
  { id: 12, key: "tempest",     name: "Tempest",     color: "§9", glyphItem: "ec.tempest",   attr: "attack_damage",    value: 1.5,  desc: "+1.5 Attack Damage" },
  { id: 13, key: "arcanum",     name: "Arcanum",     color: "§5", glyphItem: "ec.arcanum",   attr: null,               value: 0,    desc: "Randomizes to another rune" },
];

// Rune capacity by item tier
const TIER_CAPACITY = {
  common: 1, uncommon: 1, rare: 1,
  ornate: 3, exquisite: 6, mythical: 13,
};

// Eligible weapon types
const ELIGIBLE_ITEMS = [
  "sword", "axe", "pickaxe", "hoe", "shovel", "bow", "crossbow", "trident", "shield", "mace",
];

// Forge states
const STATE = { EMPTY: 0, DEPOSITED: 1, FORGING: 2, COMPLETE: 3 };

// ─── GLYPHFORGE SYSTEM ────────────────────────────────────
export class GlyphforgeSystem {
  constructor(eventBridge) {
    this.forges = new Map(); // forgeId → forge data
    this.nextForgeId = 1;
    this.tickCounter = 0;

    // Block interaction for forge lodestones
    world.afterEvents.playerInteractWithBlock.subscribe((event) => {
      const block = event.block;
      if (block?.typeId === "minecraft:lodestone") {
        this.onForgeInteract(event.player, block);
      }
    });

    // Track rune forging achievements
    eventBridge.on("glyphforge_collect", (player) => {
      this.checkAchievements(player);
    });
  }

  // ─── FORGE REGISTRATION ──────────────────────────────────

  /** Register a new forge at a lodestone position */
  registerForge(player, block) {
    const loc = block.location;
    const key = `${Math.floor(loc.x)}_${Math.floor(loc.y)}_${Math.floor(loc.z)}`;

    // Check if already registered
    if (this.forges.has(key)) {
      player.sendMessage("§5§lGlyphforge §r§7already exists here.");
      return;
    }

    const forgeData = {
      id: this.nextForgeId++,
      location: { x: loc.x, y: loc.y, z: loc.z },
      dimension: player.dimension.id,
      state: STATE.EMPTY,
      runeId: 0,
      forgeStartedAt: 0,
      forgeDuration: 0,
      owner: player.name,
    };

    this.forges.set(key, forgeData);

    // Persist to world storage
    const ws = StorageManager.world();
    ws.set(`forge_${key}`, JSON.stringify(forgeData));

    player.sendMessage("§5§l✦ Glyphforge §r§7placed! Right-click to use.");
    player.playSound("block.anvil.place");
  }

  // ─── FORGE INTERACTION ───────────────────────────────────

  onForgeInteract(player, block) {
    const loc = block.location;
    const key = `${Math.floor(loc.x)}_${Math.floor(loc.y)}_${Math.floor(loc.z)}`;

    // Check if this lodestone is a registered forge
    let forge = this.forges.get(key);
    if (!forge) {
      // Try loading from world storage
      const ws = StorageManager.world();
      const stored = ws.get(`forge_${key}`);
      if (stored) {
        try {
          forge = JSON.parse(stored);
          this.forges.set(key, forge);
        } catch { return; }
      } else {
        // Check if player has glyphforge placement tag
        if (player.hasTag("ec.placing_forge")) {
          player.removeTag("ec.placing_forge");
          this.registerForge(player, block);
          return;
        }
        return; // Not a forge
      }
    }

    this.openForgeGUI(player, forge, key);
  }

  // ─── FORGE GUI ───────────────────────────────────────────

  openForgeGUI(player, forge, forgeKey) {
    // Check forge completion first
    this.checkForgeComplete(forge);

    switch (forge.state) {
      case STATE.EMPTY:
        this.showEmptyForge(player, forge, forgeKey);
        break;
      case STATE.DEPOSITED:
        this.showDepositedForge(player, forge, forgeKey);
        break;
      case STATE.FORGING:
        this.showForgingForge(player, forge, forgeKey);
        break;
      case STATE.COMPLETE:
        this.showCompleteForge(player, forge, forgeKey);
        break;
    }
  }

  showEmptyForge(player, forge, forgeKey) {
    const form = new ActionFormData()
      .title("§5§lGlyphforge")
      .body("§7Place a glyph stone to begin forging.\n\n§7Hold a glyph in your hand and deposit it.\n\n§8State: §fEmpty");

    // List available runes as deposit options
    form.button("§a[ Deposit Glyph ]");
    form.button("§7[ Close ]");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 1) return;
      if (response.selection === 0) this.depositGlyph(player, forge, forgeKey);
    });
  }

  showDepositedForge(player, forge, forgeKey) {
    const rune = RUNES.find(r => r.id === forge.runeId);
    const runeName = rune ? `${rune.color}${rune.name}` : "§fUnknown";

    // Calculate forge duration
    const s = StorageManager.forPlayer(player);
    const runeCount = s.getNumber("runes_forged") || 0;
    const durationDays = runeCount + 3;

    const form = new ActionFormData()
      .title("§5§lGlyphforge")
      .body(`§7Deposited: ${runeName}\n§7${rune?.desc || ""}\n\n§7Forge time: §f${durationDays} days\n\n§8State: §eReady to Forge`);

    form.button("§c§l[ Start Forging ]");
    form.button("§e[ Retrieve Glyph ]");
    form.button("§7[ Close ]");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 2) return;
      if (response.selection === 0) this.startForging(player, forge, forgeKey);
      if (response.selection === 1) this.retrieveGlyph(player, forge, forgeKey);
    });
  }

  showForgingForge(player, forge, forgeKey) {
    const rune = RUNES.find(r => r.id === forge.runeId);
    const runeName = rune ? `${rune.color}${rune.name}` : "§fUnknown";

    // Calculate time remaining
    const now = system.currentTick;
    const elapsed = now - forge.forgeStartedAt;
    const remaining = Math.max(0, forge.forgeDuration - elapsed);
    const remainingSeconds = Math.floor(remaining / 20);
    const hours = Math.floor(remainingSeconds / 3600);
    const minutes = Math.floor((remainingSeconds % 3600) / 60);

    const form = new ActionFormData()
      .title("§5§lGlyphforge")
      .body(`§7Forging: ${runeName}\n\n§7Time remaining: §f${hours}h ${minutes}m\n\n§e§oThe forge burns with arcane fire...`);

    form.button("§7[ Close ]");

    form.show(player).then(response => { /* close */ });
  }

  showCompleteForge(player, forge, forgeKey) {
    const rune = RUNES.find(r => r.id === forge.runeId);
    const runeName = rune ? `${rune.color}${rune.name}` : "§fUnknown";

    const form = new ActionFormData()
      .title("§5§lGlyphforge")
      .body(`§6§l✦ Forge Complete!\n\n§7Rune: ${runeName}\n§7${rune?.desc || ""}\n\n§7Hold the weapon you want to enchant\n§7in your main hand, then collect.`);

    form.button("§6§l[ Collect Rune ]");
    form.button("§7[ Close ]");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 1) return;
      if (response.selection === 0) this.collectRune(player, forge, forgeKey);
    });
  }

  // ─── FORGE ACTIONS ───────────────────────────────────────

  depositGlyph(player, forge, forgeKey) {
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (!mainhand) {
      player.sendMessage("§c§lHold a glyph stone in your hand.");
      return;
    }

    // Detect which glyph the player is holding via item tags
    const tags = mainhand.getTags?.() || [];
    let foundRune = null;

    for (const rune of RUNES) {
      if (tags.some(t => t.includes(`forevercraft:${rune.glyphItem}`) || t.includes(rune.glyphItem))) {
        foundRune = rune;
        break;
      }
    }

    // Also check by item type ID
    if (!foundRune) {
      const typeId = mainhand.typeId || "";
      for (const rune of RUNES) {
        if (typeId.includes(rune.key) || typeId.includes(rune.glyphItem.replace("ec.", ""))) {
          foundRune = rune;
          break;
        }
      }
    }

    if (!foundRune) {
      // Show selection menu instead
      this.showRuneSelection(player, forge, forgeKey);
      return;
    }

    // Consume glyph
    try {
      player.runCommandAsync(`clear @s ${mainhand.typeId} 1`);
    } catch {}

    // Set forge state
    forge.state = STATE.DEPOSITED;
    forge.runeId = foundRune.id;
    this.saveForge(forgeKey, forge);

    player.sendMessage(`§5§l✦ §r${foundRune.color}${foundRune.name} Glyph §r§7deposited.`);
    player.playSound("block.enchanting_table.use");

    // Re-open GUI in new state
    this.showDepositedForge(player, forge, forgeKey);
  }

  showRuneSelection(player, forge, forgeKey) {
    const form = new ActionFormData()
      .title("§5Select Glyph")
      .body("§7Choose which glyph to deposit:");

    for (const rune of RUNES) {
      form.button(`${rune.color}${rune.name}\n§7${rune.desc}`);
    }
    form.button("§7[ Cancel ]");

    form.show(player).then(response => {
      if (response.canceled || response.selection === RUNES.length) return;
      const selectedRune = RUNES[response.selection];
      if (!selectedRune) return;

      forge.state = STATE.DEPOSITED;
      forge.runeId = selectedRune.id;
      this.saveForge(forgeKey, forge);

      player.sendMessage(`§5§l✦ §r${selectedRune.color}${selectedRune.name} Glyph §r§7deposited.`);
      player.playSound("block.enchanting_table.use");
    });
  }

  startForging(player, forge, forgeKey) {
    if (forge.state !== STATE.DEPOSITED) return;

    const s = StorageManager.forPlayer(player);
    const runeCount = s.getNumber("runes_forged") || 0;
    const durationDays = runeCount + 3;
    const durationTicks = durationDays * 72000; // Forevercraft day = 72000 ticks

    forge.state = STATE.FORGING;
    forge.forgeStartedAt = system.currentTick;
    forge.forgeDuration = durationTicks;
    this.saveForge(forgeKey, forge);

    const rune = RUNES.find(r => r.id === forge.runeId);
    player.sendMessage(`§5§l✦ Forging Started! §r${rune?.color || "§f"}${rune?.name || "Unknown"}`);
    player.sendMessage(`§7Duration: §f${durationDays} days`);
    player.playSound("block.anvil.use");
  }

  retrieveGlyph(player, forge, forgeKey) {
    if (forge.state !== STATE.DEPOSITED) return;

    forge.state = STATE.EMPTY;
    forge.runeId = 0;
    this.saveForge(forgeKey, forge);

    player.sendMessage("§7Glyph retrieved.");
  }

  collectRune(player, forge, forgeKey) {
    if (forge.state !== STATE.COMPLETE) return;

    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");

    if (!mainhand) {
      player.sendMessage("§c§lHold a weapon in your main hand to apply the rune.");
      return;
    }

    // Check if item is eligible
    const typeId = mainhand.typeId || "";
    const isEligible = ELIGIBLE_ITEMS.some(type => typeId.includes(type));
    if (!isEligible) {
      player.sendMessage("§c§lThis item cannot receive runes. Use a weapon, tool, or shield.");
      return;
    }

    // Check item tier capacity
    const tags = mainhand.getTags?.() || [];
    let tier = "common";
    if (tags.some(t => t.includes("mythical"))) tier = "mythical";
    else if (tags.some(t => t.includes("exquisite"))) tier = "exquisite";
    else if (tags.some(t => t.includes("ornate"))) tier = "ornate";
    else if (tags.some(t => t.includes("rare"))) tier = "rare";
    else if (tags.some(t => t.includes("uncommon"))) tier = "uncommon";

    const maxCapacity = TIER_CAPACITY[tier] || 1;
    const s = StorageManager.forPlayer(player);

    // Count existing runes on this item (simplified — track per-player)
    const itemRuneCount = this.countRunesOnItem(tags);
    if (itemRuneCount >= maxCapacity) {
      player.sendMessage(`§c§lThis ${tier} item can only hold ${maxCapacity} rune(s).`);
      return;
    }

    // Resolve Arcanum (random)
    let runeId = forge.runeId;
    if (runeId === 13) {
      runeId = 1 + Math.floor(Math.random() * 12);
      const resolved = RUNES.find(r => r.id === runeId);
      player.sendMessage(`§5§lArcanum §r§7resolved to: ${resolved?.color || ""}${resolved?.name || "Unknown"}!`);
    }

    const rune = RUNES.find(r => r.id === runeId);
    if (!rune) return;

    // Check for duplicate rune
    if (tags.some(t => t.includes(`rf_${rune.key}`))) {
      player.sendMessage(`§c§lThis weapon already has the ${rune.name} rune!`);
      return;
    }

    // Apply rune — add tag to item and apply attribute effect to player
    this.applyRuneEffect(player, rune);

    // Track stats
    const forged = s.getNumber("runes_forged") + 1;
    s.set("runes_forged", forged);
    s.set(`has_rune_${rune.key}`, 1);

    // Reset forge
    forge.state = STATE.EMPTY;
    forge.runeId = 0;
    forge.forgeStartedAt = 0;
    forge.forgeDuration = 0;
    this.saveForge(forgeKey, forge);

    player.sendMessage(`§5§l✦ ${rune.name} Rune §r§7applied! ${rune.desc}`);
    player.playSound("random.levelup");
    player.playSound("block.enchanting_table.use");

    // Check achievements
    this.checkAchievements(player);
  }

  // ─── RUNE EFFECTS ───────────────────────────────────────

  applyRuneEffect(player, rune) {
    // Apply attribute via effects (Bedrock doesn't support custom attribute modifiers as easily)
    if (rune.attr) {
      switch (rune.attr) {
        case "attack_damage":
          player.runCommandAsync(`effect @s strength ${rune.value > 2 ? 999999 : 999999} ${rune.value > 2 ? 1 : 0} true`);
          break;
        case "max_health":
          player.runCommandAsync(`effect @s health_boost 999999 ${Math.floor(rune.value / 4)} true`);
          break;
        case "attack_speed":
          player.runCommandAsync(`effect @s haste 999999 0 true`);
          break;
        case "movement_speed":
          player.runCommandAsync(`effect @s speed 999999 0 true`);
          break;
        case "armor":
          player.runCommandAsync(`effect @s resistance 999999 0 true`);
          break;
        case "armor_toughness":
          player.runCommandAsync(`effect @s resistance 999999 0 true`);
          break;
        case "luck":
          player.runCommandAsync(`effect @s absorption 999999 0 true`);
          break;
      }
    }

    // Secondary attribute for stalwart/hearthstone
    if (rune.attr2) {
      switch (rune.attr2) {
        case "armor":
          player.runCommandAsync(`effect @s resistance 999999 0 true`);
          break;
        case "armor_toughness":
          player.runCommandAsync(`effect @s resistance 999999 0 true`);
          break;
      }
    }

    // Dream Rate bonus for Gilded
    if (rune.key === "gilded") {
      const s = StorageManager.forPlayer(player);
      const dr = s.getNumber("dream_rate") + 1.5;
      s.set("dream_rate", dr);
    }

    player.addTag(`ec.rf_${rune.key}`);
    player.addTag("ec.rf_active");
  }

  /** Reapply effects when player equips glyphforged weapon */
  reapplyEffects(player) {
    for (const rune of RUNES) {
      if (rune.id === 13) continue; // Skip arcanum
      if (player.hasTag(`ec.rf_${rune.key}`)) {
        // Effects are persistent, just ensure active tag
        player.addTag("ec.rf_active");
      }
    }
  }

  /** Strip effects when player unequips glyphforged weapon */
  stripEffects(player) {
    if (!player.hasTag("ec.rf_active")) return;
    // Effects are managed per-equip in the tick loop
    player.removeTag("ec.rf_active");
  }

  countRunesOnItem(tags) {
    let count = 0;
    for (const rune of RUNES) {
      if (rune.id === 13) continue;
      if (tags.some(t => t.includes(`rf_${rune.key}`))) count++;
    }
    return count;
  }

  // ─── FORGE MANAGEMENT ───────────────────────────────────

  checkForgeComplete(forge) {
    if (forge.state !== STATE.FORGING) return;
    const now = system.currentTick;
    const elapsed = now - forge.forgeStartedAt;
    if (elapsed >= forge.forgeDuration) {
      forge.state = STATE.COMPLETE;
    }
  }

  saveForge(forgeKey, forge) {
    this.forges.set(forgeKey, forge);
    const ws = StorageManager.world();
    ws.set(`forge_${forgeKey}`, JSON.stringify(forge));
  }

  // ─── ACHIEVEMENTS ───────────────────────────────────────

  checkAchievements(player) {
    const s = StorageManager.forPlayer(player);
    const forged = s.getNumber("runes_forged") || 0;

    const milestones = [
      { count: 1, name: "Rune Awakening", color: "§a" },
      { count: 5, name: "Rune Scribe", color: "§e" },
      { count: 15, name: "Runecaster", color: "§b" },
      { count: 30, name: "Rune Warden", color: "§5" },
      { count: 50, name: "Arcane Smith", color: "§6" },
      { count: 100, name: "Runic Grandmaster", color: "§c" },
    ];

    for (const m of milestones) {
      const key = `ach_rf_${m.count}`;
      if (forged >= m.count && !s.getNumber(key)) {
        s.set(key, 1);
        player.sendMessage(`${m.color}§l✦ Runeforge: ${m.name}!`);
        player.playSound("random.levelup");
      }
    }
  }

  // ─── PER-TICK ───────────────────────────────────────────

  /** Called every 20 ticks (1 second) from main tick */
  tick(players) {
    this.tickCounter++;

    // Check forge completions every 5 seconds
    if (this.tickCounter % 5 === 0) {
      for (const [key, forge] of this.forges) {
        this.checkForgeComplete(forge);
        if (forge.state === STATE.COMPLETE) {
          this.saveForge(key, forge);
        }
      }
    }

    // Check equipped weapon for rune effects
    for (const player of players) {
      this.checkEquippedRunes(player);
    }
  }

  checkEquippedRunes(player) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;
    const mainhand = equip.getEquipment("Mainhand");
    if (!mainhand) {
      if (player.hasTag("ec.rf_active")) this.stripEffects(player);
      return;
    }

    const tags = mainhand.getTags?.() || [];
    const hasGlyphforge = tags.some(t => t.includes("glyphforge"));

    if (hasGlyphforge && !player.hasTag("ec.rf_active")) {
      this.reapplyEffects(player);
    } else if (!hasGlyphforge && player.hasTag("ec.rf_active")) {
      this.stripEffects(player);
    }
  }

  /** Give a player the glyphforge block */
  giveForgeBlock(player) {
    player.addTag("ec.placing_forge");
    try {
      player.runCommandAsync("give @s lodestone 1");
    } catch {}
    player.sendMessage("§5§l✦ Glyphforge Block §r§7— Place a lodestone to create your forge.");
  }
}
