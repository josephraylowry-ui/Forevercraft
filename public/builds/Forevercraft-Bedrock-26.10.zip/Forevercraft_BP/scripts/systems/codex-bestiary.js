/**
 * Codex Bestiary — Track 52 mob types, kill counters, mastery damage bonus.
 * Mastery: kill 100 of a mob type → permanent +20% damage vs that type.
 * GUI: paginated mob catalog with kill counts and mastery status.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// 52 trackable mob types
const MOB_ENTRIES = [
  // Overworld — Common
  { typeId: "minecraft:zombie", name: "Zombie", icon: "🧟", category: "undead" },
  { typeId: "minecraft:skeleton", name: "Skeleton", icon: "💀", category: "undead" },
  { typeId: "minecraft:creeper", name: "Creeper", icon: "💥", category: "hostile" },
  { typeId: "minecraft:spider", name: "Spider", icon: "🕷", category: "arthropod" },
  { typeId: "minecraft:cave_spider", name: "Cave Spider", icon: "🕸", category: "arthropod" },
  { typeId: "minecraft:enderman", name: "Enderman", icon: "👁", category: "ender" },
  { typeId: "minecraft:witch", name: "Witch", icon: "🧪", category: "hostile" },
  { typeId: "minecraft:slime", name: "Slime", icon: "🟢", category: "hostile" },
  // Overworld — Variants
  { typeId: "minecraft:husk", name: "Husk", icon: "🏜", category: "undead" },
  { typeId: "minecraft:drowned", name: "Drowned", icon: "🌊", category: "undead" },
  { typeId: "minecraft:stray", name: "Stray", icon: "❄", category: "undead" },
  { typeId: "minecraft:phantom", name: "Phantom", icon: "👻", category: "undead" },
  { typeId: "minecraft:bogged", name: "Bogged", icon: "🍄", category: "undead" },
  { typeId: "minecraft:silverfish", name: "Silverfish", icon: "🐛", category: "arthropod" },
  { typeId: "minecraft:endermite", name: "Endermite", icon: "🔮", category: "ender" },
  // Overworld — Illagers
  { typeId: "minecraft:pillager", name: "Pillager", icon: "🏹", category: "illager" },
  { typeId: "minecraft:vindicator", name: "Vindicator", icon: "🪓", category: "illager" },
  { typeId: "minecraft:evoker", name: "Evoker", icon: "📖", category: "illager" },
  { typeId: "minecraft:vex", name: "Vex", icon: "⚔", category: "illager" },
  { typeId: "minecraft:ravager", name: "Ravager", icon: "🐂", category: "illager" },
  // Overworld — Aquatic
  { typeId: "minecraft:guardian", name: "Guardian", icon: "🐡", category: "aquatic" },
  { typeId: "minecraft:elder_guardian", name: "Elder Guardian", icon: "👑", category: "aquatic" },
  // Nether
  { typeId: "minecraft:blaze", name: "Blaze", icon: "🔥", category: "nether" },
  { typeId: "minecraft:wither_skeleton", name: "Wither Skeleton", icon: "⚫", category: "nether" },
  { typeId: "minecraft:ghast", name: "Ghast", icon: "😢", category: "nether" },
  { typeId: "minecraft:magma_cube", name: "Magma Cube", icon: "🟠", category: "nether" },
  { typeId: "minecraft:piglin", name: "Piglin", icon: "🐷", category: "nether" },
  { typeId: "minecraft:piglin_brute", name: "Piglin Brute", icon: "🐗", category: "nether" },
  { typeId: "minecraft:hoglin", name: "Hoglin", icon: "🦏", category: "nether" },
  { typeId: "minecraft:zoglin", name: "Zoglin", icon: "🧟", category: "nether" },
  { typeId: "minecraft:zombified_piglin", name: "Zombified Piglin", icon: "🐽", category: "nether" },
  // End
  { typeId: "minecraft:shulker", name: "Shulker", icon: "📦", category: "ender" },
  { typeId: "minecraft:ender_dragon", name: "Ender Dragon", icon: "🐉", category: "ender" },
  // Bosses
  { typeId: "minecraft:wither", name: "Wither", icon: "💀", category: "boss" },
  { typeId: "minecraft:warden", name: "Warden", icon: "🦷", category: "boss" },
  // Neutral turned hostile
  { typeId: "minecraft:bee", name: "Bee", icon: "🐝", category: "neutral" },
  { typeId: "minecraft:wolf", name: "Wolf", icon: "🐺", category: "neutral" },
  { typeId: "minecraft:iron_golem", name: "Iron Golem", icon: "🤖", category: "neutral" },
  { typeId: "minecraft:polar_bear", name: "Polar Bear", icon: "🐻", category: "neutral" },
  { typeId: "minecraft:llama", name: "Llama", icon: "🦙", category: "neutral" },
  { typeId: "minecraft:dolphin", name: "Dolphin", icon: "🐬", category: "neutral" },
  { typeId: "minecraft:panda", name: "Panda", icon: "🐼", category: "neutral" },
  { typeId: "minecraft:goat", name: "Goat", icon: "🐐", category: "neutral" },
  // Breeze (1.21)
  { typeId: "minecraft:breeze", name: "Breeze", icon: "🌬", category: "hostile" },
  // Extras
  { typeId: "minecraft:zombie_villager", name: "Zombie Villager", icon: "🧟", category: "undead" },
  { typeId: "minecraft:skeleton_horse", name: "Skeleton Horse", icon: "🐴", category: "undead" },
  { typeId: "minecraft:spider_jockey", name: "Spider Jockey", icon: "🕷", category: "special" },
  // Patron types (custom)
  { typeId: "ec:patron", name: "Patron (Any)", icon: "✣", category: "patron", isTag: true },
  { typeId: "ec:patron_mythical", name: "Mythical Patron", icon: "☄", category: "patron", isTag: true },
  // Furia
  { typeId: "ec:furia", name: "Furia Mob", icon: "🔥", category: "patron", isTag: true },
  // Dungeon bosses
  { typeId: "ec:dungeon_boss", name: "Dungeon Boss", icon: "⚔", category: "boss", isTag: true },
  { typeId: "ec:castle_boss", name: "Castle Boss", icon: "🏰", category: "boss", isTag: true },
];

const MASTERY_KILLS = 100; // kills needed for mastery
const MASTERY_DAMAGE_BONUS = 0.20; // +20% damage when mastered
const ENTRIES_PER_PAGE = 10;

// Category display names
const CATEGORY_NAMES = {
  undead: "§7Undead",
  hostile: "§cHostile",
  arthropod: "§2Arthropod",
  ender: "§5Ender",
  illager: "§8Illager",
  aquatic: "§9Aquatic",
  nether: "§4Nether",
  boss: "§6Boss",
  neutral: "§aNeutral",
  special: "§eSpecial",
  patron: "§dPatron",
};

export class CodexBestiarySystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.entryMap = new Map();
    for (const entry of MOB_ENTRIES) {
      this.entryMap.set(entry.typeId, entry);
    }

    // Track kills
    world.afterEvents.entityDie.subscribe((event) => {
      const dead = event.deadEntity;
      const killer = event.damageSource?.damagingEntity;
      if (!dead || !killer || killer.typeId !== "minecraft:player") return;
      this.recordKill(killer, dead);
    });
  }

  recordKill(player, entity) {
    const storage = StorageManager.forPlayer(player);

    // Direct mob type match
    const entry = this.entryMap.get(entity.typeId);
    if (entry && !entry.isTag) {
      this.incrementKill(player, storage, entry);
    }

    // Tag-based entries
    if (entity.hasTag?.("ec.patron")) {
      const patronEntry = this.entryMap.get("ec:patron");
      if (patronEntry) this.incrementKill(player, storage, patronEntry);
      if (entity.hasTag("ec.patron_5")) {
        const mythEntry = this.entryMap.get("ec:patron_mythical");
        if (mythEntry) this.incrementKill(player, storage, mythEntry);
      }
    }
    if (entity.hasTag?.("ec.furia")) {
      const furiaEntry = this.entryMap.get("ec:furia");
      if (furiaEntry) this.incrementKill(player, storage, furiaEntry);
    }
    if (entity.hasTag?.("ec.dg_boss")) {
      const dgEntry = this.entryMap.get("ec:dungeon_boss");
      if (dgEntry) this.incrementKill(player, storage, dgEntry);
    }
    if (entity.hasTag?.("ec.castle_boss")) {
      const castleEntry = this.entryMap.get("ec:castle_boss");
      if (castleEntry) this.incrementKill(player, storage, castleEntry);
    }
  }

  incrementKill(player, storage, entry) {
    const key = `bestiary_${entry.typeId.replace(/[:.]/g, "_")}`;
    const oldCount = storage.getNumber(key, 0);
    const newCount = oldCount + 1;
    storage.set(key, newCount);

    // Mastery unlock
    if (oldCount < MASTERY_KILLS && newCount >= MASTERY_KILLS) {
      player.sendMessage(`§6§l✦ Bestiary Mastery! §r§7${entry.name} — §a+20% damage`);
      try {
        player.playSound("random.levelup", { volume: 0.5, pitch: 1.5 });
        const pos = player.location;
        player.dimension.runCommandAsync(
          `particle minecraft:totem_particle ${pos.x} ${pos.y + 1} ${pos.z} 0.3 0.5 0.3 0 15`
        );
      } catch {}
      this.eventBridge.emit("bestiary_mastery", player, entry.typeId);
    }
  }

  /**
   * Check if player has mastery over a mob type.
   * Called by combat systems for damage bonus.
   */
  hasMastery(player, mobTypeId) {
    const storage = StorageManager.forPlayer(player);
    const entry = this.entryMap.get(mobTypeId);
    if (!entry) return false;
    const key = `bestiary_${entry.typeId.replace(/[:.]/g, "_")}`;
    return storage.getNumber(key, 0) >= MASTERY_KILLS;
  }

  /**
   * Get the damage multiplier for a player attacking a specific mob type.
   */
  getDamageMultiplier(player, mobTypeId) {
    return this.hasMastery(player, mobTypeId) ? 1.0 + MASTERY_DAMAGE_BONUS : 1.0;
  }

  // ─── GUI ────────────────────────────────────────────────────

  openBestiary(player) {
    this.showPage(player, 0);
  }

  showPage(player, page) {
    const storage = StorageManager.forPlayer(player);
    const totalPages = Math.ceil(MOB_ENTRIES.length / ENTRIES_PER_PAGE);
    const startIdx = page * ENTRIES_PER_PAGE;
    const pageEntries = MOB_ENTRIES.slice(startIdx, startIdx + ENTRIES_PER_PAGE);

    // Count total mastered
    let totalMastered = 0;
    for (const entry of MOB_ENTRIES) {
      const key = `bestiary_${entry.typeId.replace(/[:.]/g, "_")}`;
      if (storage.getNumber(key, 0) >= MASTERY_KILLS) totalMastered++;
    }

    let body = `§7Bestiary Progress: §f${totalMastered}§7/§f${MOB_ENTRIES.length} mastered\n`;
    body += `§7Page ${page + 1}/${totalPages}\n\n`;

    for (const entry of pageEntries) {
      const key = `bestiary_${entry.typeId.replace(/[:.]/g, "_")}`;
      const kills = storage.getNumber(key, 0);
      const mastered = kills >= MASTERY_KILLS;
      const bar = mastered ? "§a§lMASTERED" : `§7${kills}/${MASTERY_KILLS}`;
      const cat = CATEGORY_NAMES[entry.category] || "§7???";
      body += `${entry.icon} §f${entry.name} ${cat} — ${bar}\n`;
    }

    const form = new ActionFormData()
      .title("§6Codex Bestiary")
      .body(body);

    if (page > 0) form.button("§7← Previous Page");
    else form.button("§8← Previous Page");

    if (page < totalPages - 1) form.button("§7Next Page →");
    else form.button("§8Next Page →");

    form.button("§eFilter by Category");
    form.button("§7Close");

    form.show(player).then((r) => {
      if (r.canceled) return;
      const hasPrev = page > 0;
      const hasNext = page < totalPages - 1;

      if (r.selection === 0 && hasPrev) {
        this.showPage(player, page - 1);
      } else if (r.selection === 1 && hasNext) {
        this.showPage(player, page + 1);
      } else if (r.selection === 2) {
        this.showCategoryFilter(player);
      }
      // selection 3 = close
    });
  }

  showCategoryFilter(player) {
    const categories = [...new Set(MOB_ENTRIES.map(e => e.category))];

    const form = new ActionFormData()
      .title("§6Bestiary — Filter")
      .body("§7Select a category to view:");

    for (const cat of categories) {
      const catName = CATEGORY_NAMES[cat] || cat;
      const count = MOB_ENTRIES.filter(e => e.category === cat).length;
      form.button(`${catName} §7(${count})`);
    }
    form.button("§7Back");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === categories.length) {
        this.showPage(player, 0);
        return;
      }
      this.showCategory(player, categories[r.selection]);
    });
  }

  showCategory(player, category) {
    const storage = StorageManager.forPlayer(player);
    const entries = MOB_ENTRIES.filter(e => e.category === category);
    const catName = CATEGORY_NAMES[category] || category;

    let body = `${catName} §7— ${entries.length} entries\n\n`;

    for (const entry of entries) {
      const key = `bestiary_${entry.typeId.replace(/[:.]/g, "_")}`;
      const kills = storage.getNumber(key, 0);
      const mastered = kills >= MASTERY_KILLS;
      const bar = mastered ? "§a§lMASTERED" : `§7${kills}/${MASTERY_KILLS}`;
      body += `${entry.icon} §f${entry.name} — ${bar}\n`;
    }

    const form = new ActionFormData()
      .title(`§6Bestiary — ${catName}`)
      .body(body)
      .button("§7Back to All");

    form.show(player).then((r) => {
      if (!r.canceled) {
        this.showPage(player, 0);
      }
    });
  }
}
