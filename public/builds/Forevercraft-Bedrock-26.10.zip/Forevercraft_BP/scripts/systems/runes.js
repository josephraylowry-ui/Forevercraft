/**
 * Rune Activation System — 13 rune glyphs with consumable temporary effects.
 * Replaces Java treasure/runes/ folder (12 rune activation functions + timers).
 *
 * Runes are consumable items that grant powerful temporary effects when used.
 * All share a 5-second cooldown group. Each has unique mechanics.
 * (Permanent rune forging is handled by GlyphforgeSystem.)
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const RUNE_COOLDOWN = 5; // 5 seconds shared cooldown

const RUNE_DEFS = {
  emberheart: {
    name: "Emberheart", color: "§c", duration: 10,
    desc: "Fire ring + Resistance II",
  },
  verdant: {
    name: "Verdant", color: "§a", duration: 0,
    desc: "Full heal + cleanse negatives",
  },
  quicksilver: {
    name: "Quicksilver", color: "§b", duration: 10,
    desc: "+20% attack damage, +10% speed",
  },
  obsidian: {
    name: "Obsidian", color: "§8", duration: 20,
    desc: "+20% armor + toughness",
  },
  zephyr: {
    name: "Zephyr", color: "§f", duration: 8,
    desc: "KB immunity + 10% attack damage",
  },
  briar: {
    name: "Briar", color: "§2", duration: 10,
    desc: "+40% speed, +20% attack speed",
  },
  stalwart: {
    name: "Stalwart", color: "§6", duration: 0,
    desc: "Summon dripstone stalactites",
  },
  gilded: {
    name: "Gilded", color: "§e", duration: 10,
    desc: "Weaken nearby enemies + absorption",
  },
  tidecall: {
    name: "Tidecall", color: "§3", duration: 10,
    desc: "Drain water in 5-block radius",
  },
  hearthstone_rune: {
    name: "Hearthstone", color: "§6", duration: 0,
    desc: "Buff nearby mounts",
  },
  prism: {
    name: "Prism", color: "§d", duration: 0,
    desc: "Reverse all nearby projectiles",
  },
  tempest: {
    name: "Tempest", color: "§9", duration: 0,
    desc: "Enchant offhand with Knockback",
  },
  arcanum: {
    name: "Arcanum", color: "§5", duration: 0,
    desc: "Random rune activation",
  },
};

// Non-arcanum rune keys for random selection
const STANDARD_KEYS = Object.keys(RUNE_DEFS).filter(k => k !== "arcanum");

export class RuneSystem {
  constructor(eventBridge) {
    // Rune consumed (right-click use)
    eventBridge.on("item_consumed", ({ player, item }) => {
      this.onRuneConsumed(player, item);
    });

    eventBridge.on("item_use", ({ player, item }) => {
      this.onRuneConsumed(player, item);
    });
  }

  /** Detect if consumed item is a rune glyph */
  onRuneConsumed(player, item) {
    if (!item) return;
    const tags = item.getTags?.() || [];
    const typeId = item.typeId || "";

    let runeKey = null;
    // Check tags for rune identification
    for (const key of Object.keys(RUNE_DEFS)) {
      if (tags.some(t => t.includes(`rune_${key}`) || t.includes(`ec.${key}`))) {
        runeKey = key;
        break;
      }
    }
    // Check typeId
    if (!runeKey) {
      for (const key of Object.keys(RUNE_DEFS)) {
        if (typeId.includes(`rune_${key}`)) {
          runeKey = key;
          break;
        }
      }
    }
    // Generic rune tag
    if (!runeKey && (tags.some(t => t.includes("forevercraft:rune")) || typeId.includes("rune"))) {
      // Check for specific rune data tag
      for (const tag of tags) {
        const match = tag.match(/ec\.(ember|verdant|quick|obsidian|zephyr|briar|stalwart|gilded|tide|hearth|prism|tempest|arcanum)/);
        if (match) {
          const mapping = {
            ember: "emberheart", quick: "quicksilver", tide: "tidecall", hearth: "hearthstone_rune",
          };
          runeKey = mapping[match[1]] || match[1];
          break;
        }
      }
    }

    if (!runeKey) return;
    this.activateRune(player, runeKey);
  }

  activateRune(player, runeKey) {
    const s = StorageManager.forPlayer(player);
    const cd = s.getNumber("rune_cd", 0);
    if (cd > 0) {
      player.sendMessage(`§7Rune cooldown: §f${cd}s`);
      return;
    }

    // Resolve Arcanum
    if (runeKey === "arcanum") {
      runeKey = STANDARD_KEYS[Math.floor(Math.random() * STANDARD_KEYS.length)];
      const def = RUNE_DEFS[runeKey];
      player.sendMessage(`§5§lArcanum §r§7resolved to: ${def.color}${def.name}!`);
    }

    s.set("rune_cd", RUNE_COOLDOWN);
    const def = RUNE_DEFS[runeKey];
    if (!def) return;

    // Set duration timer if applicable
    if (def.duration > 0) {
      s.set(`rune_timer_${runeKey}`, def.duration);
    }

    // Activate
    try {
      switch (runeKey) {
        case "emberheart": this.activateEmberheart(player); break;
        case "verdant": this.activateVerdant(player); break;
        case "quicksilver": this.activateQuicksilver(player); break;
        case "obsidian": this.activateObsidian(player); break;
        case "zephyr": this.activateZephyr(player); break;
        case "briar": this.activateBriar(player); break;
        case "stalwart": this.activateStalwart(player); break;
        case "gilded": this.activateGilded(player); break;
        case "tidecall": this.activateTidecall(player); break;
        case "hearthstone_rune": this.activateHearthstone(player); break;
        case "prism": this.activatePrism(player); break;
        case "tempest": this.activateTempest(player); break;
      }
    } catch {}

    player.sendMessage(`${def.color}§l✦ ${def.name} Rune §r§7activated! ${def.desc}`);
    player.playSound("block.enchanting_table.use");
  }

  // ─── RUNE ACTIVATIONS ─────────────────────────────────────

  /** Emberheart: fire ring + Resistance II (10s) */
  activateEmberheart(player) {
    player.runCommandAsync("effect @s resistance 10 1 true");
    // Fire ring: ignite nearby mobs
    try {
      const entities = player.dimension.getEntities({
        location: player.location, maxDistance: 5,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try { e.setOnFire(5, true); } catch {}
      }
    } catch {}
    player.addTag("ec.rune_emberheart");
  }

  /** Verdant: full heal + cleanse all negatives */
  activateVerdant(player) {
    try {
      const hp = player.getComponent("minecraft:health");
      if (hp) hp.setCurrentValue(hp.effectiveMax);
    } catch {}
    const negatives = ["poison", "wither", "weakness", "slowness", "blindness",
      "mining_fatigue", "nausea", "darkness", "bad_omen"];
    for (const eff of negatives) {
      try { player.runCommandAsync(`effect @s ${eff} 0`); } catch {}
    }
  }

  /** Quicksilver: +attack damage + speed (10s) */
  activateQuicksilver(player) {
    player.runCommandAsync("effect @s strength 10 0 true");
    player.runCommandAsync("effect @s speed 10 0 true");
  }

  /** Obsidian: armor + toughness (20s) */
  activateObsidian(player) {
    player.runCommandAsync("effect @s resistance 20 1 true");
  }

  /** Zephyr: KB immunity + attack damage (8s) */
  activateZephyr(player) {
    player.runCommandAsync("effect @s strength 8 0 true");
    // KB immunity via resistance
    player.runCommandAsync("effect @s resistance 8 0 true");
    player.addTag("ec.rune_zephyr");
  }

  /** Briar: +speed + attack speed (10s) */
  activateBriar(player) {
    player.runCommandAsync("effect @s speed 10 1 true");
    player.runCommandAsync("effect @s haste 10 0 true");
  }

  /** Stalwart: summon falling dripstone (instant) */
  activateStalwart(player) {
    const loc = player.location;
    const facing = player.getViewDirection();
    for (let i = 0; i < 12; i++) {
      const offsetX = (Math.random() - 0.5) * 6 + facing.x * 4;
      const offsetZ = (Math.random() - 0.5) * 6 + facing.z * 4;
      try {
        player.runCommandAsync(
          `summon falling_block ${Math.floor(loc.x + offsetX)} ${Math.floor(loc.y + 10)} ${Math.floor(loc.z + offsetZ)}`
        );
      } catch {}
    }
    // AoE damage in front
    try {
      const entities = player.dimension.getEntities({
        location: {
          x: loc.x + facing.x * 4,
          y: loc.y,
          z: loc.z + facing.z * 4,
        },
        maxDistance: 5,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try { e.applyDamage(10, { cause: "entityAttack", damagingEntity: player }); } catch {}
      }
    } catch {}
  }

  /** Gilded: weaken nearby enemies + absorption (10s) */
  activateGilded(player) {
    player.runCommandAsync("effect @s absorption 10 1 true");
    try {
      const entities = player.dimension.getEntities({
        location: player.location, maxDistance: 8,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try {
          e.runCommandAsync("effect @s weakness 10 1 true");
        } catch {}
      }
    } catch {}
    player.addTag("ec.rune_gilded");
  }

  /** Tidecall: drain water nearby (10s — effect runs in tick) */
  activateTidecall(player) {
    player.addTag("ec.rune_tidecall");
  }

  /** Hearthstone rune: buff nearby mounts (instant) */
  activateHearthstone(player) {
    try {
      const mounts = player.dimension.getEntities({
        location: player.location, maxDistance: 10,
        families: ["horse", "donkey", "mule", "camel", "strider", "pig"],
      });
      for (const m of mounts) {
        try {
          m.runCommandAsync("effect @s strength 20 1 true");
          m.runCommandAsync("effect @s regeneration 20 2 true");
          m.runCommandAsync("effect @s resistance 20 0 true");
        } catch {}
      }
      player.sendMessage(`§6Buffed §f${mounts.length} §6nearby mounts!`);
    } catch {}
  }

  /** Prism: reverse all nearby projectiles (instant) */
  activatePrism(player) {
    // In Bedrock, we can't easily reverse projectile motion.
    // Instead: destroy projectiles + damage nearby mobs
    try {
      const projectiles = player.dimension.getEntities({
        location: player.location, maxDistance: 50,
        families: ["projectile"],
      });
      for (const p of projectiles) {
        try { p.kill(); } catch {}
      }
      player.sendMessage(`§d§lPrism: §r§7Deflected ${projectiles.length} projectiles!`);
    } catch {}
  }

  /** Tempest: enchant offhand with Knockback (instant) */
  activateTempest(player) {
    try {
      const equip = player.getComponent("minecraft:equippable");
      const offhand = equip?.getEquipment("Offhand");
      if (offhand) {
        const enchComp = offhand.getComponent("minecraft:enchantable");
        if (enchComp) {
          try {
            enchComp.addEnchantment({ type: "knockback", level: 2 });
            equip.setEquipment("Offhand", offhand);
            player.sendMessage("§9§l✦ Tempest: §r§7Knockback II applied to offhand!");
          } catch {
            player.sendMessage("§c§lCannot enchant this item.");
          }
        } else {
          player.sendMessage("§c§lOffhand item is not enchantable.");
        }
      } else {
        player.sendMessage("§c§lNo item in offhand.");
      }
    } catch {}
  }

  // ─── TICK (called every 1 second from main) ───────────────

  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);

      // Shared cooldown
      let cd = s.getNumber("rune_cd", 0);
      if (cd > 0) s.set("rune_cd", cd - 1);

      // Emberheart fire ring (continuous while active)
      let emberTimer = s.getNumber("rune_timer_emberheart", 0);
      if (emberTimer > 0) {
        s.set("rune_timer_emberheart", emberTimer - 1);
        try {
          const entities = player.dimension.getEntities({
            location: player.location, maxDistance: 5,
            excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
          });
          for (const e of entities) {
            try { e.setOnFire(3, true); } catch {}
          }
        } catch {}
        if (emberTimer - 1 <= 0) player.removeTag("ec.rune_emberheart");
      }

      // Gilded: continuous enemy weakness
      let gildedTimer = s.getNumber("rune_timer_gilded", 0);
      if (gildedTimer > 0) {
        s.set("rune_timer_gilded", gildedTimer - 1);
        try {
          const entities = player.dimension.getEntities({
            location: player.location, maxDistance: 8,
            excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
          });
          for (const e of entities) {
            try { e.runCommandAsync("effect @s weakness 3 1 true"); } catch {}
          }
        } catch {}
        if (gildedTimer - 1 <= 0) player.removeTag("ec.rune_gilded");
      }

      // Tidecall: drain water
      let tideTimer = s.getNumber("rune_timer_tidecall", 0);
      if (tideTimer > 0) {
        s.set("rune_timer_tidecall", tideTimer - 1);
        try {
          const loc = player.location;
          const x = Math.floor(loc.x);
          const y = Math.floor(loc.y);
          const z = Math.floor(loc.z);
          player.runCommandAsync(`fill ${x-5} ${y-3} ${z-5} ${x+5} ${y+3} ${z+5} air replace water`);
        } catch {}
        if (tideTimer - 1 <= 0) player.removeTag("ec.rune_tidecall");
      }

      // Zephyr: maintained KB immunity
      let zephyrTimer = s.getNumber("rune_timer_zephyr", 0);
      if (zephyrTimer > 0) {
        s.set("rune_timer_zephyr", zephyrTimer - 1);
        if (zephyrTimer - 1 <= 0) player.removeTag("ec.rune_zephyr");
      }
    }
  }
}
