/**
 * Lore Discovery System — 893 lore pieces, sparkle pickup, collection tracking.
 * Replaces Java lore/ folder (interaction entities, progress bars, book items).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { showActionForm, showPaginatedMenu } from "./gui-manager.js";

// Lore regions for collection map
const LORE_REGIONS = [
  { id: "plains", name: "Plains & Meadows", total: 120 },
  { id: "forest", name: "Forests & Groves", total: 105 },
  { id: "mountain", name: "Mountains & Caves", total: 95 },
  { id: "desert", name: "Deserts & Badlands", total: 80 },
  { id: "ocean", name: "Ocean & Coast", total: 90 },
  { id: "swamp", name: "Swamps & Marshes", total: 65 },
  { id: "snow", name: "Frozen Lands", total: 70 },
  { id: "nether", name: "The Nether", total: 110 },
  { id: "end", name: "The End", total: 60 },
  { id: "village", name: "Villages & Ruins", total: 98 },
];

export class LoreSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    // Listen for lore interaction clicks
    eventBridge.on("interact:ec.lore_click", (entity) => this.onLoreClick(entity));
  }

  onLoreClick(entity) {
    // Find nearest player
    const nearby = entity.dimension.getEntities({
      type: "minecraft:player",
      location: entity.location,
      maxDistance: 5,
    });
    if (nearby.length === 0) return;
    const player = nearby[0];
    this.collectLore(player, entity);
  }

  collectLore(player, loreEntity) {
    const storage = StorageManager.forEntity(loreEntity);
    const loreId = storage.getString("lore_id");
    if (!loreId) return;

    const playerStorage = StorageManager.forPlayer(player);
    const collected = playerStorage.getString("lore_collected_ids", "");
    const ids = collected ? collected.split(",") : [];

    if (ids.includes(loreId)) {
      player.sendMessage("§7You've already discovered this lore piece.");
      return;
    }

    ids.push(loreId);
    playerStorage.set("lore_collected_ids", ids.join(","));
    const count = playerStorage.getNumber("lore_collected") + 1;
    playerStorage.set("lore_collected", count);

    const loreName = storage.getString("lore_name", "Unknown Lore");
    const loreText = storage.getString("lore_text", "");

    player.sendMessage(`§d§l✦ Lore Discovered: §r§e${loreName}`);
    if (loreText) player.sendMessage(`§7§o${loreText}`);
    player.onScreenDisplay.setTitle("§dLore Discovered", {
      subtitle: `§e${loreName}`,
      fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 10,
    });

    // Track by region for lore collection map
    const region = storage.getString("lore_region", "");
    if (region) {
      const regionKey = `lore_region_${region}`;
      playerStorage.set(regionKey, playerStorage.getNumber(regionKey, 0) + 1);
    }

    this.eventBridge.emit("lore_discovered", player, loreId, count);

    // Remove sparkle entity
    try { loreEntity.kill(); } catch {}
  }

  async showLoreCollection(player) {
    const { ActionFormData } = await import("@minecraft/server-ui");
    const s = StorageManager.forPlayer(player);
    const count = s.getNumber("lore_collected", 0);
    const pct = Math.floor((count / 893) * 100);
    const bar = this.makeProgressBar(pct, 20);

    let body = `§d§lLore Collection Map\n\n`;
    body += `§7Discovered: §f${count}§7/§f893 §7(§e${pct}%§7)\n`;
    body += `${bar}\n\n`;

    // Region breakdown
    const regions = LORE_REGIONS;
    for (const region of regions) {
      const regionCount = this.countRegionLore(s, region.id);
      const rPct = region.total > 0 ? Math.floor((regionCount / region.total) * 100) : 0;
      const rBar = this.makeProgressBar(rPct, 10);
      const color = rPct >= 100 ? "§a" : rPct >= 50 ? "§e" : "§7";
      body += `${color}${region.name}: §f${regionCount}/${region.total} ${rBar}\n`;
    }

    const form = new ActionFormData()
      .title("§dLore Collection")
      .body(body)
      .button("§7Close");
    await form.show(player);
  }

  makeProgressBar(pct, width) {
    const filled = Math.floor((pct / 100) * width);
    const empty = width - filled;
    return "§a" + "█".repeat(filled) + "§8" + "░".repeat(empty);
  }

  countRegionLore(storage, regionId) {
    return storage.getNumber(`lore_region_${regionId}`, 0);
  }
}
