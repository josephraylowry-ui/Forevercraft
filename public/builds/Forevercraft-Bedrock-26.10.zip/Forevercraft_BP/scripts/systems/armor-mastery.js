/**
 * Armor Mastery System — Per-slot XP, leveling, prestige (0-3),
 * per-slot enchantments, and Blacksmith's Dreaming Ember reward.
 * Replaces Java armor_mastery/ folder (16 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const MAX_LEVEL = 7;
const MAX_PRESTIGE = 3;
const EQUIPMENT_SLOTS = ["Head", "Chest", "Legs", "Feet"];

// XP costs per level (Java-matching)
const XP_COSTS = [5, 15, 30, 50, 75, 125, 250];

// Per-slot enchantment tables (unlocked at each level)
const SLOT_ENCHANTS = {
  Head: [
    { id: "protection", name: "Protection", maxLevel: 4 },
    { id: "thorns", name: "Thorns", maxLevel: 3 },
    { id: "respiration", name: "Respiration", maxLevel: 3 },
    { id: "aqua_affinity", name: "Aqua Affinity", maxLevel: 1 },
    { id: "unbreaking", name: "Unbreaking", maxLevel: 3 },
    { id: "mending", name: "Mending", maxLevel: 1 },
    { id: "fire_protection", name: "Fire Protection", maxLevel: 4 },
  ],
  Chest: [
    { id: "protection", name: "Protection", maxLevel: 4 },
    { id: "thorns", name: "Thorns", maxLevel: 3 },
    { id: "unbreaking", name: "Unbreaking", maxLevel: 3 },
    { id: "mending", name: "Mending", maxLevel: 1 },
    { id: "fire_protection", name: "Fire Protection", maxLevel: 4 },
    { id: "blast_protection", name: "Blast Protection", maxLevel: 4 },
    { id: "projectile_protection", name: "Projectile Protection", maxLevel: 4 },
  ],
  Legs: [
    { id: "protection", name: "Protection", maxLevel: 4 },
    { id: "thorns", name: "Thorns", maxLevel: 3 },
    { id: "swift_sneak", name: "Swift Sneak", maxLevel: 3 },
    { id: "unbreaking", name: "Unbreaking", maxLevel: 3 },
    { id: "mending", name: "Mending", maxLevel: 1 },
    { id: "fire_protection", name: "Fire Protection", maxLevel: 4 },
    { id: "blast_protection", name: "Blast Protection", maxLevel: 4 },
  ],
  Feet: [
    { id: "protection", name: "Protection", maxLevel: 4 },
    { id: "feather_falling", name: "Feather Falling", maxLevel: 4 },
    { id: "thorns", name: "Thorns", maxLevel: 3 },
    { id: "depth_strider", name: "Depth Strider", maxLevel: 3 },
    { id: "soul_speed", name: "Soul Speed", maxLevel: 3 },
    { id: "unbreaking", name: "Unbreaking", maxLevel: 3 },
    { id: "mending", name: "Mending", maxLevel: 1 },
  ],
};

// Prestige titles
const PRESTIGE_NAMES = ["", "Apprentice", "Journeyman", "Master"];

export class ArmorMasterySystem {
  constructor(eventBridge) {
    this.tickCounter = 0;

    // XP on taking damage while wearing artifact armor
    eventBridge.on("player_hurt", (player, source, damage) => {
      this.addXpFromDamage(player, damage);
    });
  }

  // ─── EFFECTIVE ENCHANT LEVEL ──────────────────────────────
  // Enchant level = base level + prestige (capped at 10 for Prot-type, enchant maxLevel otherwise)
  getEffectiveEnchantLevel(baseLevel, prestige, maxLevel) {
    return Math.min(baseLevel + prestige, Math.max(maxLevel, 10));
  }

  // ─── XP GAIN ──────────────────────────────────────────────

  addXpFromDamage(player, damage) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;
    const s = StorageManager.forPlayer(player);
    const xpGain = Math.max(1, Math.floor(damage));

    for (const slot of EQUIPMENT_SLOTS) {
      const item = equip.getEquipment(slot);
      if (!item) continue;
      const tags = item.getTags?.() || [];
      if (!tags.some(t => t.includes("forevercraft:artifact"))) continue;

      this._addXp(player, s, slot, xpGain);
    }
  }

  _addXp(player, s, slot, xpGain) {
    const slotKey = slot.toLowerCase();
    const prestige = s.getNumber(`am_prestige_${slotKey}`, 0);
    let level = s.getNumber(`am_level_${slotKey}`, 0);
    if (level >= MAX_LEVEL) return;

    let xp = s.getNumber(`am_xp_${slotKey}`, 0) + xpGain;
    const req = XP_COSTS[level] || 250;

    if (xp >= req) {
      xp -= req;
      level++;
      s.set(`am_level_${slotKey}`, level);
      const enchant = SLOT_ENCHANTS[slot]?.[level - 1];
      const enchName = enchant ? enchant.name : "";
      const prestigeTag = prestige > 0 ? ` §d[P${prestige}]` : "";
      player.sendMessage(`§b§l⬆ §r§7${slot} mastery §fLv${level}${prestigeTag}§7: §a${enchName}`);
      player.playSound("random.levelup");

      // Apply the new enchantment
      if (enchant) {
        this.applySlotEnchant(player, slot, enchant, prestige);
      }

      // Level 7 at prestige < 3: eligible for prestige
      if (level >= MAX_LEVEL && prestige < MAX_PRESTIGE) {
        player.sendMessage(`§d§l✦ §r§7${slot} mastery ready to §dPrestige§7! Use the Armor Mastery menu.`);
      }
    }
    s.set(`am_xp_${slotKey}`, xp);
  }

  // ─── ENCHANTMENT APPLICATION ──────────────────────────────

  applySlotEnchant(player, slot, enchant, prestige) {
    const slotMap = { Head: "slot.armor.head", Chest: "slot.armor.chest", Legs: "slot.armor.legs", Feet: "slot.armor.feet" };
    const bedrockSlot = slotMap[slot];
    if (!bedrockSlot) return;

    const effectiveLevel = this.getEffectiveEnchantLevel(1, prestige, enchant.maxLevel);
    try {
      // Enchant command applies to item in slot
      player.runCommandAsync(
        `enchant @s ${enchant.id} ${effectiveLevel}`
      );
    } catch {}
  }

  applyAllEnchants(player, slot) {
    const s = StorageManager.forPlayer(player);
    const slotKey = slot.toLowerCase();
    const level = s.getNumber(`am_level_${slotKey}`, 0);
    const prestige = s.getNumber(`am_prestige_${slotKey}`, 0);
    const enchants = SLOT_ENCHANTS[slot] || [];

    for (let i = 0; i < level && i < enchants.length; i++) {
      this.applySlotEnchant(player, slot, enchants[i], prestige);
    }
  }

  // ─── PRESTIGE ─────────────────────────────────────────────

  tryPrestige(player, slot) {
    const s = StorageManager.forPlayer(player);
    const slotKey = slot.toLowerCase();
    const level = s.getNumber(`am_level_${slotKey}`, 0);
    const prestige = s.getNumber(`am_prestige_${slotKey}`, 0);

    if (level < MAX_LEVEL) {
      player.sendMessage(`§c${slot} mastery must be level ${MAX_LEVEL} to prestige.`);
      return;
    }
    if (prestige >= MAX_PRESTIGE) {
      player.sendMessage(`§d${slot} mastery is at maximum prestige!`);
      return;
    }

    // XP cost for prestige: 30 levels worth of XP
    const xpCost = 30;
    try {
      player.runCommandAsync(`xp -${xpCost}L @s`);
    } catch {
      player.sendMessage(`§cNeed §f${xpCost} levels §cof XP to prestige.`);
      return;
    }

    // Reset level and XP, increment prestige
    const newPrestige = prestige + 1;
    s.set(`am_level_${slotKey}`, 0);
    s.set(`am_xp_${slotKey}`, 0);
    s.set(`am_prestige_${slotKey}`, newPrestige);

    const title = PRESTIGE_NAMES[newPrestige] || "Master";
    player.sendMessage(`§d§l✦ ${slot} Prestige ${newPrestige}: ${title}! §r§7Enchants now scale +${newPrestige}!`);
    player.playSound("random.levelup");

    // Prestige 3 on all slots: Blacksmith's Dreaming Ember
    this.checkDreamingEmber(player, s);
  }

  checkDreamingEmber(player, s) {
    for (const slot of EQUIPMENT_SLOTS) {
      const p = s.getNumber(`am_prestige_${slot.toLowerCase()}`, 0);
      if (p < MAX_PRESTIGE) return;
    }

    // All slots at prestige 3!
    if (s.getBool("am_dreaming_ember")) return; // Already awarded
    s.set("am_dreaming_ember", true);

    player.sendMessage("§d§l✦ Blacksmith's Dreaming Ember! §r§7+1 permanent Damage Reduction");
    player.playSound("random.totem");
    player.addTag("ec.dreaming_ember");
  }

  // ─── PASSIVE EFFECTS ──────────────────────────────────────

  applyPassiveEffects(player) {
    const s = StorageManager.forPlayer(player);

    // Dreaming Ember: +1 DR (resistance 0 = minor DR)
    if (player.hasTag("ec.dreaming_ember")) {
      try { player.runCommandAsync("effect @s resistance 25 0 true"); } catch {}
    }

    // Per-slot prestige passive: higher prestige → subtle armor toughness via absorption
    let totalPrestige = 0;
    for (const slot of EQUIPMENT_SLOTS) {
      totalPrestige += s.getNumber(`am_prestige_${slot.toLowerCase()}`, 0);
    }
    // Total prestige 8+ (all P2): absorption I, 12 (all P3): absorption II
    if (totalPrestige >= 12) {
      try { player.runCommandAsync("effect @s absorption 25 1 true"); } catch {}
    } else if (totalPrestige >= 8) {
      try { player.runCommandAsync("effect @s absorption 25 0 true"); } catch {}
    }
  }

  // ─── GUI ──────────────────────────────────────────────────

  openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const equip = player.getComponent("minecraft:equippable");

    let body = "";
    for (const slot of EQUIPMENT_SLOTS) {
      const slotKey = slot.toLowerCase();
      const level = s.getNumber(`am_level_${slotKey}`, 0);
      const prestige = s.getNumber(`am_prestige_${slotKey}`, 0);
      const xp = s.getNumber(`am_xp_${slotKey}`, 0);
      const req = level < MAX_LEVEL ? (XP_COSTS[level] || 250) : 0;
      const prestigeStr = prestige > 0 ? ` §d[P${prestige}]` : "";

      // Check if wearing artifact in slot
      const item = equip?.getEquipment(slot);
      const hasArtifact = item && (item.getTags?.() || []).some(t => t.includes("forevercraft:artifact"));
      const status = hasArtifact ? "§a●" : "§c○";

      body += `${status} §7${slot}: §fLv ${level}/${MAX_LEVEL}${prestigeStr}`;
      if (level < MAX_LEVEL) body += ` §7(${xp}/${req} XP)`;
      else if (prestige < MAX_PRESTIGE) body += " §d[PRESTIGE READY]";
      else body += " §d§lMAX";
      body += "\n";
    }

    // Dreaming Ember status
    if (s.getBool("am_dreaming_ember")) {
      body += "\n§d✦ Blacksmith's Dreaming Ember: §aActive";
    }

    const form = new ActionFormData()
      .title("§b⚒ Armor Mastery")
      .body(body)
      .button("§bHead Enchants")
      .button("§bChest Enchants")
      .button("§bLegs Enchants")
      .button("§bFeet Enchants")
      .button("§dPrestige")
      .button("§7Close");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection <= 3) {
        this.openSlotDetail(player, EQUIPMENT_SLOTS[response.selection]);
      } else if (response.selection === 4) {
        this.openPrestigeMenu(player);
      }
    });
  }

  openSlotDetail(player, slot) {
    const s = StorageManager.forPlayer(player);
    const slotKey = slot.toLowerCase();
    const level = s.getNumber(`am_level_${slotKey}`, 0);
    const prestige = s.getNumber(`am_prestige_${slotKey}`, 0);
    const enchants = SLOT_ENCHANTS[slot] || [];

    let body = `§7${slot} Mastery — Level §f${level}/${MAX_LEVEL}`;
    if (prestige > 0) body += ` §d[Prestige ${prestige}]`;
    body += "\n\n§7Enchantments:\n";

    for (let i = 0; i < enchants.length; i++) {
      const ench = enchants[i];
      const unlocked = i < level;
      const effectiveLevel = unlocked ? this.getEffectiveEnchantLevel(1, prestige, ench.maxLevel) : 0;
      const icon = unlocked ? "§a✓" : "§8✗";
      const levelStr = unlocked ? ` §f${this._romanNumeral(effectiveLevel)}` : "";
      body += `  ${icon} §7Lv${i + 1}: ${ench.name}${levelStr}\n`;
    }

    const form = new ActionFormData()
      .title(`§b⚒ ${slot} Mastery`)
      .body(body)
      .button("§aReapply Enchants")
      .button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection === 0) {
        this.applyAllEnchants(player, slot);
        player.sendMessage(`§a§l✦ §r§7Reapplied ${slot} enchantments.`);
        player.playSound("random.anvil_use");
      } else {
        this.openMenu(player);
      }
    });
  }

  openPrestigeMenu(player) {
    const s = StorageManager.forPlayer(player);
    let body = "§7Prestige resets your mastery level but\n§7enhances all enchantment levels permanently.\n\n";
    body += "§7Cost: §f30 XP Levels\n\n";

    for (const slot of EQUIPMENT_SLOTS) {
      const slotKey = slot.toLowerCase();
      const level = s.getNumber(`am_level_${slotKey}`, 0);
      const prestige = s.getNumber(`am_prestige_${slotKey}`, 0);
      const canPrestige = level >= MAX_LEVEL && prestige < MAX_PRESTIGE;
      const icon = canPrestige ? "§d✦" : "§8○";
      body += `${icon} §7${slot}: P${prestige}/${MAX_PRESTIGE}`;
      if (canPrestige) body += " §d[READY]";
      else if (prestige >= MAX_PRESTIGE) body += " §d§lMAX";
      else body += ` §7(Lv${level}/${MAX_LEVEL})`;
      body += "\n";
    }

    const form = new ActionFormData()
      .title("§d⚒ Prestige")
      .body(body)
      .button("§dPrestige Head")
      .button("§dPrestige Chest")
      .button("§dPrestige Legs")
      .button("§dPrestige Feet")
      .button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection <= 3) {
        this.tryPrestige(player, EQUIPMENT_SLOTS[response.selection]);
      } else {
        this.openMenu(player);
      }
    });
  }

  _romanNumeral(n) {
    const map = [[10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]];
    let result = "";
    for (const [val, sym] of map) {
      while (n >= val) { result += sym; n -= val; }
    }
    return result;
  }

  // ─── TICK ─────────────────────────────────────────────────

  tick(players) {
    this.tickCounter++;
    // Passive XP every 60 ticks (3 seconds at 20t interval = ~60 seconds)
    const doPassiveXp = this.tickCounter >= 3;
    if (doPassiveXp) this.tickCounter = 0;

    for (const player of players) {
      // Apply passive effects (prestige bonuses)
      this.applyPassiveEffects(player);

      // Passive XP for wearing artifact armor
      if (doPassiveXp) {
        const equip = player.getComponent("minecraft:equippable");
        if (!equip) continue;
        const s = StorageManager.forPlayer(player);

        for (const slot of EQUIPMENT_SLOTS) {
          const item = equip.getEquipment(slot);
          if (!item) continue;
          const tags = item.getTags?.() || [];
          if (!tags.some(t => t.includes("forevercraft:artifact"))) continue;
          this._addXp(player, s, slot, 1);
        }
      }
    }
  }
}
