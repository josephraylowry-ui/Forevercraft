/**
 * Guidestone System — Fast travel network with registerable waypoints.
 * Replaces Java guidestone/ folder (marker entities, menu, teleport).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { showActionForm, showConfirm } from "./gui-manager.js";

export class GuidestoneSystem {
  constructor(eventBridge) {
    eventBridge.on("item_use", ({ player, item }) => {
      if (item.typeId === "forevercraft:guidestone_verdant" ||
          item.typeId === "forevercraft:guidestone_solar" ||
          item.typeId === "forevercraft:guidestone_crimson" ||
          item.typeId === "forevercraft:guidestone_azure") {
        this.openMenu(player);
      }
    });
  }

  /** Register current location as a guidestone waypoint */
  register(player, name) {
    const s = StorageManager.forPlayer(player);
    const waypoints = JSON.parse(s.getString("guidestones", "[]"));
    const loc = player.location;
    const dim = player.dimension.id;

    waypoints.push({
      name,
      x: Math.floor(loc.x),
      y: Math.floor(loc.y),
      z: Math.floor(loc.z),
      dimension: dim,
    });

    s.set("guidestones", JSON.stringify(waypoints));
    player.sendMessage(`§a§l✦ §r§7Guidestone registered: §e${name}`);
  }

  /** Teleport player to a registered waypoint */
  async teleport(player, index) {
    const s = StorageManager.forPlayer(player);
    const waypoints = JSON.parse(s.getString("guidestones", "[]"));
    if (index < 0 || index >= waypoints.length) return;

    const wp = waypoints[index];
    const confirmed = await showConfirm(player,
      "§aTeleport?",
      `§7Teleport to §e${wp.name}§7?\n§7Location: §f${wp.x}, ${wp.y}, ${wp.z}`,
      "Teleport", "Cancel"
    );

    if (confirmed) {
      const dim = world.getDimension(wp.dimension.replace("minecraft:", ""));
      player.teleport({ x: wp.x, y: wp.y + 1, z: wp.z }, { dimension: dim });
      player.sendMessage(`§aTeleported to §e${wp.name}§a!`);
      player.runCommandAsync("playsound mob.endermen.portal @s");
    }
  }

  /** Open guidestone network menu */
  async openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const waypoints = JSON.parse(s.getString("guidestones", "[]"));

    if (waypoints.length === 0) {
      const sel = await showActionForm(player, "§aGuidestone Network", "§7No waypoints registered.\n§7Place a guidestone to register this location.", [
        { text: "§eRegister Here" },
        { text: "§7Close" },
      ]);
      if (sel === 0) {
        this.register(player, `Waypoint ${Math.floor(player.location.x)}, ${Math.floor(player.location.z)}`);
      }
      return;
    }

    const buttons = waypoints.map((wp, i) => {
      const dist = Math.floor(Math.sqrt(
        Math.pow(player.location.x - wp.x, 2) + Math.pow(player.location.z - wp.z, 2)
      ));
      return { text: `§e${wp.name} §7(${dist}m)` };
    });
    buttons.push({ text: "§aRegister Here" });
    buttons.push({ text: "§7Close" });

    const sel = await showActionForm(player, "§aGuidestone Network", `§7${waypoints.length} waypoints`, buttons);
    if (sel >= 0 && sel < waypoints.length) {
      await this.teleport(player, sel);
    } else if (sel === waypoints.length) {
      this.register(player, `Waypoint ${Math.floor(player.location.x)}, ${Math.floor(player.location.z)}`);
    }
  }
}
