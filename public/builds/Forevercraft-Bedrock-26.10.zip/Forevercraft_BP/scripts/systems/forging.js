/**
 * Forging System — 3-phase crafting minigame (Heat → Hammer → Quench).
 * Includes Grand Forge for legendary items and 6-type Trial system.
 * Replaces Java craftforever/forging/ (42 files) + craftforever/trials/ (179 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const FORGE_RECIPES = [
  { id: 1, name: "Reinforced Blade",    tier: "rare",      materials: ["iron_ingot:8", "diamond:2"],        result: "iron_sword",     quality_bonus: 10 },
  { id: 2, name: "Hardened Chestplate",  tier: "rare",      materials: ["iron_ingot:12", "diamond:4"],       result: "iron_chestplate",quality_bonus: 15 },
  { id: 3, name: "Enchanted Pickaxe",    tier: "ornate",    materials: ["diamond:5", "gold_ingot:3"],        result: "diamond_pickaxe",quality_bonus: 20 },
  { id: 4, name: "Master's Axe",         tier: "ornate",    materials: ["diamond:4", "netherite_scrap:1"],   result: "diamond_axe",    quality_bonus: 25 },
  { id: 5, name: "Spirit Alloy Ingot",   tier: "exquisite", materials: ["netherite_scrap:4", "diamond:8"],   result: "netherite_ingot",quality_bonus: 30 },
  { id: 6, name: "Artisan's Masterwork", tier: "mythical",  materials: ["netherite_ingot:2", "diamond:16"],  result: "netherite_sword",quality_bonus: 50 },
];

const TRIAL_TYPES = [
  { id: 1, name: "Mining Trial",    desc: "Mine specific blocks within time limit",     reward_xp: 500,  reward_coins: 10 },
  { id: 2, name: "Building Trial",  desc: "Build a structure matching a pattern",       reward_xp: 750,  reward_coins: 15 },
  { id: 3, name: "Farming Trial",   desc: "Harvest and replant crops efficiently",      reward_xp: 500,  reward_coins: 10 },
  { id: 4, name: "Fishing Trial",   desc: "Catch specific fish within time limit",      reward_xp: 600,  reward_coins: 12 },
  { id: 5, name: "Lumber Trial",    desc: "Chop trees and process wood efficiently",    reward_xp: 500,  reward_coins: 10 },
  { id: 6, name: "Artisan Trial",   desc: "Craft specific items from raw materials",    reward_xp: 1000, reward_coins: 20 },
];

export class ForgingSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    // Active forging sessions: Map<playerId, { phase, timer, quality, recipeId }>
    this.sessions = new Map();
    // Active trials: Map<playerId, { type, tier, timer, progress, target }>
    this.trials = new Map();
  }

  // Called every 20 ticks
  tick(players) {
    for (const player of players) {
      // Tick active forging
      const session = this.sessions.get(player.id);
      if (session) this.tickForge(player, session);

      // Tick active trials
      const trial = this.trials.get(player.id);
      if (trial) this.tickTrial(player, trial);
    }
  }

  // === FORGE MENU ===
  openForge(player) {
    if (this.sessions.has(player.id)) {
      player.sendMessage("§cYou're already forging!");
      return;
    }

    const s = StorageManager.forPlayer(player);
    const artisanXP = s.getNumber("artisan_xp", 0);

    const form = new ActionFormData()
      .title("Artisan Forge")
      .body(`§7Select a recipe to forge.\n§7Your Artisan XP: §f${artisanXP.toLocaleString()}`);

    for (const recipe of FORGE_RECIPES) {
      form.button(`§f${recipe.name}\n§7${recipe.tier} | Materials: ${recipe.materials.length}`);
    }
    form.button("§cClose");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= FORGE_RECIPES.length) return;
      this.startForge(player, FORGE_RECIPES[response.selection]);
    });
  }

  startForge(player, recipe) {
    this.sessions.set(player.id, {
      phase: 1, // 1=heat, 2=hammer, 3=quench
      timer: 200, // 10 seconds per phase
      quality: 0,
      recipeId: recipe.id,
      recipe: recipe,
      inputs: 0, // Player inputs during phase
    });

    player.sendMessage(`\n§6§l✦ Forging: ${recipe.name} ✦\n§r§7Phase 1: §cHeat\n§7Tap your weapon to heat the metal! Aim for the target temperature.\n`);
    player.playSound("block.furnace.fire_crackle");
  }

  tickForge(player, session) {
    session.timer--;

    // HUD update
    if (session.timer % 20 === 0) {
      const phaseNames = ["", "§cHeat", "§6Hammer", "§bQuench"];
      const timeLeft = Math.ceil(session.timer / 20);
      player.runCommandAsync(`title @s actionbar ${phaseNames[session.phase]} §7| Time: ${timeLeft}s | Quality: §a${session.quality}`);
    }

    if (session.timer <= 0) {
      // Phase complete — advance or finish
      if (session.phase < 3) {
        session.phase++;
        session.timer = 200;
        session.inputs = 0;
        const phaseDesc = session.phase === 2
          ? "§7Phase 2: §6Hammer\n§7Time your strikes! Too fast or slow reduces quality."
          : "§7Phase 3: §bQuench\n§7Cool the metal at the right moment!";
        player.sendMessage(`\n§6${phaseDesc}\n`);
        player.playSound(session.phase === 2 ? "random.anvil_use" : "random.splash");
      } else {
        this.completeForge(player, session);
      }
    }
  }

  completeForge(player, session) {
    // Route artifact material forges to the artifact handler
    if (session.recipeId === 100 && session.artifactData) {
      this.completeArtifactForge(player, session);
      return;
    }

    this.sessions.delete(player.id);
    const recipe = session.recipe;
    const quality = Math.min(100, session.quality + recipe.quality_bonus);

    // Quality determines result
    let resultTier;
    if (quality >= 90) resultTier = "§d§lMasterwork";
    else if (quality >= 70) resultTier = "§6Excellent";
    else if (quality >= 50) resultTier = "§aGood";
    else resultTier = "§7Standard";

    // Grant item
    try {
      player.runCommandAsync(`give @s ${recipe.result} 1`);
    } catch (e) {}

    // Add artisan XP
    const s = StorageManager.forPlayer(player);
    const xp = s.getNumber("artisan_xp", 0) + Math.floor(quality * 10);
    s.setNumber("artisan_xp", xp);

    player.sendMessage(`\n§6§l✦ Forging Complete! ✦\n§r§7${recipe.name} — ${resultTier}\n§7Quality: §a${quality}%\n§7+${Math.floor(quality * 10)} Artisan XP\n`);
    player.playSound("random.levelup");

    this.eventBridge.emit("forge_complete", { player, quality, recipeId: recipe.id });
  }

  // Manual input during forging (called from scriptevent)
  forgeInput(player) {
    const session = this.sessions.get(player.id);
    if (!session) return;

    // Add quality based on timing
    const phaseProgress = 1 - (session.timer / 200);
    const sweetSpot = session.phase === 1 ? 0.5 : session.phase === 2 ? 0.6 : 0.7;
    const accuracy = 1 - Math.abs(phaseProgress - sweetSpot);
    const qualityGain = Math.floor(accuracy * 15);
    session.quality += qualityGain;
    session.inputs++;

    if (qualityGain >= 10) player.sendMessage("§a§lPerfect!");
    else if (qualityGain >= 5) player.sendMessage("§eGood!");
    else player.sendMessage("§7Miss...");

    player.playSound(session.phase === 2 ? "random.anvil_use" : "random.click");
  }

  // === TRIALS ===
  openTrials(player) {
    if (this.trials.has(player.id)) {
      player.sendMessage("§cYou're already in a trial!");
      return;
    }

    const form = new ActionFormData()
      .title("Craftforever Trials")
      .body("§7Select a trial type to begin.\n§7Complete trials to earn Artisan XP and coins.");

    for (const trial of TRIAL_TYPES) {
      form.button(`§f${trial.name}\n§7${trial.desc}`);
    }
    form.button("§cClose");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= TRIAL_TYPES.length) return;
      this.startTrial(player, TRIAL_TYPES[response.selection]);
    });
  }

  startTrial(player, trialType) {
    const targets = { 1: 50, 2: 20, 3: 30, 4: 10, 5: 20, 6: 5 };
    this.trials.set(player.id, {
      type: trialType.id,
      typeData: trialType,
      timer: 1200, // 60 seconds
      progress: 0,
      target: targets[trialType.id] || 20,
    });

    player.sendMessage(`\n§6§l✦ ${trialType.name} Started! ✦\n§r§7${trialType.desc}\n§7Time limit: 60 seconds\n`);
    player.addTag("ec.in_trial");
    player.playSound("note.pling");
  }

  tickTrial(player, trial) {
    trial.timer--;

    if (trial.timer % 200 === 0) {
      const timeLeft = Math.ceil(trial.timer / 20);
      player.runCommandAsync(`title @s actionbar §6Trial §7| Progress: §a${trial.progress}/${trial.target} §7| Time: ${timeLeft}s`);
    }

    // Check for events that advance the trial
    // (In practice, events are tracked via eventBridge listeners in main.js)

    if (trial.progress >= trial.target) {
      this.completeTrial(player, trial);
    } else if (trial.timer <= 0) {
      this.failTrial(player, trial);
    }
  }

  completeTrial(player, trial) {
    this.trials.delete(player.id);
    player.removeTag("ec.in_trial");

    const s = StorageManager.forPlayer(player);
    const xp = s.getNumber("artisan_xp", 0) + trial.typeData.reward_xp;
    s.setNumber("artisan_xp", xp);

    player.sendMessage(`\n§6§l✦ Trial Complete! ✦\n§r§7${trial.typeData.name}\n§7+${trial.typeData.reward_xp} Artisan XP\n§7+${trial.typeData.reward_coins} Coins\n`);
    player.playSound("ui.toast.challenge_complete");

    this.eventBridge.emit("trial_complete", { player, trialType: trial.type });
  }

  failTrial(player, trial) {
    this.trials.delete(player.id);
    player.removeTag("ec.in_trial");
    player.sendMessage(`\n§c§lTrial Failed!\n§r§7${trial.typeData.name} — Time expired.\n§7Progress: ${trial.progress}/${trial.target}\n`);
  }

  // Called when relevant events happen during a trial
  advanceTrialProgress(player, amount) {
    const trial = this.trials.get(player.id);
    if (!trial) return;
    trial.progress += amount;
  }

  // ========================================================
  // ARTIFACT FORGE EXPANSION
  // 28 materials (7 tiers × 4 categories) + 3 catalysts
  // T1-T6: 3x material → next tier | T7: forge artifacts
  // ========================================================

  /**
   * Open the Artifact Forge menu — deposit materials, optional catalyst, forge.
   */
  openArtifactForge(player) {
    if (this.sessions.has(player.id)) {
      player.sendMessage("§cYou're already forging!");
      return;
    }

    const s = StorageManager.forPlayer(player);
    const rank = s.getNumber("cf_rank", 0);
    const artisanXP = s.getNumber("artisan_xp", 0);
    const artisanLevel = ArtifactForge.getLevel(artisanXP);

    const form = new ActionFormData()
      .title("§6Artifact Forge")
      .body([
        `§7Artisan Rank: §f${rank} §7| Level: §f${artisanLevel}`,
        `§7XP: §f${artisanXP.toLocaleString()}`,
        "",
        "§eDeposit artifact materials to forge.",
        "§73x material → next tier (T1-T6)",
        "§7T7 material → artifact weapon/armor/tool/accessory",
      ].join("\n"));

    // Show all 4 categories
    form.button("§c⚔ Weapon Materials\n§7Forge weapon-class materials");
    form.button("§9🛡 Armor Materials\n§7Forge armor-class materials");
    form.button("§a⛏ Tool Materials\n§7Forge tool-class materials");
    form.button("§6✦ Accessory Materials\n§7Forge accessory-class materials");
    form.button("§cClose");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 4) return;
      const categories = ["weapon", "armor", "tool", "accessory"];
      this.showCategoryTiers(player, categories[response.selection], rank);
    });
  }

  /**
   * Show available tiers for a material category.
   */
  showCategoryTiers(player, category, rank) {
    const catDef = ArtifactForge.CATEGORIES[category];
    const s = StorageManager.forPlayer(player);

    const form = new ActionFormData()
      .title(`§6${catDef.label} Materials`)
      .body(`§7Select a tier to forge. Requires 3x material.\n§7Higher tiers need higher Artisan Rank.`);

    for (let tier = 1; tier <= 7; tier++) {
      const mat = ArtifactForge.getMaterial(category, tier);
      const requiredRank = ArtifactForge.getRequiredRank(tier);
      const locked = rank < requiredRank;
      const count = s.getNumber(`forge_mat_${category}_t${tier}`, 0);

      if (tier <= 6) {
        const nextMat = ArtifactForge.getMaterial(category, tier + 1);
        form.button(
          locked
            ? `§8${mat.name} → ${nextMat.name}\n§cRequires Rank ${requiredRank}`
            : `${mat.color}${mat.name} §7→ ${nextMat.color}${nextMat.name}\n§7You have: §f${count} §7(need 3)`
        );
      } else {
        // T7 → Artifact
        form.button(
          locked
            ? `§8${mat.name} → Artifact\n§cRequires Rank ${requiredRank}`
            : `${mat.color}${mat.name} §7→ §d§l${catDef.label} Artifact\n§7You have: §f${count}`
        );
      }
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 7) {
        this.openArtifactForge(player);
        return;
      }

      const tier = response.selection + 1;
      const requiredRank = ArtifactForge.getRequiredRank(tier);
      if (rank < requiredRank) {
        player.sendMessage(`§cYou need Artisan Rank §e${requiredRank}§c to forge T${tier} materials.`);
        return;
      }

      const count = s.getNumber(`forge_mat_${category}_t${tier}`, 0);
      if (count < 3 && tier <= 6) {
        player.sendMessage(`§cYou need §e3x §c${ArtifactForge.getMaterial(category, tier).name}. You have ${count}.`);
        return;
      }
      if (count < 1 && tier === 7) {
        player.sendMessage(`§cYou need at least §e1x §c${ArtifactForge.getMaterial(category, tier).name}.`);
        return;
      }

      // Start forging session for artifact material
      this.startArtifactForge(player, category, tier);
    });
  }

  /**
   * Start a 3-phase artifact forge session.
   */
  startArtifactForge(player, category, tier) {
    const mat = ArtifactForge.getMaterial(category, tier);
    const s = StorageManager.forPlayer(player);
    const artisanXP = s.getNumber("artisan_xp", 0);
    const artisanLevel = ArtifactForge.getLevel(artisanXP);

    // Consume materials
    const cost = tier === 7 ? 1 : 3;
    const current = s.getNumber(`forge_mat_${category}_t${tier}`, 0);
    s.setNumber(`forge_mat_${category}_t${tier}`, current - cost);

    // Artisan mastery bonus (rank/5, capped by tier)
    const rank = s.getNumber("cf_rank", 0);
    const masteryBonus = Math.min(Math.floor(rank / 5), tier === 1 ? 0 : (tier - 1) * 2);

    this.sessions.set(player.id, {
      phase: 1,
      timer: 200,
      quality: masteryBonus, // Start with mastery bonus
      recipeId: 100, // Artifact recipe marker
      recipe: { name: mat.name, quality_bonus: 0 },
      inputs: 0,
      artifactData: { category, tier, masteryBonus },
    });

    const target = tier <= 6
      ? `§7→ ${ArtifactForge.getMaterial(category, tier + 1).color}${ArtifactForge.getMaterial(category, tier + 1).name}`
      : `§7→ §d§l${ArtifactForge.CATEGORIES[category].label} Artifact`;

    player.sendMessage([
      "",
      `§6§l✦ Artifact Forge: ${mat.color}${mat.name} ✦`,
      `§r${target}`,
      `§7Mastery Bonus: §a+${masteryBonus} quality`,
      "§7Phase 1: §cHeat §7— Tap to heat the metal!",
      "",
    ].join("\n"));
    player.playSound("block.furnace.fire_crackle");
  }

  /**
   * Override completeForge for artifact materials.
   */
  completeArtifactForge(player, session) {
    this.sessions.delete(player.id);
    const { category, tier, masteryBonus } = session.artifactData;
    const quality = session.quality;
    const s = StorageManager.forPlayer(player);

    // XP award: success = 6 + quality, fail = 1/3
    const isSuccess = quality >= 4;
    const baseXP = isSuccess ? (6 + quality) : Math.max(1, Math.floor((6 + quality) / 3));
    const xp = s.getNumber("artisan_xp", 0) + baseXP;
    s.setNumber("artisan_xp", xp);

    if (tier <= 6) {
      // T1-T6: Success = next tier material, Fail = 7% artifact chance
      if (isSuccess) {
        const nextMat = ArtifactForge.getMaterial(category, tier + 1);
        const nextCount = s.getNumber(`forge_mat_${category}_t${tier + 1}`, 0);
        s.setNumber(`forge_mat_${category}_t${tier + 1}`, nextCount + 1);

        player.sendMessage([
          "",
          `§6§l✦ Forge Success! ✦`,
          `§r§7Obtained: ${nextMat.color}${nextMat.name}`,
          `§7Quality: §a${quality} §7| +${baseXP} Artisan XP`,
          "",
        ].join("\n"));
        player.playSound("random.levelup");
      } else {
        // Fail — 7% artifact chance
        this.rollFailArtifact(player, category, tier, quality, baseXP);
      }
    } else {
      // T7: Success = GUARANTEED artifact, Fail = 7% artifact chance
      if (isSuccess) {
        this.rollT7Success(player, category, quality, baseXP);
      } else {
        this.rollFailArtifact(player, category, tier, quality, baseXP);
      }
    }

    this.eventBridge.emit("artifact_forge_complete", { player, category, tier, quality, success: isSuccess });
  }

  /**
   * T7 success — guaranteed artifact, 7% mythical.
   */
  rollT7Success(player, category, quality, xpAwarded) {
    const mythicalRoll = Math.random() * 100;
    let rarity;

    if (mythicalRoll < 7) {
      // 7% MYTHICAL!
      rarity = "mythical";
      player.sendMessage([
        "",
        "§d§l✦✦✦ MYTHICAL ARTIFACT FORGED! ✦✦✦",
        `§r§7Category: §d${ArtifactForge.CATEGORIES[category].label}`,
        `§7Quality: §a${quality} §7| +${xpAwarded} Artisan XP`,
        "",
      ].join("\n"));
      try {
        player.runCommandAsync("particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 100");
        player.playSound("mob.enderdragon.growl");
        player.playSound("ui.toast.challenge_complete");
      } catch {}
    } else {
      // 93% — roll from T7 rarity table
      rarity = ArtifactForge.rollRarity(7, false);
      player.sendMessage([
        "",
        `§6§l✦ Artifact Forged! ✦`,
        `§r§7Rarity: §e${rarity} §7| Category: §e${ArtifactForge.CATEGORIES[category].label}`,
        `§7Quality: §a${quality} §7| +${xpAwarded} Artisan XP`,
        "",
      ].join("\n"));
      player.playSound("random.levelup");
    }

    // Give artifact via loot command
    this.giveArtifact(player, category, rarity);
  }

  /**
   * Fail roll — 7% base artifact chance (+ catalyst bonus).
   */
  rollFailArtifact(player, category, tier, quality, xpAwarded) {
    const s = StorageManager.forPlayer(player);
    const catalystBonus = s.getNumber("forge_catalyst_bonus", 0); // 0-3%
    const artifactChance = 7 + catalystBonus;
    const roll = Math.random() * 100;

    if (roll < artifactChance) {
      // Won the artifact-on-fail!
      const rarity = ArtifactForge.rollRarity(tier, true);
      player.sendMessage([
        "",
        "§d§l✦ Unexpected Discovery! ✦",
        `§r§7The failed forge revealed a §d${rarity}§7 artifact!`,
        `§7Category: §e${ArtifactForge.CATEGORIES[category].label}`,
        `§7+${xpAwarded} Artisan XP`,
        "",
      ].join("\n"));
      player.playSound("random.levelup");
      this.giveArtifact(player, category, rarity);
    } else {
      // Slag — pure failure
      player.sendMessage([
        "",
        "§7§lForge Failed",
        "§r§7The material hardened into useless slag.",
        `§7Quality: §c${quality} §7| +${xpAwarded} Artisan XP`,
        "",
      ].join("\n"));
      player.playSound("random.break");
    }

    // Clear catalyst bonus after use
    s.setNumber("forge_catalyst_bonus", 0);
  }

  /**
   * Give an artifact from the matching category and rarity.
   */
  giveArtifact(player, category, rarity) {
    this.eventBridge.emit("artifact_forged", { player, category, rarity });
    // Grant via companion crate system or loot table
    try {
      player.runCommandAsync(`loot give @s loot "forevercraft:artifacts/${rarity}_${category}"`);
    } catch {
      // Fallback: emit for other systems to handle
      player.sendMessage(`§7[Artifact: §e${rarity} ${category}§7 — check inventory]`);
    }
  }

  /**
   * Grand Forge failure compensation — 33% chance for an artifact.
   */
  rollGrandForgeCompensation(player) {
    const roll = Math.random() * 100;
    if (roll < 33) {
      // Random category
      const categories = ["weapon", "armor", "tool", "accessory"];
      const category = categories[Math.floor(Math.random() * 4)];

      // Weighted rarity: 30% common, 25% uncommon, 20% rare, 15% ornate, 9% exquisite, 1% mythical
      const rarityRoll = Math.random() * 100;
      let rarity;
      if (rarityRoll < 30) rarity = "common";
      else if (rarityRoll < 55) rarity = "uncommon";
      else if (rarityRoll < 75) rarity = "rare";
      else if (rarityRoll < 90) rarity = "ornate";
      else if (rarityRoll < 99) rarity = "exquisite";
      else rarity = "mythical";

      player.sendMessage([
        "",
        "§d§l✦ Compensation Artifact! ✦",
        `§r§7The Grand Forge's energy crystallized into a §e${rarity} ${category}§7 artifact!`,
        "",
      ].join("\n"));
      player.playSound("random.levelup");
      this.giveArtifact(player, category, rarity);
    } else {
      try { player.runCommandAsync("xp 5L @s"); } catch {}
      player.sendMessage("§7The Grand Forge grants you §a5 XP levels§7 as consolation.");
    }
  }

  /**
   * Deposit a specialized catalyst (Resonance Dust / Harmonic Essence / Convergence Shard).
   */
  depositCatalyst(player, catalystType) {
    const bonuses = { resonance_dust: 1, harmonic_essence: 2, convergence_shard: 3 };
    const names = { resonance_dust: "§eResonance Dust", harmonic_essence: "§dHarmonic Essence", convergence_shard: "§bConvergence Shard" };
    const bonus = bonuses[catalystType] || 0;

    const s = StorageManager.forPlayer(player);
    s.setNumber("forge_catalyst_bonus", bonus);
    player.sendMessage(`§7Catalyst deposited: ${names[catalystType]} §7(+${bonus}% artifact chance)`);
    player.playSound("random.orb");
  }

  /**
   * Add artifact material to player's storage (from mining drops, prospect nodes, etc.)
   */
  addMaterial(player, category, tier, amount = 1) {
    const s = StorageManager.forPlayer(player);
    const key = `forge_mat_${category}_t${tier}`;
    const current = s.getNumber(key, 0);
    s.setNumber(key, current + amount);

    const mat = ArtifactForge.getMaterial(category, tier);
    player.sendMessage(`§7Found: ${mat.color}${mat.name} §7(${current + amount} total)`);
    player.playSound("random.orb");
  }

  /**
   * Check ore mining for material drops (called from block break handler).
   * 0.5% chance per ore mined, tier based on ore type.
   */
  checkOreMiningDrop(player, oreTypeId) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("cf_rank", 0) < 1) return; // Rank 1+ required

    const tierMap = ArtifactForge.ORE_TIER_MAP[oreTypeId];
    if (!tierMap) return;

    const roll = Math.random() * 200; // 0.5% = 1/200
    if (roll < 1) {
      // Random category
      const categories = ["weapon", "armor", "tool", "accessory"];
      const category = categories[Math.floor(Math.random() * 4)];
      this.addMaterial(player, category, tierMap.tier, 1);
    }

    // Ancient debris special: also 0.3% T7 chance
    if (tierMap.extraT7) {
      const t7Roll = Math.random() * 333; // 0.3% = 1/333
      if (t7Roll < 1) {
        const categories = ["weapon", "armor", "tool", "accessory"];
        const category = categories[Math.floor(Math.random() * 4)];
        this.addMaterial(player, category, 7, 1);
      }
    }
  }
}

// ========================================================
// ARTIFACT FORGE STATIC DATA
// ========================================================

class ArtifactForge {
  static CATEGORIES = {
    weapon:    { label: "Weapon",    color: "§c", tag: "[Weapon]" },
    armor:     { label: "Armor",     color: "§9", tag: "[Armor]" },
    tool:      { label: "Tool",      color: "§a", tag: "[Tool]" },
    accessory: { label: "Accessory", color: "§6", tag: "[Accessory]" },
  };

  static MATERIALS = {
    weapon: [
      null, // index 0 unused
      { name: "Warbrand Scrap",       color: "§4" },
      { name: "Embersteel Shard",     color: "§6" },
      { name: "Stormforged Edge",     color: "§b" },
      { name: "Voidthorn Fragment",   color: "§5" },
      { name: "Drakefang Alloy",      color: "§6" },
      { name: "Celestial Blade Ore",  color: "§9" },
      { name: "Doomforge Core",       color: "§e" },
    ],
    armor: [
      null,
      { name: "Ironbark Plate",       color: "§7" },
      { name: "Frostweave Thread",    color: "§b" },
      { name: "Stoneward Shell",      color: "§2" },
      { name: "Shadowmeld Fiber",     color: "§8" },
      { name: "Dragonscale Plate",    color: "§2" },
      { name: "Astralguard Lattice",  color: "§f" },
      { name: "Eternium Carapace",    color: "§d" },
    ],
    tool: [
      null,
      { name: "Copperstone Chunk",    color: "§6" },
      { name: "Manawood Resin",       color: "§a" },
      { name: "Crystalvein Ore",      color: "§d" },
      { name: "Leyline Conduit",      color: "§9" },
      { name: "Worldroot Heartwood",  color: "§4" },
      { name: "Archon's Implement",   color: "§e" },
      { name: "Genesis Catalyst",     color: "§d" },
    ],
    accessory: [
      null,
      { name: "Glimmer Dust",         color: "§e" },
      { name: "Moonstone Sliver",     color: "§7" },
      { name: "Dreamglass Shard",     color: "§3" },
      { name: "Soulthread Strand",    color: "§5" },
      { name: "Starweave Filament",   color: "§e" },
      { name: "Voidheart Gem",        color: "§5" },
      { name: "Eternity Spark",       color: "§f" },
    ],
  };

  // Ore type → material tier mapping
  static ORE_TIER_MAP = {
    "minecraft:coal_ore": { tier: 1 },
    "minecraft:deepslate_coal_ore": { tier: 1 },
    "minecraft:copper_ore": { tier: 1 },
    "minecraft:deepslate_copper_ore": { tier: 1 },
    "minecraft:iron_ore": { tier: 2 },
    "minecraft:deepslate_iron_ore": { tier: 2 },
    "minecraft:gold_ore": { tier: 2 },
    "minecraft:deepslate_gold_ore": { tier: 2 },
    "minecraft:nether_gold_ore": { tier: 2 },
    "minecraft:lapis_ore": { tier: 3 },
    "minecraft:deepslate_lapis_ore": { tier: 3 },
    "minecraft:redstone_ore": { tier: 3 },
    "minecraft:deepslate_redstone_ore": { tier: 3 },
    "minecraft:diamond_ore": { tier: 4 },
    "minecraft:deepslate_diamond_ore": { tier: 4 },
    "minecraft:emerald_ore": { tier: 5 },
    "minecraft:deepslate_emerald_ore": { tier: 5 },
    "minecraft:ancient_debris": { tier: 6, extraT7: true },
  };

  // Rank requirements per artifact tier
  static RANK_GATES = [0, 1, 10, 20, 35, 50, 70, 90];

  static getMaterial(category, tier) {
    return this.MATERIALS[category]?.[tier] || { name: "Unknown", color: "§7" };
  }

  static getRequiredRank(tier) {
    return this.RANK_GATES[tier] || 0;
  }

  static getLevel(xp) {
    // Each level = 150 XP, no cap
    return Math.floor(xp / 150);
  }

  /**
   * Roll artifact rarity based on tier.
   * @param {number} tier - Material tier (1-7)
   * @param {boolean} isFail - True if rolling from fail table
   */
  static rollRarity(tier, isFail) {
    const roll = Math.random() * 100;
    const tables = {
      1: [80, 95, 100],        // 80% common, 15% uncommon, 5% rare
      2: [80, 95, 100],
      3: [50, 80, 95, 100],    // 50% common, 30% uncommon, 15% rare, 5% exquisite
      4: [30, 60, 85, 95, 100],// 30% common, 30% uncommon, 25% rare, 10% exquisite, 5% ornate
      5: [15, 40, 65, 85, 95, 100], // 15/25/25/20/10/5
      6: [5, 20, 45, 70, 90, 100],  // 5/15/25/25/20/10
      7: [0, 10, 35, 70, 100],      // 0/10/25/35/30 (no mythical on fail)
    };
    const rarities = ["common", "uncommon", "rare", "exquisite", "ornate", "mythical"];
    const table = tables[tier] || tables[1];

    for (let i = 0; i < table.length; i++) {
      if (roll < table[i]) return rarities[i];
    }
    return "common";
  }
}
