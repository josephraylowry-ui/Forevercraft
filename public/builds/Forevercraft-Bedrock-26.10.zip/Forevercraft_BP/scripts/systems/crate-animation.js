/**
 * Crate Animation System — Reel/reveal animations for loot crates.
 * Replaces Java crate_anim/ folder (163 mcfunction files).
 *
 * Uses sequential frame-based animation with ascending pitch sounds.
 * Each tier has different frame count (Common:10 → Mythical:30).
 * Reveals loot item at end with dramatic effects.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Frame counts per rarity tier
const TIER_FRAMES = {
  common: 10,
  uncommon: 10,
  rare: 15,
  ornate: 20,
  exquisite: 25,
  mythical: 30,
};

// Colors per tier (for action bar display)
const TIER_COLORS = {
  common: "§f", uncommon: "§9", rare: "§b",
  ornate: "§5", exquisite: "§d", mythical: "§6",
};

// Crate system types
const CRATE_SYSTEMS = ["mob", "fishing", "harvest", "structure", "achievement", "companion", "artifact", "quest"];

export class CrateAnimationSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    /** @type {Map<string, {tier: string, system: string, frame: number, maxFrames: number, revealed: boolean}>} */
    this.activeAnimations = new Map();
  }

  /**
   * Start a crate opening animation for a player.
   * @param {Player} player
   * @param {string} tier - Rarity tier
   * @param {string} crateSystem - Which crate type (mob, fishing, etc.)
   * @param {string} itemName - The revealed item name
   */
  startAnimation(player, tier, crateSystem, itemName) {
    const maxFrames = TIER_FRAMES[tier] || 15;
    const color = TIER_COLORS[tier] || "§f";

    this.activeAnimations.set(player.id, {
      tier,
      system: crateSystem,
      frame: 0,
      maxFrames,
      revealed: false,
      itemName: itemName || "Mystery Item",
      color,
    });

    player.sendMessage(`\n${color}§l✦ Opening ${tier.charAt(0).toUpperCase() + tier.slice(1)} Crate... ✦§r`);
    player.playSound("random.click", { volume: 0.5, pitch: 0.5 });
  }

  /**
   * Tick all active animations (called every 2 ticks for smooth display).
   */
  tick() {
    for (const [playerId, anim] of this.activeAnimations) {
      let player;
      try {
        player = world.getEntity(playerId);
        if (!player) { this.activeAnimations.delete(playerId); continue; }
      } catch { this.activeAnimations.delete(playerId); continue; }

      anim.frame++;

      // Build reel display bar
      const progress = anim.frame / anim.maxFrames;
      const barLen = 20;
      const filled = Math.floor(progress * barLen);
      let bar = "";
      for (let i = 0; i < barLen; i++) {
        bar += i < filled ? `${anim.color}█` : "§8░";
      }

      // Ascending pitch sound every 2 frames
      if (anim.frame % 2 === 0) {
        const pitch = 0.5 + (progress * 1.5);
        try { player.playSound("note.harp", { volume: 0.3, pitch: Math.min(pitch, 2.0) }); } catch {}
      }

      // Slow down near end (dramatic tension)
      if (anim.frame >= anim.maxFrames * 0.8) {
        // Add particle effects
        try {
          player.dimension.spawnParticle("minecraft:basic_smoke_particle", {
            x: player.location.x, y: player.location.y + 1.5, z: player.location.z
          });
        } catch {}
      }

      // Display
      player.onScreenDisplay.setActionBar(`${bar} ${anim.color}${Math.floor(progress * 100)}%`);

      // Reveal
      if (anim.frame >= anim.maxFrames) {
        this.revealItem(player, anim);
        this.activeAnimations.delete(playerId);
      }
    }
  }

  /**
   * Reveal the crate item with dramatic effects.
   */
  revealItem(player, anim) {
    const tierUpper = anim.tier.charAt(0).toUpperCase() + anim.tier.slice(1);

    // Tier-specific reveal effects
    switch (anim.tier) {
      case "mythical":
        try {
          player.dimension.spawnParticle("minecraft:totem_particle", player.location);
          player.playSound("random.totem", { volume: 1.5, pitch: 1.0 });
        } catch {}
        // Server announcement
        for (const p of world.getAllPlayers()) {
          p.sendMessage(`${anim.color}§l✦ §r§f${player.name} §7found ${anim.color}§l${anim.itemName}§r§7!`);
        }
        break;
      case "exquisite":
        try {
          player.dimension.spawnParticle("minecraft:totem_particle", player.location);
          player.playSound("random.levelup", { volume: 1.0, pitch: 1.2 });
        } catch {}
        break;
      case "ornate":
        try { player.playSound("random.levelup", { volume: 0.8, pitch: 1.0 }); } catch {}
        break;
      default:
        try { player.playSound("random.orb", { volume: 0.7, pitch: 1.2 }); } catch {}
    }

    player.sendMessage(`\n${anim.color}§l✦ ${tierUpper} Crate Opened! ✦§r`);
    player.sendMessage(`${anim.color}§l${anim.itemName}§r`);

    player.onScreenDisplay.setTitle(`${anim.color}§l${anim.itemName}`, {
      subtitle: `§7${tierUpper} ${anim.system} Crate`,
      fadeInDuration: 5, stayDuration: 60, fadeOutDuration: 20,
    });

    // Track
    const s = StorageManager.forPlayer(player);
    s.set("crates_opened", s.getNumber("crates_opened", 0) + 1);
    s.set(`crates_${anim.tier}`, s.getNumber(`crates_${anim.tier}`, 0) + 1);

    this.eventBridge.emit("crate_revealed", { player, tier: anim.tier, system: anim.system, itemName: anim.itemName });
  }

  /** Check if player has active animation */
  isAnimating(playerId) {
    return this.activeAnimations.has(playerId);
  }
}
