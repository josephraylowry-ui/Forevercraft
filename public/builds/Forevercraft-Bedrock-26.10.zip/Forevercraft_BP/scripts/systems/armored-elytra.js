/**
 * Armored Elytra System — Merge elytra artifacts with chestplates on beacons.
 * 7 mythical sets. Merged items retain flight + armor stats.
 * Replaces Java armored_elytra/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Valid armor sets that can merge
const ELYTRA_SETS = [
  { id: "dragonmaster", name: "Dragonmaster", color: "§c" },
  { id: "titan", name: "Titan", color: "§b" },
  { id: "verdant", name: "Verdant", color: "§2" },
  { id: "ender_dragon", name: "Ender Dragon", color: "§5" },
  { id: "infernal", name: "Infernal", color: "§4" },
  { id: "journey", name: "Journey", color: "§e" },
  { id: "splendid", name: "Splendid", color: "§6" },
];

const SET_MAP = new Map(ELYTRA_SETS.map(s => [s.id, s]));

export class ArmoredElytraSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.scanCooldown = 0;
  }

  /**
   * Tick — runs every 20 ticks (1 second). Scans for merge/unmerge opportunities.
   */
  tick() {
    this.scanCooldown--;
    if (this.scanCooldown > 0) return;
    this.scanCooldown = 20; // Check every 20 seconds

    // Scan for item entities on beacon blocks
    for (const dimId of ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"]) {
      try {
        const dim = world.getDimension(dimId);
        const items = dim.getEntities({ type: "minecraft:item" });

        for (const itemEntity of items) {
          if (!itemEntity?.isValid()) continue;
          this.checkMerge(itemEntity, dim);
        }
      } catch {}
    }
  }

  /**
   * Check if an item entity on a beacon is eligible for merge.
   */
  checkMerge(itemEntity, dim) {
    const pos = itemEntity.location;

    // Check if sitting on a beacon
    try {
      const blockBelow = dim.getBlock({
        x: Math.floor(pos.x),
        y: Math.floor(pos.y) - 1,
        z: Math.floor(pos.z),
      });
      if (!blockBelow || blockBelow.typeId !== "minecraft:beacon") return;
    } catch { return; }

    const itemStack = itemEntity.getComponent("minecraft:item")?.itemStack;
    if (!itemStack) return;

    // Check if it's an elytra artifact
    const isElytra = itemStack.typeId.includes("elytra") && itemStack.typeId.startsWith("forevercraft:");
    const isArmored = itemStack.typeId.includes("armored_elytra");

    if (isArmored) {
      // Unmerge: armored elytra on beacon
      this.unmerge(itemEntity, itemStack, dim, pos);
    } else if (isElytra) {
      // Merge: find matching chestplate nearby
      this.tryMerge(itemEntity, itemStack, dim, pos);
    }
  }

  /**
   * Try to merge an elytra with a nearby chestplate.
   */
  tryMerge(elytraEntity, elytraItem, dim, pos) {
    // Detect set ID from elytra item type
    let setId = null;
    for (const set of ELYTRA_SETS) {
      if (elytraItem.typeId.includes(set.id)) {
        setId = set.id;
        break;
      }
    }
    if (!setId) return;

    // Find matching chestplate within 2 blocks
    const nearby = dim.getEntities({
      location: pos, maxDistance: 2,
      type: "minecraft:item",
    });

    for (const otherEntity of nearby) {
      if (otherEntity.id === elytraEntity.id) continue;
      const otherItem = otherEntity.getComponent("minecraft:item")?.itemStack;
      if (!otherItem) continue;

      // Check if it's the matching chestplate
      if (otherItem.typeId.includes(setId) && otherItem.typeId.includes("chestplate")) {
        this.performMerge(elytraEntity, otherEntity, setId, dim, pos);
        return;
      }
    }
  }

  /**
   * Perform the merge — consume both items, spawn armored elytra + effects.
   */
  performMerge(elytraEntity, chestEntity, setId, dim, pos) {
    const set = SET_MAP.get(setId);
    if (!set) return;

    // Kill both items and beacon
    try {
      elytraEntity.kill();
      chestEntity.kill();
      dim.runCommandAsync(
        `setblock ${Math.floor(pos.x)} ${Math.floor(pos.y) - 1} ${Math.floor(pos.z)} air`
      );
    } catch {}

    // Spawn armored elytra item
    try {
      dim.runCommandAsync(
        `summon item ${pos.x} ${pos.y} ${pos.z} forevercraft:${setId}_armored_elytra`
      );
    } catch {}

    // Effects
    try {
      dim.runCommandAsync(
        `summon lightning_bolt ${pos.x} ${pos.y} ${pos.z}`
      );
      dim.runCommandAsync(
        `particle minecraft:totem_particle ${pos.x} ${pos.y + 1} ${pos.z} 1 1 1 0 50`
      );
    } catch {}

    // Announce
    for (const p of world.getAllPlayers()) {
      const dist = Math.sqrt(
        (p.location.x - pos.x) ** 2 + (p.location.z - pos.z) ** 2
      );
      if (dist < 64) {
        p.sendMessage(`${set.color}§l✦ ${set.name} Armored Elytra forged!`);
        try { p.playSound("random.levelup", { volume: 0.5, pitch: 0.8 }); } catch {}
      }
    }

    // Track
    this.eventBridge.emit("elytra_merged", setId);
  }

  /**
   * Unmerge an armored elytra back into elytra + chestplate.
   */
  unmerge(itemEntity, itemStack, dim, pos) {
    let setId = null;
    for (const set of ELYTRA_SETS) {
      if (itemStack.typeId.includes(set.id)) {
        setId = set.id;
        break;
      }
    }
    if (!setId) return;

    const set = SET_MAP.get(setId);

    // Kill item and beacon
    try {
      itemEntity.kill();
      dim.runCommandAsync(
        `setblock ${Math.floor(pos.x)} ${Math.floor(pos.y) - 1} ${Math.floor(pos.z)} air`
      );
    } catch {}

    // Return both original artifacts
    try {
      dim.runCommandAsync(
        `summon item ${pos.x} ${pos.y} ${pos.z} forevercraft:${setId}_elytra`
      );
      dim.runCommandAsync(
        `summon item ${pos.x} ${pos.y + 0.5} ${pos.z} forevercraft:${setId}_chestplate`
      );
      dim.runCommandAsync(
        `summon lightning_bolt ${pos.x} ${pos.y} ${pos.z}`
      );
    } catch {}

    for (const p of world.getAllPlayers()) {
      const dist = Math.sqrt(
        (p.location.x - pos.x) ** 2 + (p.location.z - pos.z) ** 2
      );
      if (dist < 64) {
        p.sendMessage(`${set.color}§l✦ ${set.name} Armored Elytra unforged!`);
      }
    }
  }
}
