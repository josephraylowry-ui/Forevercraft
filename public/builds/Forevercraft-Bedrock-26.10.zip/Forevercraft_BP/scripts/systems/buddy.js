/**
 * Buddy System — Deep bonds with tamed vanilla mobs.
 * Replaces Java buddy/ folder (~173 files across 7 phases).
 *
 * Players designate tamed mobs as Buddies (one per type) and one Best Buddy.
 * Friendship grows through shared activities (0→10,000 cap), unlocking 7 tiers.
 *
 * Tiers: Acquaintance(0), Familiar(250), Trusted(750), Devoted(1500),
 *        Eternal(3000), Mythic Bond(5500), Spiritbound(10000)
 *
 * Tier abilities: heart particles, weatherproof, battle cry, shared meal,
 *   cozy rest, lucky paws, soullink glow, pack mule (3 slots),
 *   last stand, elemental resistance, war companion, shared vitality,
 *   dimensional bond, buddy aura, best buddy promotion
 *
 * Best Buddy: Combat AI, weapon/artifact/accessory slots, auto-revive 10min
 * Mount charge attacks: speed-based ramming at >12 blocks/sec
 */
import { world, system, EffectTypes } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

const TIER_THRESHOLDS = [0, 250, 750, 1500, 3000, 5500, 10000];
const TIER_NAMES = ["Acquaintance", "Familiar", "Trusted", "Devoted", "Eternal", "Mythic Bond", "Spiritbound"];
const TIER_COLORS = ["§7", "§a", "§e", "§6", "§d", "§5", "§b"];
const POINTS_CAP = 10000;

const BUDDY_TYPES = new Set([
  "minecraft:wolf", "minecraft:cat", "minecraft:parrot", "minecraft:horse",
  "minecraft:donkey", "minecraft:mule", "minecraft:llama", "minecraft:trader_llama",
  "minecraft:camel", "minecraft:fox", "minecraft:ocelot", "minecraft:happy_ghast",
]);

// Buddy Aura effects by mob type (Tier 5+)
const AURA_EFFECTS = {
  "minecraft:wolf":           { effect: "strength",      name: "Strength I" },
  "minecraft:cat":            { effect: "luck",           name: "Luck I" },
  "minecraft:parrot":         { effect: "speed",          name: "Speed I" },
  "minecraft:horse":          { effect: "resistance",     name: "Resistance I" },
  "minecraft:donkey":         { effect: "resistance",     name: "Resistance I" },
  "minecraft:mule":           { effect: "resistance",     name: "Resistance I" },
  "minecraft:llama":          { effect: "resistance",     name: "Resistance I" },
  "minecraft:trader_llama":   { effect: "resistance",     name: "Resistance I" },
  "minecraft:camel":          { effect: "resistance",     name: "Resistance I" },
  "minecraft:fox":            { effect: "night_vision",   name: "Night Vision" },
  "minecraft:ocelot":         { effect: "haste",          name: "Haste I" },
  "minecraft:happy_ghast":    { effect: "slow_falling",   name: "Slow Falling" },
};

// Point sources
const POINT_COMBAT = 1;
const POINT_WALK = 7;
const POINT_FEED = 5;
const POINT_FAV_FOOD = 10;
const POINT_SLEEP = 2;
const POINT_MINING = 1;
const POINT_FISH = 1;
const POINT_TRADE = 3;
const POINT_NEAR_DEATH = 10;
const POINT_STRUCTURE = 15;
const POINT_BOSS = 25;
const POINT_MILESTONE = 25;
const POINT_DEATH_PENALTY = -100;

// Ability cooldowns (in ticks, at 40-tick call rate)
const BATTLE_CRY_CD = 300;   // 15 seconds
const LAST_STAND_CD = 6000;  // 5 minutes
const VITALITY_CD = 1200;    // 60 seconds
const MEAL_CD = 600;         // 30 seconds

export class BuddySystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    /** @type {Map<string, {proximityTimer: number, walkSnapshot: {x:number,z:number}, lastPos: {x:number,z:number}, cryCd: number, lastStandCd: number, vitalityCd: number, mealCd: number, bestReviveTimer: number}>} */
    this.playerState = new Map();
    /** @type {Map<string, string[]>} playerID → pack mule items (JSON strings) */
    this.packMule = new Map();

    // Point earning hooks
    eventBridge.on("player_killed_entity", (data) => this.addPoints(data.player, POINT_COMBAT));
    eventBridge.on("fish_caught", (data) => this.addPoints(data.player, POINT_FISH));
    eventBridge.on("structure_first_find", (data) => this.addPoints(data.player, POINT_STRUCTURE));
    eventBridge.on("boss_killed", (data) => this.addPoints(data.player, POINT_BOSS));
    eventBridge.on("milestone_completed", (data) => this.addPoints(data.player, POINT_MILESTONE));
    eventBridge.on("sleep_completed", (data) => this.addPoints(data.player, POINT_SLEEP));
    eventBridge.on("ore_mined", (data) => this.addPoints(data.player, POINT_MINING));
    eventBridge.on("villager_traded", (data) => this.addPoints(data.player, POINT_TRADE));

    // Best buddy death detection
    world.afterEvents.entityDie.subscribe((event) => {
      this.onEntityDie(event);
    });
  }

  // =====================================================
  // POINT SYSTEM
  // =====================================================

  addPoints(player, amount) {
    if (!player) return;
    const s = StorageManager.forPlayer(player);
    const buddyType = s.get("bd_active_type");
    if (!buddyType) return;

    const isBest = s.get(`bd_is_best_${buddyType}`) === true;
    const multiplier = isBest ? 2 : 1;
    const actualAmount = amount * multiplier;

    const key = `bd_points_${buddyType}`;
    const current = s.getNumber(key, 0);
    const newPoints = Math.min(POINTS_CAP, Math.max(0, current + actualAmount));
    s.set(key, newPoints);

    const oldTier = this.getTier(current);
    const newTier = this.getTier(newPoints);
    if (newTier > oldTier) {
      this.onTierUp(player, buddyType, newTier);
    }
  }

  getTier(points) {
    for (let i = TIER_THRESHOLDS.length - 1; i >= 0; i--) {
      if (points >= TIER_THRESHOLDS[i]) return i;
    }
    return 0;
  }

  onTierUp(player, buddyType, tier) {
    const s = StorageManager.forPlayer(player);
    s.set(`bd_tier_${buddyType}`, tier);

    const name = s.get(`bd_name_${buddyType}`) || buddyType.replace("minecraft:", "");
    const tierName = TIER_NAMES[tier];
    const color = TIER_COLORS[tier];

    player.sendMessage(`\n${color}§l✦ Buddy Bond — ${tierName}! ✦§r`);
    player.sendMessage(`§7${name} has reached ${color}${tierName}§7 status!`);
    player.playSound("random.levelup", { volume: 0.8, pitch: 1.0 + tier * 0.05 });

    if (tier === 1) player.sendMessage("§7Unlocked: §aWeatherproof §7+ §aBattle Cry");
    if (tier === 2) player.sendMessage("§7Unlocked: §eShared Meal §7+ §eCozy Rest §7+ §eLucky Paws");
    if (tier === 3) player.sendMessage("§7Unlocked: §6Pack Mule §7(3 slots) + §6Last Stand");
    if (tier === 4) player.sendMessage("§7Unlocked: §dElemental Resistance §7+ §dWar Companion §7+ §dShared Vitality");
    if (tier === 5) player.sendMessage("§7Unlocked: §5Dimensional Bond §7+ §5Buddy Aura");
    if (tier === 6) player.sendMessage("§7Unlocked: §b✦ Best Buddy Eligible! ✦");

    this.eventBridge.emit("buddy_tier_up", { player, buddyType, tier, tierName });
  }

  // =====================================================
  // DESIGNATION + NAMING
  // =====================================================

  /** Designate a tamed mob as buddy via form UI */
  designateBuddy(player, entity) {
    if (!BUDDY_TYPES.has(entity.typeId)) {
      player.sendMessage("§cThis mob type can't be a buddy.");
      return;
    }

    const s = StorageManager.forPlayer(player);
    const mobType = entity.typeId.replace("minecraft:", "");

    if (s.get(`bd_has_${mobType}`)) {
      player.sendMessage(`§cYou already have a ${mobType} buddy! Undesignate it first.`);
      return;
    }

    // Show naming form (replaces Java charter book system)
    const form = new ModalFormData()
      .title("§l§6Buddy Charter")
      .textField("Name your new buddy:", entity.nameTag || mobType, entity.nameTag || "");

    form.show(player).then((response) => {
      if (response.canceled) return;
      const buddyName = response.formValues[0]?.trim() || mobType;
      this.finalizeBuddy(player, entity, buddyName);
    }).catch(() => {});
  }

  finalizeBuddy(player, entity, buddyName) {
    const s = StorageManager.forPlayer(player);
    const mobType = entity.typeId.replace("minecraft:", "");

    s.set(`bd_has_${mobType}`, true);
    s.set(`bd_active_type`, entity.typeId);
    s.set(`bd_name_${entity.typeId}`, buddyName);
    s.set(`bd_points_${entity.typeId}`, 0);
    s.set(`bd_tier_${entity.typeId}`, 0);

    entity.addTag("ec.bd_buddy");
    entity.addTag(`ec.bd_owner_${player.id}`);
    entity.nameTag = buddyName;

    const buddyCount = s.getNumber("bd_count", 0);
    s.set("bd_count", buddyCount + 1);

    player.sendMessage(`\n§a§l✦ New Buddy! ✦§r §7${buddyName} the ${mobType} is now your buddy!`);
    player.sendMessage("§7Feed, explore, and fight together to build friendship.");
    player.playSound("random.levelup", { volume: 0.6, pitch: 1.2 });

    this.eventBridge.emit("buddy_designated", { player, entity, mobType });
  }

  // =====================================================
  // BEST BUDDY
  // =====================================================

  promoteBestBuddy(player, buddyType) {
    const s = StorageManager.forPlayer(player);
    const tier = s.getNumber(`bd_tier_${buddyType}`, 0);

    if (tier < 6) {
      player.sendMessage("§cYour buddy must be Spiritbound (Tier 6) to become Best Buddy.");
      return;
    }

    const oldBest = s.get("bd_best_type");
    if (oldBest) {
      s.set(`bd_is_best_${oldBest}`, false);
    }

    s.set("bd_best_type", buddyType);
    s.set("bd_is_best", true);
    s.set(`bd_is_best_${buddyType}`, true);
    s.set("bd_best_dead", false);

    const name = s.get(`bd_name_${buddyType}`) || buddyType.replace("minecraft:", "");
    player.sendMessage(`\n§b§l✦ BEST BUDDY! ✦§r`);
    player.sendMessage(`§b${name} §7is now your Best Buddy!`);
    player.sendMessage("§7Unlocked: Combat AI, Equipment Slots, Auto-Revive (10min), 2x Points");
    player.playSound("random.totem", { volume: 1.0, pitch: 1.0 });

    this.eventBridge.emit("best_buddy_promoted", { player, buddyType });
  }

  /** Handle best buddy death — start revive timer */
  onEntityDie(event) {
    const dead = event.deadEntity;
    if (!dead || !BUDDY_TYPES.has(dead.typeId)) return;
    if (!dead.hasTag("ec.bd_best")) return;

    // Find owner
    for (const player of world.getAllPlayers()) {
      if (dead.hasTag(`ec.bd_owner_${player.id}`)) {
        const s = StorageManager.forPlayer(player);
        s.set("bd_best_dead", true);

        // Start 10-minute revive timer (12000 ticks)
        let state = this.playerState.get(player.id);
        if (!state) {
          state = this.defaultState();
          this.playerState.set(player.id, state);
        }
        state.bestReviveTimer = 12000;

        const name = s.get(`bd_name_${dead.typeId}`) || dead.typeId.replace("minecraft:", "");
        player.sendMessage(`\n§c§l✦ ${name} has fallen! ✦§r`);
        player.sendMessage("§7Your best buddy will revive in §f10 minutes§7...");
        player.sendMessage("§7Keep the §dBuddy's Spirit §7in your inventory.");
        player.playSound("mob.wolf.whine", { volume: 1.0, pitch: 0.7 });

        // Give spirit memento
        try {
          player.runCommandAsync(`give @s echo_shard 1`);
        } catch {}

        break;
      }
    }
  }

  /** Best buddy auto-revive tick */
  tickBestRevive(player, state) {
    if (state.bestReviveTimer <= 0) return;
    state.bestReviveTimer--;

    // Announce at milestones
    if (state.bestReviveTimer === 6000) {
      player.sendMessage("§d§oBuddy revive: §f5 minutes remaining...");
    } else if (state.bestReviveTimer === 1200) {
      player.sendMessage("§d§oBuddy revive: §f1 minute remaining...");
    }

    if (state.bestReviveTimer <= 0) {
      this.reviveBestBuddy(player);
    }
  }

  reviveBestBuddy(player) {
    const s = StorageManager.forPlayer(player);
    const buddyType = s.get("bd_best_type");
    if (!buddyType) return;

    s.set("bd_best_dead", false);
    const name = s.get(`bd_name_${buddyType}`) || buddyType.replace("minecraft:", "");
    const mobType = buddyType.replace("minecraft:", "");

    try {
      const loc = player.location;
      player.dimension.runCommandAsync(
        `summon ${mobType} ${loc.x} ${loc.y} ${loc.z} ec_bd_revived`
      );

      system.runTimeout(() => {
        try {
          const revived = player.dimension.getEntities({
            type: buddyType,
            tags: ["ec_bd_revived"],
            location: player.location,
            maxDistance: 5,
          });
          for (const entity of revived) {
            entity.removeTag("ec_bd_revived");
            entity.addTag("ec.bd_buddy");
            entity.addTag("ec.bd_best");
            entity.addTag(`ec.bd_owner_${player.id}`);
            entity.nameTag = name;
            try { entity.addTag("ec.tame_protected"); } catch {}
            try {
              player.dimension.runCommandAsync(
                `event entity @e[type=${mobType},tag=ec.bd_best,c=1,r=5] minecraft:on_tame`
              );
            } catch {}
            break;
          }
        } catch {}
      }, 5);

      // Remove echo shard memento
      try { player.runCommandAsync("clear @s echo_shard 1"); } catch {}

      player.sendMessage(`\n§b§l✦ ${name} has returned! ✦§r`);
      player.sendMessage("§7Your best buddy is back by your side.");
      player.playSound("random.totem", { volume: 1.0, pitch: 0.8 });

      try {
        player.dimension.spawnParticle("minecraft:totem_particle", {
          x: loc.x, y: loc.y + 1, z: loc.z
        });
      } catch {}
    } catch (e) {
      console.warn(`[Buddy] Failed to revive best buddy: ${e}`);
    }
  }

  // =====================================================
  // COMBAT AI
  // =====================================================

  bestBuddyCombatTick(buddy, owner) {
    if (buddy.hasTag("ec.bd_atk_cd")) return;

    try {
      const hostiles = buddy.dimension.getEntities({
        location: buddy.location,
        maxDistance: 8,
        families: ["monster"],
      });

      let target = null;
      let minDist = 9;
      for (const h of hostiles) {
        const d = this.distance(buddy.location, h.location);
        if (d < minDist) {
          minDist = d;
          target = h;
        }
      }

      if (target) {
        target.applyDamage(4, { cause: "entityAttack", damagingEntity: buddy });
        buddy.addTag("ec.bd_atk_cd");
        system.runTimeout(() => {
          try { buddy.removeTag("ec.bd_atk_cd"); } catch {}
        }, 30); // 1.5s cooldown
      }
    } catch {}
  }

  // =====================================================
  // TIER ABILITIES
  // =====================================================

  tickAbilities(player, buddy, tier, state) {
    // T0: Heart particles (every other tick call to reduce particle spam)
    if (tier >= 0 && state.proximityTimer % 3 === 0) {
      try {
        const bLoc = buddy.location;
        buddy.dimension.spawnParticle("minecraft:heart_particle", {
          x: bLoc.x, y: bLoc.y + 1, z: bLoc.z
        });
      } catch {}
    }

    // T1: Weatherproof — clear weather damage effects
    if (tier >= 1) {
      try {
        // Remove freeze damage in powder snow
        buddy.addEffect("fire_resistance", 80, { amplifier: 0, showParticles: false });
      } catch {}
    }

    // T2: Lucky Paws (Luck I)
    if (tier >= 2) {
      try { player.addEffect("luck", 80, { amplifier: 0, showParticles: false }); } catch {}
    }

    // T3: Soullink Glow — buddy glows
    if (tier >= 3) {
      try {
        if (!buddy.hasTag("ec.bd_glow")) {
          buddy.addTag("ec.bd_glow");
        }
      } catch {}
    }

    // T4: War Companion (Strength + Resistance on buddy)
    if (tier >= 4) {
      try {
        buddy.addEffect("strength", 80, { amplifier: 0, showParticles: false });
        buddy.addEffect("resistance", 80, { amplifier: 0, showParticles: false });
      } catch {}
    }

    // T4: Shared Vitality — heal player when critically low
    if (tier >= 4 && state.vitalityCd <= 0) {
      try {
        const hp = player.getComponent("minecraft:health");
        if (hp && hp.currentValue <= 4) {
          // Heal player 4 HP, damage buddy 2 HP
          try { player.addEffect("instant_health", 1, { amplifier: 0, showParticles: true }); } catch {}
          try { buddy.applyDamage(2); } catch {}
          state.vitalityCd = VITALITY_CD;
          player.sendMessage("§d§oShared Vitality! §7Your buddy shared their life force.");
        }
      } catch {}
    }

    // T5: Buddy Aura — mob-type-specific effect to nearby players
    if (tier >= 5) {
      const aura = AURA_EFFECTS[buddy.typeId];
      if (aura) {
        try {
          const nearbyPlayers = buddy.dimension.getEntities({
            type: "minecraft:player",
            location: buddy.location,
            maxDistance: 8,
          });
          for (const p of nearbyPlayers) {
            try { p.addEffect(aura.effect, 80, { amplifier: 0, showParticles: false }); } catch {}
          }
        } catch {}
      }
    }

    // Decrement cooldowns
    if (state.cryCd > 0) state.cryCd--;
    if (state.lastStandCd > 0) state.lastStandCd--;
    if (state.vitalityCd > 0) state.vitalityCd--;
    if (state.mealCd > 0) state.mealCd--;
  }

  /** T1: Battle Cry — temporary damage boost to player */
  useBattleCry(player) {
    const s = StorageManager.forPlayer(player);
    const buddyType = s.get("bd_active_type");
    if (!buddyType) return;
    const tier = s.getNumber(`bd_tier_${buddyType}`, 0);
    if (tier < 1) { player.sendMessage("§cRequires Familiar (Tier 1) bond."); return; }

    const state = this.playerState.get(player.id);
    if (state && state.cryCd > 0) {
      player.sendMessage(`§cBattle Cry on cooldown (${Math.ceil(state.cryCd / 20)}s)`);
      return;
    }

    try {
      player.addEffect("strength", 200, { amplifier: 1, showParticles: true }); // 10s Strength II
      player.playSound("mob.wolf.bark", { volume: 1.0, pitch: 0.6 });
    } catch {}

    player.sendMessage("§a§l⚔ Battle Cry! §r§7+Strength II for 10 seconds");
    if (state) state.cryCd = BATTLE_CRY_CD;
  }

  /** T3: Last Stand — buddy teleports to player, heals to full, invulnerable 5s */
  useLastStand(player) {
    const s = StorageManager.forPlayer(player);
    const buddyType = s.get("bd_active_type");
    if (!buddyType) return;
    const tier = s.getNumber(`bd_tier_${buddyType}`, 0);
    if (tier < 3) { player.sendMessage("§cRequires Devoted (Tier 3) bond."); return; }

    const state = this.playerState.get(player.id);
    if (state && state.lastStandCd > 0) {
      player.sendMessage(`§cLast Stand on cooldown (${Math.ceil(state.lastStandCd / 20)}s)`);
      return;
    }

    try {
      const buddies = player.dimension.getEntities({
        type: buddyType,
        tags: ["ec.bd_buddy", `ec.bd_owner_${player.id}`],
        location: player.location,
        maxDistance: 128,
      });

      if (buddies.length > 0) {
        const buddy = buddies[0];
        const loc = player.location;
        buddy.teleport({ x: loc.x, y: loc.y, z: loc.z });
        try {
          buddy.addEffect("instant_health", 1, { amplifier: 5, showParticles: true });
          buddy.addEffect("resistance", 100, { amplifier: 4, showParticles: true }); // 5s invulnerable
        } catch {}
        player.sendMessage("§6§l⚔ Last Stand! §r§7Buddy teleported and healed!");
        player.playSound("mob.wolf.bark", { volume: 1.2, pitch: 0.4 });
      } else {
        player.sendMessage("§cNo buddy found nearby (128 blocks).");
      }
    } catch {}

    if (state) state.lastStandCd = LAST_STAND_CD;
  }

  // =====================================================
  // PACK MULE (Tier 3+)
  // =====================================================

  openPackMule(player) {
    const s = StorageManager.forPlayer(player);
    const buddyType = s.get("bd_active_type");
    if (!buddyType) { player.sendMessage("§cNo buddy designated."); return; }
    const tier = s.getNumber(`bd_tier_${buddyType}`, 0);
    if (tier < 3) { player.sendMessage("§cRequires Devoted (Tier 3) bond."); return; }

    const name = s.get(`bd_name_${buddyType}`) || buddyType.replace("minecraft:", "");
    const muleData = JSON.parse(s.get("bd_mule_items") || '["","",""]');

    const form = new ActionFormData()
      .title(`§6${name}'s Pack`)
      .body("§7Your buddy carries up to 3 items.\nClick a slot to store/retrieve.");

    for (let i = 0; i < 3; i++) {
      const slotLabel = muleData[i] ? `§aSlot ${i + 1}: §f${muleData[i]}` : `§7Slot ${i + 1}: §8(empty)`;
      form.button(slotLabel);
    }
    form.button("§cClose");

    form.show(player).then((response) => {
      if (response.canceled || response.selection === 3) return;
      const slot = response.selection;

      if (muleData[slot]) {
        // Retrieve item
        try {
          player.runCommandAsync(`give @s ${muleData[slot]} 1`);
          player.sendMessage(`§a+ Retrieved §f${muleData[slot]}§a from pack.`);
          muleData[slot] = "";
          s.set("bd_mule_items", JSON.stringify(muleData));
        } catch {}
      } else {
        // Store held item
        try {
          const equip = player.getComponent("minecraft:equippable");
          const mainhand = equip?.getEquipment("Mainhand");
          if (mainhand) {
            muleData[slot] = mainhand.typeId;
            s.set("bd_mule_items", JSON.stringify(muleData));
            player.runCommandAsync(`clear @s ${mainhand.typeId} 1`);
            player.sendMessage(`§6+ Stored §f${mainhand.typeId}§6 in pack.`);
          } else {
            player.sendMessage("§cHold an item to store it in the pack.");
          }
        } catch {}
      }
    }).catch(() => {});
  }

  // =====================================================
  // MOUNT CHARGE
  // =====================================================

  tickMountCharge(player, state) {
    if (!player.isRiding) return;

    const loc = player.location;
    if (!state.lastPos) {
      state.lastPos = { x: loc.x, z: loc.z };
      return;
    }

    const dx = loc.x - state.lastPos.x;
    const dz = loc.z - state.lastPos.z;
    const speed = Math.sqrt(dx * dx + dz * dz); // blocks per tick (called every 40 ticks)
    const blocksPerSec = (speed / 40) * 20;

    state.lastPos = { x: loc.x, z: loc.z };

    // Charge at >12 blocks/sec
    if (blocksPerSec > 12) {
      try {
        const nearby = player.dimension.getEntities({
          location: player.location,
          maxDistance: 3,
          families: ["monster"],
        });
        for (const mob of nearby) {
          try {
            mob.applyDamage(6, { cause: "entityAttack", damagingEntity: player });
            mob.addEffect("slowness", 40, { amplifier: 2, showParticles: true });
          } catch {}
        }
        if (nearby.length > 0) {
          player.sendMessage("§6§l⚡ Charge! §r§7Trampled nearby enemies!");
          player.playSound("mob.horse.gallop", { volume: 0.8, pitch: 1.2 });
        }
      } catch {}
    }
  }

  // =====================================================
  // MAIN TICK
  // =====================================================

  buddyTickCounter = 0;

  tick(players) {
    this.buddyTickCounter++;
    const doCombat = (this.buddyTickCounter % 5 === 0); // OPT: combat AI every 5 ticks

    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const buddyType = s.get("bd_active_type");
      if (!buddyType) continue;

      let state = this.playerState.get(player.id);
      if (!state) {
        state = this.defaultState();
        this.playerState.set(player.id, state);
      }

      // Best buddy revive timer
      if (s.get("bd_best_dead")) {
        this.tickBestRevive(player, state);
      }

      // Mount charge detection
      this.tickMountCharge(player, state);

      // OPT: Cache buddy entity reference — only re-query every 5 ticks or if stale
      if (doCombat || !state.cachedBuddy) {
        try {
          const nearby = player.dimension.getEntities({
            type: buddyType,
            tags: ["ec.bd_buddy", `ec.bd_owner_${player.id}`],
            location: player.location,
            maxDistance: 16,
          });
          state.cachedBuddy = nearby.length > 0 ? nearby[0] : null;
        } catch { state.cachedBuddy = null; }
      }

      if (state.cachedBuddy) {
        // Validate cached entity is still alive
        try { if (!state.cachedBuddy.isValid) state.cachedBuddy = null; } catch { state.cachedBuddy = null; }
      }

      if (state.cachedBuddy) {
        state.proximityTimer++;
        if (state.proximityTimer >= 60) {
          state.proximityTimer = 0;
          this.addPoints(player, 1);
        }

        const tier = s.getNumber(`bd_tier_${buddyType}`, 0);

        // Run tier abilities (every tick for proximity-based)
        this.tickAbilities(player, state.cachedBuddy, tier, state);

        // Best Buddy Combat AI — OPT: every 5 ticks
        if (doCombat && s.get(`bd_is_best_${buddyType}`)) {
          this.bestBuddyCombatTick(state.cachedBuddy, player);
        }
      }
    }
  }

  // =====================================================
  // GUI — 4-Tab Catalogue (Bedrock form-based)
  // =====================================================

  openCatalogue(player) {
    const form = new ActionFormData()
      .title("§l§6Companion Catalogue")
      .body("§7Manage your animal companions and buddies.");

    form.button("§eBuddy Status");
    form.button("§6Best Buddy");
    form.button("§aDesignate Buddy");
    form.button("§dPack Mule");
    form.button("§bAbilities");
    form.button("§cClose");

    form.show(player).then((response) => {
      if (response.canceled) return;
      switch (response.selection) {
        case 0: this.showStatus(player); break;
        case 1: this.showBestBuddyMenu(player); break;
        case 2: this.showDesignateMenu(player); break;
        case 3: this.openPackMule(player); break;
        case 4: this.showAbilitiesMenu(player); break;
      }
    }).catch(() => {});
  }

  showDesignateMenu(player) {
    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 16,
      });

      const tamed = [];
      for (const e of nearby) {
        if (!BUDDY_TYPES.has(e.typeId)) continue;
        if (e.getComponent("minecraft:is_tamed") || e.hasTag("ec.tame_protected") ||
            e.hasTag("ec.fox_tamed") || e.hasTag("ec.ocelot_tamed")) {
          tamed.push(e);
        }
      }

      if (tamed.length === 0) {
        player.sendMessage("§cNo tamed animals nearby (16 blocks).");
        return;
      }

      const form = new ActionFormData()
        .title("§l§aDesignate Buddy")
        .body("§7Choose a tamed animal to become your buddy:");

      for (const e of tamed) {
        const name = e.nameTag || e.typeId.replace("minecraft:", "");
        form.button(`§f${name} §7(${e.typeId.replace("minecraft:", "")})`);
      }

      form.show(player).then((response) => {
        if (response.canceled) return;
        this.designateBuddy(player, tamed[response.selection]);
      }).catch(() => {});
    } catch {}
  }

  showBestBuddyMenu(player) {
    const s = StorageManager.forPlayer(player);
    const buddyType = s.get("bd_active_type");
    if (!buddyType) { player.sendMessage("§cNo buddy designated."); return; }

    const tier = s.getNumber(`bd_tier_${buddyType}`, 0);
    const bestType = s.get("bd_best_type");
    const name = s.get(`bd_name_${buddyType}`) || buddyType.replace("minecraft:", "");

    const form = new ActionFormData()
      .title("§l§6Best Buddy");

    if (bestType) {
      const bestName = s.get(`bd_name_${bestType}`) || bestType.replace("minecraft:", "");
      const isDead = s.get("bd_best_dead");
      form.body(`§bBest Buddy: §f${bestName}${isDead ? " §c(fallen — reviving...)" : " §a(active)"}`);
      form.button("§7Back");
    } else if (tier >= 6) {
      form.body(`§7${name} is eligible for Best Buddy promotion!\n§bRequires: Spiritbound (Tier 6) ✓`);
      form.button("§b✦ Promote to Best Buddy ✦");
      form.button("§7Back");

      form.show(player).then((response) => {
        if (response.canceled || response.selection === 1) return;
        this.promoteBestBuddy(player, buddyType);
      }).catch(() => {});
      return;
    } else {
      form.body(`§7Best Buddy requires Spiritbound (Tier 6).\n§7${name} is currently ${TIER_COLORS[tier]}${TIER_NAMES[tier]} §7(Tier ${tier}).`);
      form.button("§7Back");
    }

    form.show(player).catch(() => {});
  }

  showAbilitiesMenu(player) {
    const s = StorageManager.forPlayer(player);
    const buddyType = s.get("bd_active_type");
    if (!buddyType) { player.sendMessage("§cNo buddy designated."); return; }
    const tier = s.getNumber(`bd_tier_${buddyType}`, 0);

    const form = new ActionFormData()
      .title("§l§dBuddy Abilities");

    let body = "";
    body += tier >= 1 ? "§a✓ Battle Cry §7(Strength II, 10s)\n" : "§8✗ Battle Cry §7(Tier 1)\n";
    body += tier >= 2 ? "§a✓ Lucky Paws §7(Luck I, passive)\n" : "§8✗ Lucky Paws §7(Tier 2)\n";
    body += tier >= 3 ? "§a✓ Pack Mule §7(3 item slots)\n" : "§8✗ Pack Mule §7(Tier 3)\n";
    body += tier >= 3 ? "§a✓ Last Stand §7(Emergency heal)\n" : "§8✗ Last Stand §7(Tier 3)\n";
    body += tier >= 4 ? "§a✓ War Companion §7(Buddy Strength+Res)\n" : "§8✗ War Companion §7(Tier 4)\n";
    body += tier >= 4 ? "§a✓ Shared Vitality §7(Emergency HP share)\n" : "§8✗ Shared Vitality §7(Tier 4)\n";
    body += tier >= 5 ? `§a✓ Buddy Aura §7(${AURA_EFFECTS[buddyType]?.name || "Passive"})\n` : "§8✗ Buddy Aura §7(Tier 5)\n";
    form.body(body);

    if (tier >= 1) form.button("§a⚔ Battle Cry");
    if (tier >= 3) form.button("§6⚔ Last Stand");
    form.button("§7Back");

    form.show(player).then((response) => {
      if (response.canceled) return;
      let idx = 0;
      if (tier >= 1 && response.selection === idx++) { this.useBattleCry(player); return; }
      if (tier >= 3 && response.selection === idx++) { this.useLastStand(player); return; }
    }).catch(() => {});
  }

  // =====================================================
  // STATUS
  // =====================================================

  showStatus(player) {
    const s = StorageManager.forPlayer(player);
    const buddyType = s.get("bd_active_type");
    if (!buddyType) {
      player.sendMessage("§7You don't have a buddy yet. Use the Companion Catalogue near a tamed mob!");
      return;
    }

    const points = s.getNumber(`bd_points_${buddyType}`, 0);
    const tier = this.getTier(points);
    const name = s.get(`bd_name_${buddyType}`) || buddyType.replace("minecraft:", "");
    const tierName = TIER_NAMES[tier];
    const color = TIER_COLORS[tier];
    const isBest = s.get(`bd_is_best_${buddyType}`);
    const nextThreshold = tier < 6 ? TIER_THRESHOLDS[tier + 1] : "MAX";

    let msg = `\n§e§l✦ Buddy Status ✦§r\n`;
    msg += `§7Name: ${color}${name}${isBest ? " §b[Best Buddy]" : ""}\n`;
    msg += `§7Type: §f${buddyType.replace("minecraft:", "")}\n`;
    msg += `§7Bond: ${color}${tierName} §7(Tier ${tier})\n`;
    msg += `§7Friendship: §f${points}/${nextThreshold}\n`;
    msg += `§7Total Buddies: §f${s.getNumber("bd_count", 0)}\n`;

    // Best buddy status
    const bestType = s.get("bd_best_type");
    if (bestType) {
      const bestName = s.get(`bd_name_${bestType}`) || bestType.replace("minecraft:", "");
      const isDead = s.get("bd_best_dead");
      msg += `\n§b★ Best Buddy: §f${bestName}${isDead ? " §c(reviving...)" : " §a(active)"}`;
    }

    // Aura info
    if (tier >= 5) {
      const aura = AURA_EFFECTS[buddyType];
      if (aura) msg += `\n§5Buddy Aura: §f${aura.name} §7(8 block radius)`;
    }

    player.sendMessage(msg);
  }

  // =====================================================
  // HELPERS
  // =====================================================

  defaultState() {
    return {
      proximityTimer: 0,
      walkSnapshot: null,
      lastPos: null,
      cryCd: 0,
      lastStandCd: 0,
      vitalityCd: 0,
      mealCd: 0,
      bestReviveTimer: 0,
    };
  }

  distance(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  /** Reset daily buddy counters at dawn */
  dailyReset() {
    for (const player of world.getAllPlayers()) {
      const s = StorageManager.forPlayer(player);
      s.setNumber("bd_feed_today", 0);
      s.setNumber("bd_summon_ct", 0);
    }
  }
}
