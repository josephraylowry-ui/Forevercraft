/**
 * Dungeon System — Wave-based instanced combat (5 waves, 16 themes).
 * Structure-based entry with difficulty selection. DR-scaled rewards.
 * Replaces Java dungeon/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// 16 dungeon instances with themed mob waves
const INSTANCES = [
  { id: 1, name: "The Crypt", waves: [
    [{ type: "minecraft:zombie", count: 3 }],
    [{ type: "minecraft:husk", count: 4 }, { type: "minecraft:skeleton", count: 1 }],
    [{ type: "minecraft:zombie", count: 3 }, { type: "minecraft:stray", count: 2 }],
    [{ type: "minecraft:zombie", count: 4 }, { type: "minecraft:skeleton", count: 3 }],
    [{ type: "minecraft:wither_skeleton", count: 1, boss: true, hp: 120, name: "§c§lCrypt Lord" },
     { type: "minecraft:skeleton", count: 3, guard: true, hp: 40 }],
  ]},
  { id: 2, name: "Spider's Nest", waves: [
    [{ type: "minecraft:spider", count: 4 }],
    [{ type: "minecraft:spider", count: 3 }, { type: "minecraft:cave_spider", count: 2 }],
    [{ type: "minecraft:cave_spider", count: 4 }, { type: "minecraft:spider", count: 2 }],
    [{ type: "minecraft:cave_spider", count: 5 }, { type: "minecraft:spider", count: 3 }],
    [{ type: "minecraft:spider", count: 1, boss: true, hp: 100, name: "§c§lBroodmother" },
     { type: "minecraft:cave_spider", count: 4, guard: true, hp: 30 }],
  ]},
  { id: 3, name: "Skeleton Keep", waves: [
    [{ type: "minecraft:skeleton", count: 4 }],
    [{ type: "minecraft:skeleton", count: 3 }, { type: "minecraft:stray", count: 2 }],
    [{ type: "minecraft:stray", count: 4 }, { type: "minecraft:skeleton", count: 2 }],
    [{ type: "minecraft:skeleton", count: 4 }, { type: "minecraft:stray", count: 3 }],
    [{ type: "minecraft:wither_skeleton", count: 1, boss: true, hp: 110, name: "§c§lBone King" },
     { type: "minecraft:stray", count: 3, guard: true, hp: 35 }],
  ]},
  { id: 4, name: "Creeper Cavern", waves: [
    [{ type: "minecraft:creeper", count: 3 }],
    [{ type: "minecraft:creeper", count: 4 }, { type: "minecraft:zombie", count: 2 }],
    [{ type: "minecraft:creeper", count: 5 }, { type: "minecraft:skeleton", count: 2 }],
    [{ type: "minecraft:creeper", count: 6 }, { type: "minecraft:spider", count: 2 }],
    [{ type: "minecraft:creeper", count: 2, boss: true, hp: 80, name: "§c§lVolatile Core" },
     { type: "minecraft:creeper", count: 4, guard: true, hp: 25 }],
  ]},
  { id: 5, name: "Witch's Hollow", waves: [
    [{ type: "minecraft:witch", count: 1 }, { type: "minecraft:zombie", count: 2 }],
    [{ type: "minecraft:witch", count: 2 }, { type: "minecraft:creeper", count: 2 }],
    [{ type: "minecraft:witch", count: 3 }, { type: "minecraft:creeper", count: 3 }],
    [{ type: "minecraft:witch", count: 4 }, { type: "minecraft:spider", count: 2 }],
    [{ type: "minecraft:witch", count: 1, boss: true, hp: 110, name: "§c§lCoven Mother" },
     { type: "minecraft:creeper", count: 2, guard: true, hp: 40 }],
  ]},
  // Instances 6-16: simplified templates
  ...Array.from({ length: 11 }, (_, i) => ({
    id: i + 6,
    name: ["Blaze Pit", "Phantom Rift", "Pillager Fort", "Drowned Depths",
           "Enderman Vault", "Guardian Temple", "Ravager Arena",
           "Piglin Bastion", "Wither Sanctum", "Sculk Abyss", "The Gauntlet"][i],
    waves: generateGenericWaves(i + 6),
  })),
];

function generateGenericWaves(id) {
  const mobTypes = [
    "minecraft:zombie", "minecraft:skeleton", "minecraft:spider",
    "minecraft:creeper", "minecraft:husk", "minecraft:stray",
    "minecraft:cave_spider", "minecraft:witch",
  ];
  const bossTypes = [
    "minecraft:wither_skeleton", "minecraft:vindicator",
    "minecraft:evoker", "minecraft:ravager",
  ];

  const primary = mobTypes[(id - 1) % mobTypes.length];
  const secondary = mobTypes[id % mobTypes.length];
  const bossType = bossTypes[(id - 1) % bossTypes.length];

  return [
    [{ type: primary, count: 3 }],
    [{ type: primary, count: 3 }, { type: secondary, count: 2 }],
    [{ type: primary, count: 4 }, { type: secondary, count: 3 }],
    [{ type: primary, count: 5 }, { type: secondary, count: 3 }],
    [{ type: bossType, count: 1, boss: true, hp: 100 + id * 10, name: `§c§lDungeon Boss` },
     { type: primary, count: 3, guard: true, hp: 30 + id * 2 }],
  ];
}

// Difficulty scaling
const DIFFICULTY_SCALING = [
  { name: "Easy", color: "§a", hpMult: 1.0, dmgMult: 1.0 },
  { name: "Normal", color: "§e", hpMult: 1.25, dmgMult: 1.15 },
  { name: "Hard", color: "§c", hpMult: 1.5, dmgMult: 1.3 },
  { name: "Brutal", color: "§4", hpMult: 2.0, dmgMult: 1.5 },
];

// Random modifiers
const MODIFIERS = [
  { id: 1, name: "Relentless", desc: "Mobs are faster", color: "§e" },
  { id: 2, name: "Fortified", desc: "Mobs take less damage", color: "§9" },
  { id: 3, name: "Shrouded", desc: "Darkness envelops you", color: "§8" },
  { id: 4, name: "Volatile", desc: "Mobs resist knockback", color: "§6" },
  { id: 5, name: "Undying", desc: "Mobs slowly regenerate", color: "§a" },
  { id: 6, name: "Frenzied", desc: "Mobs deal more damage", color: "§c" },
];

// Party affixes — applied when 2+ players enter dungeon together
const PARTY_AFFIXES = [
  { id: "rally",     name: "Rally Cry",     color: "§a", desc: "+15% XP, party Strength I every 30s", xpMult: 1.15 },
  { id: "guardian",   name: "Guardian Bond",  color: "§9", desc: "Party Resistance I every 30s, +10% rewards", rewardMult: 1.1 },
  { id: "warband",    name: "Warband",        color: "§c", desc: "+1 mob per wave, +25% rewards", extraMobs: 1, rewardMult: 1.25 },
  { id: "communion",  name: "Communion",       color: "§d", desc: "Party Regen I every 30s, +20% XP", xpMult: 1.2 },
];

// Reward tiers by DR
const REWARD_TIERS = [
  { minDR: 0, tier: "common", emeralds: 16, xp: 200 },
  { minDR: 7, tier: "uncommon", emeralds: 24, xp: 400 },
  { minDR: 13, tier: "rare", emeralds: 32, xp: 800 },
  { minDR: 18, tier: "ornate", emeralds: 48, xp: 1500 },
  { minDR: 23, tier: "exquisite", emeralds: 64, xp: 3000 },
  { minDR: 30, tier: "mythical", emeralds: 64, xp: 5000 },
];

const WAVE_TIMER = 6000; // 5 minutes per wave
const LOCKOUT_TICKS = 504000; // 7 in-game days
const BOUNDARY = 64;

export class DungeonSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.active = null; // { instance, wave, timer, difficulty, modifier, center, players[], mobs[] }

    // Listen for dungeon key use
    world.afterEvents.itemUse.subscribe((event) => {
      if (event.itemStack?.typeId === "forevercraft:dungeon_key") {
        this.tryStart(event.source);
      }
    });
  }

  /**
   * Try to start a dungeon.
   */
  tryStart(player) {
    if (this.active) {
      player.sendMessage("§cA dungeon is already active!");
      return;
    }

    // Check 30-floor daily limit
    const storage = StorageManager.forPlayer(player);
    const floorsToday = storage.getNumber("dg_floors_today", 0);
    if (floorsToday >= 30) {
      player.sendMessage("§cDaily dungeon limit reached! §7(30 floors/day)");
      return;
    }

    this.openDifficultyMenu(player);
  }

  /**
   * Open difficulty selection menu.
   */
  openDifficultyMenu(player) {
    const form = new ActionFormData()
      .title("§c⚔ Dungeon Challenge")
      .body("§7Select your difficulty:\n\n§aEasy — Base stats\n§eNormal — +25% HP, +15% DMG\n§cHard — +50% HP, +30% DMG\n§4Brutal — +100% HP, +50% DMG");

    for (const diff of DIFFICULTY_SCALING) {
      form.button(`${diff.color}${diff.name}`);
    }
    form.button("§7Cancel");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 4) return;
      this.beginDungeon(player, r.selection);
    });
  }

  /**
   * Begin a dungeon with selected difficulty.
   */
  beginDungeon(player, difficulty) {
    const instance = INSTANCES[Math.floor(Math.random() * INSTANCES.length)];
    const modifier = MODIFIERS[Math.floor(Math.random() * MODIFIERS.length)];
    const diff = DIFFICULTY_SCALING[difficulty];

    // Find party members nearby
    const partyPlayers = [player];
    try {
      const nearby = player.dimension.getPlayers({ location: player.location, maxDistance: 32 });
      for (const p of nearby) {
        if (p.id !== player.id && p.hasTag("ec.in_party")) {
          partyPlayers.push(p);
        }
      }
    } catch {}

    // Roll party affix if 2+ players
    const partyAffix = partyPlayers.length >= 2
      ? PARTY_AFFIXES[Math.floor(Math.random() * PARTY_AFFIXES.length)]
      : null;

    this.active = {
      instance,
      wave: 0,
      timer: 60, // 3 second countdown
      difficulty,
      modifier,
      partyAffix,
      center: { ...player.location },
      dimension: player.dimension,
      players: partyPlayers.map(p => p.id),
      mobs: [],
      startTick: system.currentTick,
    };

    // Tag participating players
    for (const p of partyPlayers) {
      p.addTag("ec.dg_player");
    }

    // Announce
    for (const p of partyPlayers) {
      p.sendMessage(`§c§l═══════════════════════════`);
      p.sendMessage(`§c§l  ⚔ ${instance.name}`);
      p.sendMessage(`§c§l═══════════════════════════`);
      p.sendMessage(`§7Difficulty: ${diff.color}${diff.name}`);
      p.sendMessage(`§7Modifier: ${modifier.color}${modifier.name} §7— ${modifier.desc}`);
      if (partyAffix) {
        p.sendMessage(`§7Party Affix: ${partyAffix.color}${partyAffix.name} §7— ${partyAffix.desc}`);
      }
      try { p.playSound("mob.wither.spawn", { volume: 0.5, pitch: 1.2 }); } catch {}
    }
  }

  /**
   * Main dungeon tick — runs every tick when active.
   */
  tick() {
    if (!this.active) return;

    const dg = this.active;
    dg.timer--;

    if (dg.wave === 0) {
      // Countdown phase
      if (dg.timer === 40) this.announceCountdown("3");
      if (dg.timer === 20) this.announceCountdown("2");
      if (dg.timer === 1) this.announceCountdown("1");
      if (dg.timer <= 0) {
        dg.wave = 1;
        dg.timer = WAVE_TIMER;
        this.spawnWave(dg);
      }
      return;
    }

    // Check if all mobs are dead
    if (dg.timer % 20 === 0) {
      this.checkMobCount(dg);
    }

    // Timer expired = fail
    if (dg.timer <= 0) {
      this.failDungeon("Time's up!");
      return;
    }

    // Boundary check every second
    if (dg.timer % 20 === 0) {
      this.checkBoundary(dg);
    }

    // Modifier effects
    if (dg.modifier.id === 3 && dg.timer % 100 === 0) {
      // Shrouded: darkness every 5s
      for (const p of this.getActivePlayers()) {
        try { p.addEffect("darkness", 100, { amplifier: 0, showParticles: false }); } catch {}
      }
    }

    // Undying: mobs regenerate every 5s
    if (dg.modifier.id === 5 && dg.timer % 100 === 0) {
      try {
        const mobs = dg.dimension.getEntities({ location: dg.center, maxDistance: BOUNDARY, tags: ["ec.dg_mob"] });
        for (const mob of mobs) {
          try { mob.addEffect("regeneration", 100, { amplifier: 0, showParticles: false }); } catch {}
        }
      } catch {}
    }

    // Party affix effects every 30 seconds (600 ticks)
    if (dg.partyAffix && dg.timer % 600 === 0) {
      const players = this.getActivePlayers();
      switch (dg.partyAffix.id) {
        case "rally":
          for (const p of players) {
            try { p.addEffect("strength", 600, { amplifier: 0, showParticles: false }); } catch {}
          }
          break;
        case "guardian":
          for (const p of players) {
            try { p.addEffect("resistance", 600, { amplifier: 0, showParticles: false }); } catch {}
          }
          break;
        case "communion":
          for (const p of players) {
            try { p.addEffect("regeneration", 600, { amplifier: 0, showParticles: false }); } catch {}
          }
          break;
      }
    }

    // HUD update every second
    if (dg.timer % 20 === 0) {
      this.updateHUD(dg);
    }
  }

  /**
   * Spawn a wave of mobs.
   */
  spawnWave(dg) {
    const waveMobs = dg.instance.waves[dg.wave - 1];
    if (!waveMobs) return;

    const dim = dg.dimension;
    const center = dg.center;
    const diff = DIFFICULTY_SCALING[dg.difficulty];

    const extraMobs = dg.partyAffix?.extraMobs || 0;

    for (const mobDef of waveMobs) {
      const spawnCount = mobDef.count + (mobDef.boss ? 0 : extraMobs);
      for (let i = 0; i < spawnCount; i++) {
        const ox = (Math.random() - 0.5) * 16;
        const oz = (Math.random() - 0.5) * 16;
        try {
          const mob = dim.spawnEntity(mobDef.type, {
            x: center.x + ox, y: center.y, z: center.z + oz,
          });
          mob.addTag("ec.dg_mob");
          if (mobDef.boss) mob.addTag("ec.dg_boss");
          if (mobDef.guard) mob.addTag("ec.dg_guard");

          // Apply name
          if (mobDef.name) {
            mob.nameTag = mobDef.name;
          }

          // Apply HP scaling
          const baseHP = mobDef.hp || 20;
          const scaledHP = Math.floor(baseHP * diff.hpMult);
          const health = mob.getComponent("minecraft:health");
          if (health) {
            try {
              health.setCurrentValue(scaledHP);
            } catch {}
          }

          // Glowing for visibility
          try { mob.addEffect("glowing", 999999, { amplifier: 0, showParticles: false }); } catch {}

          dg.mobs.push(mob.id);
        } catch {}
      }
    }

    this.announceWave(dg.wave);
  }

  /**
   * Check mob count — advance wave if all dead.
   */
  checkMobCount(dg) {
    try {
      const alive = dg.dimension.getEntities({
        location: dg.center,
        maxDistance: BOUNDARY,
        tags: ["ec.dg_mob"],
      });

      if (alive.length === 0 && dg.wave >= 1) {
        if (dg.wave >= 5) {
          this.completeDungeon(dg);
        } else {
          dg.wave++;
          dg.timer = WAVE_TIMER;
          this.spawnWave(dg);
        }
      }
    } catch {}
  }

  /**
   * Check boundary — teleport out-of-bounds players back.
   */
  checkBoundary(dg) {
    for (const player of this.getActivePlayers()) {
      const dx = Math.abs(player.location.x - dg.center.x);
      const dz = Math.abs(player.location.z - dg.center.z);
      if (dx > BOUNDARY || dz > BOUNDARY) {
        try {
          player.teleport(dg.center);
          player.addEffect("slowness", 60, { amplifier: 2 });
          player.sendMessage("§cYou've been teleported back — stay in the arena!");
        } catch {}
      }
    }
  }

  /**
   * Complete the dungeon — rewards and cleanup.
   */
  completeDungeon(dg) {
    const elapsed = system.currentTick - dg.startTick;
    const seconds = Math.floor(elapsed / 20);

    for (const player of this.getActivePlayers()) {
      const storage = StorageManager.forPlayer(player);
      const dr = storage.getNumber("dream_rate", 0);

      // Get reward tier
      let reward = REWARD_TIERS[0];
      for (const r of REWARD_TIERS) {
        if (dr >= r.minDR) reward = r;
      }

      // Difficulty minimum enforcement
      if (dg.difficulty >= 3 && dr < 18) reward = REWARD_TIERS[3]; // Brutal → min Ornate
      if (dg.difficulty >= 2 && dr < 13) reward = REWARD_TIERS[2]; // Hard → min Rare
      if (dg.difficulty >= 1 && dr < 7) reward = REWARD_TIERS[1]; // Normal → min Uncommon

      player.sendMessage("§6§l═══════════════════════════");
      player.sendMessage("§6§l  ✦ Dungeon Complete! ✦");
      player.sendMessage("§6§l═══════════════════════════");
      player.sendMessage(`§7Time: §f${seconds}s §7| Reward: §e${reward.tier} crate`);

      // Apply party affix multipliers
      let xpReward = reward.xp;
      let emeraldReward = reward.emeralds;
      if (dg.partyAffix) {
        if (dg.partyAffix.xpMult) xpReward = Math.floor(xpReward * dg.partyAffix.xpMult);
        if (dg.partyAffix.rewardMult) emeraldReward = Math.floor(emeraldReward * dg.partyAffix.rewardMult);
      }

      // Give rewards
      this.eventBridge.emit("crate_give", player, reward.tier);
      try {
        player.dimension.runCommandAsync(`xp ${xpReward} "${player.name}"`);
        player.dimension.runCommandAsync(`give "${player.name}" emerald ${emeraldReward}`);
      } catch {}

      // 25% chance for bonus key
      if (Math.random() < 0.25) {
        try {
          player.dimension.runCommandAsync(`give "${player.name}" forevercraft:dungeon_key 1`);
          player.sendMessage("§e§lBonus Key! §r§7You found another Dungeon Key!");
        } catch {}
      }

      // Track best time
      const bestTime = storage.getNumber("best_dungeon_time", 0);
      if (bestTime === 0 || seconds < bestTime) {
        storage.set("best_dungeon_time", seconds);
      }
      storage.increment("dungeons_done", 1);

      player.removeTag("ec.dg_player");
      try { player.playSound("random.levelup", { volume: 0.8, pitch: 1.0 }); } catch {}
    }

    this.cleanup();
  }

  /**
   * Fail the dungeon.
   */
  failDungeon(reason) {
    for (const player of this.getActivePlayers()) {
      player.sendMessage(`§c§lDungeon Failed! §r§7${reason}`);
      player.removeTag("ec.dg_player");
      try { player.playSound("mob.wither.death", { volume: 0.3, pitch: 0.8 }); } catch {}
    }
    this.cleanup();
  }

  /**
   * Cleanup dungeon state.
   */
  cleanup() {
    if (!this.active) return;
    const dg = this.active;

    // Kill remaining mobs
    try {
      const mobs = dg.dimension.getEntities({
        location: dg.center,
        maxDistance: BOUNDARY + 16,
        tags: ["ec.dg_mob"],
      });
      for (const mob of mobs) {
        try { mob.kill(); } catch {}
      }
    } catch {}

    this.active = null;
  }

  /**
   * Get active players in the dungeon.
   */
  // OPT: Cache active player list — reuse within same tick, refresh per call
  _cachedDgPlayers = null;
  _cachedDgTick = -1;

  getActivePlayers() {
    const now = system.currentTick;
    if (this._cachedDgTick === now && this._cachedDgPlayers) return this._cachedDgPlayers;
    this._cachedDgPlayers = world.getAllPlayers().filter(p => p.hasTag("ec.dg_player"));
    this._cachedDgTick = now;
    return this._cachedDgPlayers;
  }

  announceCountdown(num) {
    for (const p of this.getActivePlayers()) {
      p.sendMessage(`§e§l${num}...`);
      try { p.playSound("note.hat", { volume: 0.5, pitch: 1.0 }); } catch {}
    }
  }

  announceWave(wave) {
    for (const p of this.getActivePlayers()) {
      p.sendMessage(`§c§lWave ${wave} §r§7— Fight!`);
      try { p.playSound("mob.wither.break_block", { volume: 0.3, pitch: 1.2 }); } catch {}
    }
  }

  updateHUD(dg) {
    const alive = dg.mobs.length; // approximate
    const seconds = Math.floor(dg.timer / 20);
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    const timeStr = `${min}:${sec < 10 ? "0" : ""}${sec}`;
    const floorStr = dg.floor > 0 ? `§7Floor ${dg.floor} | ` : "";

    for (const p of this.getActivePlayers()) {
      try {
        p.onScreenDisplay?.setActionBar?.(`${floorStr}§cWave ${dg.wave} §7| §f${timeStr}`);
      } catch {}
    }
  }

  // ─── MULTI-FLOOR DUNGEON DESCENT ───────────────────────────
  // After clearing a floor, players can descend up to 3 floors total.
  // Each floor gets a new random instance theme and harder waves.

  static MAX_FLOORS = 3;
  static DESCENT_OFFER_TICKS = 300; // 15 seconds to decide

  /** Offer descent after clearing all waves on a floor */
  offerDescent(dg) {
    if (!dg.floor) dg.floor = 1;
    if (dg.floor >= DungeonSystem.MAX_FLOORS) {
      // Max floors reached — complete the run
      this.completeDungeon(dg, "max_floor");
      return;
    }

    dg.descentTimer = DungeonSystem.DESCENT_OFFER_TICKS;
    dg.awaitingDescent = true;

    for (const p of this.getActivePlayers()) {
      p.sendMessage(`§6§l✦ Floor ${dg.floor} Cleared! §r§7Descend to Floor ${dg.floor + 1}?`);
      p.sendMessage("§7Type §f/scriptevent forevercraft:dungeon_descend §7to go deeper.");
      p.sendMessage(`§7Auto-completing in 15 seconds...`);
    }
  }

  /** Execute descent to next floor */
  descend(dg) {
    dg.awaitingDescent = false;
    dg.descentTimer = 0;
    dg.floor = (dg.floor || 1) + 1;
    dg.wave = 0;

    // Increment daily floor counter for all party members
    for (const p of this.getActivePlayers()) {
      const ps = StorageManager.forPlayer(p);
      ps.set("dg_floors_today", ps.getNumber("dg_floors_today", 0) + 1);
    }

    // Kill remaining mobs from previous floor
    if (dg.mobs) {
      for (const mob of dg.mobs) {
        try { mob.kill(); } catch {}
      }
      dg.mobs = [];
    }

    // Pick new instance theme
    const newInstance = INSTANCES[Math.floor(Math.random() * INSTANCES.length)];
    dg.instance = newInstance;

    // Scale difficulty for deeper floors
    const floorMult = 1 + (dg.floor - 1) * 0.25;
    dg.floorMultiplier = floorMult;

    for (const p of this.getActivePlayers()) {
      p.sendMessage(`§c§l⬇ Descending to Floor ${dg.floor}! §r§7${newInstance.name}`);
      try {
        p.runCommandAsync("effect @s resistance 5 4 true"); // Brief protection
        p.playSound("mob.warden.emerge", { volume: 0.5, pitch: 0.8 });
      } catch {}
    }

    // Start next wave after brief delay
    system.runTimeout(() => {
      if (this.activeDungeon === dg) {
        this.startNextWave(dg);
      }
    }, 60); // 3 second delay
  }

  /** Tick descent timer */
  tickDescent(dg) {
    if (!dg.awaitingDescent) return;
    dg.descentTimer--;
    if (dg.descentTimer <= 0) {
      dg.awaitingDescent = false;
      this.completeDungeon(dg, "no_descent");
    }
  }

  /** Handle descent scriptevent */
  handleDescentRequest() {
    const dg = this.activeDungeon;
    if (!dg || !dg.awaitingDescent) return;
    this.descend(dg);
  }

  /** Reset daily floor counter at dawn */
  dailyReset() {
    for (const player of world.getAllPlayers()) {
      const s = StorageManager.forPlayer(player);
      s.setNumber("dg_floors_today", 0);
    }
  }
}
