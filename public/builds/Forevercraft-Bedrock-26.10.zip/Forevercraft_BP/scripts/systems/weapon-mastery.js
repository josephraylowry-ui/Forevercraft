/**
 * Weapon Mastery System — Track XP per weapon type, level up, unlock abilities.
 * Replaces Java advancement-based weapon detection + scoreboard XP tracking.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { showActionForm } from "./gui-manager.js";

const WEAPON_TYPES = ["sword", "axe", "bow", "crossbow", "trident", "mace"];
const XP_PER_HIT = 1;
const XP_PER_KILL = 5;
const LEVELS = [0, 50, 150, 350, 700, 1200, 2000, 3500, 5500, 8000, 12000];

export class WeaponMasterySystem {
  constructor(eventBridge) {
    eventBridge.on("player_dealt_damage", ({ player, target, damage }) => {
      this.onHit(player, target, damage);
    });
    eventBridge.on("player_killed_entity", ({ player, entity }) => {
      this.onKill(player, entity);
    });
  }

  getWeaponType(player) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return null;
    const mainhand = equip.getEquipment("Mainhand");
    if (!mainhand) return null;
    const id = mainhand.typeId;
    if (id.includes("sword")) return "sword";
    if (id.includes("axe") && !id.includes("pickaxe")) return "axe";
    if (id.includes("bow") && !id.includes("crossbow")) return "bow";
    if (id.includes("crossbow")) return "crossbow";
    if (id.includes("trident")) return "trident";
    if (id.includes("mace")) return "mace";
    return null;
  }

  onHit(player, target, damage) {
    const type = this.getWeaponType(player);
    if (!type) return;
    this.addXP(player, type, XP_PER_HIT);
  }

  onKill(player, entity) {
    const type = this.getWeaponType(player);
    if (!type) return;
    this.addXP(player, type, XP_PER_KILL);
  }

  addXP(player, weaponType, amount) {
    const s = StorageManager.forPlayer(player);

    // Party bonus: +25% mastery XP when in a party with 2+ members
    if (player.hasTag("ec.in_party")) {
      const partySize = this.getPartySize(player);
      if (partySize >= 2) {
        amount = Math.ceil(amount * 1.25);
      }
    }

    const key = `wm_${weaponType}_xp`;
    const current = s.getNumber(key);
    const newXP = current + amount;
    s.set(key, newXP);

    const oldLevel = this.getLevel(current);
    const newLevel = this.getLevel(newXP);
    if (newLevel > oldLevel) {
      player.sendMessage(`§6§l⚔ ${weaponType.charAt(0).toUpperCase() + weaponType.slice(1)} Mastery Level ${newLevel}!`);
      player.onScreenDisplay.setTitle(`§6Level ${newLevel}`, {
        subtitle: `§e${weaponType.charAt(0).toUpperCase() + weaponType.slice(1)} Mastery`,
        fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 10,
      });
    }
  }

  /** Get party size for party bonus calculation.
   * OPT: Cached per player per 100 ticks — avoids getPlayers() on every hit */
  partySizeCache = new Map(); // playerId → { size, tick }

  getPartySize(player) {
    const cached = this.partySizeCache.get(player.id);
    const now = system.currentTick;
    if (cached && now - cached.tick < 100) return cached.size;

    try {
      const nearby = player.dimension.getPlayers({
        location: player.location,
        maxDistance: 64,
      });
      const size = nearby.filter(p => p.hasTag("ec.in_party")).length;
      this.partySizeCache.set(player.id, { size, tick: now });
      return size;
    } catch {
      this.partySizeCache.set(player.id, { size: 1, tick: now });
      return 1;
    }
  }

  getLevel(xp) {
    for (let i = LEVELS.length - 1; i >= 0; i--) {
      if (xp >= LEVELS[i]) return i;
    }
    return 0;
  }

  async showMastery(player) {
    const s = StorageManager.forPlayer(player);
    const lines = WEAPON_TYPES.map(t => {
      const xp = s.getNumber(`wm_${t}_xp`);
      const lvl = this.getLevel(xp);
      const next = LEVELS[lvl + 1] || "MAX";
      return `§e${t.charAt(0).toUpperCase() + t.slice(1)}: §fLevel ${lvl} §7(${xp}/${next} XP)`;
    });
    await showActionForm(player, "§6Weapon Mastery", lines.join("\n"), [{ text: "§7Close" }]);
  }
}
