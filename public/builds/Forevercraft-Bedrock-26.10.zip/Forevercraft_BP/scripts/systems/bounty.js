/**
 * Bounty System — Quest board bounty hunts with patron mob spawns.
 * Replaces Java bounty/ folder (21 files).
 * Players accept bounties targeting specific biomes, hunt patrons, earn rewards.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const BOUNTY_BIOMES = [
  { id: "plains", name: "Plains" }, { id: "forest", name: "Forest" },
  { id: "desert", name: "Desert" }, { id: "taiga", name: "Taiga" },
  { id: "jungle", name: "Jungle" }, { id: "swamp", name: "Swamp" },
  { id: "mountains", name: "Mountains" }, { id: "ocean", name: "Ocean" },
  { id: "savanna", name: "Savanna" }, { id: "badlands", name: "Badlands" },
  { id: "snowy_plains", name: "Snowy Plains" }, { id: "dark_forest", name: "Dark Forest" },
  { id: "nether_wastes", name: "Nether Wastes" }, { id: "crimson_forest", name: "Crimson Forest" },
  { id: "warped_forest", name: "Warped Forest" }, { id: "basalt_deltas", name: "Basalt Deltas" },
  { id: "soul_sand_valley", name: "Soul Sand Valley" }, { id: "deep_dark", name: "Deep Dark" },
];

const BOUNTY_TIERS = [
  { tier: 1, kills: 5, reward: "common", time: 600, color: "§f" },
  { tier: 2, kills: 8, reward: "uncommon", time: 480, color: "§e" },
  { tier: 3, kills: 10, reward: "rare", time: 360, color: "§b" },
  { tier: 4, kills: 15, reward: "ornate", time: 300, color: "§5" },
  { tier: 5, kills: 20, reward: "exquisite", time: 240, color: "§6" },
];

export class BountySystem {
  constructor(eventBridge) {
    // Entity death for bounty tracking
    world.afterEvents.entityDie.subscribe((event) => {
      const entity = event.deadEntity;
      const killer = event.damageSource?.damagingEntity;
      if (killer?.typeId === "minecraft:player" && entity?.hasTag?.("ec.bounty_target")) {
        this.onBountyKill(killer, entity);
      }
    });
  }

  /** Open bounty board for player */
  openBountyBoard(player) {
    const s = StorageManager.forPlayer(player);
    const activeTier = s.getNumber("bnt_tier");

    if (activeTier > 0) {
      this.showActiveBounty(player);
      return;
    }

    const form = new ActionFormData()
      .title("Bounty Board")
      .body("Select a bounty tier to begin hunting:");

    for (const tier of BOUNTY_TIERS) {
      form.button(`${tier.color}Tier ${tier.tier} §r— Kill ${tier.kills} (${Math.floor(tier.time / 60)}min)`);
    }

    form.show(player).then(response => {
      if (response.canceled) return;
      const selected = BOUNTY_TIERS[response.selection];
      if (selected) this.acceptBounty(player, selected);
    });
  }

  acceptBounty(player, tierData) {
    const s = StorageManager.forPlayer(player);
    const biome = BOUNTY_BIOMES[Math.floor(Math.random() * BOUNTY_BIOMES.length)];

    s.set("bnt_tier", tierData.tier);
    s.set("bnt_biome", biome.id);
    s.set("bnt_timer", tierData.time);
    s.set("bnt_kills", 0);
    s.set("bnt_target_kills", tierData.kills);
    s.set("bnt_reward", tierData.reward);

    player.sendMessage(`§6§l✦ Bounty Accepted! §r§7Kill ${tierData.kills} patrons in §f${biome.name}`);
    player.sendMessage(`§7Time limit: §f${Math.floor(tierData.time / 60)} minutes`);
    player.playSound("random.orb");
  }

  showActiveBounty(player) {
    const s = StorageManager.forPlayer(player);
    const kills = s.getNumber("bnt_kills");
    const target = s.getNumber("bnt_target_kills");
    const timer = s.getNumber("bnt_timer");
    const biome = s.get("bnt_biome") || "unknown";

    const form = new ActionFormData()
      .title("Active Bounty")
      .body(`§7Biome: §f${biome}\n§7Progress: §f${kills}/${target} kills\n§7Time: §f${Math.floor(timer / 60)}m ${timer % 60}s`)
      .button("§cAbandon Bounty");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection === 0) {
        this.abandonBounty(player);
      }
    });
  }

  abandonBounty(player) {
    const s = StorageManager.forPlayer(player);
    s.set("bnt_tier", 0);
    player.sendMessage("§c§lBounty abandoned.");
  }

  onBountyKill(player, entity) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("bnt_tier") <= 0) return;

    let kills = s.getNumber("bnt_kills") + 1;
    s.set("bnt_kills", kills);
    const target = s.getNumber("bnt_target_kills");

    player.sendMessage(`§6§l✦ §r§7Bounty: §f${kills}/${target}`);

    if (kills >= target) {
      this.completeBounty(player);
    }
  }

  completeBounty(player) {
    const s = StorageManager.forPlayer(player);
    const reward = s.get("bnt_reward") || "common";

    try {
      const loc = player.location;
      player.dimension.runCommandAsync(
        `loot spawn ${loc.x} ${loc.y + 1} ${loc.z} loot "artifacts/${reward}/main"`
      );
    } catch {}

    player.sendMessage("§6§l✦ Bounty Complete! §r§7Reward dropped.");
    player.playSound("random.levelup");

    const completed = s.getNumber("bounties_completed") + 1;
    s.set("bounties_completed", completed);
    s.set("bnt_tier", 0);
  }

  /** Per-tick: update bounty timers */
  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const tier = s.getNumber("bnt_tier");
      if (tier <= 0) continue;

      // Timer decrements handled per-second in main tick
    }
  }
}
