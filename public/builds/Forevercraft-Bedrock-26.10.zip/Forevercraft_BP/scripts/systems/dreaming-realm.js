/**
 * Dreaming Realm — Instanced dream area using far Overworld coordinates.
 * Replaces Java dreaming_realm/ folder (custom dimension → far overworld area at x=100000).
 *
 * Players teleport to the dream area, face challenges for a time limit,
 * then get teleported back. Death in the realm = wake up (no tomb).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { CONSTANTS } from "../main.js";

const DREAM_DURATION = 6000; // 5 minutes (6000 ticks)
const DREAM_CENTER_X = 100000;
const DREAM_CENTER_Z = 0;
const DREAM_Y = 100;

export class DreamingRealmSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.activeDreamers = new Map(); // playerName → { timer, returnPos }
    this.storage = StorageManager.world();

    eventBridge.on("player_leave", (playerId, playerName) => {
      // Mark disconnected dreamers for crash recovery
      if (this.activeDreamers.has(playerName)) {
        const ws = StorageManager.world();
        ws.set(`dream_crash_${playerName}`, true);
      }
    });
  }

  /** Enter the Dreaming Realm */
  enterRealm(player) {
    if (player.hasTag("dr.in_realm")) {
      player.sendMessage("§7You're already in the Dreaming Realm!");
      return;
    }

    // Save return position
    const returnPos = {
      x: player.location.x,
      y: player.location.y,
      z: player.location.z,
      dimension: player.dimension.id,
    };

    const s = StorageManager.forPlayer(player);
    s.set("dr_return_x", returnPos.x);
    s.set("dr_return_y", returnPos.y);
    s.set("dr_return_z", returnPos.z);
    s.set("dr_return_dim", returnPos.dimension);

    player.addTag("dr.in_realm");
    this.activeDreamers.set(player.name, { timer: DREAM_DURATION, returnPos });

    // Teleport to dream area
    const overworld = world.getDimension("overworld");
    player.teleport(
      { x: DREAM_CENTER_X, y: DREAM_Y, z: DREAM_CENTER_Z },
      { dimension: overworld }
    );

    player.onScreenDisplay.setTitle("§d§lThe Dreaming Realm", {
      subtitle: "§7You drift into a world between worlds...",
      fadeInDuration: 40, stayDuration: 100, fadeOutDuration: 20,
    });

    // Apply dream effects
    player.runCommandAsync("effect @s night_vision 999999 0 true");
    player.runCommandAsync("gamemode adventure @s");

    console.log(`[DreamingRealm] ${player.name} entered the Dreaming Realm`);
  }

  /** Exit the Dreaming Realm */
  exitRealm(player, reason = "complete") {
    if (!player.hasTag("dr.in_realm")) return;

    player.removeTag("dr.in_realm");
    this.activeDreamers.delete(player.name);

    // Restore return position
    const s = StorageManager.forPlayer(player);
    const x = s.getNumber("dr_return_x");
    const y = s.getNumber("dr_return_y");
    const z = s.getNumber("dr_return_z");
    const dimName = s.getString("dr_return_dim", "overworld");
    const dim = world.getDimension(dimName.replace("minecraft:", ""));

    player.teleport({ x, y, z }, { dimension: dim });

    // Clear effects
    player.runCommandAsync("effect @s clear");
    player.runCommandAsync("gamemode survival @s");

    const messages = {
      complete: "§a§l✦ §r§7You awaken, enriched by the dream...",
      death: "§c§l✦ §r§7You jolt awake, the dream fading...",
      timeout: "§e§l✦ §r§7The dream dissolves as reality returns...",
      manual: "§7You force yourself awake.",
    };

    player.sendMessage(messages[reason] || messages.complete);
    console.log(`[DreamingRealm] ${player.name} exited (${reason})`);
  }

  /** Per-tick processing for active dreamers */
  tick() {
    if (this.activeDreamers.size === 0) return;

    for (const [name, data] of this.activeDreamers) {
      data.timer--;

      // Find player
      const players = world.getAllPlayers().filter(p => p.name === name);
      if (players.length === 0) continue;
      const player = players[0];

      // Actionbar timer
      const seconds = Math.ceil(data.timer / 20);
      const minutes = Math.floor(seconds / 60);
      const secs = seconds % 60;
      player.onScreenDisplay.setActionBar(`§dDream Timer: §f${minutes}:${secs.toString().padStart(2, "0")}`);

      // Warning at 30s
      if (data.timer === 600) {
        player.sendMessage("§e§l⚠ §r§730 seconds remaining in the dream...");
      }

      // Timeout
      if (data.timer <= 0) {
        this.exitRealm(player, "timeout");
      }

      // Fall catch (prevent falling into void)
      if (player.location.y < 10) {
        player.teleport({ x: DREAM_CENTER_X, y: DREAM_Y, z: DREAM_CENTER_Z });
      }
    }
  }

  /** Crash recovery — called on player join if they were in a dream */
  crashRecovery(player) {
    const ws = StorageManager.world();
    if (ws.getBool(`dream_crash_${player.name}`)) {
      ws.set(`dream_crash_${player.name}`, false);
      this.exitRealm(player, "manual");
      player.sendMessage("§7You were returned from an interrupted dream.");
    }
  }

  // ─── DREAM JOURNAL ──────────────────────────────────────────
  // Tracks dream entries (guardians, maze, trial types), milestones at 10 and 30.

  static JOURNAL_ENTRIES_MAZE = [
    "The corridors shifted as I walked. A pattern emerged... then vanished.",
    "Glowing symbols marked the walls. I followed them deeper.",
    "The maze breathed. Walls moved when I wasn't looking.",
    "A voice echoed: 'Find the center, find yourself.'",
  ];

  static JOURNAL_ENTRIES_GUARDIAN = [
    "Spectral guardians rose from the mist. Their eyes burned with purpose.",
    "Wave after wave. Each stronger than the last. But so was I.",
    "The guardians tested my resolve. I emerged stronger.",
    "Ancient sentinels challenged me. Their power flows through me now.",
  ];

  static JOURNAL_ENTRIES_TRIAL = [
    "Platforms appeared and vanished beneath my feet.",
    "Fragments of light drifted through the void. I gathered what I could.",
    "The trial demanded precision. One misstep and the void waited below.",
    "Crystal shards pulsed with dream energy. Each one a small victory.",
  ];

  static JOURNAL_ENTRIES_FAILED = [
    "The dream slipped away before I could grasp it.",
    "Darkness consumed the realm. I was cast out.",
    "The dream collapsed. Its secrets remain hidden.",
  ];

  /** Record a journal entry after exiting the dreaming realm */
  recordJournalEntry(player, challenges) {
    const s = StorageManager.forPlayer(player);
    const count = s.getNumber("dj_count", 0) + 1;
    s.set("dj_count", count);
    const day = world.getDay();

    // Generate entry text based on challenges completed
    let entryText = "";
    if (challenges.maze) {
      const pool = DreamingRealmSystem.JOURNAL_ENTRIES_MAZE;
      entryText += pool[Math.floor(Math.random() * pool.length)] + " ";
    }
    if (challenges.guardians) {
      const pool = DreamingRealmSystem.JOURNAL_ENTRIES_GUARDIAN;
      entryText += pool[Math.floor(Math.random() * pool.length)] + " ";
    }
    if (challenges.trial) {
      const pool = DreamingRealmSystem.JOURNAL_ENTRIES_TRIAL;
      entryText += pool[Math.floor(Math.random() * pool.length)] + " ";
    }
    if (!entryText) {
      const pool = DreamingRealmSystem.JOURNAL_ENTRIES_FAILED;
      entryText = pool[Math.floor(Math.random() * pool.length)];
    }

    // Store entry
    s.set(`dj_entry_${count}`, JSON.stringify({ day, text: entryText.trim(), num: count }));

    player.sendMessage(`§d§l✦ Dream Journal — Entry #${count}`);
    player.sendMessage(`§7§o${entryText.trim()}`);

    // Milestone checks
    if (count === 10) {
      player.sendMessage("§d§l✦ Journal Milestone: 10 Dreams! §r§7Your dream rate grows stronger.");
      this.eventBridge?.emit("achievement", player, "journal_10");
      // Grant DR bonus
      const dr = s.getNumber("dream_rate", 0);
      s.set("dream_rate", dr + 1);
    }
    if (count === 30) {
      player.sendMessage("§d§l✦ Journal Milestone: 30 Dreams! §r§7The realm opens its secrets to you.");
      this.eventBridge?.emit("achievement", player, "journal_30");
      const dr = s.getNumber("dream_rate", 0);
      s.set("dream_rate", dr + 2);
    }
  }

  /** Show journal to player */
  showJournal(player) {
    const s = StorageManager.forPlayer(player);
    const count = s.getNumber("dj_count", 0);

    if (count === 0) {
      player.sendMessage("§d§l✦ Dream Journal §r§7— No entries yet. Visit the Dreaming Realm!");
      return;
    }

    player.sendMessage(`§d§l✦ Dream Journal §r§7— ${count} entries`);
    // Show last 5 entries
    const start = Math.max(1, count - 4);
    for (let i = start; i <= count; i++) {
      try {
        const entry = JSON.parse(s.get(`dj_entry_${i}`));
        player.sendMessage(`§7Day ${entry.day}: §f§o${entry.text}`);
      } catch {}
    }

    // Milestone progress
    if (count < 10) player.sendMessage(`\n§7Next milestone: §e${10 - count} dreams to go`);
    else if (count < 30) player.sendMessage(`\n§7Next milestone: §e${30 - count} dreams to go`);
    else player.sendMessage("\n§d§l✦ §r§7All milestones complete!");
  }

  // =====================================================
  // DREAM CHALLENGES (Trial, Maze, Guardians)
  // =====================================================

  /**
   * Start a random dream challenge when entering the realm.
   */
  startChallenge(player) {
    const challenges = ["trial", "maze", "guardians"];
    const chosen = challenges[Math.floor(Math.random() * challenges.length)];
    const s = StorageManager.forPlayer(player);
    s.set("dr_challenge", chosen);
    s.set("dr_challenge_done", false);

    switch (chosen) {
      case "trial": this.startTrialChallenge(player); break;
      case "maze": this.startMazeChallenge(player); break;
      case "guardians": this.startGuardianChallenge(player); break;
    }
  }

  /** Trial: Collect 5 Dream Fragments from platforms */
  startTrialChallenge(player) {
    const s = StorageManager.forPlayer(player);
    s.set("dr_frags", 0);
    player.sendMessage("\n§d§l✦ Dream Trial ✦§r");
    player.sendMessage("§7Collect §f5 Dream Fragments §7from the floating platforms!");
    player.sendMessage("§7Be careful — falling resets your progress.\n");
    player.playSound("note.chime", { volume: 0.8, pitch: 1.0 });

    // Simulate fragment collection via timed prompts
    this.tickTrialFragments(player, 0);
  }

  tickTrialFragments(player, collected) {
    if (collected >= 5) {
      this.completeChallenge(player, "trial");
      return;
    }

    const { ActionFormData } = require("@minecraft/server-ui");
    system.runTimeout(async () => {
      const s = StorageManager.forPlayer(player);
      if (s.get("dr_challenge_done")) return;

      const form = new ActionFormData()
        .title(`§dDream Fragment (${collected + 1}/5)`)
        .body("§7A glowing fragment floats before you!")
        .button("§d✦ Collect Fragment ✦");

      try {
        const res = await form.show(player);
        if (res.canceled) return;

        // 80% success, 20% fall
        if (Math.random() < 0.8) {
          const newCount = collected + 1;
          s.set("dr_frags", newCount);
          player.sendMessage(`§d✦ Dream Fragment collected! §7(${newCount}/5)`);
          player.playSound("random.orb", { volume: 0.5, pitch: 1.2 + newCount * 0.1 });
          this.tickTrialFragments(player, newCount);
        } else {
          player.sendMessage("§c§l✗ You slipped! §r§7Resetting fragments...");
          player.playSound("entity.player.hurt_on_damage", { volume: 0.5, pitch: 1.0 });
          s.set("dr_frags", 0);
          this.tickTrialFragments(player, 0);
        }
      } catch {}
    }, 40); // 2-second intervals
  }

  /** Maze: 4-step color sequence memory challenge */
  async startMazeChallenge(player) {
    const s = StorageManager.forPlayer(player);
    const colors = ["§cRed", "§9Blue", "§aGreen", "§eYellow"];
    const colorKeys = ["red", "blue", "green", "yellow"];

    // Generate random 4-step sequence
    const sequence = [];
    for (let i = 0; i < 4; i++) {
      sequence.push(Math.floor(Math.random() * 4));
    }

    const seqDisplay = sequence.map(s => colors[s]).join(" → ");
    player.sendMessage("\n§5§l✦ Dream Maze ✦§r");
    player.sendMessage(`§7Remember the sequence: ${seqDisplay}`);
    player.sendMessage("§7You have 5 seconds to memorize!\n");
    player.playSound("note.chime", { volume: 0.8, pitch: 0.8 });

    // Show for 5 seconds, then prompt
    await new Promise(resolve => system.runTimeout(resolve, 100));

    const { ActionFormData } = await import("@minecraft/server-ui");

    // Player inputs sequence
    for (let step = 0; step < 4; step++) {
      const form = new ActionFormData()
        .title(`§5Step ${step + 1}/4`)
        .body("§7Choose the correct color:")
        .button("§cRed")
        .button("§9Blue")
        .button("§aGreen")
        .button("§eYellow");

      const res = await form.show(player);
      if (res.canceled) return;

      if (res.selection === sequence[step]) {
        player.sendMessage(`§a✓ Correct! (${step + 1}/4)`);
        player.playSound("note.pling", { volume: 0.3, pitch: 1.0 + step * 0.2 });
      } else {
        player.sendMessage("§c✗ Wrong color! §7Sequence reset...");
        player.playSound("note.bass", { volume: 0.5, pitch: 0.3 });
        // Restart
        await this.startMazeChallenge(player);
        return;
      }
    }

    this.completeChallenge(player, "maze");
  }

  /** Guardians: 3-wave combat challenge */
  startGuardianChallenge(player) {
    const s = StorageManager.forPlayer(player);
    s.set("dr_wave", 1);
    s.set("dr_kills", 0);

    player.sendMessage("\n§4§l✦ Dream Guardians ✦§r");
    player.sendMessage("§7Survive 3 waves of dream entities!");
    player.sendMessage("§cWave 1: §73 Dream Wisps\n");
    player.playSound("mob.warden.sonic_boom", { volume: 0.3, pitch: 2.0 });

    this.spawnWave(player, 1);
  }

  spawnWave(player, wave) {
    const dim = player.dimension;
    const loc = player.location;

    try {
      switch (wave) {
        case 1: // 3 Dream Wisps (phantoms)
          for (let i = 0; i < 3; i++) {
            const mob = dim.spawnEntity("minecraft:phantom", {
              x: loc.x + (Math.random() - 0.5) * 6,
              y: loc.y + 3,
              z: loc.z + (Math.random() - 0.5) * 6,
            });
            mob.addTag("ec.dream_mob");
            mob.nameTag = "§d§lDream Wisp";
          }
          break;
        case 2: // 4 Wisps + 1 Dream Shade (enderman)
          for (let i = 0; i < 4; i++) {
            const mob = dim.spawnEntity("minecraft:phantom", {
              x: loc.x + (Math.random() - 0.5) * 8,
              y: loc.y + 3,
              z: loc.z + (Math.random() - 0.5) * 8,
            });
            mob.addTag("ec.dream_mob");
            mob.nameTag = "§d§lDream Wisp";
          }
          const shade = dim.spawnEntity("minecraft:enderman", {
            x: loc.x + 3, y: loc.y, z: loc.z + 3,
          });
          shade.addTag("ec.dream_mob");
          shade.nameTag = "§5§lDream Shade";
          break;
        case 3: // Dream Warden (wither_skeleton boss)
          const warden = dim.spawnEntity("minecraft:wither_skeleton", {
            x: loc.x, y: loc.y, z: loc.z + 5,
          });
          warden.addTag("ec.dream_mob");
          warden.nameTag = "§4§lDream Warden";
          try {
            warden.addEffect("resistance", 999999, { amplifier: 1, showParticles: false });
            warden.addEffect("strength", 999999, { amplifier: 2, showParticles: false });
          } catch {}
          break;
      }
    } catch {}
  }

  /** Check if dream guardian wave is cleared (called from tick) */
  tickGuardianChallenge(player) {
    const s = StorageManager.forPlayer(player);
    if (s.get("dr_challenge") !== "guardians" || s.get("dr_challenge_done")) return;

    const wave = s.getNumber("dr_wave", 1);

    // Count remaining dream mobs
    try {
      const dreamMobs = player.dimension.getEntities({
        location: player.location, maxDistance: 30, tags: ["ec.dream_mob"]
      });

      if (dreamMobs.length === 0) {
        if (wave >= 3) {
          this.completeChallenge(player, "guardians");
        } else {
          const nextWave = wave + 1;
          s.set("dr_wave", nextWave);
          player.sendMessage(`\n§cWave ${nextWave}!`);
          player.playSound("mob.warden.heartbeat", { volume: 0.5, pitch: 1.0 });
          system.runTimeout(() => this.spawnWave(player, nextWave), 60);
        }
      }
    } catch {}
  }

  /** Complete a dream challenge */
  completeChallenge(player, type) {
    const s = StorageManager.forPlayer(player);
    s.set("dr_challenge_done", true);

    const names = { trial: "Dream Trial", maze: "Dream Maze", guardians: "Dream Guardians" };

    player.sendMessage(`\n§d§l✦ ${names[type]} Complete! ✦§r`);
    player.sendMessage("§7Dream essence collected. Waking...");
    player.playSound("random.levelup", { volume: 1.0, pitch: 1.0 });

    try { player.dimension.spawnParticle("minecraft:totem_particle", player.location); } catch {}

    // Reward: DR + coins based on challenge type
    const drGain = type === "guardians" ? 3.0 : type === "maze" ? 2.0 : 1.5;
    const currentDR = s.getNumber("dream_rate", 0);
    s.set("dream_rate", currentDR + drGain);

    const coins = type === "guardians" ? 8 : type === "maze" ? 5 : 3;
    this.eventBridge.emit("grant_coins", { player, amount: coins, reason: `Dream: ${names[type]}` });

    // Track completions
    const completions = s.getNumber("dr_completions", 0) + 1;
    s.set("dr_completions", completions);

    // Journal entry
    this.eventBridge.emit("dream_journal_entry", { player, text: `Completed ${names[type]}` });
  }
}
