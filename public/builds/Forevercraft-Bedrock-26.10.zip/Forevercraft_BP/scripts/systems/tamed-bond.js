/**
 * Tamed Bond System — Pet death mementos + Moonbloom Revival Ceremony.
 * Replaces Java tamed_bond/ folder (16 mcfunction files + advancement + predicate + loot table).
 *
 * Flow:
 * 1. Tamed mobs are tracked via ec.tb_registered tag
 * 2. On death → drops a Pet Memento item (type-specific) to the owner
 * 3. Player uses memento under full moon + night + open sky + torchflower in offhand → revival
 * 4. Revived pet spawns tamed to the player with original name
 *
 * Bedrock adaptations:
 * - No totem-in-offhand trick — uses entityDie event directly
 * - No NBT storage — uses dynamic properties + StorageManager
 * - No advancement triggers — uses itemUse event for memento detection
 * - Moon phase from (globalThis._fc_daylight?.getMoonPhase?.() ?? 0) (0 = full moon in Bedrock)
 * - Open sky check via block raycast
 */
import { world, system, ItemStack, EntityComponentTypes } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const TAMEABLE_TYPES = new Set([
  "minecraft:wolf", "minecraft:cat", "minecraft:parrot",
  "minecraft:horse", "minecraft:donkey", "minecraft:mule",
  "minecraft:llama", "minecraft:trader_llama", "minecraft:camel",
  "minecraft:fox", "minecraft:ocelot",
]);

// Memento item mapping: entity type → item type ID + display name
const MEMENTO_ITEMS = {
  "minecraft:wolf":           { item: "minecraft:bone",          name: "Wolf" },
  "minecraft:cat":            { item: "minecraft:cod",           name: "Cat" },
  "minecraft:horse":          { item: "minecraft:golden_carrot", name: "Horse" },
  "minecraft:parrot":         { item: "minecraft:wheat_seeds",   name: "Parrot" },
  "minecraft:fox":            { item: "minecraft:sweet_berries", name: "Fox" },
  "minecraft:donkey":         { item: "minecraft:lead",          name: "Donkey" },
  "minecraft:mule":           { item: "minecraft:lead",          name: "Mule" },
  "minecraft:llama":          { item: "minecraft:lead",          name: "Llama" },
  "minecraft:trader_llama":   { item: "minecraft:lead",          name: "Llama" },
  "minecraft:camel":          { item: "minecraft:lead",          name: "Camel" },
  "minecraft:ocelot":         { item: "minecraft:lead",          name: "Ocelot" },
};

export class TamedBondSystem {
  constructor(eventBridge, moonSystem) {
    this.eventBridge = eventBridge;
    this.moonSystem = moonSystem;

    // Track pending mementos for players (playerName → memento data)
    this.pendingMementos = new Map();

    // Listen for tamed entity deaths
    world.afterEvents.entityDie.subscribe((event) => {
      this.onEntityDie(event);
    });

    // Listen for item use (memento activation)
    world.afterEvents.itemUse.subscribe((event) => {
      this.onItemUse(event);
    });
  }

  /**
   * Periodic tick — registers new tamed entities with tracking tag.
   * Called every 100 ticks (5 seconds).
   */
  tick(players) {
    for (const player of players) {
      try {
        // Find nearby unregistered tamed entities
        const nearby = player.dimension.getEntities({
          location: player.location,
          maxDistance: 64,
        });

        for (const entity of nearby) {
          if (!TAMEABLE_TYPES.has(entity.typeId)) continue;
          if (entity.hasTag("ec.tb_registered")) continue;

          // Check if tamed
          const isTamed = entity.getComponent("minecraft:is_tamed") ||
                          entity.hasTag("ec.tame_protected") ||
                          entity.hasTag("ec.fox_tamed") ||
                          entity.hasTag("ec.ocelot_tamed");

          if (isTamed) {
            entity.addTag("ec.tb_registered");
          }
        }
      } catch {}
    }
  }

  /**
   * Handle tamed entity death — create and deliver memento.
   */
  onEntityDie(event) {
    const dead = event.deadEntity;
    if (!dead) return;
    if (!TAMEABLE_TYPES.has(dead.typeId)) return;
    if (!dead.hasTag("ec.tb_registered")) return;

    const mementoInfo = MEMENTO_ITEMS[dead.typeId] || { item: "minecraft:lead", name: "Companion" };

    // Get pet's custom name
    const nameTag = dead.nameTag || mementoInfo.name;

    // Find the owner — check all online players
    let owner = null;
    try {
      // Try to find owner via tamed component or owner tags
      for (const player of world.getAllPlayers()) {
        // Check if this pet was tagged with owner ID
        if (dead.hasTag(`ec.bd_owner_${player.id}`)) {
          owner = player;
          break;
        }
        // Check proximity as fallback (within 128 blocks)
        if (!owner) {
          try {
            const dist = this.distance(player.location, dead.location);
            if (dist < 128 && player.dimension.id === dead.dimension.id) {
              owner = player; // Best guess — nearest player
            }
          } catch {}
        }
      }
    } catch {}

    // Store memento data
    const mementoData = {
      petType: dead.typeId,
      petName: nameTag,
      itemType: mementoInfo.item,
      displayName: mementoInfo.name,
    };

    // Death effects at location
    try {
      const loc = dead.location;
      dead.dimension.playSound("mob.wolf.whine", loc, { volume: 1.0, pitch: 0.7 });
      dead.dimension.spawnParticle("minecraft:soul_particle", { x: loc.x, y: loc.y + 0.5, z: loc.z });
    } catch {}

    if (owner) {
      this.deliverMemento(owner, mementoData);
    } else {
      // Drop memento at death location for anyone to pick up
      try {
        this.spawnMementoItem(dead.dimension, dead.location, mementoData);
      } catch {}
    }
  }

  /**
   * Deliver memento directly to the owner's inventory.
   */
  deliverMemento(player, mementoData) {
    try {
      this.spawnMementoItem(player.dimension, player.location, mementoData);

      // Store memento data on the player for revival
      const s = StorageManager.forPlayer(player);
      const mementos = JSON.parse(s.get("tb_mementos") || "[]");
      mementos.push(mementoData);
      s.set("tb_mementos", JSON.stringify(mementos));

      // Notification
      player.sendMessage("");
      player.sendMessage(`  §cYour §r§c${mementoData.petName}§c has fallen in battle.`);
      player.sendMessage("  §7Find a Torchflower to perform the Moonbloom Ceremony.");
      player.sendMessage("");

      player.onScreenDisplay.setTitle(" ", {
        subtitle: `§c§oYour ${mementoData.petName} has fallen in battle.`,
        fadeInDuration: 10,
        stayDuration: 60,
        fadeOutDuration: 20,
      });
    } catch (e) {
      console.warn(`[TamedBond] Failed to deliver memento: ${e}`);
    }
  }

  /**
   * Spawn a memento item entity at a location.
   */
  spawnMementoItem(dimension, location, mementoData) {
    try {
      // Give via command with lore identifying it as a memento
      const petTypeShort = mementoData.petType.replace("minecraft:", "");
      const loreTag = `§0§r§0memento:${petTypeShort}:${mementoData.petName}`;

      dimension.runCommandAsync(
        `summon item ${location.x} ${location.y + 0.5} ${location.z} minecraft:${mementoData.itemType.replace("minecraft:", "")}`
      );

      // Alternative: give directly to nearby player
      // We use a simpler approach — store data in player storage and give a named item
      const players = dimension.getEntities({
        type: "minecraft:player",
        location: location,
        maxDistance: 3,
      });

      for (const p of players) {
        try {
          const itemId = mementoData.itemType.replace("minecraft:", "");
          p.runCommandAsync(
            `give @s ${itemId} 1`
          );
          // The memento identification is handled via player storage tracking
        } catch {}
        break; // Only give to first nearby player
      }
    } catch (e) {
      console.warn(`[TamedBond] Failed to spawn memento item: ${e}`);
    }
  }

  /**
   * Handle item use — check if player is using a memento item.
   * Memento items are identified by the stored mementos in player storage.
   */
  onItemUse(event) {
    const player = event.source;
    if (!player || player.typeId !== "minecraft:player") return;

    const item = event.itemStack;
    if (!item) return;

    // Check if this item type matches any memento type
    const mementoEntry = Object.values(MEMENTO_ITEMS).find(m => m.item === item.typeId);
    if (!mementoEntry) return;

    // Check if player has stored mementos
    const s = StorageManager.forPlayer(player);
    const mementos = JSON.parse(s.get("tb_mementos") || "[]");
    if (mementos.length === 0) return;

    // Find matching memento by item type
    const mementoIdx = mementos.findIndex(m => m.itemType === item.typeId);
    if (mementoIdx === -1) return;

    const memento = mementos[mementoIdx];

    // Check revival conditions
    if (!this.checkRevivalConditions(player)) return;

    // All conditions met — perform revival!
    mementos.splice(mementoIdx, 1);
    s.set("tb_mementos", JSON.stringify(mementos));

    this.performRevival(player, memento);
  }

  /**
   * Check all revival conditions. Returns true if all pass.
   */
  checkRevivalConditions(player) {
    // Condition 1: Full Moon (moon phase 0 in Bedrock = full moon)
    const moonPhase = (globalThis._fc_daylight?.getMoonPhase?.() ?? 0);
    if (moonPhase !== 0) {
      player.sendMessage("  §cThe moon isn't full... §7Wait for a full moon to perform the ceremony.");
      return false;
    }

    // Condition 2: Nighttime (13000-23000 in day cycle)
    const timeOfDay = world.getTimeOfDay();
    if (timeOfDay < 13000 || timeOfDay > 23000) {
      player.sendMessage("  §cIt must be nighttime... §7The ceremony requires darkness.");
      return false;
    }

    // Condition 3: Open sky (check block above player)
    try {
      const loc = player.location;
      const dim = player.dimension;
      let canSeeSky = true;
      for (let y = Math.ceil(loc.y) + 1; y <= Math.min(loc.y + 64, 319); y++) {
        try {
          const block = dim.getBlock({ x: Math.floor(loc.x), y: y, z: Math.floor(loc.z) });
          if (block && !block.isAir) {
            canSeeSky = false;
            break;
          }
        } catch { break; }
      }
      if (!canSeeSky) {
        player.sendMessage("  §cYou need open sky... §7The moonlight must reach you.");
        return false;
      }
    } catch {}

    // Condition 4: Torchflower in offhand
    try {
      const equip = player.getComponent(EntityComponentTypes.Equippable);
      if (equip) {
        const offhand = equip.getEquipment("Offhand");
        if (!offhand || offhand.typeId !== "minecraft:torchflower") {
          player.sendMessage("  §cYou need a Torchflower in your offhand! §7Find one to complete the ceremony.");
          return false;
        }
      } else {
        player.sendMessage("  §cYou need a Torchflower in your offhand!");
        return false;
      }
    } catch {
      player.sendMessage("  §cYou need a Torchflower in your offhand!");
      return false;
    }

    return true;
  }

  /**
   * Perform the Moonbloom Revival Ceremony.
   */
  performRevival(player, memento) {
    const dim = player.dimension;
    const loc = player.location;

    // Consume the torchflower from offhand
    try {
      const equip = player.getComponent(EntityComponentTypes.Equippable);
      if (equip) {
        equip.setEquipment("Offhand", undefined);
      }
    } catch {}

    // Consume the memento item from mainhand
    try {
      const equip = player.getComponent(EntityComponentTypes.Equippable);
      if (equip) {
        const mainhand = equip.getEquipment("Mainhand");
        if (mainhand && mainhand.typeId === memento.itemType) {
          if (mainhand.amount > 1) {
            mainhand.amount -= 1;
            equip.setEquipment("Mainhand", mainhand);
          } else {
            equip.setEquipment("Mainhand", undefined);
          }
        }
      }
    } catch {}

    // Spawn the revived entity
    const petType = memento.petType.replace("minecraft:", "");
    try {
      const spawnLoc = `${loc.x} ${loc.y} ${loc.z}`;

      // Summon entity
      dim.runCommandAsync(`summon ${petType} ${spawnLoc} ec_tb_revived`);

      // Tame and name the revived entity after a short delay
      system.runTimeout(() => {
        try {
          const revived = dim.getEntities({
            type: memento.petType,
            tags: ["ec_tb_revived"],
            location: loc,
            maxDistance: 5,
          });

          for (const entity of revived) {
            entity.removeTag("ec_tb_revived");
            entity.addTag("ec.tb_registered");
            entity.addTag("ec.tame_protected");

            // Set custom name if the pet had one
            if (memento.petName && memento.petName !== MEMENTO_ITEMS[memento.petType]?.name) {
              entity.nameTag = memento.petName;
            }

            // Tame to player via event trigger
            try { entity.addTag(`ec.bd_owner_${player.id}`); } catch {}
            try {
              // Trigger taming via command for entity types that support it
              dim.runCommandAsync(`event entity @e[type=${petType},tag=ec.tb_registered,c=1,r=5] minecraft:on_tame`);
            } catch {}

            // Heart particles
            try {
              dim.spawnParticle("minecraft:heart_particle", {
                x: entity.location.x, y: entity.location.y + 1, z: entity.location.z
              });
            } catch {}

            break; // Only process one
          }
        } catch (e) {
          console.warn(`[TamedBond] Failed to finalize revival: ${e}`);
        }
      }, 5);
    } catch (e) {
      console.warn(`[TamedBond] Failed to spawn revived pet: ${e}`);
    }

    // Dramatic effects
    try {
      dim.playSound("random.totem", loc, { volume: 1.0, pitch: 0.8 });
      dim.playSound("block.amethyst_block.hit", loc, { volume: 0.8, pitch: 0.5 });
      dim.spawnParticle("minecraft:totem_particle", { x: loc.x, y: loc.y + 1, z: loc.z });
      dim.spawnParticle("minecraft:soul_particle", { x: loc.x, y: loc.y + 0.5, z: loc.z });
    } catch {}

    // Announcements
    player.sendMessage("");
    player.sendMessage("  §d§lMOONBLOOM CEREMONY");
    player.sendMessage("  §e§oYour friend has returned from beyond!");
    player.sendMessage("");

    player.onScreenDisplay.setTitle(" ", {
      subtitle: "§d§oA soul returns...",
      fadeInDuration: 10,
      stayDuration: 60,
      fadeOutDuration: 20,
    });

    player.playSound("random.levelup", { volume: 0.6, pitch: 1.2 });

    this.eventBridge.emit("pet_revived", { player, petType: memento.petType, petName: memento.petName });
  }

  /**
   * Show bond status — /trigger ec.bond equivalent.
   */
  showStatus(player) {
    const s = StorageManager.forPlayer(player);
    const mementos = JSON.parse(s.get("tb_mementos") || "[]");

    player.sendMessage("");
    player.sendMessage("  §d§lANIMAL BONDS");
    player.sendMessage("");

    // Show mount bond info if any
    const mountBond = s.getNumber("mt_bond", 0);
    if (mountBond > 0) {
      const mountTier = s.getNumber("mt_tier", 0);
      player.sendMessage(`  §6Mount Bond: §f§l${mountBond} §7XP`);
      const tierNames = ["Unfamiliar", "Trusted", "Bonded", "Soulbound", "Eternal"];
      const tierColors = ["§7", "§a", "§b", "§d", "§6"];
      const tierBonuses = ["", " (+10% speed)", " (+20% speed)", " (+30% speed, recall)", " (+40% speed, derby eligible)"];
      if (mountTier >= 0 && mountTier < 5) {
        player.sendMessage(`    §7Tier: ${tierColors[mountTier]}${tierNames[mountTier]}${tierBonuses[mountTier]}`);
      }
    }

    // Show nearby registered tamed animals
    player.sendMessage("  §bNearby Companions:");
    let count = 0;
    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 64,
        tags: ["ec.tb_registered"],
      });

      for (const entity of nearby) {
        if (!TAMEABLE_TYPES.has(entity.typeId)) continue;
        const name = entity.nameTag || entity.typeId.replace("minecraft:", "");
        player.sendMessage(`    §7- §f${name} §a(healthy)`);
        count++;
      }
    } catch {}

    if (count === 0) {
      player.sendMessage("    §7§oNo named tamed animals nearby.");
    }

    // Show pending mementos
    if (mementos.length > 0) {
      player.sendMessage("");
      player.sendMessage("  §c§lFallen Companions:");
      for (const m of mementos) {
        player.sendMessage(`    §7- §c${m.petName} §7(${m.displayName}) — use memento to revive`);
      }
    }

    player.sendMessage("");
  }

  distance(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }
}
