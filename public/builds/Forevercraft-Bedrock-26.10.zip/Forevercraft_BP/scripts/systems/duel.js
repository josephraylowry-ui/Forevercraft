/**
 * Duel System — 1v1 PvP arena combat.
 * Replaces Java duel/ folder (39 files).
 *
 * Features: challenge/accept, open world & arena modes, health monitoring,
 * disconnect handling, win/loss tracking, daily limits, spectating,
 * team save/restore, enhanced totem save, proper gladiator arena.
 */
import { world, system, GameMode } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const MAX_DUELS_PER_DAY = 3;
const INVITE_TIMEOUT = 60; // seconds
const ARENA_HEIGHT_OFFSET = 172;
const ARENA_HALF_SIZE = 15; // 31x31 arena
const BOUNDARY_RANGE = 50; // blocks for open-world mode
const BOUNDARY_WARNINGS = 3;

// Duel modes
const MODE = { OPEN_WORLD: 1, ARENA: 2 };

export class DuelSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.activeDuel = null; // {challenger, target, mode, startLoc, startTick, warnings, spectators}
    this.pendingInvite = null; // {challenger, target, mode, expireTick}

    // Death prevention (totem save)
    world.afterEvents.entityHurt.subscribe((event) => {
      if (!this.activeDuel) return;
      const entity = event.hurtEntity;
      if (entity?.typeId !== "minecraft:player") return;
      if (!this.isInDuel(entity)) return;

      try {
        const hp = entity.getComponent("minecraft:health");
        if (hp && hp.currentValue <= 4) {
          // Totem save: set to safe HP, apply Resistance V, spawn particles
          hp.setCurrentValue(4);
          entity.runCommandAsync("effect @s resistance 3 4 true");
          entity.runCommandAsync("particle minecraft:totem_particle ~ ~1 ~ 0.5 0.5 0.5 0.1 30");
          entity.runCommandAsync("playsound random.totem @a ~ ~ ~ 1 1");
          this.endDuel(entity, "health");
        }
      } catch {}
    });
  }

  isInDuel(player) {
    if (!this.activeDuel) return false;
    return this.activeDuel.challenger === player.name || this.activeDuel.target === player.name;
  }

  // ─── TEAM SAVE/RESTORE ────────────────────────────────────

  /** Save player cosmetic state before duel */
  saveTeamState(player) {
    const s = StorageManager.forPlayer(player);
    // Save gamemode
    try {
      const gm = player.getGameMode();
      s.set("duel_gamemode", gm === GameMode.creative ? "creative" : gm === GameMode.adventure ? "adventure" : "survival");
    } catch {
      s.set("duel_gamemode", "survival");
    }
    // Save active effects (we'll clear combat effects after duel)
    s.set("duel_health", Math.floor(player.getComponent("minecraft:health")?.currentValue || 20));
    s.set("duel_food", 20); // Can't read food in Bedrock Script API, assume full
  }

  /** Restore player state after duel */
  restoreTeamState(player) {
    const s = StorageManager.forPlayer(player);
    // Restore health
    try {
      const savedHP = s.getNumber("duel_health", 20);
      const hp = player.getComponent("minecraft:health");
      if (hp) hp.setCurrentValue(Math.max(savedHP, 10));
    } catch {}
    // Clear all combat effects
    try {
      player.runCommandAsync("effect @s clear");
    } catch {}
    // Restore gamemode
    try {
      const gm = s.getString("duel_gamemode", "survival");
      if (gm === "creative") player.runCommandAsync("gamemode creative @s");
      else if (gm === "adventure") player.runCommandAsync("gamemode adventure @s");
      else player.runCommandAsync("gamemode survival @s");
    } catch {}
  }

  // ─── CHALLENGE SYSTEM ──────────────────────────────────────

  openChallengeMenu(player) {
    if (this.activeDuel) {
      player.sendMessage("§c§l✗ §r§7A duel is already in progress.");
      return;
    }

    const s = StorageManager.forPlayer(player);
    const today = world.getDay();
    if (s.getNumber("duel_last_day", 0) !== today) {
      s.set("duel_today", 0);
      s.set("duel_last_day", today);
    }
    if (s.getNumber("duel_today", 0) >= MAX_DUELS_PER_DAY) {
      player.sendMessage(`§c§l✗ §r§7Daily duel limit reached (${MAX_DUELS_PER_DAY}/day).`);
      return;
    }

    // Block if in dungeon/dreaming realm/menu
    if (player.hasTag("dg.player") || player.hasTag("ec.InDreamRealm") || player.hasTag("ec.InMenu")) {
      player.sendMessage("§c§l✗ §r§7Cannot duel right now.");
      return;
    }

    const targets = world.getAllPlayers().filter(p =>
      p.name !== player.name && !p.hasTag("dg.player") && !p.hasTag("ec.InDreamRealm")
    );

    if (targets.length === 0) {
      player.sendMessage("§c§l✗ §r§7No available opponents.");
      return;
    }

    const form = new ActionFormData()
      .title("§c⚔ Challenge to Duel")
      .body("§7Choose an opponent:");

    for (const t of targets) form.button(`§f${t.name}`);
    form.button("§7Cancel");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= targets.length) return;
      this.selectMode(player, targets[response.selection].name);
    });
  }

  selectMode(player, targetName) {
    const form = new ActionFormData()
      .title("§cDuel Mode")
      .body(`§7Challenge §f${targetName}§7 to a duel!\n\n§7Choose the arena:`)
      .button("§eOpen World\n§7Fight where you stand")
      .button("§bArena\n§7Gladiator sky arena")
      .button("§7Cancel");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 2) return;
      const mode = response.selection === 0 ? MODE.OPEN_WORLD : MODE.ARENA;
      this.sendChallenge(player, targetName, mode);
    });
  }

  sendChallenge(player, targetName, mode) {
    const target = world.getAllPlayers().find(p => p.name === targetName);
    if (!target) { player.sendMessage("§c§l✗ §r§7Player went offline."); return; }

    this.pendingInvite = {
      challenger: player.name,
      target: targetName,
      mode,
      expireTick: system.currentTick + INVITE_TIMEOUT * 20,
    };

    const modeName = mode === MODE.ARENA ? "Arena" : "Open World";
    target.sendMessage(`§c§l⚔ ${player.name} §r§7challenges you to a §e${modeName} §7duel!`);
    target.sendMessage("§7Open the Duel menu to accept or decline.");
    player.sendMessage(`§a§l✓ §r§7Challenge sent to §f${targetName}§7!`);
  }

  /** Accept a pending duel invite */
  acceptChallenge(player) {
    if (!this.pendingInvite || this.pendingInvite.target !== player.name) {
      player.sendMessage("§c§l✗ §r§7No pending duel challenge.");
      return;
    }
    if (system.currentTick > this.pendingInvite.expireTick) {
      player.sendMessage("§c§l✗ §r§7Challenge expired.");
      this.pendingInvite = null;
      return;
    }

    const challenger = world.getAllPlayers().find(p => p.name === this.pendingInvite.challenger);
    if (!challenger) { player.sendMessage("§c§l✗ §r§7Challenger went offline."); this.pendingInvite = null; return; }

    this.startDuel(challenger, player, this.pendingInvite.mode);
    this.pendingInvite = null;
  }

  // ─── DUEL EXECUTION ────────────────────────────────────────

  startDuel(challenger, target, mode) {
    const startLoc = { x: challenger.location.x, y: challenger.location.y, z: challenger.location.z };

    // Save team state for both players
    this.saveTeamState(challenger);
    this.saveTeamState(target);

    // Store return positions
    const cs = StorageManager.forPlayer(challenger);
    const ts = StorageManager.forPlayer(target);
    cs.set("duel_return", JSON.stringify(challenger.location));
    ts.set("duel_return", JSON.stringify(target.location));

    this.activeDuel = {
      challenger: challenger.name,
      target: target.name,
      mode,
      startLoc,
      startTick: system.currentTick,
      warnings: { [challenger.name]: 0, [target.name]: 0 },
      spectators: [],
    };

    if (mode === MODE.ARENA) {
      this.buildGladiatorArena(challenger, startLoc);
      const ax = Math.floor(startLoc.x);
      const ay = Math.floor(startLoc.y) + ARENA_HEIGHT_OFFSET;
      const az = Math.floor(startLoc.z);
      challenger.teleport({ x: ax - 8, y: ay + 1, z: az });
      target.teleport({ x: ax + 8, y: ay + 1, z: az });
    }

    // Pre-duel effects: Resistance V + Blindness for countdown
    try {
      challenger.runCommandAsync("effect @s resistance 5 4 true");
      target.runCommandAsync("effect @s resistance 5 4 true");
      challenger.runCommandAsync("effect @s blindness 3 0 true");
      target.runCommandAsync("effect @s blindness 3 0 true");
    } catch {}

    // Tag both players as in active duel (cross-system: tomb, reputation)
    challenger.addTag("ec.duel_active_tag");
    target.addTag("ec.duel_active_tag");

    // Increment daily count
    cs.set("duel_today", cs.getNumber("duel_today", 0) + 1);
    ts.set("duel_today", ts.getNumber("duel_today", 0) + 1);

    // Announce
    for (const p of world.getAllPlayers()) {
      p.sendMessage(`§c§l⚔ DUEL! §r§f${challenger.name} §7vs §f${target.name}§7!`);
    }

    // Countdown
    system.runTimeout(() => {
      if (this.activeDuel) {
        for (const p of [challenger, target]) {
          try { p.sendMessage("§c§l3..."); p.playSound("note.hat"); } catch {}
        }
      }
    }, 40);
    system.runTimeout(() => {
      if (this.activeDuel) {
        for (const p of [challenger, target]) {
          try { p.sendMessage("§e§l2..."); p.playSound("note.hat"); } catch {}
        }
      }
    }, 60);
    system.runTimeout(() => {
      if (this.activeDuel) {
        for (const p of [challenger, target]) {
          try {
            p.sendMessage("§a§lFIGHT!");
            p.playSound("mob.wither.spawn", { volume: 0.3, pitch: 2.0 });
          } catch {}
        }
      }
    }, 80);
  }

  // ─── GLADIATOR ARENA CONSTRUCTION ───────────────────────────

  buildGladiatorArena(referencePlayer, startLoc) {
    const ax = Math.floor(startLoc.x);
    const ay = Math.floor(startLoc.y) + ARENA_HEIGHT_OFFSET;
    const az = Math.floor(startLoc.z);
    const h = ARENA_HALF_SIZE;
    const dim = referencePlayer.dimension;

    try {
      // Clear area
      dim.runCommandAsync(`fill ${ax-h} ${ay-1} ${az-h} ${ax+h} ${ay+5} ${az+h} air`);

      // Floor: deepslate brick arena floor
      dim.runCommandAsync(`fill ${ax-h} ${ay-1} ${az-h} ${ax+h} ${ay-1} ${az+h} polished_deepslate`);

      // Sand pit center (11x11)
      dim.runCommandAsync(`fill ${ax-5} ${ay-1} ${az-5} ${ax+5} ${ay-1} ${az+5} sand`);

      // Walls: deepslate brick walls (2 high)
      dim.runCommandAsync(`fill ${ax-h} ${ay} ${az-h} ${ax+h} ${ay+1} ${az-h} deepslate_bricks`);
      dim.runCommandAsync(`fill ${ax-h} ${ay} ${az+h} ${ax+h} ${ay+1} ${az+h} deepslate_bricks`);
      dim.runCommandAsync(`fill ${ax-h} ${ay} ${az-h} ${ax-h} ${ay+1} ${az+h} deepslate_bricks`);
      dim.runCommandAsync(`fill ${ax+h} ${ay} ${az-h} ${ax+h} ${ay+1} ${az+h} deepslate_bricks`);

      // Interior air (clear wall interior)
      dim.runCommandAsync(`fill ${ax-h+1} ${ay} ${az-h+1} ${ax+h-1} ${ay+4} ${az+h-1} air`);

      // Spectator stands (3-wide raised platform on two sides, 2 blocks high)
      // North stands
      dim.runCommandAsync(`fill ${ax-h+1} ${ay} ${az-h+1} ${ax+h-1} ${ay} ${az-h+3} polished_deepslate`);
      dim.runCommandAsync(`fill ${ax-h+1} ${ay+1} ${az-h+2} ${ax+h-1} ${ay+1} ${az-h+3} polished_deepslate`);
      // South stands
      dim.runCommandAsync(`fill ${ax-h+1} ${ay} ${az+h-3} ${ax+h-1} ${ay} ${az+h-1} polished_deepslate`);
      dim.runCommandAsync(`fill ${ax-h+1} ${ay+1} ${az+h-3} ${ax+h-1} ${ay+1} ${az+h-2} polished_deepslate`);

      // Fence rails on top of walls
      dim.runCommandAsync(`fill ${ax-h} ${ay+2} ${az-h} ${ax+h} ${ay+2} ${az-h} dark_oak_fence`);
      dim.runCommandAsync(`fill ${ax-h} ${ay+2} ${az+h} ${ax+h} ${ay+2} ${az+h} dark_oak_fence`);
      dim.runCommandAsync(`fill ${ax-h} ${ay+2} ${az-h} ${ax-h} ${ay+2} ${az+h} dark_oak_fence`);
      dim.runCommandAsync(`fill ${ax+h} ${ay+2} ${az-h} ${ax+h} ${ay+2} ${az+h} dark_oak_fence`);

      // Soul lanterns on corners (4 corners, on top of fence)
      dim.runCommandAsync(`setblock ${ax-h} ${ay+3} ${az-h} soul_lantern`);
      dim.runCommandAsync(`setblock ${ax+h} ${ay+3} ${az-h} soul_lantern`);
      dim.runCommandAsync(`setblock ${ax-h} ${ay+3} ${az+h} soul_lantern`);
      dim.runCommandAsync(`setblock ${ax+h} ${ay+3} ${az+h} soul_lantern`);

      // Mid-wall lanterns
      dim.runCommandAsync(`setblock ${ax} ${ay+3} ${az-h} soul_lantern`);
      dim.runCommandAsync(`setblock ${ax} ${ay+3} ${az+h} soul_lantern`);
      dim.runCommandAsync(`setblock ${ax-h} ${ay+3} ${az} soul_lantern`);
      dim.runCommandAsync(`setblock ${ax+h} ${ay+3} ${az} soul_lantern`);

    } catch {}
  }

  // ─── SPECTATOR MODE ─────────────────────────────────────────

  /** Allow a non-dueling player to spectate */
  joinSpectator(player) {
    if (!this.activeDuel) { player.sendMessage("§c§l✗ §r§7No duel in progress."); return; }
    if (this.isInDuel(player)) { player.sendMessage("§c§l✗ §r§7You are in this duel!"); return; }

    // Save return position
    const s = StorageManager.forPlayer(player);
    s.set("duel_spectator_return", JSON.stringify(player.location));

    // Add to spectator list
    this.activeDuel.spectators.push(player.name);

    if (this.activeDuel.mode === MODE.ARENA) {
      // Teleport to spectator stands
      const sl = this.activeDuel.startLoc;
      const ax = Math.floor(sl.x);
      const ay = Math.floor(sl.y) + ARENA_HEIGHT_OFFSET;
      const az = Math.floor(sl.z);
      player.teleport({ x: ax, y: ay + 2, z: az - ARENA_HALF_SIZE + 2 });
    }

    // Set gamemode spectator
    try { player.runCommandAsync("gamemode spectator @s"); } catch {}

    player.sendMessage("§7You are now spectating the duel. Use the Duel menu to leave.");
  }

  /** Remove spectator and return them */
  leaveSpectator(player) {
    const s = StorageManager.forPlayer(player);
    const returnStr = s.get("duel_spectator_return");

    // Restore gamemode
    try { player.runCommandAsync("gamemode survival @s"); } catch {}

    // Return to saved position
    if (returnStr) {
      try {
        const loc = JSON.parse(returnStr);
        player.teleport({ x: loc.x, y: loc.y, z: loc.z });
      } catch {}
    }

    // Remove from spectator list
    if (this.activeDuel) {
      this.activeDuel.spectators = this.activeDuel.spectators.filter(n => n !== player.name);
    }

    player.sendMessage("§7Left spectator mode.");
  }

  // ─── END DUEL ──────────────────────────────────────────────

  endDuel(loser, reason) {
    if (!this.activeDuel) return;

    const winnerName = loser.name === this.activeDuel.challenger
      ? this.activeDuel.target
      : this.activeDuel.challenger;

    const winner = world.getAllPlayers().find(p => p.name === winnerName);
    const mode = this.activeDuel.mode;

    // Announce result
    for (const p of world.getAllPlayers()) {
      p.sendMessage(`§c§l⚔ §r§a${winnerName} §7wins the duel against §c${loser.name}§7!`);
    }

    // Winner rewards
    if (winner) {
      winner.sendMessage("§a§l✦ Victory! §r§7+5 Victorian progress!");
      this.eventBridge.emit("duel_win", winner);
      // Restore winner state
      this.restoreTeamState(winner);
    }

    // Loser: totem save effects then restore
    try {
      loser.runCommandAsync("effect @s clear");
      loser.runCommandAsync("effect @s darkness 7 0 true");
      loser.runCommandAsync("effect @s nausea 7 0 true");
    } catch {}

    // Remove duel tags from both players
    for (const name of [this.activeDuel.challenger, this.activeDuel.target]) {
      const p = world.getAllPlayers().find(pl => pl.name === name);
      if (p) try { p.removeTag("ec.duel_active_tag"); } catch {}
    }

    // Return players to original positions
    this.returnPlayers(mode);

    // Return spectators
    const spectatorList = [...(this.activeDuel.spectators || [])]; // Copy before nulling
    for (const specName of spectatorList) {
      const spec = world.getAllPlayers().find(p => p.name === specName);
      if (spec) this.leaveSpectator(spec);
    }

    this.activeDuel = null;
  }

  returnPlayers(mode) {
    for (const name of [this.activeDuel.challenger, this.activeDuel.target]) {
      const p = world.getAllPlayers().find(pl => pl.name === name);
      if (!p) continue;
      try {
        const returnStr = StorageManager.forPlayer(p).get("duel_return");
        if (returnStr) {
          const loc = JSON.parse(returnStr);
          p.teleport({ x: loc.x, y: loc.y, z: loc.z });
        }
      } catch {}
    }

    // Cleanup arena if arena mode
    if (mode === MODE.ARENA) {
      const sl = this.activeDuel.startLoc;
      const ax = Math.floor(sl.x);
      const ay = Math.floor(sl.y) + ARENA_HEIGHT_OFFSET;
      const az = Math.floor(sl.z);
      const h = ARENA_HALF_SIZE;
      try {
        const dim = world.getDimension("overworld");
        dim.runCommandAsync(`fill ${ax-h} ${ay-1} ${az-h} ${ax+h} ${ay+5} ${az+h} air`);
      } catch {}
    }
  }

  // ─── GUI ──────────────────────────────────────────────────

  openDuelMenu(player) {
    const isSpectating = this.activeDuel?.spectators?.includes(player.name);

    const form = new ActionFormData()
      .title("§c⚔ Duel")
      .body(this.activeDuel
        ? `§7Active duel: §f${this.activeDuel.challenger} §7vs §f${this.activeDuel.target}`
        : "§7No active duel.");

    const actions = [];

    if (this.pendingInvite && this.pendingInvite.target === player.name) {
      form.button(`§aAccept Challenge\n§7From: ${this.pendingInvite.challenger}`);
      actions.push("accept");
    }
    if (!this.activeDuel) {
      form.button("§eChallenge Player\n§7Start a duel");
      actions.push("challenge");
    }
    if (this.activeDuel && !this.isInDuel(player) && !isSpectating) {
      form.button("§bSpectate\n§7Watch the duel");
      actions.push("spectate");
    }
    if (isSpectating) {
      form.button("§7Leave Spectator\n§7Return to your position");
      actions.push("leave_spectate");
    }
    form.button("§7Close");
    actions.push("close");

    form.show(player).then(response => {
      if (response.canceled) return;
      const action = actions[response.selection];
      switch (action) {
        case "accept": this.acceptChallenge(player); break;
        case "challenge": this.openChallengeMenu(player); break;
        case "spectate": this.joinSpectator(player); break;
        case "leave_spectate": this.leaveSpectator(player); break;
      }
    });
  }

  // ─── TICK (called every 1 second) ─────────────────────────

  tick(players) {
    if (!this.activeDuel) return;

    // Check both players still online
    const c = players.find(p => p.name === this.activeDuel.challenger);
    const t = players.find(p => p.name === this.activeDuel.target);

    if (!c && !t) {
      // Both disconnected — clean up arena, return spectators
      for (const specName of (this.activeDuel.spectators || [])) {
        const spec = players.find(p => p.name === specName);
        if (spec) this.leaveSpectator(spec);
      }
      if (this.activeDuel.mode === MODE.ARENA) {
        const sl = this.activeDuel.startLoc;
        const ax = Math.floor(sl.x);
        const ay = Math.floor(sl.y) + ARENA_HEIGHT_OFFSET;
        const az = Math.floor(sl.z);
        try {
          world.getDimension("overworld").runCommandAsync(
            `fill ${ax-ARENA_HALF_SIZE} ${ay-1} ${az-ARENA_HALF_SIZE} ${ax+ARENA_HALF_SIZE} ${ay+5} ${az+ARENA_HALF_SIZE} air`
          );
        } catch {}
      }
      this.activeDuel = null;
      return;
    }
    if (!c && t) { this.endDuel(t, "disconnect"); return; }
    if (c && !t) { this.endDuel(c, "disconnect"); return; }

    // Open world boundary check
    if (this.activeDuel.mode === MODE.OPEN_WORLD) {
      for (const p of [c, t]) {
        const dist = Math.sqrt(
          (p.location.x - this.activeDuel.startLoc.x) ** 2 +
          (p.location.z - this.activeDuel.startLoc.z) ** 2
        );
        if (dist > BOUNDARY_RANGE) {
          this.activeDuel.warnings[p.name]++;
          p.sendMessage(`§c§l⚠ §r§7Out of bounds! (${this.activeDuel.warnings[p.name]}/${BOUNDARY_WARNINGS})`);
          if (this.activeDuel.warnings[p.name] >= BOUNDARY_WARNINGS) {
            this.endDuel(p, "boundary");
            return;
          }
        }
      }
    }

    // Expire pending invites
    if (this.pendingInvite && system.currentTick > this.pendingInvite.expireTick) {
      this.pendingInvite = null;
    }
  }
}
