import { world } from "@minecraft/server";

export class WorldStorage {
  constructor(prefix = "fc") { this.prefix = prefix; }
  key(name) { return `${this.prefix}:${name}`; }
  get(name) { return world.getDynamicProperty(this.key(name)); }
  set(name, value) { world.setDynamicProperty(this.key(name), value); }
  remove(name) { world.setDynamicProperty(this.key(name), undefined); }
  getNumber(name, fallback = 0) { const v = this.get(name); return typeof v === "number" ? v : fallback; }
  setNumber(name, v) { this.set(name, v); }
  getString(name, fallback = "") { const v = this.get(name); return typeof v === "string" ? v : fallback; }
  getBool(name, fallback = false) { const v = this.get(name); return typeof v === "boolean" ? v : fallback; }
  setBool(name, v) { this.set(name, !!v); }
  increment(name, amount = 1) { this.set(name, this.getNumber(name, 0) + amount); }
}

export class EntityStorage {
  constructor(entity, prefix = "fc") { this.entity = entity; this.prefix = prefix; }
  key(name) { return `${this.prefix}:${name}`; }
  get(name) { try { return this.entity.getDynamicProperty(this.key(name)); } catch { return undefined; } }
  set(name, value) { try { this.entity.setDynamicProperty(this.key(name), value); } catch {} }
  remove(name) { try { this.entity.setDynamicProperty(this.key(name), undefined); } catch {} }
  getNumber(name, fallback = 0) { const v = this.get(name); return typeof v === "number" ? v : fallback; }
  setNumber(name, v) { this.set(name, v); }
  getString(name, fallback = "") { const v = this.get(name); return typeof v === "string" ? v : fallback; }
  getBool(name, fallback = false) { const v = this.get(name); return typeof v === "boolean" ? v : fallback; }
  setBool(name, v) { this.set(name, !!v); }
  increment(name, amount = 1) { this.set(name, this.getNumber(name, 0) + amount); }
}

export class StorageManager {
  // Cached instances — avoids creating new objects every tick
  static _worldCache = null;
  static _playerCache = new Map();
  static _entityCache = new Map();

  static world(prefix = "fc") {
    if (!StorageManager._worldCache || StorageManager._worldCache.prefix !== prefix) {
      StorageManager._worldCache = new WorldStorage(prefix);
    }
    return StorageManager._worldCache;
  }

  static forPlayer(player) {
    const id = player.id;
    let cached = StorageManager._playerCache.get(id);
    if (cached && cached.entity === player) return cached;
    cached = new EntityStorage(player, "fc");
    StorageManager._playerCache.set(id, cached);
    return cached;
  }

  static forEntity(entity) {
    const id = entity.id;
    let cached = StorageManager._entityCache.get(id);
    if (cached && cached.entity === entity) return cached;
    cached = new EntityStorage(entity, "fc");
    StorageManager._entityCache.set(id, cached);
    return cached;
  }

  // Call periodically (every 1200 ticks) to evict stale entries
  static cleanup() {
    // Player cache: remove entries for disconnected players
    for (const [id, storage] of StorageManager._playerCache) {
      try {
        if (!storage.entity?.isValid) StorageManager._playerCache.delete(id);
      } catch { StorageManager._playerCache.delete(id); }
    }
    // Entity cache: remove entries for dead/unloaded entities
    for (const [id, storage] of StorageManager._entityCache) {
      try {
        if (!storage.entity?.isValid) StorageManager._entityCache.delete(id);
      } catch { StorageManager._entityCache.delete(id); }
    }
  }
}
