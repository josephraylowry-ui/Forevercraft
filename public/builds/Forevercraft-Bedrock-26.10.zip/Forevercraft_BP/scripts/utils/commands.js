import { world } from "@minecraft/server";

const overworld = world.getDimension("overworld");
const nether = world.getDimension("nether");
const theEnd = world.getDimension("the_end");

export function getDimension(name) {
  if (name === "nether" || name === "minecraft:nether" || name === "the_nether") return nether;
  if (name === "the_end" || name === "minecraft:the_end") return theEnd;
  return overworld;
}

export async function runCommand(command) { await overworld.runCommandAsync(command); }
export async function runCommandAs(player, command) { await player.runCommandAsync(command); }

export async function giveEffect(player, effect, duration = 10, amplifier = 0, hideParticles = true) {
  await player.runCommandAsync(`effect @s ${effect} ${duration} ${amplifier} ${hideParticles}`);
}

export async function playSound(player, sound, volume = 1, pitch = 1) {
  await player.runCommandAsync(`playsound ${sound} @s ~ ~ ~ ${volume} ${pitch}`);
}

export function showTitle(player, title, subtitle, fadeIn = 10, stay = 70, fadeOut = 20) {
  player.onScreenDisplay.setTitle(title, { subtitle, fadeInDuration: fadeIn, stayDuration: stay, fadeOutDuration: fadeOut });
}

export function showActionBar(player, text) {
  player.onScreenDisplay.setActionBar(text);
}

export function teleportPlayer(player, x, y, z, dimension) {
  player.teleport({ x, y, z }, { dimension: dimension ?? player.dimension });
}
