/**
 * Artifact Descriptions — Ability info, stats, lore for the Codex browser.
 * Maps artifact ID → description data.
 * Ported from Java codex/abilities/ tellraw files.
 *
 * Format: { abilities: [{name, desc}], passive: string, set: string, lore: string }
 * Artifacts without entries use auto-generated descriptions from baseItem.
 */

export const ARTIFACT_DESCRIPTIONS = {
  // ══════════════════════════════════════
  // MYTHICAL ACCESSORIES
  // ══════════════════════════════════════
  "forevercraft:beacon_of_ancients": {
    type: "Mythical Accessory",
    abilities: [{ name: "Ancient Beacon", desc: "Activated once per day. Fully heals all players within 32 blocks and grants Regeneration IV for 30s." }],
    passive: "+2.0 Dream Rate while held",
    set: "Mythical Accessories",
    lore: "A relic from the first age, pulsing with the prayers of forgotten civilizations."
  },
  "forevercraft:claudes_gift": {
    type: "Mythical Accessory",
    abilities: [{ name: "Gift of Insight", desc: "Right-click to reveal all nearby hidden treasures and ores within 16 blocks for 10s." }],
    passive: "+1.5 Dream Rate, +10% XP gain",
    lore: "A mysterious gift left behind by an intelligence beyond comprehension."
  },
  "forevercraft:codex_of_everything": {
    type: "Mythical Accessory",
    abilities: [{ name: "Omniscience", desc: "When held, all mobs within 24 blocks gain Glowing. Right-click to identify any artifact's stats." }],
    passive: "+1.0 Dream Rate",
    lore: "Contains every word ever written and every thought yet to be had."
  },
  "forevercraft:ender_dragon_scale": {
    type: "Mythical Accessory",
    abilities: [{ name: "Dragon's Might", desc: "Grants Fire Resistance and +20% melee damage. Dragon breath attacks heal you instead." }],
    passive: "Permanent Fire Resistance",
    set: "Ender Dragon Set",
    lore: "A scale shed by the dragon herself, still warm after millennia."
  },
  "forevercraft:heart_of_the_void": {
    type: "Mythical Accessory",
    abilities: [{ name: "Void Heart", desc: "When health drops below 3 hearts, teleports you to a random safe location within 16 blocks and grants Resistance III for 5s. 90s cooldown." }],
    passive: "+1.0 Dream Rate",
    lore: "It beats with the rhythm of the End itself."
  },
  "forevercraft:netherite_nexus": {
    type: "Mythical Accessory",
    abilities: [{ name: "Nexus Link", desc: "Right-click to create a return point. Right-click again within 60s to teleport back." }],
    passive: "+15% movement speed in the Nether",
    lore: "Forged at the nexus where all Nether fortresses converge in the dream realm."
  },
  "forevercraft:prism_of_light": {
    type: "Mythical Accessory",
    abilities: [{ name: "Prismatic Beam", desc: "Right-click to fire a beam that damages all mobs in a 20-block line for 12 damage. 15s cooldown." }],
    passive: "+1.0 Dream Rate, Night Vision while held",
    lore: "Refracts not light, but possibility itself."
  },
  "forevercraft:redstone_heart": {
    type: "Mythical Accessory",
    abilities: [{ name: "Overclock", desc: "Right-click to gain Haste III and Speed II for 20s. Mining XP doubled during effect. 45s cooldown." }],
    passive: "+25% mining speed",
    lore: "Powered by an infinite redstone signal from a dimension that runs on logic alone."
  },
  "forevercraft:sculk_singularity": {
    type: "Mythical Accessory",
    abilities: [{ name: "Sculk Absorption", desc: "Kills within 8 blocks restore 2 hearts and grant +0.1 temporary Dream Rate (stacks to +1.0, decays over 60s)." }],
    passive: "Vibration immunity (prevents Warden detection)",
    lore: "A fragment of the sculk network's consciousness, forever hungry."
  },
  "forevercraft:temporal_hourglass": {
    type: "Mythical Accessory",
    abilities: [{ name: "Time Dilation", desc: "Right-click to slow all hostile mobs within 12 blocks (Slowness IV) for 8s while you gain Speed III. 60s cooldown." }],
    passive: "+1.0 Dream Rate",
    lore: "The sand flows upward. Time itself has forgotten which way to fall."
  },
  "forevercraft:wither_rose_crown": {
    type: "Mythical Accessory",
    abilities: [{ name: "Death's Crown", desc: "Kills grant Wither Rose stacks (max 10). At 10 stacks, release a Wither Nova dealing 20 damage in 6 blocks." }],
    passive: "Wither immunity, +10% damage to undead",
    set: "Wither Set",
    lore: "Worn by the sovereign of decay, who ruled not by conquest but by inevitability."
  },
  "forevercraft:dream_aegis": {
    type: "Mythical Accessory",
    abilities: [{ name: "Dream Shield", desc: "When taking fatal damage, instead survive at 1 HP with 5s of invulnerability and Absorption V. Once per 10 minutes." }],
    passive: "+2.0 Dream Rate",
    lore: "In the space between waking and sleeping, nothing can truly die."
  },
  "forevercraft:endless_ambrosia": {
    type: "Mythical Accessory",
    abilities: [{ name: "Divine Sustenance", desc: "Passively regenerates hunger. Right-click to fully restore hunger and grant Saturation III for 30s. 2 minute cooldown." }],
    passive: "Prevents hunger drain",
    lore: "Food of the gods, distilled into a single golden drop that never runs dry."
  },
  "forevercraft:tears_of_world_tree": {
    type: "Mythical Accessory",
    abilities: [{ name: "World Tree's Blessing", desc: "Right-click near crops to instantly grow all crops in 8 blocks. In combat, heals 4 HP per second for 10s. 45s cooldown." }],
    passive: "+1.0 Dream Rate, crops grow 50% faster nearby",
    lore: "Each tear contains the memory of a forest that once spanned an entire world."
  },

  // ══════════════════════════════════════
  // MYTHICAL WEAPONS (sample)
  // ══════════════════════════════════════
  "forevercraft:dragonmaster_sword": {
    type: "Mythical Weapon (Knight)",
    abilities: [
      { name: "Dragon Cleave", desc: "Charged attack deals 3x damage in a wide arc, hitting all enemies in front." },
      { name: "Dragon's Wrath", desc: "Every 5th hit triggers a fire explosion dealing 8 AoE damage." }
    ],
    passive: "+15% damage, Fire Aspect II",
    set: "Dragonmaster Set (4pc: Dragon Form — fly for 10s)",
    lore: "Forged in dragonfire by a knight who tamed the beast within."
  },
  "forevercraft:command_block_sword": {
    type: "Mythical Weapon (Knight)",
    abilities: [
      { name: "Command Strike", desc: "Kills grant Command charges (max 5). Shift-click to release all charges as homing energy bolts." },
      { name: "Admin Override", desc: "When below 20% HP, gain Speed III + Strength II for 8s. 2 minute cooldown." }
    ],
    passive: "+12% damage, Looting I",
    set: "Command Block Set",
    lore: "The blade that rewrites reality with every swing."
  },
  "forevercraft:zantetsuken": {
    type: "Mythical Weapon (Rogue)",
    abilities: [
      { name: "Iaido", desc: "Instant slash in a 5-block line. Deals 25 damage to the first target hit. Must be sheathed (not swinging) for 3s first." },
      { name: "Phantom Cut", desc: "Teleport behind target and strike for 2x damage. 8s cooldown." }
    ],
    passive: "+30% attack speed, +20% crit chance",
    lore: "It cuts so fast that the wound appears before the blade moves."
  },
  "forevercraft:master_bolt": {
    type: "Mythical Weapon (Javelin)",
    abilities: [
      { name: "Lightning Bolt", desc: "Throw to summon 3 lightning strikes at the impact point. 12s cooldown." },
      { name: "Static Field", desc: "Nearby hostiles take continuous shock damage (2/s) in rain or thunderstorms." }
    ],
    passive: "Channeling, Loyalty III",
    lore: "The weapon of the sky itself, lent to mortals in times of great need."
  },
  "forevercraft:awper_hand": {
    type: "Mythical Weapon (Hunter)",
    abilities: [
      { name: "Void Rift", desc: "On precision hit, creates a gravity well. Enemies levitate for 4s, then a Wither burst collapses dealing massive damage." },
      { name: "Quickscope", desc: "Instant charge after a kill for 3s." }
    ],
    passive: "+50% projectile damage, Piercing II",
    lore: "One shot. One rift. One less dimension to worry about."
  },
  "forevercraft:gaster_blaster": {
    type: "Mythical Weapon (Archer)",
    abilities: [
      { name: "Blaster Beam", desc: "Fully charged shots fire a penetrating beam that damages all entities in a 15-block line." },
      { name: "Bone Zone", desc: "Place 8 bone walls around target for 5s, trapping them. 20s cooldown." }
    ],
    passive: "Infinity, Power III",
    lore: "A weapon from the void between voids, powered by determination."
  },
  "forevercraft:ninja_trident": {
    type: "Mythical Weapon (Javelin)",
    abilities: [
      { name: "Shadow Clone", desc: "Throw to create 3 shadow clones at impact. Clones attack nearby hostiles for 5s." },
      { name: "Shroud", desc: "Grants invisibility for 5s on throw return." }
    ],
    passive: "Loyalty III, Riptide during rain",
    set: "Titan's Shroud Set",
    lore: "The weapon of a shinobi who walked between dimensions."
  },
  "forevercraft:red_dragon_wings": {
    type: "Mythical Armor (Elytra)",
    abilities: [
      { name: "Dragon Flight", desc: "Elytra with enhanced glide speed (+30%). Firework boost lasts 2x longer." },
      { name: "Dive Bomb", desc: "While gliding at steep angle, impact creates fire explosion (8 block radius, 15 damage)." }
    ],
    passive: "Permanent Slow Falling while sneaking, Fire Resistance",
    set: "Red Dragon Set",
    lore: "Wings of the ancient red dragon, still smoldering with primordial flame."
  },
};

/**
 * Get description for an artifact. Returns default if not found.
 */
export function getArtifactDescription(artifactId) {
  return ARTIFACT_DESCRIPTIONS[artifactId] || null;
}

/**
 * Format artifact description for Bedrock form display.
 */
export function formatDescription(artifact, desc) {
  const tierColors = {
    common: "§f", uncommon: "§9", rare: "§b",
    ornate: "§5", exquisite: "§d", mythical: "§6"
  };
  const color = tierColors[artifact.tier] || "§f";
  let text = "";

  text += `${color}§l${artifact.name}§r\n`;
  if (desc.type) text += `§7${desc.type}\n`;
  text += `${color}══════════════════§r\n\n`;

  if (desc.abilities) {
    for (const ab of desc.abilities) {
      text += `§f◆ ${ab.name}: §7${ab.desc}\n\n`;
    }
  }

  if (desc.passive) text += `§dPassive: §7${desc.passive}\n\n`;
  if (desc.set) text += `§6Set: §7${desc.set}\n\n`;
  if (desc.lore) text += `§8§o"${desc.lore}"§r\n`;

  text += `\n${color}══════════════════§r`;
  return text;
}
