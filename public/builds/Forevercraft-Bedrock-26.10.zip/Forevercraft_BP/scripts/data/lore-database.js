/**
 * Lore Database — Collection of 893 lore pieces organized by category.
 * Data file loaded by LoreSystem module.
 * Players discover lore pieces through exploration, combat, and interaction.
 */

// Lore categories with piece counts
export const LORE_CATEGORIES = [
  { id: "world", name: "World Lore", icon: "🌍", color: "§a", count: 120 },
  { id: "artifacts", name: "Artifact Lore", icon: "⚔", color: "§e", count: 150 },
  { id: "creatures", name: "Creature Lore", icon: "🐾", color: "§b", count: 100 },
  { id: "history", name: "Ancient History", icon: "📜", color: "§6", count: 130 },
  { id: "biomes", name: "Biome Secrets", icon: "🌲", color: "§2", count: 80 },
  { id: "dreams", name: "Dreaming Lore", icon: "🌙", color: "§d", count: 90 },
  { id: "people", name: "Characters & NPCs", icon: "👤", color: "§f", count: 73 },
  { id: "recipes", name: "Lost Recipes", icon: "🍳", color: "§c", count: 50 },
  { id: "magic", name: "Arcane Knowledge", icon: "✦", color: "§5", count: 60 },
  { id: "secrets", name: "Hidden Secrets", icon: "🔮", color: "§8", count: 40 },
];

// Sample lore entries (first few per category — full database would be loaded from file)
export const LORE_ENTRIES = [
  // World Lore
  { id: "w001", cat: "world", title: "The First Dawn", text: "Before time had a name, the world was born from a single thought in the Dreaming Realm." },
  { id: "w002", cat: "world", title: "The Seasons' Origin", text: "Four ancient spirits agreed to share the year, each painting the world in their colors." },
  { id: "w003", cat: "world", title: "The Guidestone Network", text: "The guidestones were placed by travelers long forgotten. Their magic still echoes." },
  { id: "w004", cat: "world", title: "Moon Cycles", text: "The eight phases of the moon control more than tides. They influence the strength of dreams." },
  { id: "w005", cat: "world", title: "The Patron System", text: "Some creatures carry ancient essence. Defeating them releases this power as artifacts." },

  // Artifact Lore
  { id: "a001", cat: "artifacts", title: "Forging Methods", text: "The finest artifacts are not made — they are discovered, already perfect." },
  { id: "a002", cat: "artifacts", title: "Tier Hierarchy", text: "Common, Uncommon, Rare, Ornate, Exquisite, Mythical — each tier resonates differently." },
  { id: "a003", cat: "artifacts", title: "Set Bonuses", text: "Wearing matching artifact armor creates resonance. Four pieces unlock devastating power." },
  { id: "a004", cat: "artifacts", title: "The Scarlet Set", text: "Forged in blood magic, the Scarlet Set heals its wearer with every strike." },
  { id: "a005", cat: "artifacts", title: "Excalibur", text: "The legendary blade lies dormant, waiting for one worthy enough to awaken it." },

  // Creature Lore
  { id: "c001", cat: "creatures", title: "Patron Mobs", text: "Patron creatures carry fragments of ancient power. The stronger the patron, the rarer the prize." },
  { id: "c002", cat: "creatures", title: "Night Terrors", text: "Born from excessive dreaming, Night Terrors hunt those with high Dream Rates on moonless nights." },
  { id: "c003", cat: "creatures", title: "World Bosses", text: "Five ancient guardians protect the world's deepest secrets. Each requires a team to defeat." },
  { id: "c004", cat: "creatures", title: "Companion Spirits", text: "Companions aren't ordinary animals. They're echoes of ancient spirits bound by friendship." },
  { id: "c005", cat: "creatures", title: "The Forest Guardian", text: "Deep in the oldest forests, a guardian of immense power watches silently." },

  // Ancient History
  { id: "h001", cat: "history", title: "The Age of Dreams", text: "In the beginning, the Dreaming Realm and the waking world were one." },
  { id: "h002", cat: "history", title: "The Separation", text: "A great catastrophe split the worlds apart. Only echoes remain." },
  { id: "h003", cat: "history", title: "The First Blacksmith", text: "The first to forge an artifact from dream-stuff changed the world forever." },
  { id: "h004", cat: "history", title: "The Watcher", text: "An entity older than the world itself observes from beyond the void." },
  { id: "h005", cat: "history", title: "The Lost Kingdom", text: "Once a great civilization thrived here. Only their artifacts remain." },

  // Biome Secrets
  { id: "b001", cat: "biomes", title: "Desert Whispers", text: "The desert sands shift to reveal ancient ruins when the wind blows just right." },
  { id: "b002", cat: "biomes", title: "Deep Ocean Depths", text: "Beneath the waves, monuments to forgotten gods still stand." },
  { id: "b003", cat: "biomes", title: "Frozen Peaks", text: "The highest mountains were once the pillars holding up the sky." },
  { id: "b004", cat: "biomes", title: "Nether Origins", text: "The Nether is a dream that went wrong. Its fire is the fever of a sleeping world." },
  { id: "b005", cat: "biomes", title: "The Deep Dark", text: "The Deep Dark is where the world dreams its nightmares." },

  // Dreaming Lore
  { id: "d001", cat: "dreams", title: "Dream Rate", text: "Dream Rate measures your connection to the Dreaming Realm. Higher rates unlock greater power." },
  { id: "d002", cat: "dreams", title: "The Dreaming Realm", text: "A parallel dimension where thought becomes reality. Only the brave dare enter." },
  { id: "d003", cat: "dreams", title: "Dream Milestones", text: "At certain Dream Rate thresholds, your perception of the world changes permanently." },
  { id: "d004", cat: "dreams", title: "Lucid Dreaming", text: "Masters of the dream can reshape reality itself, if only briefly." },
  { id: "d005", cat: "dreams", title: "Dream Surge", text: "During a Dream Surge event, the boundary between worlds thins. Treasures manifest." },

  // Characters & NPCs
  { id: "p001", cat: "people", title: "The Wise Wanderer", text: "A mysterious figure who appears to offer guidance. No one knows where they come from." },
  { id: "p002", cat: "people", title: "The Blacksmith", text: "Every village has a blacksmith, but only the best understand artifact forging." },
  { id: "p003", cat: "people", title: "The Expeditionist", text: "Explorers who map the unmappable. Their compasses point to impossible places." },
  { id: "p004", cat: "people", title: "The Dream Walker", text: "One who has mastered the art of traveling between worlds through dreams." },
  { id: "p005", cat: "people", title: "The Bounty Master", text: "Posts bounties for the most dangerous patron mobs. Fair pay for dangerous work." },

  // Lost Recipes
  { id: "r001", cat: "recipes", title: "Essence Cooking", text: "Mob essences can be combined with food to create meals of extraordinary power." },
  { id: "r002", cat: "recipes", title: "Campfire Mastery", text: "The campfire is more than heat. With the right ingredients, it becomes an altar." },
  { id: "r003", cat: "recipes", title: "Dream Tea", text: "A brew that temporarily doubles Dream Rate gain. The recipe is nearly forgotten." },
  { id: "r004", cat: "recipes", title: "Golden Apple Variants", text: "The ancient recipes for golden apples have been modified over millennia." },
  { id: "r005", cat: "recipes", title: "Restoration Salve", text: "A healer's poultice that cures most ailments. Simple to make, hard to master." },

  // Arcane Knowledge
  { id: "m001", cat: "magic", title: "Trim Enchantments", text: "Armor trims aren't just decoration. Each material carries ancient power." },
  { id: "m002", cat: "magic", title: "Rune Magic", text: "Six types of runes exist, each granting different magical effects." },
  { id: "m003", cat: "magic", title: "Set Resonance", text: "When four pieces of matching armor align, their combined magic transcends." },
  { id: "m004", cat: "magic", title: "Weapon Awakening", text: "Every artifact weapon can be 'awakened' to unlock its true weapon class abilities." },
  { id: "m005", cat: "magic", title: "Patina Magic", text: "Time itself enchants artifacts. The longer worn, the more powerful they become." },

  // Hidden Secrets
  { id: "s001", cat: "secrets", title: "The Hidden Coordinates", text: "At x=100000, z=0, the boundary between worlds is thinnest." },
  { id: "s002", cat: "secrets", title: "Blood Moon Secret", text: "During a Blood Moon, artifact drop rates double. The world bleeds treasure." },
  { id: "s003", cat: "secrets", title: "Claude's Gift", text: "A companion named Claude holds a secret. Look for it in the deepest caves." },
  { id: "s004", cat: "secrets", title: "The Final Quest", text: "Complete all 74 quests, and the 75th reveals itself." },
  { id: "s005", cat: "secrets", title: "Easter Egg", text: "The developers left a message in the code. It reads: 'Dream big.'" },
];

// Total lore count for progress tracking
export const TOTAL_LORE = 893;
